module.exports = Object.freeze({
  JWT_PRIVATE_KEY: "bdjwt35796101",
});
