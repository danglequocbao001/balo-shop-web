// const db = require("../models")
// const CTDonDatHang = db.CTDonDatHang

// exports.create = (req, res) => {
//     CTDonDatHang.create
// }