const db = require("../models");
const LoaiMatHang = db.LoaiMatHang;

exports.findAll = (req, res) => {
  LoaiMatHang.findAll()
    .then((data) => {
      res.status(200).send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message,
      });
    });
};

exports.create = (req, res) => {
  LoaiMatHang.create(req.body)
    .then((data) => {
      res.status(200).send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message,
      });
    });
};

exports.update = (req, res) => {
  LoaiMatHang.update(req.body, { where: { ma_loai_mh: req.body.ma_loai_mh } })
    .then((data) => {
      res.status(200).send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message,
      });
    });
};
