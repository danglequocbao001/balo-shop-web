const TEXT_CONSTANTS = {
  DANG_XU_LY: "Đang xử lý",
  THANH_CONG: "Thành công",
  THAT_BAI: "Thất bại",
  LOI: "Lỗi",

  DANG_NHAP_THANH_CONG: "Đăng nhập thành công!",
  DANG_KY_THANH_CONG: "Đăng ký thành công!",

  KHONG_BO_TRONG: "Không được bỏ trống",
};
export default TEXT_CONSTANTS;
