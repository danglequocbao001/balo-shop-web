import HandleCart from "./handleCart";
import { combineReducers } from "redux";

const rootReducers=combineReducers({
    HandleCart
})
export default rootReducers;