export const WARDS = [
  {
    value: "19483",
    label: "Xã  A Dơi",
    parent_code: "465",
  },
  {
    value: "27460",
    label: "Phường  An Lạc",
    parent_code: "777",
  },
  {
    value: "24667",
    label: "Xã  Đắk Lao",
    parent_code: "663",
  },
  {
    value: "30949",
    label: "Xã  Hòa Thuận",
    parent_code: "906",
  },
  {
    value: "06178",
    label: "Xã  Hoàng Văn Thụ",
    parent_code: "182",
  },
  {
    value: "12949",
    label: "Xã  Mỹ Lộc",
    parent_code: "341",
  },
  {
    value: "18136",
    label: "Thị trấn  Tây Sơn",
    parent_code: "439",
  },
  {
    value: "20482",
    label: "Xã  Tư",
    parent_code: "505",
  },
  {
    value: "26896",
    label: "Phường 01",
    parent_code: "764",
  },
  {
    value: "26944",
    label: "Phường 01",
    parent_code: "765",
  },
  {
    value: "26977",
    label: "Phường 01",
    parent_code: "766",
  },
  {
    value: "27058",
    label: "Phường 01",
    parent_code: "768",
  },
  {
    value: "27160",
    label: "Phường 01",
    parent_code: "770",
  },
  {
    value: "27184",
    label: "Phường 01",
    parent_code: "771",
  },
  {
    value: "27247",
    label: "Phường 01",
    parent_code: "772",
  },
  {
    value: "27298",
    label: "Phường 01",
    parent_code: "773",
  },
  {
    value: "27325",
    label: "Phường 01",
    parent_code: "774",
  },
  {
    value: "27370",
    label: "Phường 01",
    parent_code: "775",
  },
  {
    value: "27394",
    label: "Phường 01",
    parent_code: "776",
  },
  {
    value: "26941",
    label: "Phường 02",
    parent_code: "765",
  },
  {
    value: "26965",
    label: "Phường 02",
    parent_code: "766",
  },
  {
    value: "27061",
    label: "Phường 02",
    parent_code: "768",
  },
  {
    value: "27157",
    label: "Phường 02",
    parent_code: "770",
  },
  {
    value: "27190",
    label: "Phường 02",
    parent_code: "771",
  },
  {
    value: "27250",
    label: "Phường 02",
    parent_code: "772",
  },
  {
    value: "27292",
    label: "Phường 02",
    parent_code: "773",
  },
  {
    value: "27313",
    label: "Phường 02",
    parent_code: "774",
  },
  {
    value: "27367",
    label: "Phường 02",
    parent_code: "775",
  },
  {
    value: "27391",
    label: "Phường 02",
    parent_code: "776",
  },
  {
    value: "26902",
    label: "Phường 03",
    parent_code: "764",
  },
  {
    value: "26947",
    label: "Phường 03",
    parent_code: "765",
  },
  {
    value: "26980",
    label: "Phường 03",
    parent_code: "766",
  },
  {
    value: "27055",
    label: "Phường 03",
    parent_code: "768",
  },
  {
    value: "27154",
    label: "Phường 03",
    parent_code: "770",
  },
  {
    value: "27220",
    label: "Phường 03",
    parent_code: "772",
  },
  {
    value: "27286",
    label: "Phường 03",
    parent_code: "773",
  },
  {
    value: "27307",
    label: "Phường 03",
    parent_code: "774",
  },
  {
    value: "27379",
    label: "Phường 03",
    parent_code: "775",
  },
  {
    value: "27397",
    label: "Phường 03",
    parent_code: "776",
  },
  {
    value: "26893",
    label: "Phường 04",
    parent_code: "764",
  },
  {
    value: "26968",
    label: "Phường 04",
    parent_code: "766",
  },
  {
    value: "27043",
    label: "Phường 04",
    parent_code: "768",
  },
  {
    value: "27148",
    label: "Phường 04",
    parent_code: "770",
  },
  {
    value: "27193",
    label: "Phường 04",
    parent_code: "771",
  },
  {
    value: "27244",
    label: "Phường 04",
    parent_code: "772",
  },
  {
    value: "27283",
    label: "Phường 04",
    parent_code: "773",
  },
  {
    value: "27301",
    label: "Phường 04",
    parent_code: "774",
  },
  {
    value: "27373",
    label: "Phường 04",
    parent_code: "775",
  },
  {
    value: "27409",
    label: "Phường 04",
    parent_code: "776",
  },
  {
    value: "26887",
    label: "Phường 05",
    parent_code: "764",
  },
  {
    value: "26923",
    label: "Phường 05",
    parent_code: "765",
  },
  {
    value: "26989",
    label: "Phường 05",
    parent_code: "766",
  },
  {
    value: "27046",
    label: "Phường 05",
    parent_code: "768",
  },
  {
    value: "27151",
    label: "Phường 05",
    parent_code: "770",
  },
  {
    value: "27199",
    label: "Phường 05",
    parent_code: "771",
  },
  {
    value: "27211",
    label: "Phường 05",
    parent_code: "772",
  },
  {
    value: "27334",
    label: "Phường 05",
    parent_code: "774",
  },
  {
    value: "27361",
    label: "Phường 05",
    parent_code: "775",
  },
  {
    value: "27418",
    label: "Phường 05",
    parent_code: "776",
  },
  {
    value: "26932",
    label: "Phường 06",
    parent_code: "765",
  },
  {
    value: "26995",
    label: "Phường 06",
    parent_code: "766",
  },
  {
    value: "27202",
    label: "Phường 06",
    parent_code: "771",
  },
  {
    value: "27241",
    label: "Phường 06",
    parent_code: "772",
  },
  {
    value: "27265",
    label: "Phường 06",
    parent_code: "773",
  },
  {
    value: "27337",
    label: "Phường 06",
    parent_code: "774",
  },
  {
    value: "27355",
    label: "Phường 06",
    parent_code: "775",
  },
  {
    value: "27424",
    label: "Phường 06",
    parent_code: "776",
  },
  {
    value: "26890",
    label: "Phường 07",
    parent_code: "764",
  },
  {
    value: "26926",
    label: "Phường 07",
    parent_code: "765",
  },
  {
    value: "26986",
    label: "Phường 07",
    parent_code: "766",
  },
  {
    value: "27052",
    label: "Phường 07",
    parent_code: "768",
  },
  {
    value: "27196",
    label: "Phường 07",
    parent_code: "771",
  },
  {
    value: "27238",
    label: "Phường 07",
    parent_code: "772",
  },
  {
    value: "27322",
    label: "Phường 07",
    parent_code: "774",
  },
  {
    value: "27382",
    label: "Phường 07",
    parent_code: "775",
  },
  {
    value: "27433",
    label: "Phường 07",
    parent_code: "776",
  },
  {
    value: "26998",
    label: "Phường 08",
    parent_code: "766",
  },
  {
    value: "27064",
    label: "Phường 08",
    parent_code: "768",
  },
  {
    value: "27187",
    label: "Phường 08",
    parent_code: "771",
  },
  {
    value: "27229",
    label: "Phường 08",
    parent_code: "772",
  },
  {
    value: "27268",
    label: "Phường 08",
    parent_code: "773",
  },
  {
    value: "27316",
    label: "Phường 08",
    parent_code: "774",
  },
  {
    value: "27376",
    label: "Phường 08",
    parent_code: "775",
  },
  {
    value: "27388",
    label: "Phường 08",
    parent_code: "776",
  },
  {
    value: "27001",
    label: "Phường 09",
    parent_code: "766",
  },
  {
    value: "27049",
    label: "Phường 09",
    parent_code: "768",
  },
  {
    value: "27142",
    label: "Phường 09",
    parent_code: "770",
  },
  {
    value: "27181",
    label: "Phường 09",
    parent_code: "771",
  },
  {
    value: "27232",
    label: "Phường 09",
    parent_code: "772",
  },
  {
    value: "27262",
    label: "Phường 09",
    parent_code: "773",
  },
  {
    value: "27304",
    label: "Phường 09",
    parent_code: "774",
  },
  {
    value: "27352",
    label: "Phường 09",
    parent_code: "775",
  },
  {
    value: "27403",
    label: "Phường 09",
    parent_code: "776",
  },
  {
    value: "24823",
    label: "Phường 1",
    parent_code: "673",
  },
  {
    value: "25456",
    label: "Phường 1",
    parent_code: "703",
  },
  {
    value: "26506",
    label: "Phường 1",
    parent_code: "747",
  },
  {
    value: "19357",
    label: "Phường 1",
    parent_code: "462",
  },
  {
    value: "24784",
    label: "Phường 1",
    parent_code: "672",
  },
  {
    value: "27694",
    label: "Phường 1",
    parent_code: "794",
  },
  {
    value: "19333",
    label: "Phường 1",
    parent_code: "461",
  },
  {
    value: "27787",
    label: "Phường 1",
    parent_code: "795",
  },
  {
    value: "22015",
    label: "Phường 1",
    parent_code: "555",
  },
  {
    value: "28261",
    label: "Phường 1",
    parent_code: "815",
  },
  {
    value: "28303",
    label: "Phường 1",
    parent_code: "816",
  },
  {
    value: "28435",
    label: "Phường 1",
    parent_code: "817",
  },
  {
    value: "29239",
    label: "Phường 1",
    parent_code: "842",
  },
  {
    value: "29512",
    label: "Phường 1",
    parent_code: "851",
  },
  {
    value: "29548",
    label: "Phường 1",
    parent_code: "855",
  },
  {
    value: "29866",
    label: "Phường 1",
    parent_code: "866",
  },
  {
    value: "29905",
    label: "Phường 1",
    parent_code: "867",
  },
  {
    value: "31513",
    label: "Phường 1",
    parent_code: "941",
  },
  {
    value: "31732",
    label: "Phường 1",
    parent_code: "948",
  },
  {
    value: "31783",
    label: "Phường 1",
    parent_code: "950",
  },
  {
    value: "31825",
    label: "Phường 1",
    parent_code: "954",
  },
  {
    value: "31942",
    label: "Phường 1",
    parent_code: "959",
  },
  {
    value: "32005",
    label: "Phường 1",
    parent_code: "964",
  },
  {
    value: "24796",
    label: "Phường 10",
    parent_code: "672",
  },
  {
    value: "26536",
    label: "Phường 10",
    parent_code: "747",
  },
  {
    value: "26884",
    label: "Phường 10",
    parent_code: "764",
  },
  {
    value: "26992",
    label: "Phường 10",
    parent_code: "766",
  },
  {
    value: "27070",
    label: "Phường 10",
    parent_code: "768",
  },
  {
    value: "27145",
    label: "Phường 10",
    parent_code: "770",
  },
  {
    value: "27178",
    label: "Phường 10",
    parent_code: "771",
  },
  {
    value: "27223",
    label: "Phường 10",
    parent_code: "772",
  },
  {
    value: "27271",
    label: "Phường 10",
    parent_code: "773",
  },
  {
    value: "27340",
    label: "Phường 10",
    parent_code: "774",
  },
  {
    value: "27385",
    label: "Phường 10",
    parent_code: "775",
  },
  {
    value: "27406",
    label: "Phường 10",
    parent_code: "776",
  },
  {
    value: "28276",
    label: "Phường 10",
    parent_code: "815",
  },
  {
    value: "31525",
    label: "Phường 10",
    parent_code: "941",
  },
  {
    value: "24799",
    label: "Phường 11",
    parent_code: "672",
  },
  {
    value: "26539",
    label: "Phường 11",
    parent_code: "747",
  },
  {
    value: "26899",
    label: "Phường 11",
    parent_code: "764",
  },
  {
    value: "26908",
    label: "Phường 11",
    parent_code: "765",
  },
  {
    value: "26983",
    label: "Phường 11",
    parent_code: "766",
  },
  {
    value: "27073",
    label: "Phường 11",
    parent_code: "768",
  },
  {
    value: "27133",
    label: "Phường 11",
    parent_code: "770",
  },
  {
    value: "27175",
    label: "Phường 11",
    parent_code: "771",
  },
  {
    value: "27217",
    label: "Phường 11",
    parent_code: "772",
  },
  {
    value: "27328",
    label: "Phường 11",
    parent_code: "774",
  },
  {
    value: "27364",
    label: "Phường 11",
    parent_code: "775",
  },
  {
    value: "27400",
    label: "Phường 11",
    parent_code: "776",
  },
  {
    value: "29863",
    label: "Phường 11",
    parent_code: "866",
  },
  {
    value: "26542",
    label: "Phường 12",
    parent_code: "747",
  },
  {
    value: "26881",
    label: "Phường 12",
    parent_code: "764",
  },
  {
    value: "26917",
    label: "Phường 12",
    parent_code: "765",
  },
  {
    value: "26971",
    label: "Phường 12",
    parent_code: "766",
  },
  {
    value: "27130",
    label: "Phường 12",
    parent_code: "770",
  },
  {
    value: "27172",
    label: "Phường 12",
    parent_code: "771",
  },
  {
    value: "27235",
    label: "Phường 12",
    parent_code: "772",
  },
  {
    value: "27310",
    label: "Phường 12",
    parent_code: "774",
  },
  {
    value: "24775",
    label: "Phường 12",
    parent_code: "672",
  },
  {
    value: "27358",
    label: "Phường 12",
    parent_code: "775",
  },
  {
    value: "27415",
    label: "Phường 12",
    parent_code: "776",
  },
  {
    value: "26872",
    label: "Phường 13",
    parent_code: "764",
  },
  {
    value: "26905",
    label: "Phường 13",
    parent_code: "765",
  },
  {
    value: "26974",
    label: "Phường 13",
    parent_code: "766",
  },
  {
    value: "27085",
    label: "Phường 13",
    parent_code: "768",
  },
  {
    value: "27136",
    label: "Phường 13",
    parent_code: "770",
  },
  {
    value: "27166",
    label: "Phường 13",
    parent_code: "771",
  },
  {
    value: "27226",
    label: "Phường 13",
    parent_code: "772",
  },
  {
    value: "27259",
    label: "Phường 13",
    parent_code: "773",
  },
  {
    value: "27343",
    label: "Phường 13",
    parent_code: "774",
  },
  {
    value: "27349",
    label: "Phường 13",
    parent_code: "775",
  },
  {
    value: "27412",
    label: "Phường 13",
    parent_code: "776",
  },
  {
    value: "26882",
    label: "Phường 14",
    parent_code: "764",
  },
  {
    value: "26935",
    label: "Phường 14",
    parent_code: "765",
  },
  {
    value: "27004",
    label: "Phường 14",
    parent_code: "766",
  },
  {
    value: "27127",
    label: "Phường 14",
    parent_code: "770",
  },
  {
    value: "27169",
    label: "Phường 14",
    parent_code: "771",
  },
  {
    value: "27214",
    label: "Phường 14",
    parent_code: "772",
  },
  {
    value: "27280",
    label: "Phường 14",
    parent_code: "773",
  },
  {
    value: "27331",
    label: "Phường 14",
    parent_code: "774",
  },
  {
    value: "27346",
    label: "Phường 14",
    parent_code: "775",
  },
  {
    value: "27421",
    label: "Phường 14",
    parent_code: "776",
  },
  {
    value: "26869",
    label: "Phường 15",
    parent_code: "764",
  },
  {
    value: "26938",
    label: "Phường 15",
    parent_code: "765",
  },
  {
    value: "27007",
    label: "Phường 15",
    parent_code: "766",
  },
  {
    value: "27067",
    label: "Phường 15",
    parent_code: "768",
  },
  {
    value: "27163",
    label: "Phường 15",
    parent_code: "771",
  },
  {
    value: "27208",
    label: "Phường 15",
    parent_code: "772",
  },
  {
    value: "27295",
    label: "Phường 15",
    parent_code: "773",
  },
  {
    value: "27427",
    label: "Phường 15",
    parent_code: "776",
  },
  {
    value: "26878",
    label: "Phường 16",
    parent_code: "764",
  },
  {
    value: "27253",
    label: "Phường 16",
    parent_code: "772",
  },
  {
    value: "27289",
    label: "Phường 16",
    parent_code: "773",
  },
  {
    value: "27430",
    label: "Phường 16",
    parent_code: "776",
  },
  {
    value: "26875",
    label: "Phường 17",
    parent_code: "764",
  },
  {
    value: "26950",
    label: "Phường 17",
    parent_code: "765",
  },
  {
    value: "27076",
    label: "Phường 17",
    parent_code: "768",
  },
  {
    value: "27277",
    label: "Phường 18",
    parent_code: "773",
  },
  {
    value: "26959",
    label: "Phường 19",
    parent_code: "765",
  },
  {
    value: "24820",
    label: "Phường 2",
    parent_code: "673",
  },
  {
    value: "25468",
    label: "Phường 2",
    parent_code: "703",
  },
  {
    value: "26509",
    label: "Phường 2",
    parent_code: "747",
  },
  {
    value: "19360",
    label: "Phường 2",
    parent_code: "462",
  },
  {
    value: "24781",
    label: "Phường 2",
    parent_code: "672",
  },
  {
    value: "27688",
    label: "Phường 2",
    parent_code: "794",
  },
  {
    value: "19342",
    label: "Phường 2",
    parent_code: "461",
  },
  {
    value: "27788",
    label: "Phường 2",
    parent_code: "795",
  },
  {
    value: "22021",
    label: "Phường 2",
    parent_code: "555",
  },
  {
    value: "28264",
    label: "Phường 2",
    parent_code: "815",
  },
  {
    value: "28297",
    label: "Phường 2",
    parent_code: "816",
  },
  {
    value: "28436",
    label: "Phường 2",
    parent_code: "817",
  },
  {
    value: "29245",
    label: "Phường 2",
    parent_code: "842",
  },
  {
    value: "29516",
    label: "Phường 2",
    parent_code: "851",
  },
  {
    value: "29551",
    label: "Phường 2",
    parent_code: "855",
  },
  {
    value: "29869",
    label: "Phường 2",
    parent_code: "866",
  },
  {
    value: "29911",
    label: "Phường 2",
    parent_code: "867",
  },
  {
    value: "31510",
    label: "Phường 2",
    parent_code: "941",
  },
  {
    value: "31735",
    label: "Phường 2",
    parent_code: "948",
  },
  {
    value: "31801",
    label: "Phường 2",
    parent_code: "950",
  },
  {
    value: "31813",
    label: "Phường 2",
    parent_code: "954",
  },
  {
    value: "32011",
    label: "Phường 2",
    parent_code: "964",
  },
  {
    value: "26953",
    label: "Phường 21",
    parent_code: "765",
  },
  {
    value: "26956",
    label: "Phường 22",
    parent_code: "765",
  },
  {
    value: "26929",
    label: "Phường 24",
    parent_code: "765",
  },
  {
    value: "26920",
    label: "Phường 25",
    parent_code: "765",
  },
  {
    value: "26914",
    label: "Phường 26",
    parent_code: "765",
  },
  {
    value: "26911",
    label: "Phường 27",
    parent_code: "765",
  },
  {
    value: "26962",
    label: "Phường 28",
    parent_code: "765",
  },
  {
    value: "24802",
    label: "Phường 3",
    parent_code: "672",
  },
  {
    value: "25459",
    label: "Phường 3",
    parent_code: "703",
  },
  {
    value: "26512",
    label: "Phường 3",
    parent_code: "747",
  },
  {
    value: "19354",
    label: "Phường 3",
    parent_code: "461",
  },
  {
    value: "19361",
    label: "Phường 3",
    parent_code: "462",
  },
  {
    value: "27697",
    label: "Phường 3",
    parent_code: "794",
  },
  {
    value: "27806",
    label: "Phường 3",
    parent_code: "795",
  },
  {
    value: "22027",
    label: "Phường 3",
    parent_code: "555",
  },
  {
    value: "28258",
    label: "Phường 3",
    parent_code: "815",
  },
  {
    value: "28294",
    label: "Phường 3",
    parent_code: "816",
  },
  {
    value: "28437",
    label: "Phường 3",
    parent_code: "817",
  },
  {
    value: "29242",
    label: "Phường 3",
    parent_code: "842",
  },
  {
    value: "29557",
    label: "Phường 3",
    parent_code: "855",
  },
  {
    value: "29875",
    label: "Phường 3",
    parent_code: "866",
  },
  {
    value: "29902",
    label: "Phường 3",
    parent_code: "867",
  },
  {
    value: "31519",
    label: "Phường 3",
    parent_code: "941",
  },
  {
    value: "31747",
    label: "Phường 3",
    parent_code: "948",
  },
  {
    value: "31816",
    label: "Phường 3",
    parent_code: "954",
  },
  {
    value: "24793",
    label: "Phường 4",
    parent_code: "672",
  },
  {
    value: "25462",
    label: "Phường 4",
    parent_code: "703",
  },
  {
    value: "26515",
    label: "Phường 4",
    parent_code: "747",
  },
  {
    value: "27691",
    label: "Phường 4",
    parent_code: "794",
  },
  {
    value: "19345",
    label: "Phường 4",
    parent_code: "461",
  },
  {
    value: "22030",
    label: "Phường 4",
    parent_code: "555",
  },
  {
    value: "28252",
    label: "Phường 4",
    parent_code: "815",
  },
  {
    value: "28300",
    label: "Phường 4",
    parent_code: "816",
  },
  {
    value: "28439",
    label: "Phường 4",
    parent_code: "817",
  },
  {
    value: "28765",
    label: "Phường 4",
    parent_code: "829",
  },
  {
    value: "29236",
    label: "Phường 4",
    parent_code: "842",
  },
  {
    value: "29554",
    label: "Phường 4",
    parent_code: "855",
  },
  {
    value: "29872",
    label: "Phường 4",
    parent_code: "866",
  },
  {
    value: "29908",
    label: "Phường 4",
    parent_code: "867",
  },
  {
    value: "31516",
    label: "Phường 4",
    parent_code: "941",
  },
  {
    value: "32002",
    label: "Phường 4",
    parent_code: "964",
  },
  {
    value: "26518",
    label: "Phường 5",
    parent_code: "747",
  },
  {
    value: "24790",
    label: "Phường 5",
    parent_code: "672",
  },
  {
    value: "27685",
    label: "Phường 5",
    parent_code: "794",
  },
  {
    value: "19348",
    label: "Phường 5",
    parent_code: "461",
  },
  {
    value: "22033",
    label: "Phường 5",
    parent_code: "555",
  },
  {
    value: "28249",
    label: "Phường 5",
    parent_code: "815",
  },
  {
    value: "28306",
    label: "Phường 5",
    parent_code: "816",
  },
  {
    value: "28440",
    label: "Phường 5",
    parent_code: "817",
  },
  {
    value: "28768",
    label: "Phường 5",
    parent_code: "829",
  },
  {
    value: "29248",
    label: "Phường 5",
    parent_code: "842",
  },
  {
    value: "29545",
    label: "Phường 5",
    parent_code: "855",
  },
  {
    value: "31498",
    label: "Phường 5",
    parent_code: "941",
  },
  {
    value: "31819",
    label: "Phường 5",
    parent_code: "954",
  },
  {
    value: "32008",
    label: "Phường 5",
    parent_code: "964",
  },
  {
    value: "26876",
    label: "Phường 6",
    parent_code: "764",
  },
  {
    value: "24787",
    label: "Phường 6",
    parent_code: "672",
  },
  {
    value: "27700",
    label: "Phường 6",
    parent_code: "794",
  },
  {
    value: "22039",
    label: "Phường 6",
    parent_code: "555",
  },
  {
    value: "28270",
    label: "Phường 6",
    parent_code: "815",
  },
  {
    value: "28762",
    label: "Phường 6",
    parent_code: "829",
  },
  {
    value: "29251",
    label: "Phường 6",
    parent_code: "842",
  },
  {
    value: "29878",
    label: "Phường 6",
    parent_code: "866",
  },
  {
    value: "31507",
    label: "Phường 6",
    parent_code: "941",
  },
  {
    value: "32017",
    label: "Phường 6",
    parent_code: "964",
  },
  {
    value: "26524",
    label: "Phường 7",
    parent_code: "747",
  },
  {
    value: "24769",
    label: "Phường 7",
    parent_code: "672",
  },
  {
    value: "27698",
    label: "Phường 7",
    parent_code: "794",
  },
  {
    value: "22036",
    label: "Phường 7",
    parent_code: "555",
  },
  {
    value: "28255",
    label: "Phường 7",
    parent_code: "815",
  },
  {
    value: "28780",
    label: "Phường 7",
    parent_code: "829",
  },
  {
    value: "29254",
    label: "Phường 7",
    parent_code: "842",
  },
  {
    value: "31501",
    label: "Phường 7",
    parent_code: "941",
  },
  {
    value: "31822",
    label: "Phường 7",
    parent_code: "954",
  },
  {
    value: "32020",
    label: "Phường 7",
    parent_code: "964",
  },
  {
    value: "26527",
    label: "Phường 8",
    parent_code: "747",
  },
  {
    value: "26898",
    label: "Phường 8",
    parent_code: "764",
  },
  {
    value: "24772",
    label: "Phường 8",
    parent_code: "672",
  },
  {
    value: "22018",
    label: "Phường 8",
    parent_code: "555",
  },
  {
    value: "28267",
    label: "Phường 8",
    parent_code: "815",
  },
  {
    value: "28759",
    label: "Phường 8",
    parent_code: "829",
  },
  {
    value: "29257",
    label: "Phường 8",
    parent_code: "842",
  },
  {
    value: "29560",
    label: "Phường 8",
    parent_code: "855",
  },
  {
    value: "31504",
    label: "Phường 8",
    parent_code: "941",
  },
  {
    value: "31828",
    label: "Phường 8",
    parent_code: "954",
  },
  {
    value: "32014",
    label: "Phường 8",
    parent_code: "964",
  },
  {
    value: "26530",
    label: "Phường 9",
    parent_code: "747",
  },
  {
    value: "26897",
    label: "Phường 9",
    parent_code: "764",
  },
  {
    value: "24778",
    label: "Phường 9",
    parent_code: "672",
  },
  {
    value: "22024",
    label: "Phường 9",
    parent_code: "555",
  },
  {
    value: "28273",
    label: "Phường 9",
    parent_code: "815",
  },
  {
    value: "29260",
    label: "Phường 9",
    parent_code: "842",
  },
  {
    value: "29542",
    label: "Phường 9",
    parent_code: "855",
  },
  {
    value: "31522",
    label: "Phường 9",
    parent_code: "941",
  },
  {
    value: "31999",
    label: "Phường 9",
    parent_code: "964",
  },
  {
    value: "19591",
    label: "Xã A Bung",
    parent_code: "467",
  },
  {
    value: "23710",
    label: "Xã A Dơk",
    parent_code: "626",
  },
  {
    value: "02692",
    label: "Xã A Lù",
    parent_code: "082",
  },
  {
    value: "20044",
    label: "Thị trấn A Lưới",
    parent_code: "481",
  },
  {
    value: "02686",
    label: "Xã A Mú Sung",
    parent_code: "082",
  },
  {
    value: "19594",
    label: "Xã A Ngo",
    parent_code: "467",
  },
  {
    value: "20068",
    label: "Xã A Ngo",
    parent_code: "481",
  },
  {
    value: "20452",
    label: "Xã A Nông",
    parent_code: "504",
  },
  {
    value: "20095",
    label: "Xã A Roàng",
    parent_code: "481",
  },
  {
    value: "20488",
    label: "Xã A Rooi",
    parent_code: "505",
  },
  {
    value: "20455",
    label: "Xã A Tiêng",
    parent_code: "504",
  },
  {
    value: "20479",
    label: "Xã A Ting",
    parent_code: "505",
  },
  {
    value: "19585",
    label: "Xã A Vao",
    parent_code: "467",
  },
  {
    value: "20461",
    label: "Xã A Vương",
    parent_code: "504",
  },
  {
    value: "20443",
    label: "Xã A Xan",
    parent_code: "504",
  },
  {
    value: "20500",
    label: "Thị Trấn Ái Nghĩa",
    parent_code: "506",
  },
  {
    value: "10660",
    label: "Phường Ái Quốc",
    parent_code: "288",
  },
  {
    value: "06610",
    label: "Xã Ái Quốc",
    parent_code: "188",
  },
  {
    value: "14944",
    label: "Xã Ái Thượng",
    parent_code: "386",
  },
  {
    value: "19624",
    label: "Thị Trấn Ái Tử",
    parent_code: "469",
  },
  {
    value: "23953",
    label: "Xã AL Bá",
    parent_code: "633",
  },
  {
    value: "12526",
    label: "Xã An Ấp",
    parent_code: "338",
  },
  {
    value: "07660",
    label: "Xã An Bá",
    parent_code: "220",
  },
  {
    value: "12523",
    label: "Thị trấn An Bài",
    parent_code: "338",
  },
  {
    value: "11371",
    label: "Phường An Biên",
    parent_code: "305",
  },
  {
    value: "09418",
    label: "Xã An Bình",
    parent_code: "262",
  },
  {
    value: "10630",
    label: "Xã An Bình",
    parent_code: "291",
  },
  {
    value: "05428",
    label: "Xã An Bình",
    parent_code: "159",
  },
  {
    value: "13087",
    label: "Xã An Bình",
    parent_code: "343",
  },
  {
    value: "04390",
    label: "Xã An Bình",
    parent_code: "136",
  },
  {
    value: "25615",
    label: "Xã An Bình",
    parent_code: "708",
  },
  {
    value: "25870",
    label: "Xã An Bình",
    parent_code: "722",
  },
  {
    value: "25960",
    label: "Phường An Bình",
    parent_code: "724",
  },
  {
    value: "26050",
    label: "Phường An Bình",
    parent_code: "731",
  },
  {
    value: "23614",
    label: "Phường An Bình",
    parent_code: "623",
  },
  {
    value: "24308",
    label: "Phường An Bình",
    parent_code: "644",
  },
  {
    value: "29587",
    label: "Xã An Bình",
    parent_code: "857",
  },
  {
    value: "30106",
    label: "Xã An Bình",
    parent_code: "873",
  },
  {
    value: "30692",
    label: "Xã An Bình",
    parent_code: "894",
  },
  {
    value: "30751",
    label: "Phường An Bình",
    parent_code: "899",
  },
  {
    value: "31150",
    label: "Phường An Bình",
    parent_code: "916",
  },
  {
    value: "29989",
    label: "Phường An Bình A",
    parent_code: "868",
  },
  {
    value: "29986",
    label: "Phường An Bình B",
    parent_code: "868",
  },
  {
    value: "29149",
    label: "Xã An Bình Tây",
    parent_code: "836",
  },
  {
    value: "12502",
    label: "Xã An Cầu",
    parent_code: "338",
  },
  {
    value: "22156",
    label: "Xã An Chấn",
    parent_code: "559",
  },
  {
    value: "07615",
    label: "Thị trấn An Châu",
    parent_code: "220",
  },
  {
    value: "12700",
    label: "Xã An Châu",
    parent_code: "340",
  },
  {
    value: "30589",
    label: "Thị trấn An Châu",
    parent_code: "892",
  },
  {
    value: "25600",
    label: "Xã An Cơ",
    parent_code: "708",
  },
  {
    value: "22138",
    label: "Xã An Cư",
    parent_code: "559",
  },
  {
    value: "28390",
    label: "Xã An Cư",
    parent_code: "819",
  },
  {
    value: "30526",
    label: "Xã An Cư",
    parent_code: "890",
  },
  {
    value: "31129",
    label: "Phường An Cư",
    parent_code: "916",
  },
  {
    value: "19801",
    label: "Phường An Cựu",
    parent_code: "474",
  },
  {
    value: "22117",
    label: "Xã An Dân",
    parent_code: "559",
  },
  {
    value: "12571",
    label: "Xã An Dục",
    parent_code: "338",
  },
  {
    value: "18298",
    label: "Xã An Dũng",
    parent_code: "440",
  },
  {
    value: "21616",
    label: "Xã An Dũng",
    parent_code: "542",
  },
  {
    value: "11377",
    label: "Phường An Dương",
    parent_code: "305",
  },
  {
    value: "11581",
    label: "Thị trấn An Dương",
    parent_code: "312",
  },
  {
    value: "07321",
    label: "Xã An Dương",
    parent_code: "216",
  },
  {
    value: "08272",
    label: "Xã An Đạo",
    parent_code: "233",
  },
  {
    value: "25840",
    label: "Xã An Điền",
    parent_code: "721",
  },
  {
    value: "29209",
    label: "Xã An Điền",
    parent_code: "837",
  },
  {
    value: "22129",
    label: "Xã An Định",
    parent_code: "559",
  },
  {
    value: "28957",
    label: "Xã An Định",
    parent_code: "833",
  },
  {
    value: "13552",
    label: "Xã An Đổ",
    parent_code: "352",
  },
  {
    value: "19358",
    label: "Phường An Đôn",
    parent_code: "462",
  },
  {
    value: "19815",
    label: "Phường An Đông",
    parent_code: "474",
  },
  {
    value: "11623",
    label: "Xã An Đồng",
    parent_code: "312",
  },
  {
    value: "12478",
    label: "Xã An Đồng",
    parent_code: "338",
  },
  {
    value: "11173",
    label: "Xã An Đức",
    parent_code: "299",
  },
  {
    value: "29173",
    label: "Xã An Đức",
    parent_code: "836",
  },
  {
    value: "07396",
    label: "Xã An Hà",
    parent_code: "217",
  },
  {
    value: "22888",
    label: "Xã An Hải",
    parent_code: "587",
  },
  {
    value: "20272",
    label: "Phường An Hải Bắc",
    parent_code: "493",
  },
  {
    value: "20281",
    label: "Phường An Hải Đông",
    parent_code: "493",
  },
  {
    value: "20278",
    label: "Phường An Hải Tây",
    parent_code: "493",
  },
  {
    value: "30538",
    label: "Xã An Hảo",
    parent_code: "890",
  },
  {
    value: "12490",
    label: "Xã An Hiệp",
    parent_code: "338",
  },
  {
    value: "22150",
    label: "Xã An Hiệp",
    parent_code: "559",
  },
  {
    value: "28855",
    label: "Xã An Hiệp",
    parent_code: "831",
  },
  {
    value: "29161",
    label: "Xã An Hiệp",
    parent_code: "836",
  },
  {
    value: "30247",
    label: "Xã An Hiệp",
    parent_code: "877",
  },
  {
    value: "31594",
    label: "Xã An Hiệp",
    parent_code: "942",
  },
  {
    value: "11590",
    label: "Xã An Hoà",
    parent_code: "312",
  },
  {
    value: "11854",
    label: "Xã An Hoà",
    parent_code: "316",
  },
  {
    value: "29919",
    label: "Phường An Hoà",
    parent_code: "867",
  },
  {
    value: "08887",
    label: "Xã An Hòa",
    parent_code: "247",
  },
  {
    value: "17206",
    label: "Xã An Hòa",
    parent_code: "421",
  },
  {
    value: "25735",
    label: "Phường An Hòa",
    parent_code: "712",
  },
  {
    value: "26371",
    label: "Phường An Hòa",
    parent_code: "731",
  },
  {
    value: "19803",
    label: "Phường An Hòa",
    parent_code: "474",
  },
  {
    value: "21628",
    label: "Xã An Hòa",
    parent_code: "542",
  },
  {
    value: "30019",
    label: "Xã An Hòa",
    parent_code: "871",
  },
  {
    value: "30592",
    label: "Xã An Hòa",
    parent_code: "892",
  },
  {
    value: "30748",
    label: "Phường An Hòa",
    parent_code: "899",
  },
  {
    value: "31120",
    label: "Phường An Hòa",
    parent_code: "916",
  },
  {
    value: "28849",
    label: "Xã An Hóa",
    parent_code: "831",
  },
  {
    value: "22147",
    label: "Xã An Hòa Hải",
    parent_code: "559",
  },
  {
    value: "29176",
    label: "Xã An Hòa Tây",
    parent_code: "836",
  },
  {
    value: "18163",
    label: "Xã An Hòa Thịnh",
    parent_code: "439",
  },
  {
    value: "28777",
    label: "Phường An Hội",
    parent_code: "829",
  },
  {
    value: "11602",
    label: "Xã An Hồng",
    parent_code: "312",
  },
  {
    value: "11599",
    label: "Xã An Hưng",
    parent_code: "312",
  },
  {
    value: "16435",
    label: "Phường An Hưng",
    parent_code: "380",
  },
  {
    value: "21610",
    label: "Xã An Hưng",
    parent_code: "542",
  },
  {
    value: "28429",
    label: "Xã An Hữu",
    parent_code: "819",
  },
  {
    value: "02503",
    label: "Xã An Khang",
    parent_code: "070",
  },
  {
    value: "09877",
    label: "Xã An Khánh",
    parent_code: "274",
  },
  {
    value: "05824",
    label: "Xã An Khánh",
    parent_code: "171",
  },
  {
    value: "27094",
    label: "Phường An Khánh",
    parent_code: "769",
  },
  {
    value: "28810",
    label: "Xã An Khánh",
    parent_code: "831",
  },
  {
    value: "30271",
    label: "Xã An Khánh",
    parent_code: "877",
  },
  {
    value: "31149",
    label: "Phường An Khánh",
    parent_code: "916",
  },
  {
    value: "12475",
    label: "Xã An Khê",
    parent_code: "338",
  },
  {
    value: "20224",
    label: "Phường An Khê",
    parent_code: "491",
  },
  {
    value: "25330",
    label: "Xã An Khương",
    parent_code: "694",
  },
  {
    value: "01555",
    label: "Xã An Lạc",
    parent_code: "048",
  },
  {
    value: "10594",
    label: "Phường An Lạc",
    parent_code: "290",
  },
  {
    value: "07645",
    label: "Xã An Lạc",
    parent_code: "220",
  },
  {
    value: "04327",
    label: "Xã An Lạc",
    parent_code: "135",
  },
  {
    value: "24305",
    label: "Phường An Lạc",
    parent_code: "644",
  },
  {
    value: "29978",
    label: "Phường An Lạc",
    parent_code: "868",
  },
  {
    value: "27463",
    label: "Phường An Lạc A",
    parent_code: "777",
  },
  {
    value: "31540",
    label: "Xã An Lạc Tây",
    parent_code: "943",
  },
  {
    value: "31531",
    label: "Thị trấn An Lạc Thôn",
    parent_code: "943",
  },
  {
    value: "11629",
    label: "Thị trấn An Lão",
    parent_code: "313",
  },
  {
    value: "13561",
    label: "Xã An Lão",
    parent_code: "352",
  },
  {
    value: "21609",
    label: "Thị trấn An Lão",
    parent_code: "542",
  },
  {
    value: "10645",
    label: "Xã An Lâm",
    parent_code: "291",
  },
  {
    value: "25801",
    label: "Xã An Lập",
    parent_code: "720",
  },
  {
    value: "12550",
    label: "Xã An Lễ",
    parent_code: "338",
  },
  {
    value: "25861",
    label: "Xã An Linh",
    parent_code: "722",
  },
  {
    value: "22144",
    label: "Xã An Lĩnh",
    parent_code: "559",
  },
  {
    value: "25867",
    label: "Xã An Long",
    parent_code: "722",
  },
  {
    value: "30022",
    label: "Xã An Long",
    parent_code: "871",
  },
  {
    value: "25324",
    label: "Phường An Lộc",
    parent_code: "690",
  },
  {
    value: "29954",
    label: "Phường An Lộc",
    parent_code: "868",
  },
  {
    value: "27115",
    label: "Phường An Lợi Đông",
    parent_code: "769",
  },
  {
    value: "28240",
    label: "Xã An Lục Long",
    parent_code: "808",
  },
  {
    value: "11533",
    label: "Xã An Lư",
    parent_code: "311",
  },
  {
    value: "04645",
    label: "Xã An Lương",
    parent_code: "140",
  },
  {
    value: "10675",
    label: "Phường An Lưu",
    parent_code: "292",
  },
  {
    value: "31027",
    label: "Xã An Minh Bắc",
    parent_code: "913",
  },
  {
    value: "10462",
    label: "Xã An Mỹ",
    parent_code: "282",
  },
  {
    value: "12559",
    label: "Xã An Mỹ",
    parent_code: "338",
  },
  {
    value: "22153",
    label: "Xã An Mỹ",
    parent_code: "559",
  },
  {
    value: "20341",
    label: "Phường An Mỹ",
    parent_code: "502",
  },
  {
    value: "31564",
    label: "Xã An Mỹ",
    parent_code: "943",
  },
  {
    value: "26665",
    label: "Xã An Ngãi",
    parent_code: "752",
  },
  {
    value: "29158",
    label: "Xã An Ngãi Tây",
    parent_code: "836",
  },
  {
    value: "29143",
    label: "Xã An Ngãi Trung",
    parent_code: "836",
  },
  {
    value: "21634",
    label: "Xã An Nghĩa",
    parent_code: "542",
  },
  {
    value: "22132",
    label: "Xã An Nghiệp",
    parent_code: "559",
  },
  {
    value: "31126",
    label: "Phường An Nghiệp",
    parent_code: "916",
  },
  {
    value: "25129",
    label: "Xã An Nhơn",
    parent_code: "682",
  },
  {
    value: "29224",
    label: "Xã An Nhơn",
    parent_code: "837",
  },
  {
    value: "30250",
    label: "Xã An Nhơn",
    parent_code: "877",
  },
  {
    value: "27508",
    label: "Xã An Nhơn Tây",
    parent_code: "783",
  },
  {
    value: "26671",
    label: "Xã An Nhứt",
    parent_code: "752",
  },
  {
    value: "12514",
    label: "Xã An Ninh",
    parent_code: "338",
  },
  {
    value: "13012",
    label: "Xã An Ninh",
    parent_code: "342",
  },
  {
    value: "13528",
    label: "Xã An Ninh",
    parent_code: "352",
  },
  {
    value: "19240",
    label: "Xã An Ninh",
    parent_code: "456",
  },
  {
    value: "31600",
    label: "Xã An Ninh",
    parent_code: "942",
  },
  {
    value: "22123",
    label: "Xã An Ninh Đông",
    parent_code: "559",
  },
  {
    value: "27943",
    label: "Xã An Ninh Đông",
    parent_code: "802",
  },
  {
    value: "22120",
    label: "Xã An Ninh Tây",
    parent_code: "559",
  },
  {
    value: "27946",
    label: "Xã An Ninh Tây",
    parent_code: "802",
  },
  {
    value: "13540",
    label: "Xã An Nội",
    parent_code: "352",
  },
  {
    value: "15709",
    label: "Xã An Nông",
    parent_code: "397",
  },
  {
    value: "30529",
    label: "Xã An Nông",
    parent_code: "890",
  },
  {
    value: "30139",
    label: "Xã An Phong",
    parent_code: "874",
  },
  {
    value: "10504",
    label: "Xã An Phú",
    parent_code: "282",
  },
  {
    value: "04369",
    label: "Xã An Phú",
    parent_code: "135",
  },
  {
    value: "25339",
    label: "Xã An Phú",
    parent_code: "694",
  },
  {
    value: "25975",
    label: "Phường An Phú",
    parent_code: "725",
  },
  {
    value: "23602",
    label: "Xã An Phú",
    parent_code: "622",
  },
  {
    value: "27091",
    label: "Phường An Phú",
    parent_code: "769",
  },
  {
    value: "23620",
    label: "Phường An Phú",
    parent_code: "623",
  },
  {
    value: "27502",
    label: "Xã An Phú",
    parent_code: "783",
  },
  {
    value: "20356",
    label: "Phường An Phú",
    parent_code: "502",
  },
  {
    value: "22162",
    label: "Xã An Phú",
    parent_code: "555",
  },
  {
    value: "30337",
    label: "Thị trấn An Phú",
    parent_code: "886",
  },
  {
    value: "30514",
    label: "Xã An Phú",
    parent_code: "890",
  },
  {
    value: "31141",
    label: "Phường An Phú",
    parent_code: "916",
  },
  {
    value: "10732",
    label: "Phường An Phụ",
    parent_code: "292",
  },
  {
    value: "26779",
    label: "Phường An Phú Đông",
    parent_code: "761",
  },
  {
    value: "29317",
    label: "Xã An Phú Tân",
    parent_code: "845",
  },
  {
    value: "27625",
    label: "Xã An Phú Tây",
    parent_code: "785",
  },
  {
    value: "30265",
    label: "Xã An Phú Thuận",
    parent_code: "877",
  },
  {
    value: "29128",
    label: "Xã An Phú Trung",
    parent_code: "836",
  },
  {
    value: "31990",
    label: "Xã An Phúc",
    parent_code: "960",
  },
  {
    value: "26383",
    label: "Xã An Phước",
    parent_code: "740",
  },
  {
    value: "23630",
    label: "Phường An Phước",
    parent_code: "623",
  },
  {
    value: "28828",
    label: "Xã An Phước",
    parent_code: "831",
  },
  {
    value: "29629",
    label: "Xã An Phước",
    parent_code: "858",
  },
  {
    value: "29950",
    label: "Xã An Phước",
    parent_code: "869",
  },
  {
    value: "10864",
    label: "Xã An Phượng",
    parent_code: "294",
  },
  {
    value: "21631",
    label: "Xã An Quang",
    parent_code: "542",
  },
  {
    value: "29473",
    label: "Xã An Quảng Hữu",
    parent_code: "849",
  },
  {
    value: "12538",
    label: "Xã An Quí",
    parent_code: "338",
  },
  {
    value: "29218",
    label: "Xã An Quy",
    parent_code: "837",
  },
  {
    value: "10723",
    label: "Phường An Sinh",
    parent_code: "292",
  },
  {
    value: "07075",
    label: "Xã An Sinh",
    parent_code: "205",
  },
  {
    value: "10636",
    label: "Xã An Sơn",
    parent_code: "291",
  },
  {
    value: "11479",
    label: "Xã An Sơn",
    parent_code: "311",
  },
  {
    value: "06283",
    label: "Xã An Sơn",
    parent_code: "184",
  },
  {
    value: "25981",
    label: "Xã An Sơn",
    parent_code: "725",
  },
  {
    value: "20350",
    label: "Phường An Sơn",
    parent_code: "502",
  },
  {
    value: "31114",
    label: "Xã An Sơn",
    parent_code: "912",
  },
  {
    value: "11956",
    label: "Phường An Tảo",
    parent_code: "323",
  },
  {
    value: "12847",
    label: "Xã An Tân",
    parent_code: "341",
  },
  {
    value: "23623",
    label: "Phường An Tân",
    parent_code: "623",
  },
  {
    value: "21625",
    label: "Xã An Tân",
    parent_code: "542",
  },
  {
    value: "25843",
    label: "Xã An Tây",
    parent_code: "721",
  },
  {
    value: "19816",
    label: "Phường An Tây",
    parent_code: "474",
  },
  {
    value: "22126",
    label: "Xã An Thạch",
    parent_code: "559",
  },
  {
    value: "11677",
    label: "Xã An Thái",
    parent_code: "313",
  },
  {
    value: "12499",
    label: "Xã An Thái",
    parent_code: "338",
  },
  {
    value: "25865",
    label: "Xã An Thái",
    parent_code: "722",
  },
  {
    value: "28414",
    label: "Xã An Thái Đông",
    parent_code: "819",
  },
  {
    value: "28426",
    label: "Xã An Thái Trung",
    parent_code: "819",
  },
  {
    value: "11125",
    label: "Xã An Thanh",
    parent_code: "298",
  },
  {
    value: "12541",
    label: "Xã An Thanh",
    parent_code: "338",
  },
  {
    value: "23992",
    label: "Xã An Thành",
    parent_code: "634",
  },
  {
    value: "25705",
    label: "Xã An Thạnh",
    parent_code: "711",
  },
  {
    value: "25963",
    label: "Phường An Thạnh",
    parent_code: "725",
  },
  {
    value: "28012",
    label: "Xã An Thạnh",
    parent_code: "803",
  },
  {
    value: "28951",
    label: "Xã An Thạnh",
    parent_code: "833",
  },
  {
    value: "29200",
    label: "Xã An Thạnh",
    parent_code: "837",
  },
  {
    value: "29955",
    label: "Phường An Thạnh",
    parent_code: "868",
  },
  {
    value: "31618",
    label: "Xã An Thạnh 1",
    parent_code: "945",
  },
  {
    value: "31630",
    label: "Xã An Thạnh 2",
    parent_code: "945",
  },
  {
    value: "31633",
    label: "Xã An Thạnh 3",
    parent_code: "945",
  },
  {
    value: "31624",
    label: "Xã An Thạnh Đông",
    parent_code: "945",
  },
  {
    value: "31636",
    label: "Xã An Thạnh Nam",
    parent_code: "945",
  },
  {
    value: "31621",
    label: "Xã An Thạnh Tây",
    parent_code: "945",
  },
  {
    value: "28639",
    label: "Xã An Thạnh Thủy",
    parent_code: "822",
  },
  {
    value: "30670",
    label: "Xã An Thạnh Trung",
    parent_code: "893",
  },
  {
    value: "01876",
    label: "Xã An Thắng",
    parent_code: "060",
  },
  {
    value: "11653",
    label: "Xã An Thắng",
    parent_code: "313",
  },
  {
    value: "09499",
    label: "Xã An Thịnh",
    parent_code: "264",
  },
  {
    value: "04417",
    label: "Xã An Thịnh",
    parent_code: "136",
  },
  {
    value: "11674",
    label: "Xã An Thọ",
    parent_code: "313",
  },
  {
    value: "22159",
    label: "Xã An Thọ",
    parent_code: "559",
  },
  {
    value: "28966",
    label: "Xã An Thới",
    parent_code: "833",
  },
  {
    value: "31081",
    label: "Phường An Thới",
    parent_code: "911",
  },
  {
    value: "31177",
    label: "Phường An Thới",
    parent_code: "918",
  },
  {
    value: "27673",
    label: "Xã An Thới Đông",
    parent_code: "787",
  },
  {
    value: "29215",
    label: "Xã An Thuận",
    parent_code: "837",
  },
  {
    value: "19264",
    label: "Xã An Thủy",
    parent_code: "457",
  },
  {
    value: "29179",
    label: "Xã An Thủy",
    parent_code: "836",
  },
  {
    value: "09880",
    label: "Xã An Thượng",
    parent_code: "274",
  },
  {
    value: "10663",
    label: "Xã An Thượng",
    parent_code: "288",
  },
  {
    value: "07285",
    label: "Xã An Thượng",
    parent_code: "215",
  },
  {
    value: "10495",
    label: "Xã An Tiến",
    parent_code: "282",
  },
  {
    value: "11641",
    label: "Xã An Tiến",
    parent_code: "313",
  },
  {
    value: "25732",
    label: "Phường An Tịnh",
    parent_code: "712",
  },
  {
    value: "21622",
    label: "Xã An Toàn",
    parent_code: "542",
  },
  {
    value: "31987",
    label: "Xã An Trạch",
    parent_code: "960",
  },
  {
    value: "31988",
    label: "Xã An Trạch A",
    parent_code: "960",
  },
  {
    value: "12580",
    label: "Xã An Tràng",
    parent_code: "338",
  },
  {
    value: "23830",
    label: "Xã An Trung",
    parent_code: "630",
  },
  {
    value: "21613",
    label: "Xã An Trung",
    parent_code: "542",
  },
  {
    value: "29275",
    label: "Xã An Trường",
    parent_code: "844",
  },
  {
    value: "29272",
    label: "Xã An Trường A",
    parent_code: "844",
  },
  {
    value: "30577",
    label: "Xã An Tức",
    parent_code: "891",
  },
  {
    value: "09151",
    label: "Xã An Tường",
    parent_code: "252",
  },
  {
    value: "02512",
    label: "Phường An Tường",
    parent_code: "070",
  },
  {
    value: "12229",
    label: "Xã An Vĩ",
    parent_code: "330",
  },
  {
    value: "12355",
    label: "Xã An Viên",
    parent_code: "332",
  },
  {
    value: "26296",
    label: "Xã An Viễn",
    parent_code: "737",
  },
  {
    value: "12565",
    label: "Xã An Vinh",
    parent_code: "338",
  },
  {
    value: "21619",
    label: "Xã An Vinh",
    parent_code: "542",
  },
  {
    value: "27718",
    label: "Xã An Vĩnh Ngãi",
    parent_code: "794",
  },
  {
    value: "12547",
    label: "Xã An Vũ",
    parent_code: "338",
  },
  {
    value: "22141",
    label: "Xã An Xuân",
    parent_code: "559",
  },
  {
    value: "20347",
    label: "Phường An Xuân",
    parent_code: "502",
  },
  {
    value: "32023",
    label: "Xã An Xuyên",
    parent_code: "964",
  },
  {
    value: "11689",
    label: "Phường Anh Dũng",
    parent_code: "309",
  },
  {
    value: "16579",
    label: "Xã Anh Sơn",
    parent_code: "407",
  },
  {
    value: "17329",
    label: "Thị trấn Anh Sơn",
    parent_code: "424",
  },
  {
    value: "23797",
    label: "Xã Ayun",
    parent_code: "629",
  },
  {
    value: "23956",
    label: "Xã AYun",
    parent_code: "633",
  },
  {
    value: "24048",
    label: "Xã Ayun Hạ",
    parent_code: "638",
  },
  {
    value: "03310",
    label: "Xã Ẳng Cang",
    parent_code: "102",
  },
  {
    value: "03307",
    label: "Xã Ẳng Nưa",
    parent_code: "102",
  },
  {
    value: "03292",
    label: "Xã Ẳng Tở",
    parent_code: "102",
  },
  {
    value: "08095",
    label: "Xã Ấm Hạ",
    parent_code: "231",
  },
  {
    value: "21712",
    label: "Xã Ân Đức",
    parent_code: "544",
  },
  {
    value: "21691",
    label: "Xã Ân Hảo Đông",
    parent_code: "544",
  },
  {
    value: "21690",
    label: "Xã Ân Hảo Tây",
    parent_code: "544",
  },
  {
    value: "14638",
    label: "Xã Ân Hòa",
    parent_code: "376",
  },
  {
    value: "21715",
    label: "Xã Ân Hữu",
    parent_code: "544",
  },
  {
    value: "21697",
    label: "Xã Ân Mỹ",
    parent_code: "544",
  },
  {
    value: "05347",
    label: "Xã Ân Nghĩa",
    parent_code: "157",
  },
  {
    value: "21727",
    label: "Xã Ân Nghĩa",
    parent_code: "544",
  },
  {
    value: "21709",
    label: "Xã Ân Phong",
    parent_code: "544",
  },
  {
    value: "18316",
    label: "Xã Ân Phú",
    parent_code: "441",
  },
  {
    value: "21694",
    label: "Xã Ân Sơn",
    parent_code: "544",
  },
  {
    value: "21706",
    label: "Xã Ân Thạnh",
    parent_code: "544",
  },
  {
    value: "12142",
    label: "Thị trấn Ân Thi",
    parent_code: "329",
  },
  {
    value: "21703",
    label: "Xã Ân Tín",
    parent_code: "544",
  },
  {
    value: "21724",
    label: "Xã Ân Tường Đông",
    parent_code: "544",
  },
  {
    value: "21721",
    label: "Xã Ân Tường Tây",
    parent_code: "544",
  },
  {
    value: "07948",
    label: "Phường Âu Cơ",
    parent_code: "228",
  },
  {
    value: "04540",
    label: "Xã Âu Lâu",
    parent_code: "132",
  },
  {
    value: "25069",
    label: "Xã B' Lá",
    parent_code: "680",
  },
  {
    value: "24826",
    label: "Phường B'lao",
    parent_code: "673",
  },
  {
    value: "20485",
    label: "Xã Ba",
    parent_code: "505",
  },
  {
    value: "21526",
    label: "Xã Ba Bích",
    parent_code: "535",
  },
  {
    value: "06970",
    label: "Thị trấn Ba Chẽ",
    parent_code: "202",
  },
  {
    value: "30547",
    label: "Thị trấn Ba Chúc",
    parent_code: "891",
  },
  {
    value: "22732",
    label: "Xã Ba Cụm Bắc",
    parent_code: "575",
  },
  {
    value: "22735",
    label: "Xã Ba Cụm Nam",
    parent_code: "575",
  },
  {
    value: "21511",
    label: "Xã Ba Cung",
    parent_code: "535",
  },
  {
    value: "21499",
    label: "Xã Ba Dinh",
    parent_code: "535",
  },
  {
    value: "27592",
    label: "Xã Bà Điểm",
    parent_code: "784",
  },
  {
    value: "21487",
    label: "Xã Ba Điền",
    parent_code: "535",
  },
  {
    value: "14776",
    label: "Phường Ba Đình",
    parent_code: "380",
  },
  {
    value: "14812",
    label: "Phường Ba Đình",
    parent_code: "381",
  },
  {
    value: "16096",
    label: "Xã Ba Đình",
    parent_code: "401",
  },
  {
    value: "19009",
    label: "Phường Ba Đồn",
    parent_code: "458",
  },
  {
    value: "21496",
    label: "Xã Ba Động",
    parent_code: "535",
  },
  {
    value: "21500",
    label: "Xã Ba Giang",
    parent_code: "535",
  },
  {
    value: "05860",
    label: "Phường Ba Hàng",
    parent_code: "172",
  },
  {
    value: "04981",
    label: "Thị trấn Ba Hàng Đồi",
    parent_code: "159",
  },
  {
    value: "08944",
    label: "Thị trấn Bá Hiến",
    parent_code: "249",
  },
  {
    value: "21508",
    label: "Xã Ba Khâm",
    parent_code: "535",
  },
  {
    value: "31195",
    label: "Phường Ba Láng",
    parent_code: "919",
  },
  {
    value: "21532",
    label: "Xã Ba Lế",
    parent_code: "535",
  },
  {
    value: "21502",
    label: "Xã Ba Liên",
    parent_code: "535",
  },
  {
    value: "19570",
    label: "Xã Ba Lòng",
    parent_code: "467",
  },
  {
    value: "21535",
    label: "Xã Ba Nam",
    parent_code: "535",
  },
  {
    value: "19576",
    label: "Xã Ba Nang",
    parent_code: "467",
  },
  {
    value: "21505",
    label: "Xã Ba Ngạc",
    parent_code: "535",
  },
  {
    value: "22423",
    label: "Phường Ba Ngòi",
    parent_code: "569",
  },
  {
    value: "13429",
    label: "Thị trấn Ba Sao",
    parent_code: "350",
  },
  {
    value: "30085",
    label: "Xã Ba Sao",
    parent_code: "873",
  },
  {
    value: "19477",
    label: "Xã Ba Tầng",
    parent_code: "465",
  },
  {
    value: "21493",
    label: "Xã Ba Thành",
    parent_code: "535",
  },
  {
    value: "21517",
    label: "Xã Ba Tiêu",
    parent_code: "535",
  },
  {
    value: "21523",
    label: "Xã Ba Tô",
    parent_code: "535",
  },
  {
    value: "21484",
    label: "Thị trấn Ba Tơ",
    parent_code: "535",
  },
  {
    value: "09697",
    label: "Xã Ba Trại",
    parent_code: "271",
  },
  {
    value: "21520",
    label: "Xã Ba Trang",
    parent_code: "535",
  },
  {
    value: "29110",
    label: "Thị trấn Ba Tri",
    parent_code: "836",
  },
  {
    value: "13654",
    label: "Phường Bà Triệu",
    parent_code: "356",
  },
  {
    value: "31546",
    label: "Xã Ba Trinh",
    parent_code: "943",
  },
  {
    value: "09703",
    label: "Xã Ba Vì",
    parent_code: "271",
  },
  {
    value: "21529",
    label: "Xã Ba Vì",
    parent_code: "535",
  },
  {
    value: "21490",
    label: "Xã Ba Vinh",
    parent_code: "535",
  },
  {
    value: "21538",
    label: "Xã Ba Xa",
    parent_code: "535",
  },
  {
    value: "05533",
    label: "Xã Bá Xuyên",
    parent_code: "165",
  },
  {
    value: "00244",
    label: "Phường Bạch Đằng",
    parent_code: "007",
  },
  {
    value: "01708",
    label: "Xã Bạch Đằng",
    parent_code: "051",
  },
  {
    value: "10678",
    label: "Xã Bạch Đằng",
    parent_code: "292",
  },
  {
    value: "11788",
    label: "Xã Bạch Đằng",
    parent_code: "315",
  },
  {
    value: "06694",
    label: "Phường Bạch Đằng",
    parent_code: "193",
  },
  {
    value: "25930",
    label: "Xã Bạch Đằng",
    parent_code: "723",
  },
  {
    value: "00832",
    label: "Xã Bạch Đích",
    parent_code: "028",
  },
  {
    value: "04762",
    label: "Xã Bạch Hà",
    parent_code: "141",
  },
  {
    value: "10342",
    label: "Xã Bạch Hạ",
    parent_code: "280",
  },
  {
    value: "07912",
    label: "Phường Bạch Hạc",
    parent_code: "227",
  },
  {
    value: "00277",
    label: "Phường Bách Khoa",
    parent_code: "007",
  },
  {
    value: "14206",
    label: "Xã Bạch Long",
    parent_code: "365",
  },
  {
    value: "08779",
    label: "Xã Bạch Lưu",
    parent_code: "253",
  },
  {
    value: "00286",
    label: "Phường Bạch Mai",
    parent_code: "007",
  },
  {
    value: "00976",
    label: "Xã Bạch Ngọc",
    parent_code: "030",
  },
  {
    value: "05528",
    label: "Phường Bách Quang",
    parent_code: "165",
  },
  {
    value: "12124",
    label: "Phường Bạch Sam",
    parent_code: "328",
  },
  {
    value: "13243",
    label: "Xã Bách Thuận",
    parent_code: "344",
  },
  {
    value: "13333",
    label: "Phường Bạch Thượng",
    parent_code: "349",
  },
  {
    value: "02380",
    label: "Xã Bạch Xa",
    parent_code: "074",
  },
  {
    value: "05854",
    label: "Phường Bãi Bông",
    parent_code: "172",
  },
  {
    value: "06673",
    label: "Phường Bãi Cháy",
    parent_code: "193",
  },
  {
    value: "12151",
    label: "Xã Bãi Sậy",
    parent_code: "329",
  },
  {
    value: "17632",
    label: "Xã Bài Sơn",
    parent_code: "427",
  },
  {
    value: "31102",
    label: "Xã Bãi Thơm",
    parent_code: "911",
  },
  {
    value: "16177",
    label: "Xã Bãi Trành",
    parent_code: "402",
  },
  {
    value: "03424",
    label: "Xã Bản Bo",
    parent_code: "106",
  },
  {
    value: "02899",
    label: "Xã Bản Cái",
    parent_code: "085",
  },
  {
    value: "02914",
    label: "Xã Bản Cầm",
    parent_code: "086",
  },
  {
    value: "14971",
    label: "Xã Ban Công",
    parent_code: "386",
  },
  {
    value: "04612",
    label: "Xã Bản Công",
    parent_code: "139",
  },
  {
    value: "01102",
    label: "Xã Bản Díu",
    parent_code: "033",
  },
  {
    value: "05911",
    label: "Xã Bàn Đạt",
    parent_code: "173",
  },
  {
    value: "08833",
    label: "Xã Bàn Giản",
    parent_code: "246",
  },
  {
    value: "03418",
    label: "Xã Bản Giang",
    parent_code: "106",
  },
  {
    value: "03421",
    label: "Xã Bản Hon",
    parent_code: "106",
  },
  {
    value: "03046",
    label: "Xã Bản Hồ",
    parent_code: "088",
  },
  {
    value: "03577",
    label: "Xã Bản Lang",
    parent_code: "109",
  },
  {
    value: "03805",
    label: "Xã Bản Lầm",
    parent_code: "119",
  },
  {
    value: "02788",
    label: "Xã Bản Lầu",
    parent_code: "083",
  },
  {
    value: "02869",
    label: "Xã Bản Liền",
    parent_code: "085",
  },
  {
    value: "28573",
    label: "Xã Bàn Long",
    parent_code: "821",
  },
  {
    value: "01063",
    label: "Xã Bản Luốc",
    parent_code: "032",
  },
  {
    value: "01024",
    label: "Xã Bản Máy",
    parent_code: "032",
  },
  {
    value: "02806",
    label: "Xã Bản Mế",
    parent_code: "084",
  },
  {
    value: "04615",
    label: "Xã Bản Mù",
    parent_code: "139",
  },
  {
    value: "01135",
    label: "Xã Bản Ngò",
    parent_code: "033",
  },
  {
    value: "05800",
    label: "Xã Bản Ngoại",
    parent_code: "171",
  },
  {
    value: "08539",
    label: "Xã Bản Nguyên",
    parent_code: "237",
  },
  {
    value: "01069",
    label: "Xã Bản Nhùng",
    parent_code: "032",
  },
  {
    value: "02911",
    label: "Xã Bản Phiệt",
    parent_code: "086",
  },
  {
    value: "02866",
    label: "Xã Bản Phố",
    parent_code: "085",
  },
  {
    value: "01036",
    label: "Xã Bản Phùng",
    parent_code: "032",
  },
  {
    value: "02716",
    label: "Xã Bản Qua",
    parent_code: "082",
  },
  {
    value: "01231",
    label: "Xã Bản Rịa",
    parent_code: "035",
  },
  {
    value: "07018",
    label: "Xã Bản Sen",
    parent_code: "203",
  },
  {
    value: "02797",
    label: "Xã Bản Sen",
    parent_code: "083",
  },
  {
    value: "30922",
    label: "Xã Bàn Tân Định",
    parent_code: "906",
  },
  {
    value: "30919",
    label: "Xã Bàn Thạch",
    parent_code: "906",
  },
  {
    value: "02035",
    label: "Xã Bản Thi",
    parent_code: "064",
  },
  {
    value: "02710",
    label: "Xã Bản Vược",
    parent_code: "082",
  },
  {
    value: "02725",
    label: "Xã Bản Xèo",
    parent_code: "082",
  },
  {
    value: "11467",
    label: "Phường Bàng La",
    parent_code: "308",
  },
  {
    value: "01891",
    label: "Xã Bành Trạch",
    parent_code: "061",
  },
  {
    value: "04738",
    label: "Xã Bảo Ái",
    parent_code: "141",
  },
  {
    value: "22744",
    label: "Phường Bảo An",
    parent_code: "582",
  },
  {
    value: "26350",
    label: "Xã Bảo Bình",
    parent_code: "739",
  },
  {
    value: "05569",
    label: "Xã Bảo Cường",
    parent_code: "167",
  },
  {
    value: "07462",
    label: "Xã Bảo Đài",
    parent_code: "218",
  },
  {
    value: "04504",
    label: "Xã Báo Đáp",
    parent_code: "138",
  },
  {
    value: "02989",
    label: "Xã Bảo Hà",
    parent_code: "087",
  },
  {
    value: "05365",
    label: "Xã Bảo Hiệu",
    parent_code: "158",
  },
  {
    value: "26464",
    label: "Xã Bảo Hoà",
    parent_code: "741",
  },
  {
    value: "04561",
    label: "Xã Bảo Hưng",
    parent_code: "138",
  },
  {
    value: "11983",
    label: "Xã Bảo Khê",
    parent_code: "323",
  },
  {
    value: "05227",
    label: "Xã Bao La",
    parent_code: "156",
  },
  {
    value: "01321",
    label: "Thị trấn Bảo Lạc",
    parent_code: "043",
  },
  {
    value: "06190",
    label: "Xã Bảo Lâm",
    parent_code: "183",
  },
  {
    value: "05554",
    label: "Xã Bảo Linh",
    parent_code: "167",
  },
  {
    value: "05929",
    label: "Xã Bảo Lý",
    parent_code: "173",
  },
  {
    value: "16840",
    label: "Xã Bảo Nam",
    parent_code: "417",
  },
  {
    value: "02890",
    label: "Xã Bảo Nhai",
    parent_code: "085",
  },
  {
    value: "18889",
    label: "Xã Bảo Ninh",
    parent_code: "450",
  },
  {
    value: "26092",
    label: "Xã Bảo Quang",
    parent_code: "732",
  },
  {
    value: "07459",
    label: "Xã Bảo Sơn",
    parent_code: "218",
  },
  {
    value: "08254",
    label: "Xã Bảo Thanh",
    parent_code: "233",
  },
  {
    value: "17605",
    label: "Xã Bảo Thành",
    parent_code: "426",
  },
  {
    value: "29125",
    label: "Xã Bảo Thạnh",
    parent_code: "836",
  },
  {
    value: "16846",
    label: "Xã Bảo Thắng",
    parent_code: "417",
  },
  {
    value: "25033",
    label: "Xã Bảo Thuận",
    parent_code: "679",
  },
  {
    value: "29152",
    label: "Xã Bảo Thuận",
    parent_code: "836",
  },
  {
    value: "01333",
    label: "Xã Bảo Toàn",
    parent_code: "043",
  },
  {
    value: "26098",
    label: "Phường Bảo Vinh",
    parent_code: "732",
  },
  {
    value: "08680",
    label: "Xã Bảo Yên",
    parent_code: "239",
  },
  {
    value: "23946",
    label: "Xã Bar Măih",
    parent_code: "633",
  },
  {
    value: "00877",
    label: "Xã Bát Đại Sơn",
    parent_code: "029",
  },
  {
    value: "15607",
    label: "Xã Bát Mọt",
    parent_code: "396",
  },
  {
    value: "11632",
    label: "Xã Bát Trang",
    parent_code: "313",
  },
  {
    value: "00583",
    label: "Xã Bát Tràng",
    parent_code: "018",
  },
  {
    value: "02683",
    label: "Thị trấn Bát Xát",
    parent_code: "082",
  },
  {
    value: "26410",
    label: "Xã Bàu Cạn",
    parent_code: "740",
  },
  {
    value: "23899",
    label: "Xã Bàu Cạn",
    parent_code: "632",
  },
  {
    value: "26574",
    label: "Xã Bàu Chinh",
    parent_code: "750",
  },
  {
    value: "25666",
    label: "Xã Bàu Đồn",
    parent_code: "710",
  },
  {
    value: "26257",
    label: "Xã Bàu Hàm",
    parent_code: "737",
  },
  {
    value: "26314",
    label: "Xã Bàu Hàm 2",
    parent_code: "738",
  },
  {
    value: "26638",
    label: "Xã Bàu Lâm",
    parent_code: "751",
  },
  {
    value: "25567",
    label: "Xã Bàu Năng",
    parent_code: "707",
  },
  {
    value: "26104",
    label: "Phường Bàu Sen",
    parent_code: "732",
  },
  {
    value: "26107",
    label: "Xã Bàu Trâm",
    parent_code: "732",
  },
  {
    value: "31346",
    label: "Thị trấn Bảy Ngàn",
    parent_code: "932",
  },
  {
    value: "10558",
    label: "Xã Bắc An",
    parent_code: "290",
  },
  {
    value: "08785",
    label: "Xã Bắc Bình",
    parent_code: "246",
  },
  {
    value: "02668",
    label: "Phường Bắc Cường",
    parent_code: "080",
  },
  {
    value: "02839",
    label: "Thị trấn Bắc Hà",
    parent_code: "085",
  },
  {
    value: "18076",
    label: "Phường Bắc Hà",
    parent_code: "436",
  },
  {
    value: "13048",
    label: "Xã Bắc Hải",
    parent_code: "342",
  },
  {
    value: "27829",
    label: "Xã Bắc Hòa",
    parent_code: "799",
  },
  {
    value: "00463",
    label: "Xã Bắc Hồng",
    parent_code: "017",
  },
  {
    value: "18115",
    label: "Phường Bắc Hồng",
    parent_code: "437",
  },
  {
    value: "06139",
    label: "Xã Bắc Hùng",
    parent_code: "182",
  },
  {
    value: "11803",
    label: "Xã Bắc Hưng",
    parent_code: "315",
  },
  {
    value: "06133",
    label: "Xã Bắc La",
    parent_code: "182",
  },
  {
    value: "06646",
    label: "Xã Bắc Lãng",
    parent_code: "189",
  },
  {
    value: "02650",
    label: "Phường Bắc Lệnh",
    parent_code: "080",
  },
  {
    value: "07513",
    label: "Xã Bắc Lũng",
    parent_code: "218",
  },
  {
    value: "15502",
    label: "Xã Bắc Lương",
    parent_code: "395",
  },
  {
    value: "07870",
    label: "Xã Bắc Lý",
    parent_code: "223",
  },
  {
    value: "13588",
    label: "Xã Bắc Lý",
    parent_code: "353",
  },
  {
    value: "16819",
    label: "Xã Bắc Lý",
    parent_code: "417",
  },
  {
    value: "18859",
    label: "Phường Bắc Lý",
    parent_code: "450",
  },
  {
    value: "18877",
    label: "Phường Bắc Nghĩa",
    parent_code: "450",
  },
  {
    value: "05098",
    label: "Xã Bắc Phong",
    parent_code: "154",
  },
  {
    value: "03976",
    label: "Xã Bắc Phong",
    parent_code: "122",
  },
  {
    value: "22856",
    label: "Xã Bắc Phong",
    parent_code: "588",
  },
  {
    value: "00403",
    label: "Xã Bắc Phú",
    parent_code: "016",
  },
  {
    value: "06343",
    label: "Xã Bắc Quỳnh",
    parent_code: "185",
  },
  {
    value: "23152",
    label: "Xã Bắc Ruộng",
    parent_code: "599",
  },
  {
    value: "00379",
    label: "Xã Bắc Sơn",
    parent_code: "016",
  },
  {
    value: "08443",
    label: "Xã Bắc Sơn",
    parent_code: "236",
  },
  {
    value: "11434",
    label: "Phường Bắc Sơn",
    parent_code: "307",
  },
  {
    value: "11605",
    label: "Xã Bắc Sơn",
    parent_code: "312",
  },
  {
    value: "12148",
    label: "Xã Bắc Sơn",
    parent_code: "329",
  },
  {
    value: "05857",
    label: "Phường Bắc Sơn",
    parent_code: "172",
  },
  {
    value: "06325",
    label: "Thị trấn Bắc Sơn",
    parent_code: "185",
  },
  {
    value: "06727",
    label: "Xã Bắc Sơn",
    parent_code: "194",
  },
  {
    value: "06814",
    label: "Phường Bắc Sơn",
    parent_code: "196",
  },
  {
    value: "12628",
    label: "Xã Bắc Sơn",
    parent_code: "339",
  },
  {
    value: "14362",
    label: "Phường Bắc Sơn",
    parent_code: "370",
  },
  {
    value: "14809",
    label: "Phường Bắc Sơn",
    parent_code: "381",
  },
  {
    value: "14833",
    label: "Phường Bắc Sơn",
    parent_code: "382",
  },
  {
    value: "17095",
    label: "Xã Bắc Sơn",
    parent_code: "420",
  },
  {
    value: "17638",
    label: "Xã Bắc Sơn",
    parent_code: "427",
  },
  {
    value: "26269",
    label: "Xã Bắc Sơn",
    parent_code: "737",
  },
  {
    value: "22853",
    label: "Xã Bắc Sơn",
    parent_code: "588",
  },
  {
    value: "17569",
    label: "Xã Bắc Thành",
    parent_code: "426",
  },
  {
    value: "06478",
    label: "Xã Bắc Thủy",
    parent_code: "187",
  },
  {
    value: "19126",
    label: "Xã Bắc Trạch",
    parent_code: "455",
  },
  {
    value: "06154",
    label: "Xã Bắc Việt",
    parent_code: "182",
  },
  {
    value: "06619",
    label: "Xã Bắc Xa",
    parent_code: "189",
  },
  {
    value: "03856",
    label: "Thị trấn Bắc Yên",
    parent_code: "121",
  },
  {
    value: "24568",
    label: "Xã Băng A Drênh",
    parent_code: "655",
  },
  {
    value: "09262",
    label: "Xã Bằng An",
    parent_code: "259",
  },
  {
    value: "07057",
    label: "Xã Bằng Cả",
    parent_code: "193",
  },
  {
    value: "02416",
    label: "Xã Bằng Cốc",
    parent_code: "074",
  },
  {
    value: "07996",
    label: "Xã Bằng Doãn",
    parent_code: "230",
  },
  {
    value: "08125",
    label: "Xã Bằng Giã",
    parent_code: "231",
  },
  {
    value: "01186",
    label: "Xã Bằng Hành",
    parent_code: "034",
  },
  {
    value: "06487",
    label: "Xã Bằng Hữu",
    parent_code: "187",
  },
  {
    value: "01246",
    label: "Xã Bằng Lang",
    parent_code: "035",
  },
  {
    value: "02065",
    label: "Xã Bằng Lãng",
    parent_code: "064",
  },
  {
    value: "07981",
    label: "Xã Bằng Luân",
    parent_code: "230",
  },
  {
    value: "02020",
    label: "Thị trấn Bằng Lũng",
    parent_code: "064",
  },
  {
    value: "06493",
    label: "Xã Bằng Mạc",
    parent_code: "187",
  },
  {
    value: "02041",
    label: "Xã Bằng Phúc",
    parent_code: "064",
  },
  {
    value: "01858",
    label: "Xã Bằng Thành",
    parent_code: "060",
  },
  {
    value: "01942",
    label: "Xã Bằng Vân",
    parent_code: "062",
  },
  {
    value: "12103",
    label: "Phường Bần Yên Nhân",
    parent_code: "328",
  },
  {
    value: "01630",
    label: "Xã Bế Văn Đàn",
    parent_code: "049",
  },
  {
    value: "25681",
    label: "Thị trấn Bến Cầu",
    parent_code: "711",
  },
  {
    value: "25576",
    label: "Xã Bến Củi",
    parent_code: "707",
  },
  {
    value: "07915",
    label: "Phường Bến Gót",
    parent_code: "227",
  },
  {
    value: "27991",
    label: "Thị trấn Bến Lức",
    parent_code: "803",
  },
  {
    value: "26740",
    label: "Phường Bến Nghé",
    parent_code: "760",
  },
  {
    value: "19366",
    label: "Thị trấn Bến Quan",
    parent_code: "464",
  },
  {
    value: "16228",
    label: "Thị trấn Bến Sung",
    parent_code: "403",
  },
  {
    value: "10552",
    label: "Phường Bến Tắm",
    parent_code: "290",
  },
  {
    value: "26743",
    label: "Phường Bến Thành",
    parent_code: "760",
  },
  {
    value: "16693",
    label: "Phường Bến Thủy",
    parent_code: "412",
  },
  {
    value: "20458",
    label: "Xã Bha Lê",
    parent_code: "504",
  },
  {
    value: "14332",
    label: "Phường Bích Đào",
    parent_code: "369",
  },
  {
    value: "07777",
    label: "Thị trấn Bích Động",
    parent_code: "222",
  },
  {
    value: "10126",
    label: "Xã Bích Hòa",
    parent_code: "278",
  },
  {
    value: "32068",
    label: "Xã Biển Bạch",
    parent_code: "967",
  },
  {
    value: "32074",
    label: "Xã Biển Bạch Đông",
    parent_code: "967",
  },
  {
    value: "07573",
    label: "Xã Biển Động",
    parent_code: "219",
  },
  {
    value: "10123",
    label: "Phường Biên Giang",
    parent_code: "268",
  },
  {
    value: "25603",
    label: "Xã Biên Giới",
    parent_code: "708",
  },
  {
    value: "23590",
    label: "Xã Biển Hồ",
    parent_code: "622",
  },
  {
    value: "07555",
    label: "Xã Biên Sơn",
    parent_code: "219",
  },
  {
    value: "02290",
    label: "Xã Bình An",
    parent_code: "071",
  },
  {
    value: "18430",
    label: "Xã Bình An",
    parent_code: "448",
  },
  {
    value: "25951",
    label: "Phường Bình An",
    parent_code: "724",
  },
  {
    value: "26386",
    label: "Xã Bình An",
    parent_code: "740",
  },
  {
    value: "23014",
    label: "Xã Bình An",
    parent_code: "596",
  },
  {
    value: "20845",
    label: "Xã Bình An",
    parent_code: "513",
  },
  {
    value: "21064",
    label: "Xã Bình An",
    parent_code: "524",
  },
  {
    value: "28054",
    label: "Xã Bình An",
    parent_code: "804",
  },
  {
    value: "30808",
    label: "Xã Bình An",
    parent_code: "902",
  },
  {
    value: "30898",
    label: "Xã Bình An",
    parent_code: "905",
  },
  {
    value: "28735",
    label: "Xã Bình Ân",
    parent_code: "824",
  },
  {
    value: "26578",
    label: "Xã Bình Ba",
    parent_code: "750",
  },
  {
    value: "27637",
    label: "Xã Bình Chánh",
    parent_code: "785",
  },
  {
    value: "20830",
    label: "Xã Bình Chánh",
    parent_code: "513",
  },
  {
    value: "21052",
    label: "Xã Bình Chánh",
    parent_code: "524",
  },
  {
    value: "30499",
    label: "Xã Bình Chánh",
    parent_code: "889",
  },
  {
    value: "26656",
    label: "Xã Bình Châu",
    parent_code: "751",
  },
  {
    value: "21112",
    label: "Xã Bình Châu",
    parent_code: "524",
  },
  {
    value: "26797",
    label: "Phường Bình Chiểu",
    parent_code: "769",
  },
  {
    value: "17230",
    label: "Xã Bình Chuẩn",
    parent_code: "422",
  },
  {
    value: "25969",
    label: "Phường Bình Chuẩn",
    parent_code: "725",
  },
  {
    value: "21100",
    label: "Xã Bình Chương",
    parent_code: "524",
  },
  {
    value: "10798",
    label: "Xã Bình Dân",
    parent_code: "293",
  },
  {
    value: "07000",
    label: "Xã Bình Dân",
    parent_code: "203",
  },
  {
    value: "01711",
    label: "Xã Bình Dương",
    parent_code: "051",
  },
  {
    value: "09118",
    label: "Xã Bình Dương",
    parent_code: "252",
  },
  {
    value: "09475",
    label: "Xã Bình Dương",
    parent_code: "263",
  },
  {
    value: "07090",
    label: "Xã Bình Dương",
    parent_code: "205",
  },
  {
    value: "20794",
    label: "Xã Bình Dương",
    parent_code: "513",
  },
  {
    value: "21070",
    label: "Xã Bình Dương",
    parent_code: "524",
  },
  {
    value: "21733",
    label: "Thị trấn Bình Dương",
    parent_code: "545",
  },
  {
    value: "26047",
    label: "Phường Bình Đa",
    parent_code: "731",
  },
  {
    value: "29050",
    label: "Thị trấn Bình Đại",
    parent_code: "835",
  },
  {
    value: "20809",
    label: "Xã Bình Đào",
    parent_code: "513",
  },
  {
    value: "09034",
    label: "Xã Bình Định",
    parent_code: "251",
  },
  {
    value: "09529",
    label: "Xã Bình Định",
    parent_code: "264",
  },
  {
    value: "13186",
    label: "Xã Bình Định",
    parent_code: "343",
  },
  {
    value: "21907",
    label: "Phường Bình Định",
    parent_code: "549",
  },
  {
    value: "20821",
    label: "Xã Bình Định Bắc",
    parent_code: "513",
  },
  {
    value: "20822",
    label: "Xã Bình Định Nam",
    parent_code: "513",
  },
  {
    value: "21049",
    label: "Xã Bình Đông",
    parent_code: "524",
  },
  {
    value: "28708",
    label: "Xã Bình Đông",
    parent_code: "816",
  },
  {
    value: "28015",
    label: "Xã Bình Đức",
    parent_code: "803",
  },
  {
    value: "28579",
    label: "Xã Bình Đức",
    parent_code: "821",
  },
  {
    value: "30289",
    label: "Phường Bình Đức",
    parent_code: "883",
  },
  {
    value: "06112",
    label: "Thị trấn Bình Gia",
    parent_code: "181",
  },
  {
    value: "26590",
    label: "Xã Bình Giã",
    parent_code: "750",
  },
  {
    value: "20797",
    label: "Xã Bình Giang",
    parent_code: "513",
  },
  {
    value: "30826",
    label: "Xã Bình Giang",
    parent_code: "903",
  },
  {
    value: "23890",
    label: "Xã Bình Giáo",
    parent_code: "632",
  },
  {
    value: "20839",
    label: "Xã Bình Hải",
    parent_code: "513",
  },
  {
    value: "21067",
    label: "Xã Bình Hải",
    parent_code: "524",
  },
  {
    value: "10510",
    label: "Phường Bình Hàn",
    parent_code: "288",
  },
  {
    value: "30124",
    label: "Xã Bình Hàng Tây",
    parent_code: "873",
  },
  {
    value: "30118",
    label: "Xã Bình Hàng Trung",
    parent_code: "873",
  },
  {
    value: "05308",
    label: "Xã Bình Hẻm",
    parent_code: "157",
  },
  {
    value: "20251",
    label: "Phường Bình Hiên",
    parent_code: "492",
  },
  {
    value: "21103",
    label: "Xã Bình Hiệp",
    parent_code: "524",
  },
  {
    value: "27793",
    label: "Xã Bình Hiệp",
    parent_code: "795",
  },
  {
    value: "29017",
    label: "Xã Bình Hoà",
    parent_code: "834",
  },
  {
    value: "14170",
    label: "Xã Bình Hòa",
    parent_code: "365",
  },
  {
    value: "25987",
    label: "Phường Bình Hòa",
    parent_code: "725",
  },
  {
    value: "26197",
    label: "Xã Bình Hòa",
    parent_code: "735",
  },
  {
    value: "24574",
    label: "Xã Bình Hòa",
    parent_code: "655",
  },
  {
    value: "21079",
    label: "Xã Bình Hòa",
    parent_code: "524",
  },
  {
    value: "21829",
    label: "Xã Bình Hòa",
    parent_code: "547",
  },
  {
    value: "30607",
    label: "Xã Bình Hòa",
    parent_code: "892",
  },
  {
    value: "27919",
    label: "Xã Bình Hòa Bắc",
    parent_code: "801",
  },
  {
    value: "27811",
    label: "Xã Bình Hòa Đông",
    parent_code: "798",
  },
  {
    value: "27922",
    label: "Xã Bình Hòa Hưng",
    parent_code: "801",
  },
  {
    value: "27925",
    label: "Xã Bình Hòa Nam",
    parent_code: "801",
  },
  {
    value: "29581",
    label: "Xã Bình Hòa Phước",
    parent_code: "857",
  },
  {
    value: "27796",
    label: "Xã Bình Hòa Tây",
    parent_code: "798",
  },
  {
    value: "27808",
    label: "Xã Bình Hòa Trung",
    parent_code: "798",
  },
  {
    value: "22939",
    label: "Phường Bình Hưng",
    parent_code: "593",
  },
  {
    value: "27619",
    label: "Xã Bình Hưng",
    parent_code: "785",
  },
  {
    value: "27436",
    label: "Phường Bình Hưng Hòa",
    parent_code: "777",
  },
  {
    value: "27439",
    label: "Phường Bình Hưng Hoà A",
    parent_code: "777",
  },
  {
    value: "27442",
    label: "Phường Bình Hưng Hoà B",
    parent_code: "777",
  },
  {
    value: "27667",
    label: "Xã Bình Khánh",
    parent_code: "787",
  },
  {
    value: "30292",
    label: "Phường Bình Khánh",
    parent_code: "883",
  },
  {
    value: "28945",
    label: "Xã Bình Khánh ",
    parent_code: "833",
  },
  {
    value: "07081",
    label: "Xã Bình Khê",
    parent_code: "205",
  },
  {
    value: "21058",
    label: "Xã Bình Khương",
    parent_code: "524",
  },
  {
    value: "22045",
    label: "Xã Bình Kiến",
    parent_code: "555",
  },
  {
    value: "12235",
    label: "Xã Bình Kiều",
    parent_code: "330",
  },
  {
    value: "06118",
    label: "Xã Bình La",
    parent_code: "181",
  },
  {
    value: "28096",
    label: "Xã Bình Lãng",
    parent_code: "805",
  },
  {
    value: "20815",
    label: "Xã Bình Lãnh",
    parent_code: "513",
  },
  {
    value: "11092",
    label: "Xã Bình Lăng",
    parent_code: "298",
  },
  {
    value: "20767",
    label: "Xã Bình Lâm",
    parent_code: "512",
  },
  {
    value: "06838",
    label: "Thị trấn Bình Liêu",
    parent_code: "198",
  },
  {
    value: "05758",
    label: "Xã Bình Long",
    parent_code: "170",
  },
  {
    value: "21088",
    label: "Xã Bình Long",
    parent_code: "524",
  },
  {
    value: "30484",
    label: "Xã Bình Long",
    parent_code: "889",
  },
  {
    value: "22696",
    label: "Xã Bình Lộc",
    parent_code: "574",
  },
  {
    value: "26089",
    label: "Xã Bình Lộc",
    parent_code: "732",
  },
  {
    value: "26185",
    label: "Xã Bình Lợi",
    parent_code: "735",
  },
  {
    value: "27607",
    label: "Xã Bình Lợi",
    parent_code: "785",
  },
  {
    value: "03412",
    label: "Xã Bình Lư",
    parent_code: "106",
  },
  {
    value: "16204",
    label: "Xã Bình Lương",
    parent_code: "402",
  },
  {
    value: "10135",
    label: "Xã Bình Minh",
    parent_code: "278",
  },
  {
    value: "10975",
    label: "Xã Bình Minh",
    parent_code: "296",
  },
  {
    value: "12211",
    label: "Xã Bình Minh",
    parent_code: "330",
  },
  {
    value: "13138",
    label: "Xã Bình Minh",
    parent_code: "343",
  },
  {
    value: "14011",
    label: "Xã Bình Minh",
    parent_code: "362",
  },
  {
    value: "14623",
    label: "Thị trấn Bình Minh",
    parent_code: "376",
  },
  {
    value: "02658",
    label: "Phường Bình Minh",
    parent_code: "080",
  },
  {
    value: "16618",
    label: "Phường Bình Minh",
    parent_code: "407",
  },
  {
    value: "25404",
    label: "Xã Bình Minh",
    parent_code: "696",
  },
  {
    value: "25477",
    label: "Xã Bình Minh",
    parent_code: "703",
  },
  {
    value: "26278",
    label: "Xã Bình Minh",
    parent_code: "737",
  },
  {
    value: "20812",
    label: "Xã Bình Minh",
    parent_code: "513",
  },
  {
    value: "21085",
    label: "Xã Bình Minh",
    parent_code: "524",
  },
  {
    value: "31064",
    label: "Xã Bình Minh",
    parent_code: "910",
  },
  {
    value: "13501",
    label: "Thị trấn Bình Mỹ",
    parent_code: "352",
  },
  {
    value: "25897",
    label: "Xã Bình Mỹ",
    parent_code: "726",
  },
  {
    value: "27550",
    label: "Xã Bình Mỹ",
    parent_code: "783",
  },
  {
    value: "21106",
    label: "Xã Bình Mỹ",
    parent_code: "524",
  },
  {
    value: "30487",
    label: "Xã Bình Mỹ",
    parent_code: "889",
  },
  {
    value: "20851",
    label: "Xã Bình Nam",
    parent_code: "513",
  },
  {
    value: "21847",
    label: "Xã Bình Nghi",
    parent_code: "547",
  },
  {
    value: "28741",
    label: "Xã Bình Nghị",
    parent_code: "824",
  },
  {
    value: "13504",
    label: "Xã Bình Nghĩa",
    parent_code: "352",
  },
  {
    value: "06751",
    label: "Phường Bình Ngọc",
    parent_code: "194",
  },
  {
    value: "22048",
    label: "Xã Bình Ngọc",
    parent_code: "555",
  },
  {
    value: "13096",
    label: "Xã Bình Nguyên",
    parent_code: "343",
  },
  {
    value: "20800",
    label: "Xã Bình Nguyên",
    parent_code: "513",
  },
  {
    value: "21055",
    label: "Xã Bình Nguyên",
    parent_code: "524",
  },
  {
    value: "25984",
    label: "Phường Bình Nhâm",
    parent_code: "725",
  },
  {
    value: "02371",
    label: "Xã Bình Nhân",
    parent_code: "073",
  },
  {
    value: "28666",
    label: "Xã Bình Nhì",
    parent_code: "823",
  },
  {
    value: "28648",
    label: "Xã Bình Ninh",
    parent_code: "822",
  },
  {
    value: "29767",
    label: "Xã Bình Ninh",
    parent_code: "860",
  },
  {
    value: "28633",
    label: "Xã Bình Phan",
    parent_code: "822",
  },
  {
    value: "27814",
    label: "Thị trấn Bình Phong Thạnh",
    parent_code: "798",
  },
  {
    value: "10006",
    label: "Xã Bình Phú",
    parent_code: "276",
  },
  {
    value: "08275",
    label: "Xã Bình Phú",
    parent_code: "233",
  },
  {
    value: "02323",
    label: "Xã Bình Phú",
    parent_code: "073",
  },
  {
    value: "20827",
    label: "Xã Bình Phú",
    parent_code: "513",
  },
  {
    value: "28471",
    label: "Xã Bình Phú",
    parent_code: "820",
  },
  {
    value: "28657",
    label: "Xã Bình Phú",
    parent_code: "823",
  },
  {
    value: "28789",
    label: "Xã Bình Phú",
    parent_code: "829",
  },
  {
    value: "29287",
    label: "Xã Bình Phú",
    parent_code: "844",
  },
  {
    value: "29935",
    label: "Xã Bình Phú",
    parent_code: "869",
  },
  {
    value: "30496",
    label: "Xã Bình Phú",
    parent_code: "889",
  },
  {
    value: "06298",
    label: "Xã Bình Phúc",
    parent_code: "184",
  },
  {
    value: "20803",
    label: "Xã Bình Phục",
    parent_code: "513",
  },
  {
    value: "28621",
    label: "Xã Bình Phục Nhứt",
    parent_code: "822",
  },
  {
    value: "21073",
    label: "Xã Bình Phước",
    parent_code: "524",
  },
  {
    value: "29644",
    label: "Xã Bình Phước",
    parent_code: "858",
  },
  {
    value: "30667",
    label: "Xã Bình Phước Xuân",
    parent_code: "893",
  },
  {
    value: "20842",
    label: "Xã Bình Quế",
    parent_code: "513",
  },
  {
    value: "28213",
    label: "Xã Bình Quới",
    parent_code: "808",
  },
  {
    value: "20824",
    label: "Xã Bình Quý",
    parent_code: "513",
  },
  {
    value: "20836",
    label: "Xã Bình Sa",
    parent_code: "513",
  },
  {
    value: "30772",
    label: "Phường Bình San",
    parent_code: "900",
  },
  {
    value: "05530",
    label: "Xã Bình Sơn",
    parent_code: "165",
  },
  {
    value: "07492",
    label: "Xã Bình Sơn",
    parent_code: "218",
  },
  {
    value: "04990",
    label: "Xã Bình Sơn",
    parent_code: "153",
  },
  {
    value: "15769",
    label: "Xã Bình Sơn",
    parent_code: "397",
  },
  {
    value: "17338",
    label: "Xã Bình Sơn",
    parent_code: "424",
  },
  {
    value: "25244",
    label: "Xã Bình Sơn",
    parent_code: "698",
  },
  {
    value: "26395",
    label: "Xã Bình Sơn",
    parent_code: "740",
  },
  {
    value: "20788",
    label: "Xã Bình Sơn",
    parent_code: "512",
  },
  {
    value: "30823",
    label: "Xã Bình Sơn",
    parent_code: "903",
  },
  {
    value: "27712",
    label: "Xã Bình Tâm",
    parent_code: "794",
  },
  {
    value: "25243",
    label: "Xã Bình Tân",
    parent_code: "698",
  },
  {
    value: "23237",
    label: "Phường Bình Tân",
    parent_code: "594",
  },
  {
    value: "23047",
    label: "Xã Bình Tân",
    parent_code: "596",
  },
  {
    value: "24332",
    label: "Phường Bình Tân",
    parent_code: "644",
  },
  {
    value: "27799",
    label: "Xã Bình Tân",
    parent_code: "795",
  },
  {
    value: "21811",
    label: "Xã Bình Tân",
    parent_code: "547",
  },
  {
    value: "28681",
    label: "Xã Bình Tân",
    parent_code: "823",
  },
  {
    value: "30148",
    label: "Xã Bình Tấn",
    parent_code: "874",
  },
  {
    value: "21109",
    label: "Xã Bình Tân Phú",
    parent_code: "524",
  },
  {
    value: "05092",
    label: "Xã Bình Thanh",
    parent_code: "154",
  },
  {
    value: "13183",
    label: "Xã Bình Thanh",
    parent_code: "343",
  },
  {
    value: "05605",
    label: "Xã Bình Thành",
    parent_code: "167",
  },
  {
    value: "20041",
    label: "Xã Bình Thành",
    parent_code: "480",
  },
  {
    value: "21823",
    label: "Xã Bình Thành",
    parent_code: "547",
  },
  {
    value: "27916",
    label: "Xã Bình Thành",
    parent_code: "801",
  },
  {
    value: "29032",
    label: "Xã Bình Thành",
    parent_code: "834",
  },
  {
    value: "30163",
    label: "Xã Bình Thành",
    parent_code: "874",
  },
  {
    value: "30193",
    label: "Xã Bình Thành",
    parent_code: "875",
  },
  {
    value: "30724",
    label: "Xã Bình Thành",
    parent_code: "894",
  },
  {
    value: "31402",
    label: "Xã Bình Thành",
    parent_code: "934",
  },
  {
    value: "24970",
    label: "Xã Bình Thạnh",
    parent_code: "678",
  },
  {
    value: "22999",
    label: "Xã Bình Thạnh",
    parent_code: "595",
  },
  {
    value: "21046",
    label: "Xã Bình Thạnh",
    parent_code: "524",
  },
  {
    value: "27802",
    label: "Xã Bình Thạnh",
    parent_code: "798",
  },
  {
    value: "28063",
    label: "Xã Bình Thạnh",
    parent_code: "804",
  },
  {
    value: "29212",
    label: "Xã Bình Thạnh",
    parent_code: "837",
  },
  {
    value: "29959",
    label: "Xã Bình Thạnh",
    parent_code: "868",
  },
  {
    value: "30127",
    label: "Xã Bình Thạnh",
    parent_code: "873",
  },
  {
    value: "30601",
    label: "Xã Bình Thạnh",
    parent_code: "892",
  },
  {
    value: "31473",
    label: "Phường Bình Thạnh",
    parent_code: "937",
  },
  {
    value: "21091",
    label: "Xã Bình Thanh ",
    parent_code: "524",
  },
  {
    value: "30454",
    label: "Xã Bình Thạnh Đông",
    parent_code: "888",
  },
  {
    value: "30205",
    label: "Xã Bình Thạnh Trung",
    parent_code: "875",
  },
  {
    value: "25234",
    label: "Xã Bình Thắng",
    parent_code: "691",
  },
  {
    value: "25954",
    label: "Phường Bình Thắng",
    parent_code: "724",
  },
  {
    value: "29092",
    label: "Xã Bình Thắng",
    parent_code: "835",
  },
  {
    value: "26824",
    label: "Phường Bình Thọ",
    parent_code: "769",
  },
  {
    value: "29086",
    label: "Xã Bình Thới",
    parent_code: "835",
  },
  {
    value: "05830",
    label: "Xã Bình Thuận",
    parent_code: "171",
  },
  {
    value: "04702",
    label: "Xã Bình Thuận",
    parent_code: "140",
  },
  {
    value: "27478",
    label: "Phường Bình Thuận",
    parent_code: "778",
  },
  {
    value: "20254",
    label: "Phường Bình Thuận",
    parent_code: "492",
  },
  {
    value: "24337",
    label: "Xã Bình Thuận",
    parent_code: "644",
  },
  {
    value: "21043",
    label: "Xã Bình Thuận",
    parent_code: "524",
  },
  {
    value: "21817",
    label: "Xã Bình Thuận",
    parent_code: "547",
  },
  {
    value: "30490",
    label: "Xã Bình Thủy",
    parent_code: "889",
  },
  {
    value: "31168",
    label: "Phường Bình Thủy",
    parent_code: "918",
  },
  {
    value: "20035",
    label: "Xã Bình Tiến",
    parent_code: "480",
  },
  {
    value: "28099",
    label: "Xã Bình Tịnh",
    parent_code: "805",
  },
  {
    value: "20818",
    label: "Xã Bình Trị",
    parent_code: "513",
  },
  {
    value: "21061",
    label: "Xã Bình Trị",
    parent_code: "524",
  },
  {
    value: "30809",
    label: "Xã Bình Trị",
    parent_code: "902",
  },
  {
    value: "27445",
    label: "Phường Bình Trị Đông",
    parent_code: "777",
  },
  {
    value: "27448",
    label: "Phường Bình Trị Đông A",
    parent_code: "777",
  },
  {
    value: "27451",
    label: "Phường Bình Trị Đông B",
    parent_code: "777",
  },
  {
    value: "20806",
    label: "Xã Bình Triều",
    parent_code: "513",
  },
  {
    value: "28090",
    label: "Xã Bình Trinh Đông",
    parent_code: "805",
  },
  {
    value: "06217",
    label: "Xã Bình Trung",
    parent_code: "183",
  },
  {
    value: "02080",
    label: "Xã Bình Trung",
    parent_code: "064",
  },
  {
    value: "26593",
    label: "Xã Bình Trung",
    parent_code: "750",
  },
  {
    value: "20848",
    label: "Xã Bình Trung",
    parent_code: "513",
  },
  {
    value: "21082",
    label: "Xã Bình Trung",
    parent_code: "524",
  },
  {
    value: "28564",
    label: "Xã Bình Trưng",
    parent_code: "821",
  },
  {
    value: "27097",
    label: "Phường Bình Trưng Đông",
    parent_code: "769",
  },
  {
    value: "27100",
    label: "Phường Bình Trưng Tây",
    parent_code: "769",
  },
  {
    value: "20833",
    label: "Xã Bình Tú",
    parent_code: "513",
  },
  {
    value: "21835",
    label: "Xã Bình Tường",
    parent_code: "547",
  },
  {
    value: "02125",
    label: "Xã Bình Văn",
    parent_code: "065",
  },
  {
    value: "02404",
    label: "Xã Bình Xa",
    parent_code: "074",
  },
  {
    value: "06622",
    label: "Xã Bính Xá",
    parent_code: "189",
  },
  {
    value: "28717",
    label: "Xã Bình Xuân",
    parent_code: "816",
  },
  {
    value: "10996",
    label: "Xã Bình Xuyên",
    parent_code: "296",
  },
  {
    value: "09982",
    label: "Xã Bình Yên",
    parent_code: "276",
  },
  {
    value: "05587",
    label: "Xã Bình Yên",
    parent_code: "167",
  },
  {
    value: "02554",
    label: "Xã Bình Yên",
    parent_code: "076",
  },
  {
    value: "04978",
    label: "Thị trấn Bo",
    parent_code: "153",
  },
  {
    value: "03778",
    label: "Xã Bó Mười",
    parent_code: "119",
  },
  {
    value: "04171",
    label: "Xã Bó Sinh",
    parent_code: "126",
  },
  {
    value: "21718",
    label: "Xã Bok Tới",
    parent_code: "544",
  },
  {
    value: "25405",
    label: "Xã Bom Bo",
    parent_code: "696",
  },
  {
    value: "03793",
    label: "Xã Bon Phặng",
    parent_code: "119",
  },
  {
    value: "00139",
    label: "Phường Bồ Đề",
    parent_code: "004",
  },
  {
    value: "13531",
    label: "Xã Bồ Đề",
    parent_code: "352",
  },
  {
    value: "07294",
    label: "Thị trấn Bố Hạ",
    parent_code: "215",
  },
  {
    value: "08920",
    label: "Xã Bồ Lý",
    parent_code: "248",
  },
  {
    value: "09097",
    label: "Xã Bồ Sao",
    parent_code: "252",
  },
  {
    value: "12436",
    label: "Phường Bồ Xuyên",
    parent_code: "336",
  },
  {
    value: "01864",
    label: "Xã Bộc Bố",
    parent_code: "060",
  },
  {
    value: "05596",
    label: "Xã Bộc Nhiêu",
    parent_code: "167",
  },
  {
    value: "13534",
    label: "Xã Bối Cầu",
    parent_code: "352",
  },
  {
    value: "17626",
    label: "Xã Bồi Sơn",
    parent_code: "427",
  },
  {
    value: "17254",
    label: "Xã Bồng Khê",
    parent_code: "422",
  },
  {
    value: "24586",
    label: "Xã Bông Krang",
    parent_code: "656",
  },
  {
    value: "09295",
    label: "Xã Bồng Lai",
    parent_code: "259",
  },
  {
    value: "21640",
    label: "Phường Bồng Sơn",
    parent_code: "543",
  },
  {
    value: "26632",
    label: "Xã Bông Trang",
    parent_code: "751",
  },
  {
    value: "10459",
    label: "Xã Bột Xuyên",
    parent_code: "282",
  },
  {
    value: "23947",
    label: "Xã Bờ Ngoong",
    parent_code: "633",
  },
  {
    value: "23395",
    label: "Xã Bờ Y",
    parent_code: "611",
  },
  {
    value: "25222",
    label: "Xã Bù Gia Mập",
    parent_code: "691",
  },
  {
    value: "25252",
    label: "Xã Bù Nho",
    parent_code: "698",
  },
  {
    value: "31178",
    label: "Phường Bùi Hữu Nghĩa",
    parent_code: "918",
  },
  {
    value: "18262",
    label: "Xã Bùi La Nhân",
    parent_code: "440",
  },
  {
    value: "21589",
    label: "Phường Bùi Thị Xuân",
    parent_code: "540",
  },
  {
    value: "03466",
    label: "Xã Bum Nưa",
    parent_code: "107",
  },
  {
    value: "03454",
    label: "Xã Bum Tở",
    parent_code: "107",
  },
  {
    value: "03301",
    label: "Xã Búng Lao",
    parent_code: "102",
  },
  {
    value: "31433",
    label: "Thị trấn Búng Tàu",
    parent_code: "934",
  },
  {
    value: "24694",
    label: "Xã Buôn Choah",
    parent_code: "664",
  },
  {
    value: "24538",
    label: "Thị trấn Buôn Trấp",
    parent_code: "655",
  },
  {
    value: "24595",
    label: "Xã Buôn Tría",
    parent_code: "656",
  },
  {
    value: "24592",
    label: "Xã Buôn Triết",
    parent_code: "656",
  },
  {
    value: "15865",
    label: "Thị trấn Bút Sơn",
    parent_code: "399",
  },
  {
    value: "26653",
    label: "Xã Bưng Riềng",
    parent_code: "751",
  },
  {
    value: "00109",
    label: "Phường Bưởi",
    parent_code: "003",
  },
  {
    value: "26053",
    label: "Phường Bửu Hòa",
    parent_code: "731",
  },
  {
    value: "26011",
    label: "Phường Bửu Long",
    parent_code: "731",
  },
  {
    value: "20713",
    label: "Xã Cà Dy",
    parent_code: "510",
  },
  {
    value: "08050",
    label: "Xã Ca Đình",
    parent_code: "230",
  },
  {
    value: "22180",
    label: "Xã Cà Lúi",
    parent_code: "560",
  },
  {
    value: "22910",
    label: "Xã Cà Ná",
    parent_code: "589",
  },
  {
    value: "03685",
    label: "Xã Cà Nàng",
    parent_code: "118",
  },
  {
    value: "01738",
    label: "Xã Ca Thành",
    parent_code: "052",
  },
  {
    value: "16591",
    label: "Xã Các Sơn",
    parent_code: "407",
  },
  {
    value: "09298",
    label: "Xã Cách Bi",
    parent_code: "259",
  },
  {
    value: "01636",
    label: "Xã Cách Linh",
    parent_code: "049",
  },
  {
    value: "28360",
    label: "Thị trấn Cái Bè",
    parent_code: "819",
  },
  {
    value: "01597",
    label: "Xã Cai Bộ",
    parent_code: "049",
  },
  {
    value: "06967",
    label: "Xã Cái Chiên",
    parent_code: "201",
  },
  {
    value: "30463",
    label: "Thị trấn Cái Dầu",
    parent_code: "889",
  },
  {
    value: "05515",
    label: "Phường Cải Đan",
    parent_code: "165",
  },
  {
    value: "32212",
    label: "Thị trấn Cái Đôi Vàm",
    parent_code: "972",
  },
  {
    value: "31117",
    label: "Phường Cái Khế",
    parent_code: "916",
  },
  {
    value: "06427",
    label: "Xã Cai Kinh",
    parent_code: "186",
  },
  {
    value: "29641",
    label: "Thị trấn Cái Nhum",
    parent_code: "858",
  },
  {
    value: "32128",
    label: "Thị trấn Cái Nước",
    parent_code: "969",
  },
  {
    value: "06994",
    label: "Thị trấn Cái Rồng",
    parent_code: "203",
  },
  {
    value: "30244",
    label: "Thị trấn Cái Tàu Hạ",
    parent_code: "877",
  },
  {
    value: "31362",
    label: "Thị trấn Cái Tắc",
    parent_code: "932",
  },
  {
    value: "01402",
    label: "Xã Cải Viên",
    parent_code: "045",
  },
  {
    value: "29770",
    label: "Phường Cái Vồn",
    parent_code: "861",
  },
  {
    value: "22465",
    label: "Xã Cam An Bắc",
    parent_code: "570",
  },
  {
    value: "22471",
    label: "Xã Cam An Nam",
    parent_code: "570",
  },
  {
    value: "04750",
    label: "Xã Cảm Ân",
    parent_code: "141",
  },
  {
    value: "22486",
    label: "Xã Cam Bình",
    parent_code: "569",
  },
  {
    value: "19618",
    label: "Xã Cam Chính",
    parent_code: "468",
  },
  {
    value: "02974",
    label: "Xã Cam Cọn",
    parent_code: "087",
  },
  {
    value: "22453",
    label: "Thị trấn Cam Đức",
    parent_code: "570",
  },
  {
    value: "02674",
    label: "Xã Cam Đường",
    parent_code: "080",
  },
  {
    value: "05467",
    label: "Phường Cam Giá",
    parent_code: "164",
  },
  {
    value: "22441",
    label: "Xã Cam Hải Đông",
    parent_code: "570",
  },
  {
    value: "22444",
    label: "Xã Cam Hải Tây",
    parent_code: "570",
  },
  {
    value: "22450",
    label: "Xã Cam Hiệp Bắc",
    parent_code: "570",
  },
  {
    value: "22456",
    label: "Xã Cam Hiệp Nam",
    parent_code: "570",
  },
  {
    value: "19615",
    label: "Xã Cam Hiếu",
    parent_code: "468",
  },
  {
    value: "22438",
    label: "Xã Cam Hòa",
    parent_code: "570",
  },
  {
    value: "17236",
    label: "Xã Cam Lâm",
    parent_code: "422",
  },
  {
    value: "22483",
    label: "Xã Cam Lập",
    parent_code: "569",
  },
  {
    value: "22432",
    label: "Phường Cam Linh",
    parent_code: "569",
  },
  {
    value: "19597",
    label: "Thị trấn Cam Lộ",
    parent_code: "468",
  },
  {
    value: "22417",
    label: "Phường Cam Lộc",
    parent_code: "569",
  },
  {
    value: "22429",
    label: "Phường Cam Lợi",
    parent_code: "569",
  },
  {
    value: "22408",
    label: "Phường Cam Nghĩa",
    parent_code: "569",
  },
  {
    value: "19621",
    label: "Xã Cam Nghĩa",
    parent_code: "468",
  },
  {
    value: "04726",
    label: "Xã Cảm Nhân",
    parent_code: "141",
  },
  {
    value: "22420",
    label: "Phường Cam Phú",
    parent_code: "569",
  },
  {
    value: "22411",
    label: "Phường Cam Phúc Bắc",
    parent_code: "569",
  },
  {
    value: "22414",
    label: "Phường Cam Phúc Nam",
    parent_code: "569",
  },
  {
    value: "22474",
    label: "Xã Cam Phước Đông",
    parent_code: "569",
  },
  {
    value: "22459",
    label: "Xã Cam Phước Tây",
    parent_code: "570",
  },
  {
    value: "22435",
    label: "Xã Cam Tân",
    parent_code: "570",
  },
  {
    value: "19612",
    label: "Xã Cam Thành",
    parent_code: "468",
  },
  {
    value: "22462",
    label: "Xã Cam Thành Bắc",
    parent_code: "570",
  },
  {
    value: "22468",
    label: "Xã Cam Thành Nam",
    parent_code: "569",
  },
  {
    value: "22480",
    label: "Xã Cam Thịnh Đông",
    parent_code: "569",
  },
  {
    value: "22477",
    label: "Xã Cam Thịnh Tây",
    parent_code: "569",
  },
  {
    value: "22426",
    label: "Phường Cam Thuận",
    parent_code: "569",
  },
  {
    value: "19606",
    label: "Xã Cam Thủy",
    parent_code: "468",
  },
  {
    value: "19270",
    label: "Xã Cam Thủy",
    parent_code: "457",
  },
  {
    value: "09688",
    label: "Xã Cam Thượng",
    parent_code: "271",
  },
  {
    value: "19600",
    label: "Xã Cam Tuyền",
    parent_code: "468",
  },
  {
    value: "02821",
    label: "Xã Cán Cấu",
    parent_code: "084",
  },
  {
    value: "00799",
    label: "Xã Cán Chu Phìn",
    parent_code: "027",
  },
  {
    value: "16231",
    label: "Xã Cán Khê",
    parent_code: "403",
  },
  {
    value: "00883",
    label: "Xã Cán Tỷ",
    parent_code: "029",
  },
  {
    value: "29266",
    label: "Thị trấn Càng Long",
    parent_code: "844",
  },
  {
    value: "19036",
    label: "Xã Cảnh Dương",
    parent_code: "454",
  },
  {
    value: "22006",
    label: "Xã Canh Hiển",
    parent_code: "551",
  },
  {
    value: "22000",
    label: "Xã Canh Hiệp",
    parent_code: "551",
  },
  {
    value: "22012",
    label: "Xã Canh Hòa",
    parent_code: "551",
  },
  {
    value: "19048",
    label: "Xã Cảnh Hóa",
    parent_code: "454",
  },
  {
    value: "09364",
    label: "Xã Cảnh Hưng",
    parent_code: "260",
  },
  {
    value: "21997",
    label: "Xã Canh Liên",
    parent_code: "551",
  },
  {
    value: "14923",
    label: "Thị trấn Cành Nàng",
    parent_code: "386",
  },
  {
    value: "09973",
    label: "Xã Canh Nậu",
    parent_code: "276",
  },
  {
    value: "07246",
    label: "Xã Canh Nậu",
    parent_code: "215",
  },
  {
    value: "01789",
    label: "Xã Canh Tân",
    parent_code: "053",
  },
  {
    value: "12601",
    label: "Xã Canh Tân",
    parent_code: "339",
  },
  {
    value: "22009",
    label: "Xã Canh Thuận",
    parent_code: "551",
  },
  {
    value: "07738",
    label: "Xã Cảnh Thụy",
    parent_code: "221",
  },
  {
    value: "22003",
    label: "Xã Canh Vinh",
    parent_code: "551",
  },
  {
    value: "10927",
    label: "Xã Cao An",
    parent_code: "295",
  },
  {
    value: "00952",
    label: "Xã Cao Bồ",
    parent_code: "030",
  },
  {
    value: "01471",
    label: "Xã Cao Chương",
    parent_code: "047",
  },
  {
    value: "10174",
    label: "Xã Cao Dương",
    parent_code: "278",
  },
  {
    value: "05008",
    label: "Xã Cao Dương",
    parent_code: "152",
  },
  {
    value: "09109",
    label: "Xã Cao Đại",
    parent_code: "252",
  },
  {
    value: "09466",
    label: "Xã Cao Đức",
    parent_code: "263",
  },
  {
    value: "02104",
    label: "Xã Cao Kỳ",
    parent_code: "065",
  },
  {
    value: "06196",
    label: "Xã Cao Lâu",
    parent_code: "183",
  },
  {
    value: "06187",
    label: "Thị trấn Cao Lộc",
    parent_code: "183",
  },
  {
    value: "00886",
    label: "Xã Cao Mã Pờ",
    parent_code: "029",
  },
  {
    value: "08752",
    label: "Xã Cao Minh",
    parent_code: "244",
  },
  {
    value: "11902",
    label: "Xã Cao Minh",
    parent_code: "316",
  },
  {
    value: "06010",
    label: "Xã Cao Minh",
    parent_code: "180",
  },
  {
    value: "05695",
    label: "Xã Cao Ngạn",
    parent_code: "164",
  },
  {
    value: "15079",
    label: "Xã Cao Ngọc",
    parent_code: "389",
  },
  {
    value: "11518",
    label: "Xã Cao Nhân",
    parent_code: "311",
  },
  {
    value: "04480",
    label: "Xã Cao Phạ",
    parent_code: "137",
  },
  {
    value: "08860",
    label: "Xã Cao Phong",
    parent_code: "253",
  },
  {
    value: "05089",
    label: "Thị trấn Cao Phong",
    parent_code: "154",
  },
  {
    value: "19003",
    label: "Xã Cao Quảng",
    parent_code: "453",
  },
  {
    value: "02002",
    label: "Xã Cao Sơn",
    parent_code: "063",
  },
  {
    value: "02782",
    label: "Xã Cao Sơn",
    parent_code: "083",
  },
  {
    value: "04876",
    label: "Xã Cao Sơn",
    parent_code: "150",
  },
  {
    value: "04957",
    label: "Xã Cao Sơn",
    parent_code: "152",
  },
  {
    value: "17386",
    label: "Xã Cao Sơn",
    parent_code: "424",
  },
  {
    value: "01885",
    label: "Xã Cao Tân",
    parent_code: "060",
  },
  {
    value: "10372",
    label: "Xã Cao Thành",
    parent_code: "281",
  },
  {
    value: "01519",
    label: "Xã Cao Thăng",
    parent_code: "047",
  },
  {
    value: "11278",
    label: "Xã Cao Thắng",
    parent_code: "300",
  },
  {
    value: "06676",
    label: "Phường Cao Thắng",
    parent_code: "193",
  },
  {
    value: "15100",
    label: "Xã Cao Thịnh",
    parent_code: "389",
  },
  {
    value: "01900",
    label: "Xã Cao Thượng",
    parent_code: "061",
  },
  {
    value: "07339",
    label: "Thị trấn Cao Thượng",
    parent_code: "216",
  },
  {
    value: "10132",
    label: "Xã Cao Viên",
    parent_code: "278",
  },
  {
    value: "08527",
    label: "Xã Cao Xá",
    parent_code: "237",
  },
  {
    value: "07336",
    label: "Xã Cao Xá",
    parent_code: "216",
  },
  {
    value: "06658",
    label: "Phường Cao Xanh",
    parent_code: "193",
  },
  {
    value: "11914",
    label: "Thị trấn Cát Bà",
    parent_code: "317",
  },
  {
    value: "11422",
    label: "Phường Cát Bi",
    parent_code: "306",
  },
  {
    value: "21904",
    label: "Xã Cát Chánh",
    parent_code: "548",
  },
  {
    value: "11368",
    label: "Phường Cát Dài",
    parent_code: "305",
  },
  {
    value: "11917",
    label: "Thị trấn Cát Hải",
    parent_code: "317",
  },
  {
    value: "21880",
    label: "Xã Cát Hải",
    parent_code: "548",
  },
  {
    value: "21871",
    label: "Xã Cát Hanh",
    parent_code: "548",
  },
  {
    value: "21883",
    label: "Xã Cát Hiệp",
    parent_code: "548",
  },
  {
    value: "21889",
    label: "Xã Cát Hưng",
    parent_code: "548",
  },
  {
    value: "21862",
    label: "Xã Cát Khánh",
    parent_code: "548",
  },
  {
    value: "27109",
    label: "Phường Cát Lái",
    parent_code: "769",
  },
  {
    value: "21868",
    label: "Xã Cát Lâm",
    parent_code: "548",
  },
  {
    value: "00178",
    label: "Phường Cát Linh",
    parent_code: "006",
  },
  {
    value: "21859",
    label: "Xã Cát Minh",
    parent_code: "548",
  },
  {
    value: "05848",
    label: "Xã Cát Nê",
    parent_code: "171",
  },
  {
    value: "21886",
    label: "Xã Cát Nhơn",
    parent_code: "548",
  },
  {
    value: "09850",
    label: "Xã Cát Quế",
    parent_code: "274",
  },
  {
    value: "21856",
    label: "Xã Cát Sơn",
    parent_code: "548",
  },
  {
    value: "21865",
    label: "Xã Cát Tài",
    parent_code: "548",
  },
  {
    value: "16198",
    label: "Xã Cát Tân",
    parent_code: "402",
  },
  {
    value: "21895",
    label: "Xã Cát Tân",
    parent_code: "548",
  },
  {
    value: "14056",
    label: "Thị trấn Cát Thành",
    parent_code: "363",
  },
  {
    value: "21874",
    label: "Xã Cát Thành",
    parent_code: "548",
  },
  {
    value: "21901",
    label: "Xã Cát Thắng",
    parent_code: "548",
  },
  {
    value: "04693",
    label: "Xã Cát Thịnh",
    parent_code: "140",
  },
  {
    value: "25159",
    label: "Thị trấn Cát Tiên",
    parent_code: "683",
  },
  {
    value: "21898",
    label: "Thị trấn Cát Tiến",
    parent_code: "548",
  },
  {
    value: "21877",
    label: "Xã Cát Trinh",
    parent_code: "548",
  },
  {
    value: "21892",
    label: "Xã Cát Tường",
    parent_code: "548",
  },
  {
    value: "17716",
    label: "Xã Cát Văn",
    parent_code: "428",
  },
  {
    value: "16195",
    label: "Xã Cát Vân",
    parent_code: "402",
  },
  {
    value: "16774",
    label: "Xã Căm Muộn",
    parent_code: "415",
  },
  {
    value: "03538",
    label: "Xã Căn Co",
    parent_code: "108",
  },
  {
    value: "20419",
    label: "Phường Cẩm An",
    parent_code: "503",
  },
  {
    value: "06796",
    label: "Phường Cẩm Bình",
    parent_code: "195",
  },
  {
    value: "15151",
    label: "Xã Cẩm Bình",
    parent_code: "390",
  },
  {
    value: "18685",
    label: "Xã Cẩm Bình",
    parent_code: "446",
  },
  {
    value: "15160",
    label: "Xã Cẩm Châu",
    parent_code: "390",
  },
  {
    value: "20413",
    label: "Phường Cẩm Châu",
    parent_code: "503",
  },
  {
    value: "10828",
    label: "Xã Cẩm Chế",
    parent_code: "294",
  },
  {
    value: "18715",
    label: "Xã Cẩm Duệ",
    parent_code: "446",
  },
  {
    value: "18682",
    label: "Xã Cẩm Dương",
    parent_code: "446",
  },
  {
    value: "07642",
    label: "Xã Cẩm Đàn",
    parent_code: "220",
  },
  {
    value: "10936",
    label: "Xã Cẩm Điền",
    parent_code: "295",
  },
  {
    value: "10942",
    label: "Xã Cẩm Đoài",
    parent_code: "295",
  },
  {
    value: "10939",
    label: "Xã Cẩm Đông",
    parent_code: "295",
  },
  {
    value: "06769",
    label: "Phường Cẩm Đông",
    parent_code: "195",
  },
  {
    value: "26401",
    label: "Xã Cẩm Đường",
    parent_code: "740",
  },
  {
    value: "10888",
    label: "Thị trấn Cẩm Giang",
    parent_code: "295",
  },
  {
    value: "15148",
    label: "Xã Cẩm Giang",
    parent_code: "390",
  },
  {
    value: "25660",
    label: "Xã Cẩm Giang",
    parent_code: "710",
  },
  {
    value: "02008",
    label: "Xã Cẩm Giàng",
    parent_code: "063",
  },
  {
    value: "18727",
    label: "Xã Cẩm Hà",
    parent_code: "446",
  },
  {
    value: "20422",
    label: "Xã Cẩm Hà",
    parent_code: "503",
  },
  {
    value: "06802",
    label: "Xã Cẩm Hải",
    parent_code: "195",
  },
  {
    value: "10897",
    label: "Xã Cẩm Hoàng",
    parent_code: "295",
  },
  {
    value: "10894",
    label: "Xã Cẩm Hưng",
    parent_code: "295",
  },
  {
    value: "18733",
    label: "Xã Cẩm Hưng",
    parent_code: "446",
  },
  {
    value: "08341",
    label: "Thị trấn Cẩm Khê",
    parent_code: "235",
  },
  {
    value: "20425",
    label: "Xã Cẩm Kim",
    parent_code: "503",
  },
  {
    value: "07171",
    label: "Xã Cẩm La",
    parent_code: "206",
  },
  {
    value: "18748",
    label: "Xã Cẩm Lạc",
    parent_code: "446",
  },
  {
    value: "15145",
    label: "Xã Cẩm Liên",
    parent_code: "390",
  },
  {
    value: "09673",
    label: "Xã Cẩm Lĩnh",
    parent_code: "271",
  },
  {
    value: "18721",
    label: "Xã Cẩm Lĩnh",
    parent_code: "446",
  },
  {
    value: "15172",
    label: "Xã Cẩm Long",
    parent_code: "390",
  },
  {
    value: "18730",
    label: "Xã Cẩm Lộc",
    parent_code: "446",
  },
  {
    value: "15139",
    label: "Xã Cẩm Lương",
    parent_code: "390",
  },
  {
    value: "07519",
    label: "Xã Cẩm Lý",
    parent_code: "218",
  },
  {
    value: "18751",
    label: "Xã Cẩm Minh",
    parent_code: "446",
  },
  {
    value: "18739",
    label: "Xã Cẩm Mỹ",
    parent_code: "446",
  },
  {
    value: "20428",
    label: "Phường Cẩm Nam",
    parent_code: "503",
  },
  {
    value: "15169",
    label: "Xã Cẩm Ngọc",
    parent_code: "390",
  },
  {
    value: "18709",
    label: "Xã Cẩm Nhượng",
    parent_code: "446",
  },
  {
    value: "12181",
    label: "Xã Cẩm Ninh",
    parent_code: "329",
  },
  {
    value: "20404",
    label: "Phường Cẩm Phô",
    parent_code: "503",
  },
  {
    value: "06772",
    label: "Phường Cẩm Phú",
    parent_code: "195",
  },
  {
    value: "15181",
    label: "Xã Cẩm Phú",
    parent_code: "390",
  },
  {
    value: "10933",
    label: "Xã Cẩm Phúc",
    parent_code: "295",
  },
  {
    value: "18724",
    label: "Xã Cẩm Quan",
    parent_code: "446",
  },
  {
    value: "18697",
    label: "Xã Cẩm Quang",
    parent_code: "446",
  },
  {
    value: "15136",
    label: "Xã Cẩm Quý",
    parent_code: "390",
  },
  {
    value: "06766",
    label: "Phường Cẩm Sơn",
    parent_code: "195",
  },
  {
    value: "17350",
    label: "Xã Cẩm Sơn",
    parent_code: "424",
  },
  {
    value: "18745",
    label: "Xã Cẩm Sơn",
    parent_code: "446",
  },
  {
    value: "28489",
    label: "Xã Cẩm Sơn",
    parent_code: "820",
  },
  {
    value: "28978",
    label: "Xã Cẩm Sơn",
    parent_code: "833",
  },
  {
    value: "07528",
    label: "Xã Cấm Sơn",
    parent_code: "219",
  },
  {
    value: "15163",
    label: "Xã Cẩm Tâm",
    parent_code: "390",
  },
  {
    value: "15178",
    label: "Xã Cẩm Tân",
    parent_code: "390",
  },
  {
    value: "06775",
    label: "Phường Cẩm Tây",
    parent_code: "195",
  },
  {
    value: "06787",
    label: "Phường Cẩm Thạch",
    parent_code: "195",
  },
  {
    value: "15142",
    label: "Xã Cẩm Thạch",
    parent_code: "390",
  },
  {
    value: "18706",
    label: "Xã Cẩm Thạch",
    parent_code: "446",
  },
  {
    value: "20431",
    label: "Xã Cẩm Thanh",
    parent_code: "503",
  },
  {
    value: "06790",
    label: "Phường Cẩm Thành",
    parent_code: "195",
  },
  {
    value: "15133",
    label: "Xã Cẩm Thành",
    parent_code: "390",
  },
  {
    value: "18694",
    label: "Xã Cẩm Thành",
    parent_code: "446",
  },
  {
    value: "06781",
    label: "Phường Cẩm Thịnh",
    parent_code: "195",
  },
  {
    value: "18736",
    label: "Xã Cẩm Thịnh",
    parent_code: "446",
  },
  {
    value: "06784",
    label: "Phường Cẩm Thủy",
    parent_code: "195",
  },
  {
    value: "10507",
    label: "Phường Cẩm Thượng",
    parent_code: "288",
  },
  {
    value: "06793",
    label: "Phường Cẩm Trung",
    parent_code: "195",
  },
  {
    value: "18742",
    label: "Xã Cẩm Trung",
    parent_code: "446",
  },
  {
    value: "15154",
    label: "Xã Cẩm Tú",
    parent_code: "390",
  },
  {
    value: "10900",
    label: "Xã Cẩm Văn",
    parent_code: "295",
  },
  {
    value: "15184",
    label: "Xã Cẩm Vân",
    parent_code: "390",
  },
  {
    value: "18691",
    label: "Xã Cẩm Vĩnh",
    parent_code: "446",
  },
  {
    value: "10909",
    label: "Xã Cẩm Vũ",
    parent_code: "295",
  },
  {
    value: "12109",
    label: "Xã Cẩm Xá",
    parent_code: "328",
  },
  {
    value: "18673",
    label: "Thị trấn Cẩm Xuyên",
    parent_code: "446",
  },
  {
    value: "09961",
    label: "Xã Cẩm Yên",
    parent_code: "276",
  },
  {
    value: "15175",
    label: "Xã Cẩm Yên",
    parent_code: "390",
  },
  {
    value: "30595",
    label: "Xã Cần Đăng",
    parent_code: "892",
  },
  {
    value: "28108",
    label: "Thị trấn Cần Đước",
    parent_code: "806",
  },
  {
    value: "28159",
    label: "Thị trấn Cần Giuộc",
    parent_code: "807",
  },
  {
    value: "09943",
    label: "Xã Cấn Hữu",
    parent_code: "275",
  },
  {
    value: "09991",
    label: "Xã Cần Kiệm",
    parent_code: "276",
  },
  {
    value: "01367",
    label: "Xã Cần Nông",
    parent_code: "045",
  },
  {
    value: "27664",
    label: "Thị trấn Cần Thạnh",
    parent_code: "787",
  },
  {
    value: "01366",
    label: "Xã Cần Yên",
    parent_code: "045",
  },
  {
    value: "08383",
    label: "Xã Cấp Dẫn",
    parent_code: "235",
  },
  {
    value: "11779",
    label: "Xã Cấp Tiến",
    parent_code: "315",
  },
  {
    value: "02563",
    label: "Xã Cấp Tiến",
    parent_code: "076",
  },
  {
    value: "22636",
    label: "Xã Cầu Bà",
    parent_code: "573",
  },
  {
    value: "00274",
    label: "Phường Cầu Dền",
    parent_code: "007",
  },
  {
    value: "00592",
    label: "Phường Cầu Diễn",
    parent_code: "019",
  },
  {
    value: "11353",
    label: "Phường Cầu Đất",
    parent_code: "304",
  },
  {
    value: "17098",
    label: "Thị trấn Cầu Giát",
    parent_code: "421",
  },
  {
    value: "29308",
    label: "Thị trấn Cầu Kè",
    parent_code: "845",
  },
  {
    value: "26761",
    label: "Phường Cầu Kho",
    parent_code: "760",
  },
  {
    value: "25573",
    label: "Xã Cầu Khởi",
    parent_code: "707",
  },
  {
    value: "16033",
    label: "Xã Cầu Lộc",
    parent_code: "400",
  },
  {
    value: "03028",
    label: "Phường Cầu Mây",
    parent_code: "088",
  },
  {
    value: "29416",
    label: "Thị trấn Cầu Ngang",
    parent_code: "848",
  },
  {
    value: "26752",
    label: "Phường Cầu Ông Lãnh",
    parent_code: "760",
  },
  {
    value: "29344",
    label: "Thị trấn Cầu Quan",
    parent_code: "846",
  },
  {
    value: "04291",
    label: "Phường Cầu Thia",
    parent_code: "133",
  },
  {
    value: "11338",
    label: "Phường Cầu Tre",
    parent_code: "304",
  },
  {
    value: "31396",
    label: "Thị trấn Cây Dương",
    parent_code: "934",
  },
  {
    value: "26254",
    label: "Xã Cây Gáo",
    parent_code: "737",
  },
  {
    value: "05689",
    label: "Xã Cây Thị",
    parent_code: "169",
  },
  {
    value: "25819",
    label: "Xã Cây Trường II",
    parent_code: "719",
  },
  {
    value: "20437",
    label: "Xã Ch'ơm",
    parent_code: "504",
  },
  {
    value: "03166",
    label: "Xã Chà Cang",
    parent_code: "103",
  },
  {
    value: "25570",
    label: "Xã Chà Là",
    parent_code: "707",
  },
  {
    value: "03187",
    label: "Xã Chà Nưa",
    parent_code: "103",
  },
  {
    value: "03175",
    label: "Xã Chà Tở",
    parent_code: "103",
  },
  {
    value: "20707",
    label: "Xã Chà Vàl",
    parent_code: "510",
  },
  {
    value: "09985",
    label: "Xã Chàng Sơn",
    parent_code: "276",
  },
  {
    value: "29647",
    label: "Xã Chánh An",
    parent_code: "858",
  },
  {
    value: "21031",
    label: "Phường Chánh Lộ",
    parent_code: "522",
  },
  {
    value: "25774",
    label: "Phường Chánh Mỹ",
    parent_code: "718",
  },
  {
    value: "25756",
    label: "Phường Chánh Nghĩa",
    parent_code: "718",
  },
  {
    value: "25837",
    label: "Phường Chánh Phú Hòa",
    parent_code: "721",
  },
  {
    value: "03487",
    label: "Xã Chăn Nưa",
    parent_code: "108",
  },
  {
    value: "09085",
    label: "Xã Chấn Hưng",
    parent_code: "252",
  },
  {
    value: "13576",
    label: "Xã Chân Lý",
    parent_code: "353",
  },
  {
    value: "08047",
    label: "Xã Chân Mộng",
    parent_code: "230",
  },
  {
    value: "02491",
    label: "Xã Chân Sơn",
    parent_code: "075",
  },
  {
    value: "04699",
    label: "Xã Chấn Thịnh",
    parent_code: "140",
  },
  {
    value: "14653",
    label: "Xã Chất Bình",
    parent_code: "376",
  },
  {
    value: "16804",
    label: "Xã Châu Bình",
    parent_code: "416",
  },
  {
    value: "29008",
    label: "Xã Châu Bình",
    parent_code: "834",
  },
  {
    value: "16780",
    label: "Xã Châu Bính",
    parent_code: "416",
  },
  {
    value: "10348",
    label: "Xã Châu Can",
    parent_code: "280",
  },
  {
    value: "17062",
    label: "Xã Châu Cường",
    parent_code: "420",
  },
  {
    value: "29314",
    label: "Xã Châu Điền",
    parent_code: "845",
  },
  {
    value: "17080",
    label: "Xã Châu Đình",
    parent_code: "420",
  },
  {
    value: "13330",
    label: "Phường Châu Giang",
    parent_code: "349",
  },
  {
    value: "16795",
    label: "Xã Châu Hạnh",
    parent_code: "416",
  },
  {
    value: "28996",
    label: "Xã Châu Hòa",
    parent_code: "834",
  },
  {
    value: "19000",
    label: "Xã Châu Hóa",
    parent_code: "453",
  },
  {
    value: "16807",
    label: "Xã Châu Hoàn",
    parent_code: "416",
  },
  {
    value: "16786",
    label: "Xã Châu Hội",
    parent_code: "416",
  },
  {
    value: "17044",
    label: "Xã Châu Hồng",
    parent_code: "420",
  },
  {
    value: "29071",
    label: "Xã Châu Hưng",
    parent_code: "835",
  },
  {
    value: "31780",
    label: "Xã Châu Hưng",
    parent_code: "949",
  },
  {
    value: "31900",
    label: "Thị trấn Châu Hưng",
    parent_code: "958",
  },
  {
    value: "31903",
    label: "Xã Châu Hưng A",
    parent_code: "958",
  },
  {
    value: "31663",
    label: "Xã Châu Khánh",
    parent_code: "946",
  },
  {
    value: "09388",
    label: "Phường Châu Khê",
    parent_code: "261",
  },
  {
    value: "17248",
    label: "Xã Châu Khê",
    parent_code: "422",
  },
  {
    value: "16759",
    label: "Xã Châu Kim",
    parent_code: "415",
  },
  {
    value: "30562",
    label: "Xã Châu Lăng",
    parent_code: "891",
  },
  {
    value: "17056",
    label: "Xã Châu Lộc",
    parent_code: "420",
  },
  {
    value: "17089",
    label: "Xã Châu Lý",
    parent_code: "420",
  },
  {
    value: "07882",
    label: "Xã Châu Minh",
    parent_code: "223",
  },
  {
    value: "16789",
    label: "Xã Châu Nga",
    parent_code: "416",
  },
  {
    value: "18052",
    label: "Xã Châu Nhân",
    parent_code: "431",
  },
  {
    value: "21040",
    label: "Thị Trấn Châu Ổ",
    parent_code: "524",
  },
  {
    value: "26728",
    label: "Xã Châu Pha",
    parent_code: "754",
  },
  {
    value: "09292",
    label: "Xã Châu Phong",
    parent_code: "259",
  },
  {
    value: "16801",
    label: "Xã Châu Phong",
    parent_code: "416",
  },
  {
    value: "30397",
    label: "Xã Châu Phong",
    parent_code: "887",
  },
  {
    value: "30319",
    label: "Phường Châu Phú A",
    parent_code: "884",
  },
  {
    value: "30316",
    label: "Phường Châu Phú B",
    parent_code: "884",
  },
  {
    value: "17065",
    label: "Xã Châu Quang",
    parent_code: "420",
  },
  {
    value: "04387",
    label: "Xã Châu Quế Hạ",
    parent_code: "136",
  },
  {
    value: "04384",
    label: "Xã Châu Quế Thượng",
    parent_code: "136",
  },
  {
    value: "09637",
    label: "Xã Châu Sơn",
    parent_code: "271",
  },
  {
    value: "12532",
    label: "Xã Châu Sơn",
    parent_code: "338",
  },
  {
    value: "05509",
    label: "Phường Châu Sơn",
    parent_code: "165",
  },
  {
    value: "06637",
    label: "Xã Châu Sơn",
    parent_code: "189",
  },
  {
    value: "13318",
    label: "Phường Châu Sơn",
    parent_code: "347",
  },
  {
    value: "17077",
    label: "Xã Châu Thái",
    parent_code: "420",
  },
  {
    value: "17050",
    label: "Xã Châu Thành",
    parent_code: "420",
  },
  {
    value: "25585",
    label: "Thị trấn Châu Thành",
    parent_code: "708",
  },
  {
    value: "28801",
    label: "Thị trấn Châu Thành",
    parent_code: "831",
  },
  {
    value: "29374",
    label: "Thị trấn Châu Thành",
    parent_code: "847",
  },
  {
    value: "31569",
    label: "Thị trấn Châu Thành",
    parent_code: "942",
  },
  {
    value: "16798",
    label: "Xã Châu Thắng",
    parent_code: "416",
  },
  {
    value: "16765",
    label: "Xã Châu Thôn",
    parent_code: "415",
  },
  {
    value: "31912",
    label: "Xã Châu Thới",
    parent_code: "958",
  },
  {
    value: "16783",
    label: "Xã Châu Thuận",
    parent_code: "416",
  },
  {
    value: "16792",
    label: "Xã Châu Tiến",
    parent_code: "416",
  },
  {
    value: "17041",
    label: "Xã Châu Tiến",
    parent_code: "420",
  },
  {
    value: "31153",
    label: "Phường Châu Văn Liêm",
    parent_code: "917",
  },
  {
    value: "24041",
    label: "Phường Cheo Reo",
    parent_code: "624",
  },
  {
    value: "04471",
    label: "Xã Chế Cu Nha",
    parent_code: "137",
  },
  {
    value: "01138",
    label: "Xã Chế Là",
    parent_code: "033",
  },
  {
    value: "04489",
    label: "Xã Chế Tạo",
    parent_code: "137",
  },
  {
    value: "01105",
    label: "Xã Chí Cà",
    parent_code: "033",
  },
  {
    value: "22996",
    label: "Xã Chí Công",
    parent_code: "595",
  },
  {
    value: "07999",
    label: "Xã Chí Đám",
    parent_code: "230",
  },
  {
    value: "11992",
    label: "Xã Chỉ Đạo",
    parent_code: "325",
  },
  {
    value: "05323",
    label: "Xã Chí Đạo",
    parent_code: "157",
  },
  {
    value: "08973",
    label: "Thị trấn Chi Đông",
    parent_code: "250",
  },
  {
    value: "12679",
    label: "Xã Chí Hòa",
    parent_code: "339",
  },
  {
    value: "17251",
    label: "Xã Chi Khê",
    parent_code: "422",
  },
  {
    value: "09313",
    label: "Xã Chi Lăng",
    parent_code: "259",
  },
  {
    value: "05983",
    label: "Phường Chi Lăng",
    parent_code: "178",
  },
  {
    value: "06034",
    label: "Xã Chi Lăng",
    parent_code: "180",
  },
  {
    value: "06466",
    label: "Thị trấn Chi Lăng",
    parent_code: "187",
  },
  {
    value: "06523",
    label: "Xã Chi Lăng",
    parent_code: "187",
  },
  {
    value: "12656",
    label: "Xã Chi Lăng",
    parent_code: "339",
  },
  {
    value: "23586",
    label: "Phường Chi Lăng",
    parent_code: "622",
  },
  {
    value: "30505",
    label: "Thị trấn Chi Lăng",
    parent_code: "890",
  },
  {
    value: "11281",
    label: "Xã Chi Lăng Bắc",
    parent_code: "300",
  },
  {
    value: "11284",
    label: "Xã Chi Lăng Nam",
    parent_code: "300",
  },
  {
    value: "10582",
    label: "Phường Chí Minh",
    parent_code: "290",
  },
  {
    value: "11095",
    label: "Xã Chí Minh",
    parent_code: "298",
  },
  {
    value: "06013",
    label: "Xã Chí Minh",
    parent_code: "180",
  },
  {
    value: "05392",
    label: "Thị trấn Chi Nê",
    parent_code: "159",
  },
  {
    value: "12265",
    label: "Xã Chí Tân",
    parent_code: "330",
  },
  {
    value: "22114",
    label: "Thị trấn Chí Thạnh",
    parent_code: "559",
  },
  {
    value: "01606",
    label: "Xã Chí Thảo",
    parent_code: "049",
  },
  {
    value: "02599",
    label: "Xã Chi Thiết",
    parent_code: "076",
  },
  {
    value: "08206",
    label: "Xã Chí Tiên",
    parent_code: "232",
  },
  {
    value: "01501",
    label: "Xã Chí Viễn",
    parent_code: "047",
  },
  {
    value: "01042",
    label: "Xã Chiến Phố",
    parent_code: "032",
  },
  {
    value: "11671",
    label: "Xã Chiến Thắng",
    parent_code: "313",
  },
  {
    value: "06364",
    label: "Xã Chiến Thắng",
    parent_code: "185",
  },
  {
    value: "06481",
    label: "Xã Chiến Thắng",
    parent_code: "187",
  },
  {
    value: "03667",
    label: "Phường Chiềng An",
    parent_code: "116",
  },
  {
    value: "03832",
    label: "Xã Chiềng Ân",
    parent_code: "120",
  },
  {
    value: "04120",
    label: "Xã Chiềng Ban",
    parent_code: "125",
  },
  {
    value: "03706",
    label: "Xã Chiềng Bằng",
    parent_code: "118",
  },
  {
    value: "03766",
    label: "Xã Chiềng Bôm",
    parent_code: "119",
  },
  {
    value: "04207",
    label: "Xã Chiềng Cang",
    parent_code: "126",
  },
  {
    value: "04114",
    label: "Xã Chiềng Chăn",
    parent_code: "125",
  },
  {
    value: "05248",
    label: "Xã Chiềng Châu",
    parent_code: "156",
  },
  {
    value: "04129",
    label: "Xã Chiềng Chung",
    parent_code: "125",
  },
  {
    value: "03658",
    label: "Xã Chiềng Cọ",
    parent_code: "116",
  },
  {
    value: "03838",
    label: "Xã Chiềng Công",
    parent_code: "120",
  },
  {
    value: "03670",
    label: "Phường Chiềng Cơi",
    parent_code: "116",
  },
  {
    value: "04147",
    label: "Xã Chiềng Dong",
    parent_code: "125",
  },
  {
    value: "03661",
    label: "Xã Chiềng Đen",
    parent_code: "116",
  },
  {
    value: "03299",
    label: "Xã Chiềng Đông",
    parent_code: "099",
  },
  {
    value: "04063",
    label: "Xã Chiềng Đông",
    parent_code: "124",
  },
  {
    value: "04180",
    label: "Xã Chiềng En",
    parent_code: "126",
  },
  {
    value: "04012",
    label: "Xã Chiềng Hắc",
    parent_code: "123",
  },
  {
    value: "04078",
    label: "Xã Chiềng Hặc",
    parent_code: "124",
  },
  {
    value: "03850",
    label: "Xã Chiềng Hoa",
    parent_code: "120",
  },
  {
    value: "03091",
    label: "Xã Chiềng Ken",
    parent_code: "089",
  },
  {
    value: "03688",
    label: "Xã Chiềng Khay",
    parent_code: "118",
  },
  {
    value: "04150",
    label: "Xã Chiềng Kheo",
    parent_code: "125",
  },
  {
    value: "04036",
    label: "Xã Chiềng Khoa",
    parent_code: "128",
  },
  {
    value: "03718",
    label: "Xã Chiềng Khoang",
    parent_code: "118",
  },
  {
    value: "04090",
    label: "Xã Chiềng Khoi",
    parent_code: "124",
  },
  {
    value: "04204",
    label: "Xã Chiềng Khoong",
    parent_code: "126",
  },
  {
    value: "04024",
    label: "Xã Chiềng Khừa",
    parent_code: "123",
  },
  {
    value: "04222",
    label: "Xã Chiềng Khương",
    parent_code: "126",
  },
  {
    value: "03733",
    label: "Xã Chiềng La",
    parent_code: "119",
  },
  {
    value: "03814",
    label: "Xã Chiềng Lao",
    parent_code: "120",
  },
  {
    value: "03646",
    label: "Phường Chiềng Lề",
    parent_code: "116",
  },
  {
    value: "04156",
    label: "Xã Chiềng Lương",
    parent_code: "125",
  },
  {
    value: "03751",
    label: "Xã Chiềng Ly",
    parent_code: "119",
  },
  {
    value: "04132",
    label: "Xã Chiềng Mai",
    parent_code: "125",
  },
  {
    value: "04123",
    label: "Xã Chiềng Mung",
    parent_code: "125",
  },
  {
    value: "03829",
    label: "Xã Chiềng Muôn",
    parent_code: "120",
  },
  {
    value: "03736",
    label: "Xã Chiềng Ngàm",
    parent_code: "119",
  },
  {
    value: "03673",
    label: "Xã Chiềng Ngần",
    parent_code: "116",
  },
  {
    value: "04141",
    label: "Xã Chiềng Nơi",
    parent_code: "125",
  },
  {
    value: "04084",
    label: "Xã Chiềng On",
    parent_code: "124",
  },
  {
    value: "03700",
    label: "Xã Chiềng Ơn",
    parent_code: "118",
  },
  {
    value: "04072",
    label: "Xã Chiềng Pằn",
    parent_code: "124",
  },
  {
    value: "03787",
    label: "Xã Chiềng Pấc",
    parent_code: "119",
  },
  {
    value: "03730",
    label: "Xã Chiềng Pha",
    parent_code: "119",
  },
  {
    value: "04177",
    label: "Xã Chiềng Phung",
    parent_code: "126",
  },
  {
    value: "03895",
    label: "Xã Chiềng Sại",
    parent_code: "121",
  },
  {
    value: "03844",
    label: "Xã Chiềng San",
    parent_code: "120",
  },
  {
    value: "04069",
    label: "Xã Chiềng Sàng",
    parent_code: "124",
  },
  {
    value: "03298",
    label: "Xã Chiềng Sinh",
    parent_code: "099",
  },
  {
    value: "03679",
    label: "Phường Chiềng Sinh",
    parent_code: "116",
  },
  {
    value: "03211",
    label: "Xã Chiềng Sơ",
    parent_code: "101",
  },
  {
    value: "04195",
    label: "Xã Chiềng Sơ",
    parent_code: "126",
  },
  {
    value: "03985",
    label: "Xã Chiềng Sơn",
    parent_code: "123",
  },
  {
    value: "04108",
    label: "Xã Chiềng Sung",
    parent_code: "125",
  },
  {
    value: "04102",
    label: "Xã Chiềng Tương",
    parent_code: "124",
  },
  {
    value: "04153",
    label: "Xã Chiềng Ve",
    parent_code: "125",
  },
  {
    value: "03664",
    label: "Xã Chiềng Xôm",
    parent_code: "116",
  },
  {
    value: "04056",
    label: "Xã Chiềng Xuân",
    parent_code: "128",
  },
  {
    value: "04054",
    label: "Xã Chiềng Yên",
    parent_code: "128",
  },
  {
    value: "16855",
    label: "Xã Chiêu Lưu",
    parent_code: "417",
  },
  {
    value: "06358",
    label: "Xã Chiêu Vũ",
    parent_code: "185",
  },
  {
    value: "02443",
    label: "Xã Chiêu Yên",
    parent_code: "075",
  },
  {
    value: "03877",
    label: "Xã Chim Vàn",
    parent_code: "121",
  },
  {
    value: "20215",
    label: "Phường Chính Gián",
    parent_code: "491",
  },
  {
    value: "13573",
    label: "Xã Chính Lý",
    parent_code: "353",
  },
  {
    value: "11509",
    label: "Xã Chính Mỹ",
    parent_code: "311",
  },
  {
    value: "12304",
    label: "Xã Chính Nghĩa",
    parent_code: "331",
  },
  {
    value: "09193",
    label: "Thị trấn Chờ",
    parent_code: "258",
  },
  {
    value: "05536",
    label: "Thị trấn Chợ Chu",
    parent_code: "167",
  },
  {
    value: "21364",
    label: "Thị trấn Chợ Chùa",
    parent_code: "532",
  },
  {
    value: "20699",
    label: "Xã Chơ Chun",
    parent_code: "510",
  },
  {
    value: "28594",
    label: "Thị trấn Chợ Gạo",
    parent_code: "822",
  },
  {
    value: "28870",
    label: "Thị trấn Chợ Lách",
    parent_code: "832",
  },
  {
    value: "23005",
    label: "Thị trấn Chợ Lầu",
    parent_code: "596",
  },
  {
    value: "23851",
    label: "Xã Chơ Long",
    parent_code: "630",
  },
  {
    value: "30628",
    label: "Thị trấn Chợ Mới",
    parent_code: "893",
  },
  {
    value: "01888",
    label: "Thị trấn Chợ Rã",
    parent_code: "061",
  },
  {
    value: "30409",
    label: "Thị trấn Chợ Vàm",
    parent_code: "888",
  },
  {
    value: "25432",
    label: "Thị trấn Chơn Thành",
    parent_code: "697",
  },
  {
    value: "24060",
    label: "Xã Chrôh Pơnan",
    parent_code: "638",
  },
  {
    value: "07525",
    label: "Thị trấn Chũ",
    parent_code: "219",
  },
  {
    value: "07480",
    label: "Xã Chu Điện",
    parent_code: "218",
  },
  {
    value: "08506",
    label: "Xã Chu Hóa",
    parent_code: "227",
  },
  {
    value: "01921",
    label: "Xã Chu Hương",
    parent_code: "061",
  },
  {
    value: "09667",
    label: "Xã Chu Minh",
    parent_code: "271",
  },
  {
    value: "09004",
    label: "Xã Chu Phan",
    parent_code: "250",
  },
  {
    value: "01720",
    label: "Xã Chu Trinh",
    parent_code: "040",
  },
  {
    value: "05659",
    label: "Phường Chùa Hang",
    parent_code: "164",
  },
  {
    value: "10015",
    label: "Thị trấn Chúc Sơn",
    parent_code: "277",
  },
  {
    value: "03157",
    label: "Xã Chung Chải",
    parent_code: "096",
  },
  {
    value: "10321",
    label: "Xã Chuyên Mỹ",
    parent_code: "280",
  },
  {
    value: "13345",
    label: "Xã Chuyên Ngoại",
    parent_code: "349",
  },
  {
    value: "23599",
    label: "Xã Chư Á",
    parent_code: "622",
  },
  {
    value: "24046",
    label: "Xã Chư A Thai",
    parent_code: "638",
  },
  {
    value: "24065",
    label: "Xã Chư Băh",
    parent_code: "624",
  },
  {
    value: "23980",
    label: "Xã Chư Don",
    parent_code: "639",
  },
  {
    value: "24094",
    label: "Xã Chư Drăng",
    parent_code: "637",
  },
  {
    value: "23746",
    label: "Xã Chư Đăng Ya",
    parent_code: "627",
  },
  {
    value: "24085",
    label: "Xã Chư Gu",
    parent_code: "637",
  },
  {
    value: "23332",
    label: "Xã Chư Hreng",
    parent_code: "608",
  },
  {
    value: "24310",
    label: "Xã Chư KBô",
    parent_code: "649",
  },
  {
    value: "23827",
    label: "Xã Chư Krêy",
    parent_code: "630",
  },
  {
    value: "24025",
    label: "Xã Chư Mố",
    parent_code: "635",
  },
  {
    value: "24106",
    label: "Xã Chư Ngọc",
    parent_code: "637",
  },
  {
    value: "23945",
    label: "Xã Chư Pơng",
    parent_code: "633",
  },
  {
    value: "23887",
    label: "Thị trấn Chư Prông",
    parent_code: "632",
  },
  {
    value: "24016",
    label: "Xã Chư Răng",
    parent_code: "635",
  },
  {
    value: "24112",
    label: "Xã Chư Rcăm",
    parent_code: "637",
  },
  {
    value: "23941",
    label: "Thị trấn Chư Sê",
    parent_code: "633",
  },
  {
    value: "23857",
    label: "Thị trấn Chư Ty",
    parent_code: "631",
  },
  {
    value: "00067",
    label: "Phường Chương Dương",
    parent_code: "002",
  },
  {
    value: "10237",
    label: "Xã Chương Dương",
    parent_code: "279",
  },
  {
    value: "12727",
    label: "Xã Chương Dương",
    parent_code: "340",
  },
  {
    value: "08413",
    label: "Xã Chương Xá",
    parent_code: "235",
  },
  {
    value: "04138",
    label: "Xã Cò  Nòi",
    parent_code: "125",
  },
  {
    value: "03781",
    label: "Xã Co Mạ",
    parent_code: "119",
  },
  {
    value: "03796",
    label: "Xã Co Tòng",
    parent_code: "119",
  },
  {
    value: "17227",
    label: "Thị trấn Con Cuông",
    parent_code: "422",
  },
  {
    value: "11905",
    label: "Xã Cổ Am",
    parent_code: "316",
  },
  {
    value: "01330",
    label: "Xã Cô Ba",
    parent_code: "043",
  },
  {
    value: "00553",
    label: "Xã Cổ Bi",
    parent_code: "018",
  },
  {
    value: "10984",
    label: "Xã Cổ Bì",
    parent_code: "296",
  },
  {
    value: "10762",
    label: "Xã Cổ Dũng",
    parent_code: "293",
  },
  {
    value: "18391",
    label: "Xã Cỗ Đạm",
    parent_code: "442",
  },
  {
    value: "09628",
    label: "Xã Cổ Đô",
    parent_code: "271",
  },
  {
    value: "09616",
    label: "Xã Cổ Đông",
    parent_code: "269",
  },
  {
    value: "26755",
    label: "Phường Cô Giang",
    parent_code: "760",
  },
  {
    value: "14026",
    label: "Thị trấn Cổ Lễ",
    parent_code: "363",
  },
  {
    value: "01879",
    label: "Xã Cổ Linh",
    parent_code: "060",
  },
  {
    value: "00505",
    label: "Xã Cổ Loa",
    parent_code: "017",
  },
  {
    value: "05650",
    label: "Xã Cổ Lũng",
    parent_code: "168",
  },
  {
    value: "14965",
    label: "Xã Cổ Lũng",
    parent_code: "386",
  },
  {
    value: "01567",
    label: "Xã Cô Ngân",
    parent_code: "048",
  },
  {
    value: "00616",
    label: "Phường Cổ Nhuế 1",
    parent_code: "021",
  },
  {
    value: "00617",
    label: "Phường Cổ Nhuế 2",
    parent_code: "021",
  },
  {
    value: "04498",
    label: "Thị trấn Cổ Phúc",
    parent_code: "138",
  },
  {
    value: "10576",
    label: "Phường Cổ Thành",
    parent_code: "290",
  },
  {
    value: "07192",
    label: "Thị trấn Cô Tô",
    parent_code: "207",
  },
  {
    value: "30580",
    label: "Thị trấn Cô Tô",
    parent_code: "891",
  },
  {
    value: "01945",
    label: "Xã Cốc Đán",
    parent_code: "062",
  },
  {
    value: "02896",
    label: "Xã Cốc Lầu",
    parent_code: "085",
  },
  {
    value: "02644",
    label: "Phường Cốc Lếu",
    parent_code: "080",
  },
  {
    value: "02878",
    label: "Xã Cốc Ly",
    parent_code: "085",
  },
  {
    value: "02704",
    label: "Xã Cốc Mỳ",
    parent_code: "082",
  },
  {
    value: "01096",
    label: "Thị trấn Cốc Pài",
    parent_code: "033",
  },
  {
    value: "01324",
    label: "Xã Cốc Pàng",
    parent_code: "043",
  },
  {
    value: "01123",
    label: "Xã Cốc Rế",
    parent_code: "033",
  },
  {
    value: "02746",
    label: "Xã Cốc San",
    parent_code: "080",
  },
  {
    value: "14218",
    label: "Thị trấn Cồn",
    parent_code: "366",
  },
  {
    value: "02245",
    label: "Xã Côn Lôn",
    parent_code: "072",
  },
  {
    value: "02173",
    label: "Xã Côn Minh",
    parent_code: "066",
  },
  {
    value: "14689",
    label: "Xã Cồn Thoi",
    parent_code: "376",
  },
  {
    value: "01867",
    label: "Xã Công Bằng",
    parent_code: "060",
  },
  {
    value: "16369",
    label: "Xã Công Chính",
    parent_code: "404",
  },
  {
    value: "02485",
    label: "Xã Công Đa",
    parent_code: "075",
  },
  {
    value: "22840",
    label: "Xã Công Hải",
    parent_code: "588",
  },
  {
    value: "11899",
    label: "Xã Cộng Hiền",
    parent_code: "316",
  },
  {
    value: "10570",
    label: "Phường Cộng Hoà",
    parent_code: "290",
  },
  {
    value: "09931",
    label: "Xã Cộng Hòa",
    parent_code: "275",
  },
  {
    value: "10639",
    label: "Xã Cộng Hòa",
    parent_code: "291",
  },
  {
    value: "10756",
    label: "Xã Cộng Hòa",
    parent_code: "293",
  },
  {
    value: "06799",
    label: "Xã Cộng Hòa",
    parent_code: "195",
  },
  {
    value: "07150",
    label: "Phường Cộng Hòa",
    parent_code: "206",
  },
  {
    value: "12595",
    label: "Xã Cộng Hòa",
    parent_code: "339",
  },
  {
    value: "13762",
    label: "Xã Cộng Hòa",
    parent_code: "359",
  },
  {
    value: "11140",
    label: "Xã Cộng Lạc",
    parent_code: "298",
  },
  {
    value: "16354",
    label: "Xã Công Liêm",
    parent_code: "404",
  },
  {
    value: "13582",
    label: "Xã Công Lý",
    parent_code: "353",
  },
  {
    value: "06232",
    label: "Xã Công Sơn",
    parent_code: "183",
  },
  {
    value: "17611",
    label: "Xã Công Thành",
    parent_code: "426",
  },
  {
    value: "00007",
    label: "Phường Cống Vị",
    parent_code: "001",
  },
  {
    value: "31261",
    label: "Thị trấn Cờ Đỏ",
    parent_code: "925",
  },
  {
    value: "26599",
    label: "Xã Cù Bị",
    parent_code: "750",
  },
  {
    value: "27496",
    label: "Thị trấn Củ Chi",
    parent_code: "783",
  },
  {
    value: "31615",
    label: "Thị trấn Cù Lao Dung",
    parent_code: "945",
  },
  {
    value: "05809",
    label: "Xã Cù Vân",
    parent_code: "171",
  },
  {
    value: "05737",
    label: "Xã Cúc Đường",
    parent_code: "170",
  },
  {
    value: "14404",
    label: "Xã Cúc Phương",
    parent_code: "372",
  },
  {
    value: "05224",
    label: "Xã Cun Pheo",
    parent_code: "156",
  },
  {
    value: "22165",
    label: "Thị trấn Củng Sơn",
    parent_code: "560",
  },
  {
    value: "24301",
    label: "Xã Cuor Đăng",
    parent_code: "648",
  },
  {
    value: "05077",
    label: "Xã Cuối Hạ",
    parent_code: "153",
  },
  {
    value: "24247",
    label: "Xã Cuôr KNia",
    parent_code: "647",
  },
  {
    value: "24194",
    label: "Xã Cư A Mung",
    parent_code: "645",
  },
  {
    value: "24001",
    label: "Xã Cư An",
    parent_code: "634",
  },
  {
    value: "24340",
    label: "Xã Cư Bao",
    parent_code: "644",
  },
  {
    value: "24406",
    label: "Xã Cư Bông",
    parent_code: "651",
  },
  {
    value: "24271",
    label: "Xã Cư Dliê M'nông",
    parent_code: "648",
  },
  {
    value: "24484",
    label: "Xã Cư Drăm",
    parent_code: "653",
  },
  {
    value: "08614",
    label: "Xã Cự Đồng",
    parent_code: "238",
  },
  {
    value: "24404",
    label: "Xã Cư ELang",
    parent_code: "651",
  },
  {
    value: "24541",
    label: "Xã Cư Ê Wi",
    parent_code: "657",
  },
  {
    value: "24160",
    label: "Xã Cư ÊBur",
    parent_code: "643",
  },
  {
    value: "24385",
    label: "Xã Cư Huê",
    parent_code: "651",
  },
  {
    value: "24409",
    label: "Xã Cư Jang",
    parent_code: "651",
  },
  {
    value: "24439",
    label: "Xã Cư K Róa",
    parent_code: "652",
  },
  {
    value: "24226",
    label: "Xã Cư KBang",
    parent_code: "646",
  },
  {
    value: "10120",
    label: "Xã Cự Khê",
    parent_code: "278",
  },
  {
    value: "00154",
    label: "Phường Cự Khối",
    parent_code: "004",
  },
  {
    value: "24367",
    label: "Xã Cư Klông",
    parent_code: "650",
  },
  {
    value: "24658",
    label: "Xã Cư Knia",
    parent_code: "662",
  },
  {
    value: "24454",
    label: "Xã Cư KTy",
    parent_code: "653",
  },
  {
    value: "02176",
    label: "Xã Cư Lễ",
    parent_code: "066",
  },
  {
    value: "24289",
    label: "Xã Cư M'gar",
    parent_code: "648",
  },
  {
    value: "24232",
    label: "Xã Cư M'Lan",
    parent_code: "646",
  },
  {
    value: "24436",
    label: "Xã Cư M'ta",
    parent_code: "652",
  },
  {
    value: "24196",
    label: "Xã Cư Mốt",
    parent_code: "645",
  },
  {
    value: "19141",
    label: "Xã Cự Nẫm",
    parent_code: "455",
  },
  {
    value: "24307",
    label: "Xã Cư Né",
    parent_code: "649",
  },
  {
    value: "24397",
    label: "Xã Cư Ni",
    parent_code: "651",
  },
  {
    value: "24313",
    label: "Xã Cư Pơng",
    parent_code: "649",
  },
  {
    value: "24415",
    label: "Xã Cư Prao",
    parent_code: "652",
  },
  {
    value: "24401",
    label: "Xã Cư Prông",
    parent_code: "651",
  },
  {
    value: "24478",
    label: "Xã Cư Pui",
    parent_code: "653",
  },
  {
    value: "24444",
    label: "Xã Cư San",
    parent_code: "652",
  },
  {
    value: "24298",
    label: "Xã Cư Suê",
    parent_code: "648",
  },
  {
    value: "08602",
    label: "Xã Cự Thắng",
    parent_code: "238",
  },
  {
    value: "04960",
    label: "Xã Cư Yên",
    parent_code: "152",
  },
  {
    value: "13648",
    label: "Phường Cửa Bắc",
    parent_code: "356",
  },
  {
    value: "31084",
    label: "Xã Cửa Cạn",
    parent_code: "911",
  },
  {
    value: "31090",
    label: "Xã Cửa Dương",
    parent_code: "911",
  },
  {
    value: "20416",
    label: "Phường Cửa Đại",
    parent_code: "503",
  },
  {
    value: "00055",
    label: "Phường Cửa Đông",
    parent_code: "002",
  },
  {
    value: "00073",
    label: "Phường Cửa Nam",
    parent_code: "002",
  },
  {
    value: "13690",
    label: "Phường Cửa Nam",
    parent_code: "356",
  },
  {
    value: "16678",
    label: "Phường Cửa Nam",
    parent_code: "412",
  },
  {
    value: "06763",
    label: "Phường Cửa Ông",
    parent_code: "195",
  },
  {
    value: "19414",
    label: "Thị trấn Cửa Tùng",
    parent_code: "464",
  },
  {
    value: "19496",
    label: "Thị trấn Cửa Việt",
    parent_code: "466",
  },
  {
    value: "12376",
    label: "Xã Cương Chính",
    parent_code: "332",
  },
  {
    value: "18403",
    label: "Xã Cương Gián",
    parent_code: "442",
  },
  {
    value: "06634",
    label: "Xã Cường Lợi",
    parent_code: "189",
  },
  {
    value: "02152",
    label: "Xã Cường Lợi",
    parent_code: "066",
  },
  {
    value: "07483",
    label: "Xã Cương Sơn",
    parent_code: "218",
  },
  {
    value: "04522",
    label: "Xã Cường Thịnh",
    parent_code: "138",
  },
  {
    value: "23629",
    label: "Xã Cửu An",
    parent_code: "623",
  },
  {
    value: "12025",
    label: "Xã Cửu Cao",
    parent_code: "326",
  },
  {
    value: "24928",
    label: "Thị trấn D'Ran",
    parent_code: "677",
  },
  {
    value: "12214",
    label: "Xã Dạ Trạch",
    parent_code: "330",
  },
  {
    value: "26119",
    label: "Xã Dak Lua",
    parent_code: "734",
  },
  {
    value: "20464",
    label: "Xã Dang",
    parent_code: "504",
  },
  {
    value: "24451",
    label: "Xã Dang Kang",
    parent_code: "653",
  },
  {
    value: "07861",
    label: "Xã Danh Thắng",
    parent_code: "223",
  },
  {
    value: "03571",
    label: "Xã Dào San",
    parent_code: "109",
  },
  {
    value: "01657",
    label: "Xã Dân Chủ",
    parent_code: "051",
  },
  {
    value: "11110",
    label: "Xã Dân Chủ",
    parent_code: "298",
  },
  {
    value: "07051",
    label: "Xã Dân Chủ",
    parent_code: "193",
  },
  {
    value: "12598",
    label: "Xã Dân Chủ",
    parent_code: "339",
  },
  {
    value: "04819",
    label: "Phường Dân Chủ",
    parent_code: "148",
  },
  {
    value: "10168",
    label: "Xã Dân Hòa",
    parent_code: "278",
  },
  {
    value: "18904",
    label: "Xã Dân Hóa",
    parent_code: "452",
  },
  {
    value: "15700",
    label: "Xã Dân Lực",
    parent_code: "397",
  },
  {
    value: "15703",
    label: "Xã Dân Lý",
    parent_code: "397",
  },
  {
    value: "08491",
    label: "Xã Dân Quyền",
    parent_code: "236",
  },
  {
    value: "15706",
    label: "Xã Dân Quyền",
    parent_code: "397",
  },
  {
    value: "03088",
    label: "Xã Dần Thàng",
    parent_code: "089",
  },
  {
    value: "29524",
    label: "Xã Dân Thành",
    parent_code: "851",
  },
  {
    value: "12238",
    label: "Xã Dân Tiến",
    parent_code: "330",
  },
  {
    value: "05755",
    label: "Xã Dân Tiến",
    parent_code: "170",
  },
  {
    value: "26326",
    label: "Thị trấn Dầu Giây",
    parent_code: "738",
  },
  {
    value: "25777",
    label: "Thị trấn Dầu Tiếng",
    parent_code: "720",
  },
  {
    value: "04486",
    label: "Xã Dế Su Phình",
    parent_code: "137",
  },
  {
    value: "02707",
    label: "Xã Dền Sáng",
    parent_code: "082",
  },
  {
    value: "02722",
    label: "Xã Dền Thàng",
    parent_code: "082",
  },
  {
    value: "25942",
    label: "Phường Dĩ An",
    parent_code: "724",
  },
  {
    value: "12349",
    label: "Xã Dị Chế",
    parent_code: "332",
  },
  {
    value: "21289",
    label: "Thị trấn Di Lăng",
    parent_code: "529",
  },
  {
    value: "25000",
    label: "Thị trấn Di Linh",
    parent_code: "679",
  },
  {
    value: "09979",
    label: "Xã Dị Nậu",
    parent_code: "276",
  },
  {
    value: "08482",
    label: "Xã Dị Nậu",
    parent_code: "236",
  },
  {
    value: "12121",
    label: "Phường Dị Sử",
    parent_code: "328",
  },
  {
    value: "09844",
    label: "Xã Di Trạch",
    parent_code: "274",
  },
  {
    value: "00166",
    label: "Phường Dịch Vọng",
    parent_code: "005",
  },
  {
    value: "00167",
    label: "Phường Dịch Vọng Hậu",
    parent_code: "005",
  },
  {
    value: "12826",
    label: "Thị trấn Diêm Điền",
    parent_code: "341",
  },
  {
    value: "22693",
    label: "Xã Diên An",
    parent_code: "574",
  },
  {
    value: "17500",
    label: "Xã Diễn An",
    parent_code: "425",
  },
  {
    value: "17446",
    label: "Xã Diễn Bích",
    parent_code: "425",
  },
  {
    value: "23440",
    label: "Xã Diên Bình",
    parent_code: "612",
  },
  {
    value: "17476",
    label: "Xã Diễn Cát",
    parent_code: "425",
  },
  {
    value: "17389",
    label: "Thị trấn Diễn Châu",
    parent_code: "425",
  },
  {
    value: "22657",
    label: "Xã Diên Điền",
    parent_code: "574",
  },
  {
    value: "17395",
    label: "Xã Diễn Đoài",
    parent_code: "425",
  },
  {
    value: "22666",
    label: "Xã Diên Đồng",
    parent_code: "574",
  },
  {
    value: "17443",
    label: "Xã Diễn Đồng",
    parent_code: "425",
  },
  {
    value: "17419",
    label: "Xã Diễn Hải",
    parent_code: "425",
  },
  {
    value: "17449",
    label: "Xã Diễn Hạnh",
    parent_code: "425",
  },
  {
    value: "22684",
    label: "Xã Diên Hòa",
    parent_code: "574",
  },
  {
    value: "17461",
    label: "Xã Diễn Hoa",
    parent_code: "425",
  },
  {
    value: "17404",
    label: "Xã Diễn Hoàng",
    parent_code: "425",
  },
  {
    value: "23560",
    label: "Phường Diên Hồng",
    parent_code: "622",
  },
  {
    value: "17413",
    label: "Xã Diễn Hồng",
    parent_code: "425",
  },
  {
    value: "17407",
    label: "Xã Diễn Hùng",
    parent_code: "425",
  },
  {
    value: "22651",
    label: "Thị trấn Diên Khánh",
    parent_code: "574",
  },
  {
    value: "17431",
    label: "Xã Diễn Kim",
    parent_code: "425",
  },
  {
    value: "17434",
    label: "Xã Diễn Kỷ",
    parent_code: "425",
  },
  {
    value: "22678",
    label: "Xã Diên Lạc",
    parent_code: "574",
  },
  {
    value: "16810",
    label: "Xã Diên Lãm",
    parent_code: "416",
  },
  {
    value: "22654",
    label: "Xã Diên Lâm",
    parent_code: "574",
  },
  {
    value: "17392",
    label: "Xã Diễn Lâm",
    parent_code: "425",
  },
  {
    value: "17425",
    label: "Xã Diễn Liên",
    parent_code: "425",
  },
  {
    value: "17494",
    label: "Xã Diễn Lộc",
    parent_code: "425",
  },
  {
    value: "17491",
    label: "Xã Diễn Lợi",
    parent_code: "425",
  },
  {
    value: "17410",
    label: "Xã Diễn Mỹ",
    parent_code: "425",
  },
  {
    value: "17452",
    label: "Xã Diễn Ngọc",
    parent_code: "425",
  },
  {
    value: "17458",
    label: "Xã Diễn Nguyên",
    parent_code: "425",
  },
  {
    value: "17416",
    label: "Xã Diễn Phong",
    parent_code: "425",
  },
  {
    value: "22669",
    label: "Xã Diên Phú",
    parent_code: "574",
  },
  {
    value: "23605",
    label: "Xã Diên Phú",
    parent_code: "622",
  },
  {
    value: "17503",
    label: "Xã Diễn Phú",
    parent_code: "425",
  },
  {
    value: "17467",
    label: "Xã Diễn Phúc",
    parent_code: "425",
  },
  {
    value: "22675",
    label: "Xã Diên Phước",
    parent_code: "574",
  },
  {
    value: "17455",
    label: "Xã Diễn Quảng",
    parent_code: "425",
  },
  {
    value: "19681",
    label: "Thị trấn Diên Sanh",
    parent_code: "470",
  },
  {
    value: "22663",
    label: "Xã Diên Sơn",
    parent_code: "574",
  },
  {
    value: "22681",
    label: "Xã Diên Tân",
    parent_code: "574",
  },
  {
    value: "17482",
    label: "Xã Diễn Tân",
    parent_code: "425",
  },
  {
    value: "17440",
    label: "Xã Diễn Thái",
    parent_code: "425",
  },
  {
    value: "22687",
    label: "Xã Diên Thạnh",
    parent_code: "574",
  },
  {
    value: "17464",
    label: "Xã Diễn Thành",
    parent_code: "425",
  },
  {
    value: "17422",
    label: "Xã Diễn Tháp",
    parent_code: "425",
  },
  {
    value: "17479",
    label: "Xã Diễn Thịnh",
    parent_code: "425",
  },
  {
    value: "22672",
    label: "Xã Diên Thọ",
    parent_code: "574",
  },
  {
    value: "17488",
    label: "Xã Diễn Thọ",
    parent_code: "425",
  },
  {
    value: "22690",
    label: "Xã Diên Toàn",
    parent_code: "574",
  },
  {
    value: "17497",
    label: "Xã Diễn Trung",
    parent_code: "425",
  },
  {
    value: "17398",
    label: "Xã Diễn Trường",
    parent_code: "425",
  },
  {
    value: "17428",
    label: "Xã Diễn Vạn",
    parent_code: "425",
  },
  {
    value: "22660",
    label: "Xã Diên Xuân",
    parent_code: "574",
  },
  {
    value: "17437",
    label: "Xã Diễn Xuân",
    parent_code: "425",
  },
  {
    value: "17401",
    label: "Xã Diễn Yên",
    parent_code: "425",
  },
  {
    value: "21955",
    label: "Thị trấn Diêu Trì",
    parent_code: "550",
  },
  {
    value: "02764",
    label: "Xã Dìn Chin",
    parent_code: "083",
  },
  {
    value: "07231",
    label: "Phường Dĩnh Kế",
    parent_code: "213",
  },
  {
    value: "07441",
    label: "Xã Dĩnh Trì",
    parent_code: "213",
  },
  {
    value: "24205",
    label: "Xã Dliê Yang",
    parent_code: "645",
  },
  {
    value: "04234",
    label: "Xã Dồm Cang",
    parent_code: "127",
  },
  {
    value: "24561",
    label: "Xã Dray Bhăng",
    parent_code: "657",
  },
  {
    value: "24556",
    label: "Xã Dray Sáp",
    parent_code: "655",
  },
  {
    value: "00871",
    label: "Xã Du Già",
    parent_code: "028",
  },
  {
    value: "11716",
    label: "Xã Du Lễ",
    parent_code: "314",
  },
  {
    value: "00868",
    label: "Xã Du Tiến",
    parent_code: "028",
  },
  {
    value: "00496",
    label: "Xã Dục Tú",
    parent_code: "017",
  },
  {
    value: "23965",
    label: "Xã Dun",
    parent_code: "633",
  },
  {
    value: "09196",
    label: "Xã Dũng Liệt",
    parent_code: "258",
  },
  {
    value: "13231",
    label: "Xã Dũng Nghĩa",
    parent_code: "344",
  },
  {
    value: "05116",
    label: "Xã Dũng Phong",
    parent_code: "154",
  },
  {
    value: "10249",
    label: "Xã Dũng Tiến",
    parent_code: "279",
  },
  {
    value: "11827",
    label: "Xã Dũng Tiến",
    parent_code: "316",
  },
  {
    value: "24571",
    label: "Xã Dur KMăl",
    parent_code: "655",
  },
  {
    value: "20614",
    label: "Xã Duy Châu",
    parent_code: "508",
  },
  {
    value: "13342",
    label: "Phường Duy Hải",
    parent_code: "349",
  },
  {
    value: "20638",
    label: "Xã Duy Hải",
    parent_code: "508",
  },
  {
    value: "20611",
    label: "Xã Duy Hòa",
    parent_code: "508",
  },
  {
    value: "13336",
    label: "Phường Duy Minh",
    parent_code: "349",
  },
  {
    value: "20635",
    label: "Xã Duy Nghĩa",
    parent_code: "508",
  },
  {
    value: "13279",
    label: "Xã Duy Nhất",
    parent_code: "344",
  },
  {
    value: "19222",
    label: "Xã Duy Ninh",
    parent_code: "456",
  },
  {
    value: "08893",
    label: "Xã Duy Phiên",
    parent_code: "247",
  },
  {
    value: "20605",
    label: "Xã Duy Phú",
    parent_code: "508",
  },
  {
    value: "20626",
    label: "Xã Duy Phước",
    parent_code: "508",
  },
  {
    value: "20620",
    label: "Xã Duy Sơn",
    parent_code: "508",
  },
  {
    value: "10696",
    label: "Phường Duy Tân",
    parent_code: "292",
  },
  {
    value: "23284",
    label: "Phường Duy Tân",
    parent_code: "608",
  },
  {
    value: "20608",
    label: "Xã Duy Tân",
    parent_code: "508",
  },
  {
    value: "20629",
    label: "Xã Duy Thành",
    parent_code: "508",
  },
  {
    value: "20602",
    label: "Xã Duy Thu",
    parent_code: "508",
  },
  {
    value: "20617",
    label: "Xã Duy Trinh",
    parent_code: "508",
  },
  {
    value: "20623",
    label: "Xã Duy Trung",
    parent_code: "508",
  },
  {
    value: "20632",
    label: "Xã Duy Vinh",
    parent_code: "508",
  },
  {
    value: "00670",
    label: "Xã Duyên Hà",
    parent_code: "020",
  },
  {
    value: "12619",
    label: "Xã Duyên Hải",
    parent_code: "339",
  },
  {
    value: "02635",
    label: "Phường Duyên Hải",
    parent_code: "080",
  },
  {
    value: "10192",
    label: "Xã Duyên Thái",
    parent_code: "279",
  },
  {
    value: "01288",
    label: "Phường Duyệt Trung",
    parent_code: "040",
  },
  {
    value: "11389",
    label: "Phường Dư Hàng",
    parent_code: "305",
  },
  {
    value: "11404",
    label: "Phường Dư Hàng Kênh",
    parent_code: "305",
  },
  {
    value: "06910",
    label: "Xã Dực Yên",
    parent_code: "200",
  },
  {
    value: "28546",
    label: "Xã Dưỡng Điềm",
    parent_code: "821",
  },
  {
    value: "31078",
    label: "Phường Dương Đông",
    parent_code: "911",
  },
  {
    value: "07408",
    label: "Xã Dương Đức",
    parent_code: "217",
  },
  {
    value: "00541",
    label: "Xã Dương Hà",
    parent_code: "018",
  },
  {
    value: "19993",
    label: "Xã Dương Hòa",
    parent_code: "479",
  },
  {
    value: "30805",
    label: "Xã Dương Hòa",
    parent_code: "902",
  },
  {
    value: "12916",
    label: "Xã Dương Hồng  Thủy",
    parent_code: "341",
  },
  {
    value: "06805",
    label: "Xã Dương Huy",
    parent_code: "195",
  },
  {
    value: "07666",
    label: "Xã Dương Hưu",
    parent_code: "220",
  },
  {
    value: "09841",
    label: "Xã Dương Liễu",
    parent_code: "274",
  },
  {
    value: "25552",
    label: "Thị trấn Dương Minh Châu",
    parent_code: "707",
  },
  {
    value: "09886",
    label: "Phường Dương Nội",
    parent_code: "268",
  },
  {
    value: "02014",
    label: "Xã Dương Phong",
    parent_code: "063",
  },
  {
    value: "12865",
    label: "Xã Dương Phúc",
    parent_code: "341",
  },
  {
    value: "11578",
    label: "Xã Dương Quan",
    parent_code: "311",
  },
  {
    value: "00568",
    label: "Xã Dương Quang",
    parent_code: "018",
  },
  {
    value: "01849",
    label: "Xã Dương Quang",
    parent_code: "058",
  },
  {
    value: "12112",
    label: "Xã Dương Quang",
    parent_code: "328",
  },
  {
    value: "03106",
    label: "Xã Dương Quỳ",
    parent_code: "089",
  },
  {
    value: "02188",
    label: "Xã Dương Sơn",
    parent_code: "066",
  },
  {
    value: "05965",
    label: "Xã Dương Thành",
    parent_code: "173",
  },
  {
    value: "19291",
    label: "Xã Dương Thủy",
    parent_code: "457",
  },
  {
    value: "31096",
    label: "Xã Dương Tơ",
    parent_code: "911",
  },
  {
    value: "00571",
    label: "Xã Dương Xá",
    parent_code: "018",
  },
  {
    value: "28237",
    label: "Xã Dương Xuân Hội",
    parent_code: "808",
  },
  {
    value: "07888",
    label: "Phường Dữu Lâu",
    parent_code: "227",
  },
  {
    value: "26614",
    label: "Xã Đá Bạc",
    parent_code: "750",
  },
  {
    value: "04831",
    label: "Thị trấn Đà Bắc",
    parent_code: "150",
  },
  {
    value: "24847",
    label: "Xã Đạ Chais",
    parent_code: "675",
  },
  {
    value: "03967",
    label: "Xã Đá Đỏ",
    parent_code: "122",
  },
  {
    value: "24895",
    label: "Xã Đạ Đờn",
    parent_code: "676",
  },
  {
    value: "24889",
    label: "Xã Đạ K' Nàng",
    parent_code: "674",
  },
  {
    value: "23197",
    label: "Xã Đa Kai",
    parent_code: "600",
  },
  {
    value: "26737",
    label: "Phường Đa Kao",
    parent_code: "760",
  },
  {
    value: "25153",
    label: "Xã Đạ Kho",
    parent_code: "682",
  },
  {
    value: "25231",
    label: "Xã Đa Kia",
    parent_code: "691",
  },
  {
    value: "19564",
    label: "Xã Đa Krông",
    parent_code: "467",
  },
  {
    value: "25141",
    label: "Xã Đạ Lây",
    parent_code: "682",
  },
  {
    value: "24994",
    label: "Xã Đà Loan",
    parent_code: "678",
  },
  {
    value: "24856",
    label: "Xã Đạ Long",
    parent_code: "674",
  },
  {
    value: "12187",
    label: "Xã Đa Lộc",
    parent_code: "329",
  },
  {
    value: "16087",
    label: "Xã Đa Lộc",
    parent_code: "400",
  },
  {
    value: "22084",
    label: "Xã Đa Lộc",
    parent_code: "558",
  },
  {
    value: "29377",
    label: "Xã Đa Lộc",
    parent_code: "847",
  },
  {
    value: "24859",
    label: "Xã Đạ M' Rong",
    parent_code: "674",
  },
  {
    value: "25096",
    label: "Thị trấn Đạ M'ri",
    parent_code: "681",
  },
  {
    value: "07228",
    label: "Phường Đa Mai",
    parent_code: "213",
  },
  {
    value: "23107",
    label: "Xã Đa Mi",
    parent_code: "597",
  },
  {
    value: "24848",
    label: "Xã Đạ Nhim",
    parent_code: "675",
  },
  {
    value: "25111",
    label: "Xã Đạ Oai",
    parent_code: "681",
  },
  {
    value: "25156",
    label: "Xã Đạ Pal",
    parent_code: "682",
  },
  {
    value: "11683",
    label: "Phường Đa Phúc",
    parent_code: "309",
  },
  {
    value: "05368",
    label: "Xã Đa Phúc",
    parent_code: "158",
  },
  {
    value: "27631",
    label: "Xã Đa Phước",
    parent_code: "785",
  },
  {
    value: "30373",
    label: "Xã Đa Phước",
    parent_code: "886",
  },
  {
    value: "28939",
    label: "Xã Đa Phước Hội",
    parent_code: "833",
  },
  {
    value: "25114",
    label: "Xã Đạ Ploa",
    parent_code: "681",
  },
  {
    value: "24989",
    label: "Xã Đa Quyn",
    parent_code: "678",
  },
  {
    value: "24937",
    label: "Xã Đạ Ròn",
    parent_code: "677",
  },
  {
    value: "24875",
    label: "Xã Đạ Rsal",
    parent_code: "674",
  },
  {
    value: "24865",
    label: "Xã Đạ Sar",
    parent_code: "675",
  },
  {
    value: "17668",
    label: "Xã Đà Sơn",
    parent_code: "427",
  },
  {
    value: "25126",
    label: "Thị trấn Đạ Tẻh",
    parent_code: "682",
  },
  {
    value: "01375",
    label: "Xã Đa Thông",
    parent_code: "045",
  },
  {
    value: "00577",
    label: "Xã Đa Tốn",
    parent_code: "018",
  },
  {
    value: "25108",
    label: "Xã Đạ Tồn",
    parent_code: "681",
  },
  {
    value: "24853",
    label: "Xã Đạ Tông",
    parent_code: "674",
  },
  {
    value: "02260",
    label: "Xã Đà Vị",
    parent_code: "072",
  },
  {
    value: "08161",
    label: "Xã Đại An",
    parent_code: "232",
  },
  {
    value: "13756",
    label: "Xã Đại An",
    parent_code: "359",
  },
  {
    value: "20547",
    label: "Xã Đại An",
    parent_code: "506",
  },
  {
    value: "29491",
    label: "Xã Đại An",
    parent_code: "849",
  },
  {
    value: "00679",
    label: "Xã Đại áng",
    parent_code: "020",
  },
  {
    value: "31672",
    label: "Xã Đại Ân  2",
    parent_code: "951",
  },
  {
    value: "31627",
    label: "Xã Đại Ân 1",
    parent_code: "945",
  },
  {
    value: "09490",
    label: "Xã Đại Bái",
    parent_code: "263",
  },
  {
    value: "11587",
    label: "Xã Đại Bản",
    parent_code: "312",
  },
  {
    value: "06919",
    label: "Xã Đại Bình",
    parent_code: "200",
  },
  {
    value: "20530",
    label: "Xã Đại Chánh",
    parent_code: "506",
  },
  {
    value: "13390",
    label: "Xã Đại Cương",
    parent_code: "350",
  },
  {
    value: "10432",
    label: "Xã Đại Cường",
    parent_code: "281",
  },
  {
    value: "20545",
    label: "Xã Đại Cường",
    parent_code: "506",
  },
  {
    value: "06868",
    label: "Xã Đại Dực",
    parent_code: "199",
  },
  {
    value: "29188",
    label: "Xã Đại Điền",
    parent_code: "837",
  },
  {
    value: "08923",
    label: "Thị trấn Đại Đình",
    parent_code: "248",
  },
  {
    value: "09958",
    label: "Xã Đại Đồng",
    parent_code: "276",
  },
  {
    value: "09100",
    label: "Xã Đại Đồng",
    parent_code: "252",
  },
  {
    value: "09355",
    label: "Xã Đại Đồng",
    parent_code: "260",
  },
  {
    value: "11704",
    label: "Xã Đại Đồng",
    parent_code: "314",
  },
  {
    value: "11995",
    label: "Xã Đại Đồng",
    parent_code: "325",
  },
  {
    value: "06040",
    label: "Xã Đại Đồng",
    parent_code: "180",
  },
  {
    value: "04768",
    label: "Xã Đại Đồng",
    parent_code: "141",
  },
  {
    value: "17749",
    label: "Xã Đại Đồng",
    parent_code: "428",
  },
  {
    value: "20515",
    label: "Xã Đại Đồng",
    parent_code: "506",
  },
  {
    value: "09406",
    label: "Xã Đại Đồng Thành",
    parent_code: "262",
  },
  {
    value: "10810",
    label: "Xã Đại Đức",
    parent_code: "293",
  },
  {
    value: "11728",
    label: "Xã Đại Hà",
    parent_code: "314",
  },
  {
    value: "31561",
    label: "Xã Đại Hải",
    parent_code: "943",
  },
  {
    value: "20524",
    label: "Xã Đại Hiệp",
    parent_code: "506",
  },
  {
    value: "20548",
    label: "Xã Đại Hòa",
    parent_code: "506",
  },
  {
    value: "07312",
    label: "Xã Đại Hóa",
    parent_code: "216",
  },
  {
    value: "29098",
    label: "Xã Đại Hòa Lộc",
    parent_code: "835",
  },
  {
    value: "20512",
    label: "Xã Đại Hồng",
    parent_code: "506",
  },
  {
    value: "11119",
    label: "Xã Đại Hợp",
    parent_code: "298",
  },
  {
    value: "11752",
    label: "Xã Đại Hợp",
    parent_code: "314",
  },
  {
    value: "10423",
    label: "Xã Đại Hùng",
    parent_code: "281",
  },
  {
    value: "10480",
    label: "Xã Đại Hưng",
    parent_code: "282",
  },
  {
    value: "12268",
    label: "Xã Đại Hưng",
    parent_code: "330",
  },
  {
    value: "20509",
    label: "Xã Đại Hưng",
    parent_code: "506",
  },
  {
    value: "00316",
    label: "Phường Đại Kim",
    parent_code: "008",
  },
  {
    value: "09469",
    label: "Xã Đại Lai",
    parent_code: "263",
  },
  {
    value: "22492",
    label: "Xã Đại Lãnh",
    parent_code: "571",
  },
  {
    value: "20506",
    label: "Xã Đại Lãnh",
    parent_code: "506",
  },
  {
    value: "24844",
    label: "Xã Đại Lào",
    parent_code: "673",
  },
  {
    value: "07435",
    label: "Xã Đại Lâm",
    parent_code: "217",
  },
  {
    value: "04687",
    label: "Xã Đại Lịch",
    parent_code: "140",
  },
  {
    value: "16018",
    label: "Xã Đại Lộc",
    parent_code: "400",
  },
  {
    value: "00499",
    label: "Xã Đại Mạch",
    parent_code: "017",
  },
  {
    value: "04786",
    label: "Xã Đại Minh",
    parent_code: "141",
  },
  {
    value: "20539",
    label: "Xã Đại Minh",
    parent_code: "506",
  },
  {
    value: "00634",
    label: "Phường Đại Mỗ",
    parent_code: "019",
  },
  {
    value: "18082",
    label: "Phường Đại Nài",
    parent_code: "436",
  },
  {
    value: "31645",
    label: "Thị trấn Đại Ngãi",
    parent_code: "946",
  },
  {
    value: "10441",
    label: "Thị trấn Đại Nghĩa",
    parent_code: "282",
  },
  {
    value: "20521",
    label: "Xã Đại Nghĩa",
    parent_code: "506",
  },
  {
    value: "04435",
    label: "Xã Đại Phác",
    parent_code: "136",
  },
  {
    value: "08056",
    label: "Xã Đại Phạm",
    parent_code: "231",
  },
  {
    value: "20536",
    label: "Xã Đại Phong",
    parent_code: "506",
  },
  {
    value: "02617",
    label: "Xã Đại Phú",
    parent_code: "076",
  },
  {
    value: "09181",
    label: "Phường Đại Phúc",
    parent_code: "256",
  },
  {
    value: "29293",
    label: "Xã Đại Phúc",
    parent_code: "844",
  },
  {
    value: "26476",
    label: "Xã Đại Phước",
    parent_code: "742",
  },
  {
    value: "29296",
    label: "Xã Đại Phước",
    parent_code: "844",
  },
  {
    value: "20518",
    label: "Xã Đại Quang",
    parent_code: "506",
  },
  {
    value: "02068",
    label: "Xã Đại Sảo",
    parent_code: "064",
  },
  {
    value: "22765",
    label: "Phường Đài Sơn",
    parent_code: "582",
  },
  {
    value: "01639",
    label: "Xã Đại Sơn",
    parent_code: "049",
  },
  {
    value: "11083",
    label: "Xã Đại Sơn",
    parent_code: "298",
  },
  {
    value: "07627",
    label: "Xã Đại Sơn",
    parent_code: "220",
  },
  {
    value: "04429",
    label: "Xã Đại Sơn",
    parent_code: "136",
  },
  {
    value: "17710",
    label: "Xã Đại Sơn",
    parent_code: "427",
  },
  {
    value: "20503",
    label: "Xã Đại Sơn",
    parent_code: "506",
  },
  {
    value: "31690",
    label: "Xã Đại Tâm",
    parent_code: "947",
  },
  {
    value: "20533",
    label: "Xã Đại Tân",
    parent_code: "506",
  },
  {
    value: "12262",
    label: "Xã Đại Tập",
    parent_code: "330",
  },
  {
    value: "09937",
    label: "Xã Đại Thành",
    parent_code: "275",
  },
  {
    value: "07852",
    label: "Xã Đại Thành",
    parent_code: "223",
  },
  {
    value: "17599",
    label: "Xã Đại Thành",
    parent_code: "426",
  },
  {
    value: "31411",
    label: "Xã Đại Thành",
    parent_code: "931",
  },
  {
    value: "20527",
    label: "Xã Đại Thạnh",
    parent_code: "506",
  },
  {
    value: "10291",
    label: "Xã Đại Thắng",
    parent_code: "280",
  },
  {
    value: "11758",
    label: "Xã Đại Thắng",
    parent_code: "315",
  },
  {
    value: "13786",
    label: "Xã Đại Thắng",
    parent_code: "359",
  },
  {
    value: "20542",
    label: "Xã Đại Thắng",
    parent_code: "506",
  },
  {
    value: "08974",
    label: "Xã Đại Thịnh",
    parent_code: "250",
  },
  {
    value: "01666",
    label: "Xã Đại Tiến",
    parent_code: "051",
  },
  {
    value: "19186",
    label: "Xã Đại Trạch",
    parent_code: "455",
  },
  {
    value: "09067",
    label: "Xã Đại Tự",
    parent_code: "251",
  },
  {
    value: "09253",
    label: "Xã Đại Xuân",
    parent_code: "259",
  },
  {
    value: "06997",
    label: "Xã Đài Xuyên",
    parent_code: "203",
  },
  {
    value: "10336",
    label: "Xã Đại Xuyên",
    parent_code: "280",
  },
  {
    value: "10054",
    label: "Xã Đại Yên",
    parent_code: "277",
  },
  {
    value: "06706",
    label: "Phường Đại Yên",
    parent_code: "193",
  },
  {
    value: "23798",
    label: "Xã Đak Jơ Ta",
    parent_code: "629",
  },
  {
    value: "21700",
    label: "Xã Đak Mang",
    parent_code: "544",
  },
  {
    value: "25399",
    label: "Xã Đak Nhau",
    parent_code: "696",
  },
  {
    value: "25225",
    label: "Xã Đak Ơ",
    parent_code: "691",
  },
  {
    value: "23995",
    label: "Thị trấn Đak Pơ",
    parent_code: "634",
  },
  {
    value: "23660",
    label: "Xã Đak SMar",
    parent_code: "625",
  },
  {
    value: "23799",
    label: "Xã Đak Ta Ley",
    parent_code: "629",
  },
  {
    value: "24832",
    label: "Xã Đạm Bri",
    parent_code: "673",
  },
  {
    value: "01495",
    label: "Xã Đàm Thuỷ",
    parent_code: "047",
  },
  {
    value: "07522",
    label: "Xã Đan Hội",
    parent_code: "218",
  },
  {
    value: "09823",
    label: "Xã Đan Phượng",
    parent_code: "273",
  },
  {
    value: "24922",
    label: "Xã Đan Phượng",
    parent_code: "676",
  },
  {
    value: "08062",
    label: "Xã Đan Thượng",
    parent_code: "231",
  },
  {
    value: "18358",
    label: "Xã Đan Trường",
    parent_code: "442",
  },
  {
    value: "01045",
    label: "Xã Đản Ván",
    parent_code: "032",
  },
  {
    value: "12154",
    label: "Xã Đào Dương",
    parent_code: "329",
  },
  {
    value: "00955",
    label: "Xã Đạo Đức",
    parent_code: "030",
  },
  {
    value: "08962",
    label: "Thị trấn Đạo Đức",
    parent_code: "249",
  },
  {
    value: "30493",
    label: "Xã Đào Hữu Cảnh",
    parent_code: "889",
  },
  {
    value: "22762",
    label: "Phường Đạo Long",
    parent_code: "582",
  },
  {
    value: "13579",
    label: "Xã Đạo Lý",
    parent_code: "353",
  },
  {
    value: "07390",
    label: "Xã Đào Mỹ",
    parent_code: "217",
  },
  {
    value: "24757",
    label: "Xã Đạo Nghĩa",
    parent_code: "666",
  },
  {
    value: "28282",
    label: "Xã Đạo Thạnh",
    parent_code: "815",
  },
  {
    value: "04507",
    label: "Xã Đào Thịnh",
    parent_code: "138",
  },
  {
    value: "08914",
    label: "Xã Đạo Trù",
    parent_code: "248",
  },
  {
    value: "08884",
    label: "Xã Đạo Tú",
    parent_code: "247",
  },
  {
    value: "09301",
    label: "Xã Đào Viên",
    parent_code: "259",
  },
  {
    value: "06043",
    label: "Xã Đào Viên",
    parent_code: "180",
  },
  {
    value: "02467",
    label: "Xã Đạo Viện",
    parent_code: "075",
  },
  {
    value: "08662",
    label: "Xã Đào Xá",
    parent_code: "239",
  },
  {
    value: "05926",
    label: "Xã Đào Xá",
    parent_code: "173",
  },
  {
    value: "09166",
    label: "Phường Đáp Cầu",
    parent_code: "256",
  },
  {
    value: "06979",
    label: "Xã Đạp Thanh",
    parent_code: "202",
  },
  {
    value: "24318",
    label: "Phường Đạt Hiếu",
    parent_code: "644",
  },
  {
    value: "20716",
    label: "Xã Đắc Pre",
    parent_code: "510",
  },
  {
    value: "20719",
    label: "Xã Đắc Pring",
    parent_code: "510",
  },
  {
    value: "09865",
    label: "Xã Đắc Sở",
    parent_code: "274",
  },
  {
    value: "05875",
    label: "Xã Đắc Sơn",
    parent_code: "172",
  },
  {
    value: "20705",
    label: "Xã Đắc Tôi",
    parent_code: "510",
  },
  {
    value: "23380",
    label: "Xã Đắk Ang",
    parent_code: "611",
  },
  {
    value: "23323",
    label: "Xã Đắk Blà",
    parent_code: "608",
  },
  {
    value: "23344",
    label: "Xã Đắk Blô",
    parent_code: "610",
  },
  {
    value: "24739",
    label: "Xã Đắk Búk So",
    parent_code: "667",
  },
  {
    value: "23311",
    label: "Xã Đắk Cấm",
    parent_code: "608",
  },
  {
    value: "23356",
    label: "Xã Đắk Choong",
    parent_code: "610",
  },
  {
    value: "23806",
    label: "Xã Đăk Djrăng",
    parent_code: "629",
  },
  {
    value: "24700",
    label: "Xã Đắk Drô",
    parent_code: "664",
  },
  {
    value: "24652",
    label: "Xã Đắk DRông",
    parent_code: "662",
  },
  {
    value: "23383",
    label: "Xã Đắk Dục",
    parent_code: "611",
  },
  {
    value: "23677",
    label: "Thị trấn Đăk Đoa",
    parent_code: "626",
  },
  {
    value: "24673",
    label: "Xã Đắk Gằn",
    parent_code: "663",
  },
  {
    value: "23341",
    label: "Thị trấn Đắk Glei",
    parent_code: "610",
  },
  {
    value: "24622",
    label: "Xã Đắk Ha",
    parent_code: "661",
  },
  {
    value: "23500",
    label: "Thị trấn Đắk Hà",
    parent_code: "615",
  },
  {
    value: "23425",
    label: "Xã Đắk Hà",
    parent_code: "617",
  },
  {
    value: "23674",
    label: "Xã Đăk HLơ",
    parent_code: "625",
  },
  {
    value: "24719",
    label: "Xã Đắk Hòa",
    parent_code: "665",
  },
  {
    value: "23506",
    label: "Xã Đắk HRing",
    parent_code: "615",
  },
  {
    value: "23392",
    label: "Xã Đắk Kan",
    parent_code: "611",
  },
  {
    value: "23482",
    label: "Xã Đắk Kôi",
    parent_code: "614",
  },
  {
    value: "23840",
    label: "Xã Đắk Kơ Ning",
    parent_code: "630",
  },
  {
    value: "23684",
    label: "Xã Đăk Krong",
    parent_code: "626",
  },
  {
    value: "23371",
    label: "Xã Đắk KRoong",
    parent_code: "610",
  },
  {
    value: "23524",
    label: "Xã Đắk La",
    parent_code: "615",
  },
  {
    value: "24589",
    label: "Xã Đắk Liêng",
    parent_code: "656",
  },
  {
    value: "23504",
    label: "Xã Đăk Long",
    parent_code: "615",
  },
  {
    value: "23368",
    label: "Xã Đắk Long",
    parent_code: "610",
  },
  {
    value: "23347",
    label: "Xã Đắk Man",
    parent_code: "610",
  },
  {
    value: "23512",
    label: "Xã Đắk Mar",
    parent_code: "615",
  },
  {
    value: "24688",
    label: "Thị trấn Đắk Mâm",
    parent_code: "664",
  },
  {
    value: "24664",
    label: "Thị trấn Đắk Mil",
    parent_code: "663",
  },
  {
    value: "24718",
    label: "Xã Đắk Môl",
    parent_code: "665",
  },
  {
    value: "23374",
    label: "Xã Đắk Môn",
    parent_code: "610",
  },
  {
    value: "24677",
    label: "Xã Đắk N'Drót",
    parent_code: "663",
  },
  {
    value: "24727",
    label: "Xã Đắk N'Dung",
    parent_code: "665",
  },
  {
    value: "23407",
    label: "Xã Đắk Na",
    parent_code: "617",
  },
  {
    value: "24709",
    label: "Xã Đắk Nang",
    parent_code: "664",
  },
  {
    value: "23327",
    label: "Xã Đăk Năng",
    parent_code: "608",
  },
  {
    value: "23452",
    label: "Xã Đắk Nên",
    parent_code: "613",
  },
  {
    value: "24746",
    label: "Xã Đắk Ngo",
    parent_code: "667",
  },
  {
    value: "23510",
    label: "Xã Đăk Ngọk",
    parent_code: "615",
  },
  {
    value: "23350",
    label: "Xã Đắk Nhoong",
    parent_code: "610",
  },
  {
    value: "24628",
    label: "Xã Đắk Nia",
    parent_code: "660",
  },
  {
    value: "23386",
    label: "Xã Đắk Nông",
    parent_code: "611",
  },
  {
    value: "24601",
    label: "Xã Đắk Nuê",
    parent_code: "656",
  },
  {
    value: "23353",
    label: "Xã Đắk Pék",
    parent_code: "610",
  },
  {
    value: "24598",
    label: "Xã Đắk Phơi",
    parent_code: "656",
  },
  {
    value: "24634",
    label: "Xã Đắk Plao",
    parent_code: "661",
  },
  {
    value: "23843",
    label: "Xã Đăk Pling",
    parent_code: "630",
  },
  {
    value: "23491",
    label: "Xã Đắk Pne",
    parent_code: "614",
  },
  {
    value: "23846",
    label: "Xã Đăk Pơ Pho",
    parent_code: "630",
  },
  {
    value: "23503",
    label: "Xã Đắk PXi",
    parent_code: "615",
  },
  {
    value: "24670",
    label: "Xã Đắk R'La",
    parent_code: "663",
  },
  {
    value: "24625",
    label: "Xã Đắk R'Măng",
    parent_code: "661",
  },
  {
    value: "24618",
    label: "Xã Đăk R'Moan",
    parent_code: "660",
  },
  {
    value: "24742",
    label: "Xã Đắk R'Tíh",
    parent_code: "667",
  },
  {
    value: "23455",
    label: "Xã Đắk Ring",
    parent_code: "613",
  },
  {
    value: "23644",
    label: "Xã Đăk Roong",
    parent_code: "625",
  },
  {
    value: "23427",
    label: "Xã Đắk Rơ Nga",
    parent_code: "612",
  },
  {
    value: "23417",
    label: "Xã Đắk Rơ Ông",
    parent_code: "617",
  },
  {
    value: "23335",
    label: "Xã Đắk Rơ Wa",
    parent_code: "608",
  },
  {
    value: "24763",
    label: "Xã Đắk Ru",
    parent_code: "666",
  },
  {
    value: "23488",
    label: "Xã Đắk Ruồng",
    parent_code: "614",
  },
  {
    value: "23479",
    label: "Thị trấn Đắk Rve",
    parent_code: "614",
  },
  {
    value: "23416",
    label: "Xã Đắk Sao",
    parent_code: "617",
  },
  {
    value: "24679",
    label: "Xã Đắk Sắk",
    parent_code: "663",
  },
  {
    value: "24760",
    label: "Xã Đắk Sin",
    parent_code: "666",
  },
  {
    value: "24637",
    label: "Xã Đắk Som",
    parent_code: "661",
  },
  {
    value: "23842",
    label: "Xã Đăk Song",
    parent_code: "630",
  },
  {
    value: "24691",
    label: "Xã Đắk Sôr",
    parent_code: "664",
  },
  {
    value: "23683",
    label: "Xã Đăk Sơmei",
    parent_code: "626",
  },
  {
    value: "23461",
    label: "Xã Đắk Tăng",
    parent_code: "613",
  },
  {
    value: "23401",
    label: "Thị trấn Đắk Tô",
    parent_code: "612",
  },
  {
    value: "23419",
    label: "Xã Đắk Tờ Kan",
    parent_code: "617",
  },
  {
    value: "23485",
    label: "Xã Đắk Tơ Lung",
    parent_code: "614",
  },
  {
    value: "23836",
    label: "Xã Đăk Tơ Pang",
    parent_code: "630",
  },
  {
    value: "23494",
    label: "Xã Đắk Tờ Re",
    parent_code: "614",
  },
  {
    value: "23740",
    label: "Xã Đăk Tơ Ver",
    parent_code: "627",
  },
  {
    value: "23430",
    label: "Xã Đắk Trăm",
    parent_code: "612",
  },
  {
    value: "23821",
    label: "Xã Đăk Trôi",
    parent_code: "629",
  },
  {
    value: "23509",
    label: "Xã Đắk Ui",
    parent_code: "615",
  },
  {
    value: "24750",
    label: "Xã Đắk Wer",
    parent_code: "666",
  },
  {
    value: "24643",
    label: "Xã Đắk Wil",
    parent_code: "662",
  },
  {
    value: "23389",
    label: "Xã Đắk Xú",
    parent_code: "611",
  },
  {
    value: "23803",
    label: "Xã Đăk Yă",
    parent_code: "629",
  },
  {
    value: "11614",
    label: "Xã Đặng Cương",
    parent_code: "312",
  },
  {
    value: "11359",
    label: "Phường Đằng Giang",
    parent_code: "304",
  },
  {
    value: "25426",
    label: "Xã Đăng Hà",
    parent_code: "696",
  },
  {
    value: "11416",
    label: "Phường Đằng Hải",
    parent_code: "306",
  },
  {
    value: "28624",
    label: "Xã Đăng Hưng Phước",
    parent_code: "822",
  },
  {
    value: "11413",
    label: "Phường Đằng Lâm",
    parent_code: "306",
  },
  {
    value: "12178",
    label: "Xã Đặng Lễ",
    parent_code: "329",
  },
  {
    value: "17650",
    label: "Xã Đặng Sơn",
    parent_code: "427",
  },
  {
    value: "00556",
    label: "Xã Đặng Xá",
    parent_code: "018",
  },
  {
    value: "32152",
    label: "Thị trấn Đầm Dơi",
    parent_code: "970",
  },
  {
    value: "06895",
    label: "Thị trấn Đầm Hà",
    parent_code: "200",
  },
  {
    value: "06916",
    label: "Xã Đầm Hà",
    parent_code: "200",
  },
  {
    value: "21910",
    label: "Phường Đập Đá",
    parent_code: "549",
  },
  {
    value: "24088",
    label: "Xã Đất Bằng",
    parent_code: "637",
  },
  {
    value: "25907",
    label: "Xã Đất Cuốc",
    parent_code: "726",
  },
  {
    value: "26680",
    label: "Thị trấn Đất Đỏ",
    parent_code: "753",
  },
  {
    value: "32200",
    label: "Xã Đất Mới",
    parent_code: "971",
  },
  {
    value: "32248",
    label: "Xã Đất Mũi",
    parent_code: "973",
  },
  {
    value: "18127",
    label: "Phường Đậu Liêu",
    parent_code: "437",
  },
  {
    value: "07609",
    label: "Xã Đèo Gia",
    parent_code: "219",
  },
  {
    value: "23815",
    label: "Xã Đê Ar",
    parent_code: "629",
  },
  {
    value: "01282",
    label: "Phường Đề Thám",
    parent_code: "040",
  },
  {
    value: "12439",
    label: "Phường Đề Thám",
    parent_code: "336",
  },
  {
    value: "06046",
    label: "Xã Đề Thám",
    parent_code: "180",
  },
  {
    value: "01915",
    label: "Xã Địa Linh",
    parent_code: "061",
  },
  {
    value: "08572",
    label: "Xã Địch Quả",
    parent_code: "238",
  },
  {
    value: "06280",
    label: "Xã Điềm He",
    parent_code: "184",
  },
  {
    value: "28540",
    label: "Xã Điềm Hy",
    parent_code: "821",
  },
  {
    value: "05590",
    label: "Xã Điềm Mặc",
    parent_code: "167",
  },
  {
    value: "05941",
    label: "Xã Điềm Thụy",
    parent_code: "173",
  },
  {
    value: "20575",
    label: "Phường Điện An",
    parent_code: "507",
  },
  {
    value: "00019",
    label: "Phường Điện Biên",
    parent_code: "001",
  },
  {
    value: "14767",
    label: "Phường Điện Biên",
    parent_code: "380",
  },
  {
    value: "03203",
    label: "Thị trấn Điện Biên Đông",
    parent_code: "101",
  },
  {
    value: "20581",
    label: "Phường Điện Dương",
    parent_code: "507",
  },
  {
    value: "14929",
    label: "Xã Điền Hạ",
    parent_code: "386",
  },
  {
    value: "19843",
    label: "Xã Điền Hải",
    parent_code: "476",
  },
  {
    value: "31985",
    label: "Xã Điền Hải",
    parent_code: "960",
  },
  {
    value: "19834",
    label: "Xã Điền Hòa",
    parent_code: "476",
  },
  {
    value: "20557",
    label: "Xã Điện Hòa",
    parent_code: "507",
  },
  {
    value: "20566",
    label: "Xã Điện Hồng",
    parent_code: "507",
  },
  {
    value: "19822",
    label: "Xã Điền Hương",
    parent_code: "476",
  },
  {
    value: "19828",
    label: "Xã Điền Lộc",
    parent_code: "476",
  },
  {
    value: "14950",
    label: "Xã Điền Lư",
    parent_code: "386",
  },
  {
    value: "20593",
    label: "Xã Điện Minh",
    parent_code: "507",
  },
  {
    value: "19825",
    label: "Xã Điền Môn",
    parent_code: "476",
  },
  {
    value: "18499",
    label: "Xã Điền Mỹ",
    parent_code: "444",
  },
  {
    value: "20578",
    label: "Phường Điện Nam Bắc",
    parent_code: "507",
  },
  {
    value: "20580",
    label: "Phường Điện Nam Đông",
    parent_code: "507",
  },
  {
    value: "20579",
    label: "Phường Điện Nam Trung",
    parent_code: "507",
  },
  {
    value: "20563",
    label: "Phường Điện Ngọc",
    parent_code: "507",
  },
  {
    value: "20590",
    label: "Xã Điện Phong",
    parent_code: "507",
  },
  {
    value: "20572",
    label: "Xã Điện Phước",
    parent_code: "507",
  },
  {
    value: "20596",
    label: "Xã Điện Phương",
    parent_code: "507",
  },
  {
    value: "02959",
    label: "Xã Điện Quan",
    parent_code: "087",
  },
  {
    value: "14932",
    label: "Xã Điền Quang",
    parent_code: "386",
  },
  {
    value: "20584",
    label: "Xã Điện Quang",
    parent_code: "507",
  },
  {
    value: "20560",
    label: "Xã Điện Thắng Bắc",
    parent_code: "507",
  },
  {
    value: "20562",
    label: "Xã Điện Thắng Nam",
    parent_code: "507",
  },
  {
    value: "20561",
    label: "Xã Điện Thắng Trung",
    parent_code: "507",
  },
  {
    value: "20569",
    label: "Xã Điện Thọ",
    parent_code: "507",
  },
  {
    value: "14926",
    label: "Xã Điền Thượng",
    parent_code: "386",
  },
  {
    value: "20554",
    label: "Xã Điện Tiến",
    parent_code: "507",
  },
  {
    value: "14935",
    label: "Xã Điền Trung",
    parent_code: "386",
  },
  {
    value: "20587",
    label: "Xã Điện Trung",
    parent_code: "507",
  },
  {
    value: "06874",
    label: "Xã Điền Xá",
    parent_code: "199",
  },
  {
    value: "13972",
    label: "Xã Điền Xá",
    parent_code: "362",
  },
  {
    value: "12589",
    label: "Xã Điệp Nông",
    parent_code: "339",
  },
  {
    value: "08428",
    label: "Xã Điêu Lương",
    parent_code: "235",
  },
  {
    value: "25789",
    label: "Xã Định An",
    parent_code: "720",
  },
  {
    value: "29462",
    label: "Thị trấn Định An",
    parent_code: "849",
  },
  {
    value: "29494",
    label: "Xã Định An",
    parent_code: "849",
  },
  {
    value: "30196",
    label: "Xã Định An",
    parent_code: "875",
  },
  {
    value: "30964",
    label: "Xã Định An",
    parent_code: "907",
  },
  {
    value: "18595",
    label: "Xã Đỉnh Bàn",
    parent_code: "445",
  },
  {
    value: "09394",
    label: "Phường Đình Bảng",
    parent_code: "261",
  },
  {
    value: "05575",
    label: "Xã Định Biên",
    parent_code: "167",
  },
  {
    value: "15478",
    label: "Xã Định Bình",
    parent_code: "394",
  },
  {
    value: "32035",
    label: "Xã Định Bình",
    parent_code: "964",
  },
  {
    value: "05716",
    label: "Thị trấn Đình Cả",
    parent_code: "170",
  },
  {
    value: "12412",
    label: "Xã Đình Cao",
    parent_code: "333",
  },
  {
    value: "08857",
    label: "Xã Đình Chu",
    parent_code: "246",
  },
  {
    value: "00307",
    label: "Phường Định Công",
    parent_code: "008",
  },
  {
    value: "15454",
    label: "Xã Định Công",
    parent_code: "394",
  },
  {
    value: "05320",
    label: "Xã Định Cư",
    parent_code: "157",
  },
  {
    value: "12004",
    label: "Xã Đình Dù",
    parent_code: "325",
  },
  {
    value: "15475",
    label: "Xã Định Hải",
    parent_code: "394",
  },
  {
    value: "16600",
    label: "Xã Định Hải",
    parent_code: "407",
  },
  {
    value: "25798",
    label: "Xã Định Hiệp",
    parent_code: "720",
  },
  {
    value: "25759",
    label: "Phường Định Hoà",
    parent_code: "718",
  },
  {
    value: "15448",
    label: "Xã Định Hòa",
    parent_code: "394",
  },
  {
    value: "30238",
    label: "Xã Định Hòa",
    parent_code: "876",
  },
  {
    value: "30958",
    label: "Xã Định Hòa",
    parent_code: "907",
  },
  {
    value: "14677",
    label: "Xã Định Hóa",
    parent_code: "376",
  },
  {
    value: "15472",
    label: "Xã Định Hưng",
    parent_code: "394",
  },
  {
    value: "25018",
    label: "Xã Đinh Lạc",
    parent_code: "679",
  },
  {
    value: "06613",
    label: "Thị trấn Đình Lập",
    parent_code: "189",
  },
  {
    value: "06628",
    label: "Xã Đình Lập",
    parent_code: "189",
  },
  {
    value: "15466",
    label: "Xã Định Liên",
    parent_code: "394",
  },
  {
    value: "15463",
    label: "Xã Định Long",
    parent_code: "394",
  },
  {
    value: "31288",
    label: "Xã Định Môn",
    parent_code: "927",
  },
  {
    value: "30706",
    label: "Xã Định Mỹ",
    parent_code: "894",
  },
  {
    value: "01489",
    label: "Xã Đình Phong",
    parent_code: "047",
  },
  {
    value: "01357",
    label: "Xã Đình Phùng",
    parent_code: "043",
  },
  {
    value: "13123",
    label: "Xã Đình Phùng",
    parent_code: "343",
  },
  {
    value: "26206",
    label: "Thị trấn Định Quán",
    parent_code: "736",
  },
  {
    value: "17344",
    label: "Xã Đỉnh Sơn",
    parent_code: "424",
  },
  {
    value: "10918",
    label: "Xã Định Sơn",
    parent_code: "295",
  },
  {
    value: "15445",
    label: "Xã Định Tăng",
    parent_code: "394",
  },
  {
    value: "15457",
    label: "Xã Định Tân",
    parent_code: "394",
  },
  {
    value: "15451",
    label: "Xã Định Thành",
    parent_code: "394",
  },
  {
    value: "25795",
    label: "Xã Định Thành",
    parent_code: "720",
  },
  {
    value: "30709",
    label: "Xã Định Thành",
    parent_code: "894",
  },
  {
    value: "31993",
    label: "Xã Định Thành",
    parent_code: "960",
  },
  {
    value: "31996",
    label: "Xã Định Thành A",
    parent_code: "960",
  },
  {
    value: "28930",
    label: "Xã Định Thủy",
    parent_code: "833",
  },
  {
    value: "15460",
    label: "Xã Định Tiến",
    parent_code: "394",
  },
  {
    value: "09415",
    label: "Xã Đình Tổ",
    parent_code: "262",
  },
  {
    value: "25024",
    label: "Xã Đinh Trang Hòa",
    parent_code: "679",
  },
  {
    value: "25003",
    label: "Xã Đinh Trang Thượng",
    parent_code: "679",
  },
  {
    value: "08725",
    label: "Xã Định Trung",
    parent_code: "243",
  },
  {
    value: "29080",
    label: "Xã Định Trung",
    parent_code: "835",
  },
  {
    value: "24871",
    label: "Thị trấn Đinh Văn",
    parent_code: "676",
  },
  {
    value: "13507",
    label: "Xã Đinh Xá",
    parent_code: "347",
  },
  {
    value: "00538",
    label: "Xã Đình Xuyên",
    parent_code: "018",
  },
  {
    value: "30199",
    label: "Xã Định Yên",
    parent_code: "875",
  },
  {
    value: "24346",
    label: "Xã ĐLiê Ya",
    parent_code: "650",
  },
  {
    value: "01525",
    label: "Xã Đoài Dương",
    parent_code: "047",
  },
  {
    value: "07867",
    label: "Xã Đoan Bái",
    parent_code: "223",
  },
  {
    value: "12406",
    label: "Xã Đoàn Đào",
    parent_code: "333",
  },
  {
    value: "08683",
    label: "Xã Đoan Hạ",
    parent_code: "239",
  },
  {
    value: "07969",
    label: "Thị trấn Đoan Hùng",
    parent_code: "230",
  },
  {
    value: "12616",
    label: "Xã Đoan Hùng",
    parent_code: "339",
  },
  {
    value: "11263",
    label: "Xã Đoàn Kết",
    parent_code: "300",
  },
  {
    value: "05380",
    label: "Xã Đoàn Kết",
    parent_code: "158",
  },
  {
    value: "06001",
    label: "Xã Đoàn Kết",
    parent_code: "180",
  },
  {
    value: "07009",
    label: "Xã Đoàn Kết",
    parent_code: "203",
  },
  {
    value: "03389",
    label: "Phường Đoàn Kết",
    parent_code: "105",
  },
  {
    value: "04858",
    label: "Xã Đoàn Kết",
    parent_code: "150",
  },
  {
    value: "25120",
    label: "Xã Đoàn Kết",
    parent_code: "681",
  },
  {
    value: "25411",
    label: "Xã Đoàn Kết",
    parent_code: "696",
  },
  {
    value: "23329",
    label: "Xã Đoàn Kết",
    parent_code: "608",
  },
  {
    value: "24044",
    label: "Phường Đoàn Kết",
    parent_code: "624",
  },
  {
    value: "24322",
    label: "Phường Đoàn Kết",
    parent_code: "644",
  },
  {
    value: "11785",
    label: "Xã Đoàn Lập",
    parent_code: "315",
  },
  {
    value: "11056",
    label: "Xã Đoàn Thượng",
    parent_code: "297",
  },
  {
    value: "11251",
    label: "Xã Đoàn Tùng",
    parent_code: "300",
  },
  {
    value: "11746",
    label: "Xã Đoàn Xá",
    parent_code: "314",
  },
  {
    value: "16825",
    label: "Xã Đoọc Mạy",
    parent_code: "417",
  },
  {
    value: "10153",
    label: "Xã Đỗ Động",
    parent_code: "278",
  },
  {
    value: "12691",
    label: "Xã Đô Lương",
    parent_code: "340",
  },
  {
    value: "17617",
    label: "Thị trấn Đô Lương",
    parent_code: "427",
  },
  {
    value: "08221",
    label: "Xã Đỗ Sơn",
    parent_code: "232",
  },
  {
    value: "17527",
    label: "Xã Đô Thành",
    parent_code: "426",
  },
  {
    value: "22738",
    label: "Phường Đô Vinh",
    parent_code: "582",
  },
  {
    value: "08224",
    label: "Xã Đỗ Xuyên",
    parent_code: "232",
  },
  {
    value: "30061",
    label: "Xã Đốc Binh Kiều",
    parent_code: "872",
  },
  {
    value: "01594",
    label: "Xã Độc Lập",
    parent_code: "049",
  },
  {
    value: "12676",
    label: "Xã Độc Lập",
    parent_code: "339",
  },
  {
    value: "04921",
    label: "Xã Độc Lập",
    parent_code: "148",
  },
  {
    value: "10486",
    label: "Xã Đốc Tín",
    parent_code: "282",
  },
  {
    value: "26284",
    label: "Xã Đồi 61",
    parent_code: "737",
  },
  {
    value: "10420",
    label: "Xã Đội Bình",
    parent_code: "281",
  },
  {
    value: "02533",
    label: "Xã Đội Bình",
    parent_code: "075",
  },
  {
    value: "00022",
    label: "Phường Đội Cấn",
    parent_code: "001",
  },
  {
    value: "06025",
    label: "Xã Đội Cấn",
    parent_code: "180",
  },
  {
    value: "02524",
    label: "Phường Đội Cấn",
    parent_code: "070",
  },
  {
    value: "16684",
    label: "Phường Đội Cung",
    parent_code: "412",
  },
  {
    value: "07444",
    label: "Thị trấn Đồi Ngô",
    parent_code: "218",
  },
  {
    value: "29500",
    label: "Xã Đôn Châu",
    parent_code: "850",
  },
  {
    value: "06988",
    label: "Xã Đồn Đạc",
    parent_code: "202",
  },
  {
    value: "08806",
    label: "Xã Đôn Nhân",
    parent_code: "253",
  },
  {
    value: "01984",
    label: "Xã Đôn Phong",
    parent_code: "063",
  },
  {
    value: "17242",
    label: "Xã Đôn Phục",
    parent_code: "422",
  },
  {
    value: "25711",
    label: "Xã Đôn Thuận",
    parent_code: "712",
  },
  {
    value: "13525",
    label: "Xã Đồn Xá",
    parent_code: "352",
  },
  {
    value: "29497",
    label: "Xã Đôn Xuân",
    parent_code: "850",
  },
  {
    value: "23659",
    label: "Xã Đông",
    parent_code: "625",
  },
  {
    value: "12802",
    label: "Xã Đông Á",
    parent_code: "340",
  },
  {
    value: "04396",
    label: "Xã Đông An",
    parent_code: "136",
  },
  {
    value: "00454",
    label: "Thị trấn Đông Anh",
    parent_code: "017",
  },
  {
    value: "19768",
    label: "Phường Đông Ba",
    parent_code: "474",
  },
  {
    value: "11923",
    label: "Xã Đồng Bài",
    parent_code: "317",
  },
  {
    value: "05014",
    label: "Xã Đông Bắc",
    parent_code: "153",
  },
  {
    value: "05710",
    label: "Phường Đồng Bẩm",
    parent_code: "164",
  },
  {
    value: "29812",
    label: "Xã Đông Bình",
    parent_code: "861",
  },
  {
    value: "31279",
    label: "Xã Đông Bình",
    parent_code: "927",
  },
  {
    value: "06553",
    label: "Xã Đồng Bục",
    parent_code: "188",
  },
  {
    value: "12757",
    label: "Xã Đông Các",
    parent_code: "340",
  },
  {
    value: "05896",
    label: "Xã Đông Cao",
    parent_code: "172",
  },
  {
    value: "10804",
    label: "Xã Đồng Cẩm",
    parent_code: "293",
  },
  {
    value: "04852",
    label: "Xã Đồng Chum",
    parent_code: "150",
  },
  {
    value: "07591",
    label: "Xã Đồng Cốc",
    parent_code: "219",
  },
  {
    value: "13018",
    label: "Xã Đông Cơ",
    parent_code: "342",
  },
  {
    value: "04399",
    label: "Xã Đông Cuông",
    parent_code: "136",
  },
  {
    value: "14791",
    label: "Phường Đông Cương",
    parent_code: "380",
  },
  {
    value: "12706",
    label: "Xã Đông Cường",
    parent_code: "340",
  },
  {
    value: "09028",
    label: "Xã Đồng Cương",
    parent_code: "251",
  },
  {
    value: "08638",
    label: "Xã Đông Cửu",
    parent_code: "238",
  },
  {
    value: "09487",
    label: "Xã Đông Cứu",
    parent_code: "263",
  },
  {
    value: "13516",
    label: "Xã Đồng Du",
    parent_code: "352",
  },
  {
    value: "00574",
    label: "Xã Đông Dư",
    parent_code: "018",
  },
  {
    value: "12811",
    label: "Xã Đông Dương",
    parent_code: "340",
  },
  {
    value: "08716",
    label: "Phường Đống Đa",
    parent_code: "243",
  },
  {
    value: "23579",
    label: "Phường Đống Đa",
    parent_code: "622",
  },
  {
    value: "21556",
    label: "Phường Đống Đa",
    parent_code: "540",
  },
  {
    value: "05629",
    label: "Xã Động Đạt",
    parent_code: "168",
  },
  {
    value: "06184",
    label: "Thị trấn Đồng Đăng",
    parent_code: "183",
  },
  {
    value: "12631",
    label: "Xã Đông Đô",
    parent_code: "339",
  },
  {
    value: "12775",
    label: "Xã Đông Động",
    parent_code: "340",
  },
  {
    value: "23074",
    label: "Xã Đông Giang",
    parent_code: "597",
  },
  {
    value: "19330",
    label: "Phường Đông Giang",
    parent_code: "461",
  },
  {
    value: "06295",
    label: "Xã Đồng Giáp",
    parent_code: "184",
  },
  {
    value: "00895",
    label: "Xã Đông Hà",
    parent_code: "029",
  },
  {
    value: "23224",
    label: "Xã Đông Hà",
    parent_code: "600",
  },
  {
    value: "11395",
    label: "Phường Đông Hải",
    parent_code: "305",
  },
  {
    value: "06883",
    label: "Xã Đông Hải",
    parent_code: "199",
  },
  {
    value: "12574",
    label: "Xã Đông Hải",
    parent_code: "338",
  },
  {
    value: "14797",
    label: "Phường Đông Hải",
    parent_code: "380",
  },
  {
    value: "22768",
    label: "Phường Đông Hải",
    parent_code: "582",
  },
  {
    value: "29536",
    label: "Xã Đông Hải",
    parent_code: "850",
  },
  {
    value: "18868",
    label: "Phường Đồng Hải",
    parent_code: "450",
  },
  {
    value: "11410",
    label: "Phường Đông Hải 1",
    parent_code: "306",
  },
  {
    value: "11411",
    label: "Phường Đông Hải 2",
    parent_code: "306",
  },
  {
    value: "31273",
    label: "Xã Đông Hiệp",
    parent_code: "925",
  },
  {
    value: "17017",
    label: "Xã Đông Hiếu",
    parent_code: "414",
  },
  {
    value: "26266",
    label: "Xã Đông Hoà",
    parent_code: "737",
  },
  {
    value: "12457",
    label: "Xã Đông Hòa",
    parent_code: "336",
  },
  {
    value: "16390",
    label: "Xã Đông Hòa",
    parent_code: "405",
  },
  {
    value: "25957",
    label: "Phường Đông Hòa",
    parent_code: "724",
  },
  {
    value: "28549",
    label: "Xã Đông Hòa",
    parent_code: "821",
  },
  {
    value: "31024",
    label: "Xã Đông Hòa",
    parent_code: "909",
  },
  {
    value: "11431",
    label: "Phường Đồng Hoà",
    parent_code: "307",
  },
  {
    value: "13405",
    label: "Xã Đồng Hóa",
    parent_code: "350",
  },
  {
    value: "18976",
    label: "Xã Đồng Hóa",
    parent_code: "453",
  },
  {
    value: "28411",
    label: "Xã Đông Hòa Hiệp",
    parent_code: "819",
  },
  {
    value: "12808",
    label: "Xã Đông Hoàng",
    parent_code: "340",
  },
  {
    value: "13000",
    label: "Xã Đông Hoàng",
    parent_code: "342",
  },
  {
    value: "16381",
    label: "Xã Đông Hoàng",
    parent_code: "405",
  },
  {
    value: "30769",
    label: "Phường Đông Hồ",
    parent_code: "900",
  },
  {
    value: "00523",
    label: "Xã Đông Hội",
    parent_code: "017",
  },
  {
    value: "12751",
    label: "Xã Đông Hợp",
    parent_code: "340",
  },
  {
    value: "17047",
    label: "Xã Đồng Hợp",
    parent_code: "420",
  },
  {
    value: "11815",
    label: "Xã Đông Hưng",
    parent_code: "315",
  },
  {
    value: "07450",
    label: "Xã Đông Hưng",
    parent_code: "218",
  },
  {
    value: "12688",
    label: "Thị trấn Đông Hưng",
    parent_code: "340",
  },
  {
    value: "31033",
    label: "Xã Đông Hưng",
    parent_code: "909",
  },
  {
    value: "32142",
    label: "Xã Đông Hưng",
    parent_code: "969",
  },
  {
    value: "31036",
    label: "Xã Đông Hưng A",
    parent_code: "909",
  },
  {
    value: "31039",
    label: "Xã Đông Hưng B",
    parent_code: "909",
  },
  {
    value: "26788",
    label: "Phường Đông Hưng Thuận",
    parent_code: "761",
  },
  {
    value: "14794",
    label: "Phường Đông Hương",
    parent_code: "380",
  },
  {
    value: "14656",
    label: "Xã Đồng Hướng",
    parent_code: "376",
  },
  {
    value: "07258",
    label: "Xã Đồng Hưu",
    parent_code: "215",
  },
  {
    value: "08839",
    label: "Xã Đồng Ích",
    parent_code: "246",
  },
  {
    value: "12232",
    label: "Xã Đông Kết",
    parent_code: "330",
  },
  {
    value: "01786",
    label: "Thị trấn Đông Khê",
    parent_code: "053",
  },
  {
    value: "11350",
    label: "Phường Đông Khê",
    parent_code: "304",
  },
  {
    value: "16408",
    label: "Xã Đông Khê",
    parent_code: "405",
  },
  {
    value: "04690",
    label: "Xã Đồng Khê",
    parent_code: "140",
  },
  {
    value: "23173",
    label: "Xã Đồng Kho",
    parent_code: "599",
  },
  {
    value: "25594",
    label: "Xã Đồng Khởi",
    parent_code: "708",
  },
  {
    value: "05980",
    label: "Phường Đông Kinh",
    parent_code: "178",
  },
  {
    value: "12748",
    label: "Xã Đông Kinh",
    parent_code: "340",
  },
  {
    value: "07282",
    label: "Xã Đồng Kỳ",
    parent_code: "215",
  },
  {
    value: "09382",
    label: "Phường Đồng Kỵ",
    parent_code: "261",
  },
  {
    value: "09892",
    label: "Xã Đông La",
    parent_code: "274",
  },
  {
    value: "12718",
    label: "Xã Đông La",
    parent_code: "340",
  },
  {
    value: "10105",
    label: "Xã Đồng Lạc",
    parent_code: "277",
  },
  {
    value: "02029",
    label: "Xã Đồng Lạc",
    parent_code: "064",
  },
  {
    value: "10600",
    label: "Phường Đồng Lạc",
    parent_code: "290",
  },
  {
    value: "10657",
    label: "Xã Đồng Lạc",
    parent_code: "291",
  },
  {
    value: "07270",
    label: "Xã Đồng Lạc",
    parent_code: "215",
  },
  {
    value: "08320",
    label: "Xã Đồng Lạc",
    parent_code: "234",
  },
  {
    value: "05173",
    label: "Xã Đông Lai",
    parent_code: "155",
  },
  {
    value: "13024",
    label: "Xã Đông Lâm",
    parent_code: "342",
  },
  {
    value: "07042",
    label: "Xã Đồng Lâm",
    parent_code: "193",
  },
  {
    value: "19336",
    label: "Phường Đông Lễ",
    parent_code: "461",
  },
  {
    value: "18949",
    label: "Thị trấn Đồng Lê",
    parent_code: "453",
  },
  {
    value: "05914",
    label: "Xã Đồng Liên",
    parent_code: "164",
  },
  {
    value: "08158",
    label: "Xã Đông Lĩnh",
    parent_code: "232",
  },
  {
    value: "16396",
    label: "Phường Đông Lĩnh",
    parent_code: "380",
  },
  {
    value: "01543",
    label: "Xã Đồng Loan",
    parent_code: "048",
  },
  {
    value: "12979",
    label: "Xã Đông Long",
    parent_code: "342",
  },
  {
    value: "10426",
    label: "Xã Đông Lỗ",
    parent_code: "281",
  },
  {
    value: "07879",
    label: "Xã Đông Lỗ",
    parent_code: "223",
  },
  {
    value: "16015",
    label: "Xã Đồng Lộc",
    parent_code: "400",
  },
  {
    value: "18484",
    label: "Thị trấn Đồng Lộc",
    parent_code: "443",
  },
  {
    value: "02602",
    label: "Xã Đông Lợi",
    parent_code: "076",
  },
  {
    value: "15721",
    label: "Xã Đồng Lợi",
    parent_code: "397",
  },
  {
    value: "19351",
    label: "Phường Đông Lương",
    parent_code: "461",
  },
  {
    value: "08431",
    label: "Xã Đồng Lương",
    parent_code: "235",
  },
  {
    value: "15058",
    label: "Xã Đồng Lương",
    parent_code: "388",
  },
  {
    value: "00265",
    label: "Phường Đống Mác",
    parent_code: "007",
  },
  {
    value: "07135",
    label: "Phường Đông Mai",
    parent_code: "206",
  },
  {
    value: "10117",
    label: "Phường Đồng Mai",
    parent_code: "268",
  },
  {
    value: "00850",
    label: "Xã Đông Minh",
    parent_code: "028",
  },
  {
    value: "13003",
    label: "Xã Đông Minh",
    parent_code: "342",
  },
  {
    value: "16399",
    label: "Xã Đông Minh",
    parent_code: "405",
  },
  {
    value: "11875",
    label: "Xã Đồng Minh",
    parent_code: "316",
  },
  {
    value: "06463",
    label: "Thị trấn Đồng Mỏ",
    parent_code: "187",
  },
  {
    value: "18103",
    label: "Xã Đồng Môn",
    parent_code: "436",
  },
  {
    value: "00685",
    label: "Xã Đông Mỹ",
    parent_code: "020",
  },
  {
    value: "12817",
    label: "Xã Đông Mỹ",
    parent_code: "336",
  },
  {
    value: "25414",
    label: "Xã Đồng Nai",
    parent_code: "696",
  },
  {
    value: "25192",
    label: "Xã Đồng Nai Thượng",
    parent_code: "683",
  },
  {
    value: "16423",
    label: "Xã Đông Nam",
    parent_code: "405",
  },
  {
    value: "00601",
    label: "Phường Đông Ngạc",
    parent_code: "021",
  },
  {
    value: "09367",
    label: "Phường Đông Ngàn",
    parent_code: "261",
  },
  {
    value: "06877",
    label: "Xã Đông Ngũ",
    parent_code: "199",
  },
  {
    value: "09385",
    label: "Phường Đồng Nguyên",
    parent_code: "261",
  },
  {
    value: "00259",
    label: "Phường Đồng Nhân",
    parent_code: "007",
  },
  {
    value: "12259",
    label: "Xã Đông Ninh",
    parent_code: "330",
  },
  {
    value: "16384",
    label: "Xã Đông Ninh",
    parent_code: "405",
  },
  {
    value: "25360",
    label: "Xã Đồng Nơ",
    parent_code: "694",
  },
  {
    value: "09229",
    label: "Xã Đông Phong",
    parent_code: "258",
  },
  {
    value: "13009",
    label: "Xã Đông Phong",
    parent_code: "342",
  },
  {
    value: "03408",
    label: "Phường Đông Phong",
    parent_code: "105",
  },
  {
    value: "14416",
    label: "Xã Đồng Phong",
    parent_code: "372",
  },
  {
    value: "07453",
    label: "Xã Đông Phú",
    parent_code: "218",
  },
  {
    value: "16420",
    label: "Xã Đông Phú",
    parent_code: "405",
  },
  {
    value: "20641",
    label: "Thị trấn Đông Phú",
    parent_code: "509",
  },
  {
    value: "31375",
    label: "Xã Đông Phú",
    parent_code: "933",
  },
  {
    value: "10096",
    label: "Xã Đồng Phú",
    parent_code: "277",
  },
  {
    value: "18856",
    label: "Phường Đồng Phú",
    parent_code: "450",
  },
  {
    value: "29578",
    label: "Xã Đồng Phú",
    parent_code: "857",
  },
  {
    value: "01933",
    label: "Xã Đồng Phúc",
    parent_code: "061",
  },
  {
    value: "07750",
    label: "Xã Đồng Phúc",
    parent_code: "221",
  },
  {
    value: "31384",
    label: "Xã Đông Phước",
    parent_code: "933",
  },
  {
    value: "31387",
    label: "Xã Đông Phước A",
    parent_code: "933",
  },
  {
    value: "11695",
    label: "Xã Đông Phương",
    parent_code: "314",
  },
  {
    value: "12694",
    label: "Xã Đông Phương",
    parent_code: "340",
  },
  {
    value: "10030",
    label: "Xã Đông Phương Yên",
    parent_code: "277",
  },
  {
    value: "06592",
    label: "Xã Đông Quan",
    parent_code: "188",
  },
  {
    value: "12793",
    label: "Xã Đông Quan",
    parent_code: "340",
  },
  {
    value: "04351",
    label: "Xã Động Quan",
    parent_code: "135",
  },
  {
    value: "09679",
    label: "Xã Đông Quang",
    parent_code: "271",
  },
  {
    value: "12796",
    label: "Xã Đông Quang",
    parent_code: "340",
  },
  {
    value: "16426",
    label: "Xã Đông Quang",
    parent_code: "405",
  },
  {
    value: "09919",
    label: "Xã Đồng Quang",
    parent_code: "275",
  },
  {
    value: "11065",
    label: "Xã Đồng Quang",
    parent_code: "297",
  },
  {
    value: "05458",
    label: "Phường Đồng Quang",
    parent_code: "164",
  },
  {
    value: "08800",
    label: "Xã Đồng Quế",
    parent_code: "253",
  },
  {
    value: "12982",
    label: "Xã Đông Quí",
    parent_code: "342",
  },
  {
    value: "11365",
    label: "Phường Đổng Quốc Bình",
    parent_code: "304",
  },
  {
    value: "02587",
    label: "Xã Đồng Quý",
    parent_code: "076",
  },
  {
    value: "06892",
    label: "Xã Đồng Rui",
    parent_code: "199",
  },
  {
    value: "04861",
    label: "Xã Đồng Ruộng",
    parent_code: "150",
  },
  {
    value: "04030",
    label: "Xã Đông Sang",
    parent_code: "123",
  },
  {
    value: "10027",
    label: "Xã Đông Sơn",
    parent_code: "277",
  },
  {
    value: "11524",
    label: "Xã Đông Sơn",
    parent_code: "311",
  },
  {
    value: "07273",
    label: "Xã Đông Sơn",
    parent_code: "215",
  },
  {
    value: "12703",
    label: "Xã Đông Sơn",
    parent_code: "340",
  },
  {
    value: "14380",
    label: "Xã Đông Sơn",
    parent_code: "370",
  },
  {
    value: "14785",
    label: "Phường Đông Sơn",
    parent_code: "380",
  },
  {
    value: "14821",
    label: "Phường Đông Sơn",
    parent_code: "381",
  },
  {
    value: "17653",
    label: "Xã Đông Sơn",
    parent_code: "427",
  },
  {
    value: "20098",
    label: "Xã Đông Sơn",
    parent_code: "481",
  },
  {
    value: "08557",
    label: "Xã Đồng Sơn",
    parent_code: "240",
  },
  {
    value: "07036",
    label: "Xã Đồng Sơn",
    parent_code: "193",
  },
  {
    value: "07696",
    label: "Xã Đồng Sơn",
    parent_code: "213",
  },
  {
    value: "14014",
    label: "Xã Đồng Sơn",
    parent_code: "362",
  },
  {
    value: "18871",
    label: "Phường Đồng Sơn",
    parent_code: "450",
  },
  {
    value: "28654",
    label: "Xã Đồng Sơn",
    parent_code: "823",
  },
  {
    value: "12208",
    label: "Xã Đông Tảo",
    parent_code: "330",
  },
  {
    value: "00280",
    label: "Phường Đồng Tâm",
    parent_code: "007",
  },
  {
    value: "10444",
    label: "Xã Đồng Tâm",
    parent_code: "282",
  },
  {
    value: "01168",
    label: "Xã Đồng Tâm",
    parent_code: "034",
  },
  {
    value: "08722",
    label: "Phường Đồng Tâm",
    parent_code: "243",
  },
  {
    value: "11203",
    label: "Xã Đồng Tâm",
    parent_code: "299",
  },
  {
    value: "05419",
    label: "Xã Đồng Tâm",
    parent_code: "159",
  },
  {
    value: "06844",
    label: "Xã Đồng Tâm",
    parent_code: "198",
  },
  {
    value: "07260",
    label: "Xã Đồng Tâm",
    parent_code: "215",
  },
  {
    value: "02086",
    label: "Thị trấn Đồng Tâm",
    parent_code: "065",
  },
  {
    value: "04261",
    label: "Phường Đồng Tâm",
    parent_code: "132",
  },
  {
    value: "25369",
    label: "Xã Đồng Tâm",
    parent_code: "695",
  },
  {
    value: "12769",
    label: "Xã Đông Tân",
    parent_code: "340",
  },
  {
    value: "16432",
    label: "Phường Đông Tân",
    parent_code: "380",
  },
  {
    value: "10390",
    label: "Xã Đồng Tân",
    parent_code: "281",
  },
  {
    value: "05221",
    label: "Xã Đồng Tân",
    parent_code: "156",
  },
  {
    value: "06424",
    label: "Xã Đồng Tân",
    parent_code: "186",
  },
  {
    value: "07813",
    label: "Xã Đồng Tân",
    parent_code: "223",
  },
  {
    value: "31006",
    label: "Xã Đông Thái",
    parent_code: "908",
  },
  {
    value: "09655",
    label: "Xã Đồng Thái",
    parent_code: "271",
  },
  {
    value: "11617",
    label: "Xã Đồng Thái",
    parent_code: "312",
  },
  {
    value: "12061",
    label: "Xã Đồng Than",
    parent_code: "327",
  },
  {
    value: "16402",
    label: "Xã Đông Thanh",
    parent_code: "405",
  },
  {
    value: "24901",
    label: "Xã Đông Thanh",
    parent_code: "676",
  },
  {
    value: "19339",
    label: "Phường Đông Thanh",
    parent_code: "461",
  },
  {
    value: "01219",
    label: "Xã Đông Thành",
    parent_code: "034",
  },
  {
    value: "08209",
    label: "Xã Đông Thành",
    parent_code: "232",
  },
  {
    value: "14320",
    label: "Phường Đông Thành",
    parent_code: "369",
  },
  {
    value: "27898",
    label: "Thị trấn Đông Thành",
    parent_code: "801",
  },
  {
    value: "29818",
    label: "Xã Đông Thành",
    parent_code: "861",
  },
  {
    value: "27568",
    label: "Xã Đông Thạnh",
    parent_code: "784",
  },
  {
    value: "28204",
    label: "Xã Đông Thạnh",
    parent_code: "807",
  },
  {
    value: "29809",
    label: "Xã Đông Thạnh",
    parent_code: "861",
  },
  {
    value: "31030",
    label: "Xã Đông Thạnh",
    parent_code: "909",
  },
  {
    value: "31369",
    label: "Xã Đông Thạnh",
    parent_code: "933",
  },
  {
    value: "12298",
    label: "Xã Đồng Thanh",
    parent_code: "331",
  },
  {
    value: "13198",
    label: "Xã Đồng Thanh",
    parent_code: "344",
  },
  {
    value: "17545",
    label: "Xã Đồng Thành",
    parent_code: "426",
  },
  {
    value: "28660",
    label: "Xã Đồng Thạnh",
    parent_code: "823",
  },
  {
    value: "09826",
    label: "Xã Đồng Tháp",
    parent_code: "273",
  },
  {
    value: "31274",
    label: "Xã Đông Thắng",
    parent_code: "925",
  },
  {
    value: "06643",
    label: "Xã Đồng Thắng",
    parent_code: "189",
  },
  {
    value: "02059",
    label: "Xã Đồng Thắng",
    parent_code: "064",
  },
  {
    value: "15727",
    label: "Xã Đồng Thắng",
    parent_code: "397",
  },
  {
    value: "16414",
    label: "Xã Đông Thịnh",
    parent_code: "405",
  },
  {
    value: "08848",
    label: "Xã Đồng Thịnh",
    parent_code: "253",
  },
  {
    value: "05572",
    label: "Xã Đồng Thịnh",
    parent_code: "167",
  },
  {
    value: "08326",
    label: "Xã Đồng Thịnh",
    parent_code: "234",
  },
  {
    value: "15088",
    label: "Xã Đồng Thịnh",
    parent_code: "389",
  },
  {
    value: "09241",
    label: "Xã Đông Thọ",
    parent_code: "258",
  },
  {
    value: "12820",
    label: "Xã Đông Thọ",
    parent_code: "336",
  },
  {
    value: "14758",
    label: "Phường Đông Thọ",
    parent_code: "380",
  },
  {
    value: "02572",
    label: "Xã Đông Thọ",
    parent_code: "076",
  },
  {
    value: "32143",
    label: "Xã Đông Thới",
    parent_code: "969",
  },
  {
    value: "29813",
    label: "Phường Đông Thuận",
    parent_code: "861",
  },
  {
    value: "31282",
    label: "Xã Đông Thuận",
    parent_code: "927",
  },
  {
    value: "09217",
    label: "Xã Đông Tiến",
    parent_code: "258",
  },
  {
    value: "16405",
    label: "Xã Đông Tiến",
    parent_code: "405",
  },
  {
    value: "23068",
    label: "Xã Đông Tiến",
    parent_code: "597",
  },
  {
    value: "10381",
    label: "Xã Đồng Tiến",
    parent_code: "281",
  },
  {
    value: "01165",
    label: "Xã Đồng Tiến",
    parent_code: "034",
  },
  {
    value: "12241",
    label: "Xã Đồng Tiến",
    parent_code: "330",
  },
  {
    value: "05878",
    label: "Phường Đồng Tiến",
    parent_code: "172",
  },
  {
    value: "06436",
    label: "Xã Đồng Tiến",
    parent_code: "186",
  },
  {
    value: "07195",
    label: "Xã Đồng Tiến",
    parent_code: "207",
  },
  {
    value: "07243",
    label: "Xã Đồng Tiến",
    parent_code: "215",
  },
  {
    value: "12583",
    label: "Xã Đồng Tiến",
    parent_code: "338",
  },
  {
    value: "04804",
    label: "Phường Đồng Tiến",
    parent_code: "148",
  },
  {
    value: "15724",
    label: "Xã Đồng Tiến",
    parent_code: "397",
  },
  {
    value: "25390",
    label: "Xã Đồng Tiến",
    parent_code: "695",
  },
  {
    value: "08875",
    label: "Xã Đồng Tĩnh",
    parent_code: "247",
  },
  {
    value: "12976",
    label: "Xã Đông Trà",
    parent_code: "342",
  },
  {
    value: "19159",
    label: "Xã Đồng Trạch",
    parent_code: "455",
  },
  {
    value: "07072",
    label: "Phường Đông Triều",
    parent_code: "205",
  },
  {
    value: "10012",
    label: "Xã Đồng Trúc",
    parent_code: "276",
  },
  {
    value: "12997",
    label: "Xã Đông Trung",
    parent_code: "342",
  },
  {
    value: "08686",
    label: "Xã Đồng Trung",
    parent_code: "239",
  },
  {
    value: "02662",
    label: "Xã Đồng Tuyển",
    parent_code: "080",
  },
  {
    value: "16417",
    label: "Xã Đông Văn",
    parent_code: "405",
  },
  {
    value: "00721",
    label: "Thị trấn Đồng Văn",
    parent_code: "026",
  },
  {
    value: "09031",
    label: "Xã Đồng Văn",
    parent_code: "251",
  },
  {
    value: "06847",
    label: "Xã Đồng Văn",
    parent_code: "198",
  },
  {
    value: "13321",
    label: "Phường Đồng Văn",
    parent_code: "349",
  },
  {
    value: "16744",
    label: "Xã Đồng Văn",
    parent_code: "415",
  },
  {
    value: "17287",
    label: "Xã Đồng Văn",
    parent_code: "423",
  },
  {
    value: "17764",
    label: "Xã Đồng Văn",
    parent_code: "428",
  },
  {
    value: "14782",
    label: "Phường Đông Vệ",
    parent_code: "380",
  },
  {
    value: "07747",
    label: "Xã Đồng Việt",
    parent_code: "221",
  },
  {
    value: "12772",
    label: "Xã Đông Vinh",
    parent_code: "340",
  },
  {
    value: "16429",
    label: "Xã Đông Vinh",
    parent_code: "380",
  },
  {
    value: "16663",
    label: "Phường Đông Vĩnh",
    parent_code: "412",
  },
  {
    value: "07255",
    label: "Xã Đồng Vương",
    parent_code: "215",
  },
  {
    value: "07015",
    label: "Xã Đông Xá",
    parent_code: "203",
  },
  {
    value: "12724",
    label: "Xã Đông Xá",
    parent_code: "340",
  },
  {
    value: "02194",
    label: "Xã Đổng Xá",
    parent_code: "066",
  },
  {
    value: "00436",
    label: "Xã Đông Xuân",
    parent_code: "016",
  },
  {
    value: "04939",
    label: "Xã Đông Xuân",
    parent_code: "275",
  },
  {
    value: "12799",
    label: "Xã Đông Xuân",
    parent_code: "340",
  },
  {
    value: "00040",
    label: "Phường Đồng Xuân",
    parent_code: "002",
  },
  {
    value: "08747",
    label: "Phường Đồng Xuân",
    parent_code: "244",
  },
  {
    value: "08170",
    label: "Xã Đồng Xuân",
    parent_code: "232",
  },
  {
    value: "11188",
    label: "Xã Đông Xuyên",
    parent_code: "299",
  },
  {
    value: "12988",
    label: "Xã Đông Xuyên",
    parent_code: "342",
  },
  {
    value: "30285",
    label: "Phường Đông Xuyên",
    parent_code: "883",
  },
  {
    value: "06337",
    label: "Xã Đồng ý",
    parent_code: "185",
  },
  {
    value: "09952",
    label: "Xã Đông Yên",
    parent_code: "275",
  },
  {
    value: "16393",
    label: "Xã Đông Yên",
    parent_code: "405",
  },
  {
    value: "31009",
    label: "Xã Đông Yên",
    parent_code: "908",
  },
  {
    value: "01216",
    label: "Xã Đồng Yên",
    parent_code: "034",
  },
  {
    value: "05611",
    label: "Thị trấn Đu",
    parent_code: "168",
  },
  {
    value: "04984",
    label: "Xã Đú Sáng",
    parent_code: "153",
  },
  {
    value: "19780",
    label: "Phường Phường Đúc",
    parent_code: "474",
  },
  {
    value: "04189",
    label: "Xã Đứa Mòn",
    parent_code: "126",
  },
  {
    value: "24717",
    label: "Thị trấn Đức An",
    parent_code: "665",
  },
  {
    value: "08854",
    label: "Xã Đức Bác",
    parent_code: "253",
  },
  {
    value: "23179",
    label: "Xã Đức Bình",
    parent_code: "599",
  },
  {
    value: "22222",
    label: "Xã Đức Bình Đông",
    parent_code: "561",
  },
  {
    value: "22213",
    label: "Xã Đức Bình Tây",
    parent_code: "561",
  },
  {
    value: "18331",
    label: "Xã Đức Bồng",
    parent_code: "441",
  },
  {
    value: "21412",
    label: "Xã Đức Chánh",
    parent_code: "533",
  },
  {
    value: "10912",
    label: "Xã Đức Chính",
    parent_code: "295",
  },
  {
    value: "07093",
    label: "Phường Đức Chính",
    parent_code: "205",
  },
  {
    value: "18304",
    label: "Xã Đức Đồng",
    parent_code: "440",
  },
  {
    value: "00124",
    label: "Phường Đức Giang",
    parent_code: "004",
  },
  {
    value: "09847",
    label: "Xã Đức Giang",
    parent_code: "274",
  },
  {
    value: "07735",
    label: "Xã Đức Giang",
    parent_code: "221",
  },
  {
    value: "18319",
    label: "Xã Đức Giang",
    parent_code: "441",
  },
  {
    value: "01291",
    label: "Xã Đức Hạnh",
    parent_code: "042",
  },
  {
    value: "25228",
    label: "Xã Đức Hạnh",
    parent_code: "691",
  },
  {
    value: "23212",
    label: "Xã Đức Hạnh",
    parent_code: "600",
  },
  {
    value: "21415",
    label: "Xã Đức Hiệp",
    parent_code: "533",
  },
  {
    value: "00430",
    label: "Xã Đức Hoà",
    parent_code: "016",
  },
  {
    value: "21424",
    label: "Xã Đức Hòa",
    parent_code: "533",
  },
  {
    value: "27937",
    label: "Thị trấn Đức Hòa",
    parent_code: "802",
  },
  {
    value: "18988",
    label: "Xã Đức Hóa",
    parent_code: "453",
  },
  {
    value: "27982",
    label: "Xã Đức Hòa Đông",
    parent_code: "802",
  },
  {
    value: "27985",
    label: "Xã Đức Hòa Hạ",
    parent_code: "802",
  },
  {
    value: "27967",
    label: "Xã Đức Hòa Thượng",
    parent_code: "802",
  },
  {
    value: "01522",
    label: "Xã Đức Hồng",
    parent_code: "047",
  },
  {
    value: "12316",
    label: "Xã Đức Hợp",
    parent_code: "331",
  },
  {
    value: "18328",
    label: "Xã Đức Hương",
    parent_code: "441",
  },
  {
    value: "18307",
    label: "Xã Đức Lạng",
    parent_code: "440",
  },
  {
    value: "21436",
    label: "Xã Đức Lân",
    parent_code: "533",
  },
  {
    value: "27958",
    label: "Xã Đức Lập Hạ",
    parent_code: "802",
  },
  {
    value: "27955",
    label: "Xã Đức Lập Thượng",
    parent_code: "802",
  },
  {
    value: "18334",
    label: "Xã Đức Liên",
    parent_code: "441",
  },
  {
    value: "25417",
    label: "Xã Đức Liễu",
    parent_code: "696",
  },
  {
    value: "18322",
    label: "Xã Đức Lĩnh",
    parent_code: "441",
  },
  {
    value: "01669",
    label: "Xã Đức Long",
    parent_code: "051",
  },
  {
    value: "01822",
    label: "Xã Đức Long",
    parent_code: "053",
  },
  {
    value: "09310",
    label: "Xã Đức Long",
    parent_code: "259",
  },
  {
    value: "14410",
    label: "Xã Đức Long",
    parent_code: "372",
  },
  {
    value: "22954",
    label: "Phường Đức Long",
    parent_code: "593",
  },
  {
    value: "21403",
    label: "Xã Đức Lợi",
    parent_code: "533",
  },
  {
    value: "05776",
    label: "Xã Đức Lương",
    parent_code: "171",
  },
  {
    value: "13591",
    label: "Xã Đức Lý",
    parent_code: "353",
  },
  {
    value: "24676",
    label: "Xã Đức Mạnh",
    parent_code: "663",
  },
  {
    value: "24685",
    label: "Xã Đức Minh",
    parent_code: "663",
  },
  {
    value: "21418",
    label: "Xã Đức Minh",
    parent_code: "533",
  },
  {
    value: "29305",
    label: "Xã Đức Mỹ",
    parent_code: "844",
  },
  {
    value: "22942",
    label: "Phường Đức Nghĩa",
    parent_code: "593",
  },
  {
    value: "21409",
    label: "Xã Đức Nhuận",
    parent_code: "533",
  },
  {
    value: "02422",
    label: "Xã Đức Ninh",
    parent_code: "074",
  },
  {
    value: "18898",
    label: "Xã Đức Ninh",
    parent_code: "450",
  },
  {
    value: "18880",
    label: "Phường Đức Ninh Đông",
    parent_code: "450",
  },
  {
    value: "25396",
    label: "Thị trấn Đức Phong",
    parent_code: "696",
  },
  {
    value: "21433",
    label: "Xã Đức Phong",
    parent_code: "533",
  },
  {
    value: "25183",
    label: "Xã Đức Phổ",
    parent_code: "683",
  },
  {
    value: "23170",
    label: "Xã Đức Phú",
    parent_code: "599",
  },
  {
    value: "21430",
    label: "Xã Đức Phú",
    parent_code: "533",
  },
  {
    value: "01546",
    label: "Xã Đức Quang",
    parent_code: "048",
  },
  {
    value: "17353",
    label: "Xã Đức Sơn",
    parent_code: "424",
  },
  {
    value: "23194",
    label: "Thị trấn Đức Tài",
    parent_code: "600",
  },
  {
    value: "21427",
    label: "Xã Đức Tân",
    parent_code: "533",
  },
  {
    value: "28102",
    label: "Xã Đức Tân",
    parent_code: "805",
  },
  {
    value: "17518",
    label: "Xã Đức Thành",
    parent_code: "426",
  },
  {
    value: "21421",
    label: "Xã Đức Thạnh",
    parent_code: "533",
  },
  {
    value: "00602",
    label: "Phường Đức Thắng",
    parent_code: "021",
  },
  {
    value: "12358",
    label: "Xã Đức Thắng",
    parent_code: "332",
  },
  {
    value: "22948",
    label: "Phường Đức Thắng",
    parent_code: "593",
  },
  {
    value: "21406",
    label: "Xã Đức Thắng",
    parent_code: "533",
  },
  {
    value: "18229",
    label: "Thị trấn Đức Thọ",
    parent_code: "440",
  },
  {
    value: "01801",
    label: "Xã Đức Thông",
    parent_code: "053",
  },
  {
    value: "18124",
    label: "Phường Đức Thuận",
    parent_code: "437",
  },
  {
    value: "23185",
    label: "Xã Đức Thuận",
    parent_code: "599",
  },
  {
    value: "09835",
    label: "Xã Đức Thượng",
    parent_code: "274",
  },
  {
    value: "23215",
    label: "Xã Đức Tín",
    parent_code: "600",
  },
  {
    value: "19162",
    label: "Xã Đức Trạch",
    parent_code: "455",
  },
  {
    value: "01951",
    label: "Xã Đức Vân",
    parent_code: "062",
  },
  {
    value: "01204",
    label: "Xã Đức Xuân",
    parent_code: "034",
  },
  {
    value: "01831",
    label: "Xã Đức Xuân",
    parent_code: "053",
  },
  {
    value: "01840",
    label: "Phường Đức Xuân",
    parent_code: "058",
  },
  {
    value: "24706",
    label: "Xã Đức Xuyên",
    parent_code: "664",
  },
  {
    value: "11071",
    label: "Xã Đức Xương",
    parent_code: "297",
  },
  {
    value: "24850",
    label: "Xã Đưng KNớ",
    parent_code: "675",
  },
  {
    value: "25398",
    label: "Xã Đường 10",
    parent_code: "696",
  },
  {
    value: "01012",
    label: "Xã Đường Âm",
    parent_code: "031",
  },
  {
    value: "06949",
    label: "Xã Đường Hoa",
    parent_code: "201",
  },
  {
    value: "01015",
    label: "Xã Đường Hồng",
    parent_code: "031",
  },
  {
    value: "09592",
    label: "Xã Đường Lâm",
    parent_code: "269",
  },
  {
    value: "00862",
    label: "Xã Đường Thượng",
    parent_code: "028",
  },
  {
    value: "03742",
    label: "Xã é Tòng",
    parent_code: "119",
  },
  {
    value: "22216",
    label: "Xã Ea Bá",
    parent_code: "561",
  },
  {
    value: "24250",
    label: "Xã Ea Bar",
    parent_code: "647",
  },
  {
    value: "24550",
    label: "Xã Ea BHốk",
    parent_code: "657",
  },
  {
    value: "24325",
    label: "Xã Ea Blang",
    parent_code: "644",
  },
  {
    value: "24565",
    label: "Xã Ea Bông",
    parent_code: "655",
  },
  {
    value: "24229",
    label: "Xã Ea Bung",
    parent_code: "646",
  },
  {
    value: "24292",
    label: "Xã Ea D'Rơng",
    parent_code: "648",
  },
  {
    value: "24360",
    label: "Xã Ea Dăh",
    parent_code: "650",
  },
  {
    value: "24181",
    label: "Thị trấn Ea Drăng",
    parent_code: "645",
  },
  {
    value: "24328",
    label: "Xã Ea Drông",
    parent_code: "644",
  },
  {
    value: "24391",
    label: "Xã Ea Đar",
    parent_code: "651",
  },
  {
    value: "24274",
    label: "Xã Ea H'đinh",
    parent_code: "648",
  },
  {
    value: "24184",
    label: "Xã Ea H'leo",
    parent_code: "645",
  },
  {
    value: "24424",
    label: "Xã Ea H'MLay",
    parent_code: "652",
  },
  {
    value: "24199",
    label: "Xã Ea Hiao",
    parent_code: "645",
  },
  {
    value: "24520",
    label: "Xã Ea Hiu",
    parent_code: "654",
  },
  {
    value: "24361",
    label: "Xã Ea Hồ",
    parent_code: "650",
  },
  {
    value: "24553",
    label: "Xã Ea Hu",
    parent_code: "657",
  },
  {
    value: "24238",
    label: "Xã Ea Huar",
    parent_code: "647",
  },
  {
    value: "24169",
    label: "Xã Ea Kao",
    parent_code: "643",
  },
  {
    value: "24373",
    label: "Thị trấn Ea Kar",
    parent_code: "651",
  },
  {
    value: "24499",
    label: "Xã Ea Kênh",
    parent_code: "654",
  },
  {
    value: "24202",
    label: "Xã Ea Khal",
    parent_code: "645",
  },
  {
    value: "24265",
    label: "Xã Ea Kiết",
    parent_code: "648",
  },
  {
    value: "24496",
    label: "Xã Ea Kly",
    parent_code: "654",
  },
  {
    value: "24394",
    label: "Xã Ea Kmút",
    parent_code: "651",
  },
  {
    value: "24376",
    label: "Thị trấn Ea Knốp",
    parent_code: "651",
  },
  {
    value: "24505",
    label: "Xã Ea KNuec",
    parent_code: "654",
  },
  {
    value: "24280",
    label: "Xã Ea KPam",
    parent_code: "648",
  },
  {
    value: "24544",
    label: "Xã Ea Ktur",
    parent_code: "657",
  },
  {
    value: "24514",
    label: "Xã Ea Kuăng",
    parent_code: "654",
  },
  {
    value: "24264",
    label: "Xã Ea Kuêh",
    parent_code: "648",
  },
  {
    value: "24421",
    label: "Xã Ea Lai",
    parent_code: "652",
  },
  {
    value: "22210",
    label: "Xã Ea Lâm",
    parent_code: "561",
  },
  {
    value: "24223",
    label: "Xã Ea Lê",
    parent_code: "646",
  },
  {
    value: "24430",
    label: "Xã Ea M' Doal",
    parent_code: "652",
  },
  {
    value: "24283",
    label: "Xã Ea M'DRóh",
    parent_code: "648",
  },
  {
    value: "24295",
    label: "Xã Ea M'nang",
    parent_code: "648",
  },
  {
    value: "24559",
    label: "Xã Ea Na",
    parent_code: "655",
  },
  {
    value: "24208",
    label: "Xã Ea Nam",
    parent_code: "645",
  },
  {
    value: "24319",
    label: "Xã Ea Ngai",
    parent_code: "649",
  },
  {
    value: "24540",
    label: "Xã Ea Ning",
    parent_code: "657",
  },
  {
    value: "24253",
    label: "Xã Ea Nuôl",
    parent_code: "647",
  },
  {
    value: "24403",
    label: "Xã Ea Ô",
    parent_code: "651",
  },
  {
    value: "24400",
    label: "Xã Ea Păl",
    parent_code: "651",
  },
  {
    value: "24502",
    label: "Xã Ea Phê",
    parent_code: "654",
  },
  {
    value: "24418",
    label: "Xã Ea Pil",
    parent_code: "652",
  },
  {
    value: "24646",
    label: "Xã Ea Pô",
    parent_code: "662",
  },
  {
    value: "24256",
    label: "Thị trấn Ea Pốk",
    parent_code: "648",
  },
  {
    value: "24359",
    label: "Xã Ea Puk",
    parent_code: "650",
  },
  {
    value: "24610",
    label: "Xã Ea R'Bin",
    parent_code: "656",
  },
  {
    value: "24190",
    label: "Xã Ea Ral",
    parent_code: "645",
  },
  {
    value: "24433",
    label: "Xã Ea Riêng",
    parent_code: "652",
  },
  {
    value: "24217",
    label: "Xã Ea Rốk",
    parent_code: "646",
  },
  {
    value: "24380",
    label: "Xã Ea Sar",
    parent_code: "651",
  },
  {
    value: "24334",
    label: "Xã Ea Siên",
    parent_code: "644",
  },
  {
    value: "24314",
    label: "Xã Ea Sin",
    parent_code: "649",
  },
  {
    value: "24187",
    label: "Xã Ea Sol",
    parent_code: "645",
  },
  {
    value: "24379",
    label: "Xã Ea Sô",
    parent_code: "651",
  },
  {
    value: "24211",
    label: "Thị trấn Ea Súp",
    parent_code: "646",
  },
  {
    value: "24640",
    label: "Thị trấn Ea T'Ling",
    parent_code: "662",
  },
  {
    value: "24151",
    label: "Phường Ea Tam",
    parent_code: "643",
  },
  {
    value: "24352",
    label: "Xã Ea Tam",
    parent_code: "650",
  },
  {
    value: "24268",
    label: "Xã Ea Tar",
    parent_code: "648",
  },
  {
    value: "24370",
    label: "Xã Ea Tân",
    parent_code: "650",
  },
  {
    value: "24547",
    label: "Xã Ea Tiêu",
    parent_code: "657",
  },
  {
    value: "24388",
    label: "Xã Ea Tih",
    parent_code: "651",
  },
  {
    value: "24207",
    label: "Xã Ea Tir",
    parent_code: "645",
  },
  {
    value: "24349",
    label: "Xã Ea Tóh",
    parent_code: "650",
  },
  {
    value: "24445",
    label: "Xã Ea Trang",
    parent_code: "652",
  },
  {
    value: "24472",
    label: "Xã Ea Trul",
    parent_code: "653",
  },
  {
    value: "24163",
    label: "Xã Ea Tu",
    parent_code: "643",
  },
  {
    value: "24277",
    label: "Xã Ea Tul",
    parent_code: "648",
  },
  {
    value: "24532",
    label: "Xã Ea Uy",
    parent_code: "654",
  },
  {
    value: "24241",
    label: "Xã Ea Wer",
    parent_code: "647",
  },
  {
    value: "24193",
    label: "Xã Ea Wy",
    parent_code: "645",
  },
  {
    value: "24535",
    label: "Xã Ea Yiêng",
    parent_code: "654",
  },
  {
    value: "24508",
    label: "Xã Ea Yông",
    parent_code: "654",
  },
  {
    value: "22225",
    label: "Xã EaBar",
    parent_code: "561",
  },
  {
    value: "22228",
    label: "Xã EaBia",
    parent_code: "561",
  },
  {
    value: "22192",
    label: "Xã Eachà Rang",
    parent_code: "560",
  },
  {
    value: "22237",
    label: "Xã Ealy",
    parent_code: "561",
  },
  {
    value: "22231",
    label: "Xã EaTrol",
    parent_code: "561",
  },
  {
    value: "20440",
    label: "Xã Ga Ri",
    parent_code: "504",
  },
  {
    value: "31087",
    label: "Xã Gành Dầu",
    parent_code: "911",
  },
  {
    value: "31972",
    label: "Thị trấn Gành Hào",
    parent_code: "960",
  },
  {
    value: "23611",
    label: "Xã Gào",
    parent_code: "622",
  },
  {
    value: "30079",
    label: "Xã Gáo Giồng",
    parent_code: "873",
  },
  {
    value: "21595",
    label: "Phường Ghềnh Ráng",
    parent_code: "540",
  },
  {
    value: "23176",
    label: "Xã Gia An",
    parent_code: "599",
  },
  {
    value: "25051",
    label: "Xã Gia Bắc",
    parent_code: "679",
  },
  {
    value: "09454",
    label: "Thị trấn Gia Bình",
    parent_code: "263",
  },
  {
    value: "25723",
    label: "Phường Gia Bình",
    parent_code: "712",
  },
  {
    value: "26230",
    label: "Xã Gia Canh",
    parent_code: "736",
  },
  {
    value: "06235",
    label: "Xã Gia Cát",
    parent_code: "183",
  },
  {
    value: "07900",
    label: "Phường Gia Cẩm",
    parent_code: "227",
  },
  {
    value: "08092",
    label: "Xã Gia Điền",
    parent_code: "231",
  },
  {
    value: "09424",
    label: "Xã Gia Đông",
    parent_code: "262",
  },
  {
    value: "11497",
    label: "Xã Gia Đức",
    parent_code: "311",
  },
  {
    value: "18463",
    label: "Xã Gia Hanh",
    parent_code: "443",
  },
  {
    value: "25015",
    label: "Xã Gia Hiệp",
    parent_code: "679",
  },
  {
    value: "14467",
    label: "Xã Gia Hòa",
    parent_code: "373",
  },
  {
    value: "31720",
    label: "Xã Gia Hòa 1",
    parent_code: "947",
  },
  {
    value: "31726",
    label: "Xã Gia Hòa 2",
    parent_code: "947",
  },
  {
    value: "04636",
    label: "Xã Gia Hội",
    parent_code: "140",
  },
  {
    value: "19756",
    label: "Phường Gia Hội",
    parent_code: "474",
  },
  {
    value: "23182",
    label: "Xã Gia Huynh",
    parent_code: "599",
  },
  {
    value: "14470",
    label: "Xã Gia Hưng",
    parent_code: "373",
  },
  {
    value: "08936",
    label: "Thị trấn Gia Khánh",
    parent_code: "249",
  },
  {
    value: "11035",
    label: "Xã Gia Khánh",
    parent_code: "297",
  },
  {
    value: "26308",
    label: "Xã Gia Kiệm",
    parent_code: "738",
  },
  {
    value: "14515",
    label: "Xã Gia Lạc",
    parent_code: "373",
  },
  {
    value: "14389",
    label: "Xã Gia Lâm",
    parent_code: "372",
  },
  {
    value: "24904",
    label: "Xã Gia Lâm",
    parent_code: "676",
  },
  {
    value: "14488",
    label: "Xã Gia Lập",
    parent_code: "373",
  },
  {
    value: "10999",
    label: "Thị trấn Gia Lộc",
    parent_code: "297",
  },
  {
    value: "06475",
    label: "Xã Gia Lộc",
    parent_code: "187",
  },
  {
    value: "25720",
    label: "Phường Gia Lộc",
    parent_code: "712",
  },
  {
    value: "11935",
    label: "Xã Gia Luận",
    parent_code: "317",
  },
  {
    value: "11038",
    label: "Xã Gia Lương",
    parent_code: "297",
  },
  {
    value: "06160",
    label: "Xã Gia Miễn",
    parent_code: "182",
  },
  {
    value: "11494",
    label: "Xã Gia Minh",
    parent_code: "311",
  },
  {
    value: "14512",
    label: "Xã Gia Minh",
    parent_code: "373",
  },
  {
    value: "05197",
    label: "Xã Gia Mô",
    parent_code: "155",
  },
  {
    value: "19225",
    label: "Xã Gia Ninh",
    parent_code: "456",
  },
  {
    value: "14524",
    label: "Xã Gia Phong",
    parent_code: "373",
  },
  {
    value: "18532",
    label: "Xã Gia Phố",
    parent_code: "444",
  },
  {
    value: "03922",
    label: "Xã Gia Phù",
    parent_code: "122",
  },
  {
    value: "14482",
    label: "Xã Gia Phú",
    parent_code: "373",
  },
  {
    value: "02923",
    label: "Xã Gia Phú",
    parent_code: "086",
  },
  {
    value: "14500",
    label: "Xã Gia Phương",
    parent_code: "373",
  },
  {
    value: "26425",
    label: "Thị trấn Gia Ray",
    parent_code: "741",
  },
  {
    value: "05461",
    label: "Phường Gia Sàng",
    parent_code: "164",
  },
  {
    value: "14521",
    label: "Xã Gia Sinh",
    parent_code: "373",
  },
  {
    value: "14392",
    label: "Xã Gia Sơn",
    parent_code: "372",
  },
  {
    value: "11029",
    label: "Xã Gia Tân",
    parent_code: "297",
  },
  {
    value: "14503",
    label: "Xã Gia Tân",
    parent_code: "373",
  },
  {
    value: "26299",
    label: "Xã Gia Tân 1",
    parent_code: "738",
  },
  {
    value: "26302",
    label: "Xã Gia Tân 2",
    parent_code: "738",
  },
  {
    value: "26305",
    label: "Xã Gia Tân 3",
    parent_code: "738",
  },
  {
    value: "08260",
    label: "Xã Gia Thanh",
    parent_code: "233",
  },
  {
    value: "14476",
    label: "Xã Gia Thanh",
    parent_code: "373",
  },
  {
    value: "14506",
    label: "Xã Gia Thắng",
    parent_code: "373",
  },
  {
    value: "14497",
    label: "Xã Gia Thịnh",
    parent_code: "373",
  },
  {
    value: "28714",
    label: "Xã Gia Thuận",
    parent_code: "824",
  },
  {
    value: "14398",
    label: "Xã Gia Thủy",
    parent_code: "372",
  },
  {
    value: "00130",
    label: "Phường Gia Thụy",
    parent_code: "004",
  },
  {
    value: "14518",
    label: "Xã Gia Tiến",
    parent_code: "373",
  },
  {
    value: "14494",
    label: "Xã Gia Trấn",
    parent_code: "373",
  },
  {
    value: "14509",
    label: "Xã Gia Trung",
    parent_code: "373",
  },
  {
    value: "14401",
    label: "Xã Gia Tường",
    parent_code: "372",
  },
  {
    value: "14479",
    label: "Xã Gia Vân",
    parent_code: "373",
  },
  {
    value: "11347",
    label: "Phường Gia Viên",
    parent_code: "304",
  },
  {
    value: "25168",
    label: "Xã Gia Viễn",
    parent_code: "683",
  },
  {
    value: "14491",
    label: "Xã Gia Vượng",
    parent_code: "373",
  },
  {
    value: "14485",
    label: "Xã Gia Xuân",
    parent_code: "373",
  },
  {
    value: "11017",
    label: "Xã Gia Xuyên",
    parent_code: "288",
  },
  {
    value: "12055",
    label: "Xã Giai Phạm",
    parent_code: "327",
  },
  {
    value: "17278",
    label: "Xã Giai Xuân",
    parent_code: "423",
  },
  {
    value: "31303",
    label: "Xã Giai Xuân",
    parent_code: "926",
  },
  {
    value: "00121",
    label: "Phường Giang Biên",
    parent_code: "004",
  },
  {
    value: "11830",
    label: "Xã Giang Biên",
    parent_code: "316",
  },
  {
    value: "00784",
    label: "Xã Giàng Chu Phìn",
    parent_code: "027",
  },
  {
    value: "26293",
    label: "Xã Giang Điền",
    parent_code: "737",
  },
  {
    value: "20122",
    label: "Xã Giang Hải",
    parent_code: "482",
  },
  {
    value: "22633",
    label: "Xã Giang Ly",
    parent_code: "573",
  },
  {
    value: "03405",
    label: "Xã Giang Ma",
    parent_code: "106",
  },
  {
    value: "09463",
    label: "Xã Giang Sơn",
    parent_code: "263",
  },
  {
    value: "17619",
    label: "Xã Giang Sơn Đông",
    parent_code: "427",
  },
  {
    value: "17620",
    label: "Xã Giang Sơn Tây",
    parent_code: "427",
  },
  {
    value: "05608",
    label: "Thị trấn Giang Tiên",
    parent_code: "168",
  },
  {
    value: "00031",
    label: "Phường Giảng Võ",
    parent_code: "001",
  },
  {
    value: "14182",
    label: "Xã Giao An",
    parent_code: "365",
  },
  {
    value: "15040",
    label: "Xã Giao An",
    parent_code: "388",
  },
  {
    value: "14188",
    label: "Xã Giao Châu",
    parent_code: "365",
  },
  {
    value: "14176",
    label: "Xã Giao Hà",
    parent_code: "365",
  },
  {
    value: "14203",
    label: "Xã Giao Hải",
    parent_code: "365",
  },
  {
    value: "01870",
    label: "Xã Giáo Hiệu",
    parent_code: "060",
  },
  {
    value: "14155",
    label: "Xã Giao Hương",
    parent_code: "365",
  },
  {
    value: "14185",
    label: "Xã Giao Lạc",
    parent_code: "365",
  },
  {
    value: "07636",
    label: "Xã Giáo Liêm",
    parent_code: "220",
  },
  {
    value: "14209",
    label: "Xã Giao Long",
    parent_code: "365",
  },
  {
    value: "28813",
    label: "Xã Giao Long",
    parent_code: "831",
  },
  {
    value: "14179",
    label: "Xã Giao Nhân",
    parent_code: "365",
  },
  {
    value: "14212",
    label: "Xã Giao Phong",
    parent_code: "365",
  },
  {
    value: "14191",
    label: "Xã Giao Tân",
    parent_code: "365",
  },
  {
    value: "14164",
    label: "Xã Giao Thanh",
    parent_code: "365",
  },
  {
    value: "29227",
    label: "Xã Giao Thạnh",
    parent_code: "837",
  },
  {
    value: "14161",
    label: "Xã Giao Thiện",
    parent_code: "365",
  },
  {
    value: "15043",
    label: "Xã Giao Thiện",
    parent_code: "388",
  },
  {
    value: "14200",
    label: "Xã Giao Thịnh",
    parent_code: "365",
  },
  {
    value: "14173",
    label: "Xã Giao Tiến",
    parent_code: "365",
  },
  {
    value: "14197",
    label: "Xã Giao Xuân",
    parent_code: "365",
  },
  {
    value: "14194",
    label: "Xã Giao Yến",
    parent_code: "365",
  },
  {
    value: "00325",
    label: "Phường Giáp Bát",
    parent_code: "008",
  },
  {
    value: "04840",
    label: "Xã Giáp Đắt",
    parent_code: "150",
  },
  {
    value: "08575",
    label: "Xã Giáp Lai",
    parent_code: "238",
  },
  {
    value: "07570",
    label: "Xã Giáp Sơn",
    parent_code: "219",
  },
  {
    value: "00985",
    label: "Xã Giáp Trung",
    parent_code: "031",
  },
  {
    value: "06661",
    label: "Phường Giếng Đáy",
    parent_code: "193",
  },
  {
    value: "19522",
    label: "Xã Gio An",
    parent_code: "466",
  },
  {
    value: "19525",
    label: "Xã Gio Châu",
    parent_code: "466",
  },
  {
    value: "19519",
    label: "Xã Gio Hải",
    parent_code: "466",
  },
  {
    value: "19495",
    label: "Thị trấn Gio Linh",
    parent_code: "466",
  },
  {
    value: "19543",
    label: "Xã Gio Mai",
    parent_code: "466",
  },
  {
    value: "19510",
    label: "Xã Gio Mỹ",
    parent_code: "466",
  },
  {
    value: "19552",
    label: "Xã Gio Quang",
    parent_code: "466",
  },
  {
    value: "19537",
    label: "Xã Gio Sơn",
    parent_code: "466",
  },
  {
    value: "19531",
    label: "Xã Gio Việt",
    parent_code: "466",
  },
  {
    value: "30904",
    label: "Thị Trấn Giồng Riềng",
    parent_code: "906",
  },
  {
    value: "28984",
    label: "Thị trấn Giồng Trôm",
    parent_code: "834",
  },
  {
    value: "04543",
    label: "Xã Giới Phiên",
    parent_code: "132",
  },
  {
    value: "30889",
    label: "Xã Giục Tượng",
    parent_code: "905",
  },
  {
    value: "23707",
    label: "Xã Glar",
    parent_code: "626",
  },
  {
    value: "25654",
    label: "Thị trấn Gò Dầu",
    parent_code: "710",
  },
  {
    value: "30952",
    label: "Thị trấn Gò Quao",
    parent_code: "907",
  },
  {
    value: "13741",
    label: "Thị trấn Gôi",
    parent_code: "359",
  },
  {
    value: "25030",
    label: "Xã Gung Ré",
    parent_code: "679",
  },
  {
    value: "23968",
    label: "Xã H Bông",
    parent_code: "633",
  },
  {
    value: "23701",
    label: "Xã H' Neng",
    parent_code: "626",
  },
  {
    value: "07168",
    label: "Phường Hà An",
    parent_code: "206",
  },
  {
    value: "15280",
    label: "Xã Hà Bắc",
    parent_code: "392",
  },
  {
    value: "10009",
    label: "Xã Hạ Bằng",
    parent_code: "276",
  },
  {
    value: "23692",
    label: "Xã Hà Bầu",
    parent_code: "626",
  },
  {
    value: "15328",
    label: "Xã Hà Bình",
    parent_code: "392",
  },
  {
    value: "09556",
    label: "Phường Hà Cầu",
    parent_code: "268",
  },
  {
    value: "05968",
    label: "Xã Hà Châu",
    parent_code: "173",
  },
  {
    value: "15334",
    label: "Xã Hà Châu",
    parent_code: "392",
  },
  {
    value: "00361",
    label: "Phường Hạ Đình",
    parent_code: "009",
  },
  {
    value: "15319",
    label: "Xã Hà Đông",
    parent_code: "392",
  },
  {
    value: "23680",
    label: "Xã Hà Đông",
    parent_code: "626",
  },
  {
    value: "12745",
    label: "Xã Hà Giang",
    parent_code: "340",
  },
  {
    value: "15292",
    label: "Xã Hà Giang",
    parent_code: "392",
  },
  {
    value: "08251",
    label: "Xã Hạ Giáp",
    parent_code: "233",
  },
  {
    value: "15343",
    label: "Xã Hà Hải",
    parent_code: "392",
  },
  {
    value: "01897",
    label: "Xã Hà Hiệu",
    parent_code: "061",
  },
  {
    value: "08053",
    label: "Thị trấn Hạ Hoà",
    parent_code: "231",
  },
  {
    value: "10225",
    label: "Xã Hà Hồi",
    parent_code: "279",
  },
  {
    value: "16666",
    label: "Phường Hà Huy Tập",
    parent_code: "412",
  },
  {
    value: "18085",
    label: "Phường Hà Huy Tập",
    parent_code: "436",
  },
  {
    value: "06649",
    label: "Phường Hà Khánh",
    parent_code: "193",
  },
  {
    value: "06655",
    label: "Phường Hà Khẩu",
    parent_code: "193",
  },
  {
    value: "11149",
    label: "Xã Hà Kỳ",
    parent_code: "298",
  },
  {
    value: "15331",
    label: "Xã Hà Lai",
    parent_code: "392",
  },
  {
    value: "20791",
    label: "Thị trấn Hà Lam",
    parent_code: "513",
  },
  {
    value: "02311",
    label: "Xã Hà Lang",
    parent_code: "073",
  },
  {
    value: "25105",
    label: "Xã Hà Lâm",
    parent_code: "681",
  },
  {
    value: "06670",
    label: "Phường Hà Lầm",
    parent_code: "193",
  },
  {
    value: "06865",
    label: "Xã Hà Lâu",
    parent_code: "199",
  },
  {
    value: "12202",
    label: "Xã Hạ Lễ",
    parent_code: "329",
  },
  {
    value: "18502",
    label: "Xã Hà Linh",
    parent_code: "444",
  },
  {
    value: "15316",
    label: "Xã Hà Lĩnh",
    parent_code: "392",
  },
  {
    value: "15274",
    label: "Xã Hà Long",
    parent_code: "392",
  },
  {
    value: "07012",
    label: "Xã Hạ Long",
    parent_code: "203",
  },
  {
    value: "13633",
    label: "Phường Hạ Long",
    parent_code: "356",
  },
  {
    value: "07951",
    label: "Xã Hà Lộc",
    parent_code: "228",
  },
  {
    value: "08065",
    label: "Xã Hà Lương",
    parent_code: "231",
  },
  {
    value: "11308",
    label: "Phường Hạ Lý",
    parent_code: "303",
  },
  {
    value: "09436",
    label: "Xã Hà Mãn",
    parent_code: "262",
  },
  {
    value: "23521",
    label: "Xã Hà Mòn",
    parent_code: "615",
  },
  {
    value: "09805",
    label: "Xã Hạ Mỗ",
    parent_code: "273",
  },
  {
    value: "15304",
    label: "Xã Hà Ngọc",
    parent_code: "392",
  },
  {
    value: "06652",
    label: "Phường Hà Phong",
    parent_code: "193",
  },
  {
    value: "15313",
    label: "Xã Hà Sơn",
    parent_code: "392",
  },
  {
    value: "17092",
    label: "Xã Hạ Sơn",
    parent_code: "420",
  },
  {
    value: "23989",
    label: "Xã Hà Tam",
    parent_code: "634",
  },
  {
    value: "15322",
    label: "Xã Hà Tân",
    parent_code: "392",
  },
  {
    value: "23725",
    label: "Xã Hà Tây",
    parent_code: "627",
  },
  {
    value: "07963",
    label: "Xã Hà Thạch",
    parent_code: "228",
  },
  {
    value: "15340",
    label: "Xã Hà Thái",
    parent_code: "392",
  },
  {
    value: "11152",
    label: "Xã Hà Thanh",
    parent_code: "298",
  },
  {
    value: "05812",
    label: "Xã Hà Thượng",
    parent_code: "171",
  },
  {
    value: "15325",
    label: "Xã Hà Tiến",
    parent_code: "392",
  },
  {
    value: "19123",
    label: "Xã Hạ Trạch",
    parent_code: "455",
  },
  {
    value: "06667",
    label: "Phường Hà Trung",
    parent_code: "193",
  },
  {
    value: "15271",
    label: "Thị trấn Hà Trung",
    parent_code: "392",
  },
  {
    value: "14962",
    label: "Xã Hạ Trung",
    parent_code: "386",
  },
  {
    value: "06664",
    label: "Phường Hà Tu",
    parent_code: "193",
  },
  {
    value: "15277",
    label: "Xã Hà Vinh",
    parent_code: "392",
  },
  {
    value: "14284",
    label: "Xã Hải An",
    parent_code: "366",
  },
  {
    value: "16585",
    label: "Phường Hải An",
    parent_code: "407",
  },
  {
    value: "19684",
    label: "Xã Hải An",
    parent_code: "470",
  },
  {
    value: "14236",
    label: "Xã Hải Anh",
    parent_code: "366",
  },
  {
    value: "19687",
    label: "Xã Hải Ba",
    parent_code: "470",
  },
  {
    value: "13297",
    label: "Phường Hai Bà Trưng",
    parent_code: "347",
  },
  {
    value: "14242",
    label: "Xã Hải Bắc",
    parent_code: "366",
  },
  {
    value: "16633",
    label: "Phường Hải Bình",
    parent_code: "407",
  },
  {
    value: "00508",
    label: "Xã Hải Bối",
    parent_code: "017",
  },
  {
    value: "21562",
    label: "Phường Hải Cảng",
    parent_code: "540",
  },
  {
    value: "19738",
    label: "Xã Hải Chánh",
    parent_code: "470",
  },
  {
    value: "14311",
    label: "Xã Hải Châu",
    parent_code: "366",
  },
  {
    value: "16564",
    label: "Phường Hải Châu",
    parent_code: "407",
  },
  {
    value: "20236",
    label: "Phường Hải Châu  I",
    parent_code: "492",
  },
  {
    value: "20239",
    label: "Phường Hải Châu II",
    parent_code: "492",
  },
  {
    value: "14305",
    label: "Xã Hải Chính",
    parent_code: "366",
  },
  {
    value: "14299",
    label: "Xã Hải Cường",
    parent_code: "366",
  },
  {
    value: "19711",
    label: "Xã Hải Dương",
    parent_code: "470",
  },
  {
    value: "19999",
    label: "Xã Hải Dương",
    parent_code: "474",
  },
  {
    value: "19714",
    label: "Xã Hải Định",
    parent_code: "470",
  },
  {
    value: "06730",
    label: "Xã Hải Đông",
    parent_code: "194",
  },
  {
    value: "14269",
    label: "Xã Hải Đông",
    parent_code: "366",
  },
  {
    value: "14260",
    label: "Xã Hải Đường",
    parent_code: "366",
  },
  {
    value: "14296",
    label: "Xã Hải Giang",
    parent_code: "366",
  },
  {
    value: "14251",
    label: "Xã Hải Hà",
    parent_code: "366",
  },
  {
    value: "16660",
    label: "Xã Hải Hà",
    parent_code: "407",
  },
  {
    value: "06742",
    label: "Phường Hải Hoà",
    parent_code: "194",
  },
  {
    value: "14317",
    label: "Xã Hải Hòa",
    parent_code: "366",
  },
  {
    value: "16561",
    label: "Phường Hải Hòa",
    parent_code: "407",
  },
  {
    value: "14239",
    label: "Xã Hải Hưng",
    parent_code: "366",
  },
  {
    value: "19699",
    label: "Xã Hải Hưng",
    parent_code: "470",
  },
  {
    value: "19741",
    label: "Xã Hải Khê",
    parent_code: "470",
  },
  {
    value: "06886",
    label: "Xã Hải Lạng",
    parent_code: "199",
  },
  {
    value: "19717",
    label: "Xã Hải Lâm",
    parent_code: "470",
  },
  {
    value: "19705",
    label: "Xã Hải Lệ",
    parent_code: "462",
  },
  {
    value: "16597",
    label: "Phường Hải Lĩnh",
    parent_code: "407",
  },
  {
    value: "14254",
    label: "Xã Hải Long",
    parent_code: "366",
  },
  {
    value: "16252",
    label: "Xã Hải Long",
    parent_code: "403",
  },
  {
    value: "14263",
    label: "Xã Hải Lộc",
    parent_code: "366",
  },
  {
    value: "16084",
    label: "Xã Hải Lộc",
    parent_code: "400",
  },
  {
    value: "08782",
    label: "Xã Hải Lựu",
    parent_code: "253",
  },
  {
    value: "14290",
    label: "Xã Hải Lý",
    parent_code: "366",
  },
  {
    value: "14233",
    label: "Xã Hải Minh",
    parent_code: "366",
  },
  {
    value: "14224",
    label: "Xã Hải Nam",
    parent_code: "366",
  },
  {
    value: "16612",
    label: "Xã Hải Nhân",
    parent_code: "407",
  },
  {
    value: "14302",
    label: "Xã Hải Ninh",
    parent_code: "366",
  },
  {
    value: "16576",
    label: "Phường Hải Ninh",
    parent_code: "407",
  },
  {
    value: "23020",
    label: "Xã Hải Ninh",
    parent_code: "596",
  },
  {
    value: "19216",
    label: "Xã Hải Ninh",
    parent_code: "456",
  },
  {
    value: "14281",
    label: "Xã Hải Phong",
    parent_code: "366",
  },
  {
    value: "19726",
    label: "Xã Hải Phong",
    parent_code: "470",
  },
  {
    value: "14293",
    label: "Xã Hải Phú",
    parent_code: "366",
  },
  {
    value: "19702",
    label: "Xã Hải Phú",
    parent_code: "470",
  },
  {
    value: "19144",
    label: "Xã Hải Phú",
    parent_code: "455",
  },
  {
    value: "14245",
    label: "Xã Hải Phúc",
    parent_code: "366",
  },
  {
    value: "14257",
    label: "Xã Hải Phương",
    parent_code: "366",
  },
  {
    value: "14266",
    label: "Xã Hải Quang",
    parent_code: "366",
  },
  {
    value: "19696",
    label: "Xã Hải Quế",
    parent_code: "470",
  },
  {
    value: "19693",
    label: "Xã Hải Quy",
    parent_code: "470",
  },
  {
    value: "22207",
    label: "Thị trấn Hai Riêng",
    parent_code: "561",
  },
  {
    value: "11458",
    label: "Phường Hải Sơn",
    parent_code: "308",
  },
  {
    value: "06724",
    label: "Xã Hải Sơn",
    parent_code: "194",
  },
  {
    value: "14272",
    label: "Xã Hải Sơn",
    parent_code: "366",
  },
  {
    value: "19735",
    label: "Xã Hải Sơn",
    parent_code: "470",
  },
  {
    value: "10537",
    label: "Phường Hải Tân",
    parent_code: "288",
  },
  {
    value: "14275",
    label: "Xã Hải Tân",
    parent_code: "366",
  },
  {
    value: "14287",
    label: "Xã Hải Tây",
    parent_code: "366",
  },
  {
    value: "19546",
    label: "Xã Hải Thái",
    parent_code: "466",
  },
  {
    value: "14248",
    label: "Xã Hải Thanh",
    parent_code: "366",
  },
  {
    value: "16621",
    label: "Phường Hải Thanh",
    parent_code: "407",
  },
  {
    value: "11692",
    label: "Phường Hải Thành",
    parent_code: "309",
  },
  {
    value: "18853",
    label: "Phường Hải Thành",
    parent_code: "450",
  },
  {
    value: "16654",
    label: "Phường Hải Thượng",
    parent_code: "407",
  },
  {
    value: "19708",
    label: "Xã Hải Thượng",
    parent_code: "470",
  },
  {
    value: "06733",
    label: "Xã Hải Tiến",
    parent_code: "194",
  },
  {
    value: "12364",
    label: "Xã Hải Triều",
    parent_code: "332",
  },
  {
    value: "14314",
    label: "Xã Hải Triều",
    parent_code: "366",
  },
  {
    value: "14227",
    label: "Xã Hải Trung",
    parent_code: "366",
  },
  {
    value: "19729",
    label: "Xã Hải Trường",
    parent_code: "470",
  },
  {
    value: "14230",
    label: "Xã Hải Vân",
    parent_code: "366",
  },
  {
    value: "06745",
    label: "Xã Hải Xuân",
    parent_code: "194",
  },
  {
    value: "14308",
    label: "Xã Hải Xuân",
    parent_code: "366",
  },
  {
    value: "23686",
    label: "Xã Hải Yang",
    parent_code: "626",
  },
  {
    value: "06736",
    label: "Phường Hải Yên",
    parent_code: "194",
  },
  {
    value: "06220",
    label: "Xã Hải Yến",
    parent_code: "183",
  },
  {
    value: "16651",
    label: "Xã Hải Yến",
    parent_code: "407",
  },
  {
    value: "23116",
    label: "Xã Hàm Cần",
    parent_code: "598",
  },
  {
    value: "23098",
    label: "Xã Hàm Chính",
    parent_code: "597",
  },
  {
    value: "23128",
    label: "Xã Hàm Cường",
    parent_code: "598",
  },
  {
    value: "23092",
    label: "Xã Hàm Đức",
    parent_code: "597",
  },
  {
    value: "29488",
    label: "Xã Hàm Giang",
    parent_code: "849",
  },
  {
    value: "23101",
    label: "Xã Hàm Hiệp",
    parent_code: "597",
  },
  {
    value: "23125",
    label: "Xã Hàm Kiệm",
    parent_code: "598",
  },
  {
    value: "23095",
    label: "Xã Hàm Liêm",
    parent_code: "597",
  },
  {
    value: "23137",
    label: "Xã Hàm Minh",
    parent_code: "598",
  },
  {
    value: "23131",
    label: "Xã Hàm Mỹ",
    parent_code: "598",
  },
  {
    value: "19219",
    label: "Xã Hàm Ninh",
    parent_code: "456",
  },
  {
    value: "31093",
    label: "Xã Hàm Ninh",
    parent_code: "911",
  },
  {
    value: "23077",
    label: "Xã Hàm Phú",
    parent_code: "597",
  },
  {
    value: "14755",
    label: "Phường Hàm Rồng",
    parent_code: "380",
  },
  {
    value: "03016",
    label: "Phường Hàm Rồng",
    parent_code: "088",
  },
  {
    value: "32194",
    label: "Xã Hàm Rồng",
    parent_code: "971",
  },
  {
    value: "29489",
    label: "Xã Hàm Tân",
    parent_code: "849",
  },
  {
    value: "23122",
    label: "Xã Hàm Thạnh",
    parent_code: "598",
  },
  {
    value: "23104",
    label: "Xã Hàm Thắng",
    parent_code: "597",
  },
  {
    value: "22918",
    label: "Phường Hàm Tiến",
    parent_code: "593",
  },
  {
    value: "23089",
    label: "Xã Hàm Trí",
    parent_code: "597",
  },
  {
    value: "12217",
    label: "Xã Hàm Tử",
    parent_code: "330",
  },
  {
    value: "04780",
    label: "Xã Hán Đà",
    parent_code: "141",
  },
  {
    value: "09316",
    label: "Xã Hán Quảng",
    parent_code: "259",
  },
  {
    value: "00061",
    label: "Phường Hàng Bạc",
    parent_code: "002",
  },
  {
    value: "00088",
    label: "Phường Hàng Bài",
    parent_code: "002",
  },
  {
    value: "00052",
    label: "Phường Hàng Bồ",
    parent_code: "002",
  },
  {
    value: "00076",
    label: "Phường Hàng Bông",
    parent_code: "002",
  },
  {
    value: "00196",
    label: "Phường Hàng Bột",
    parent_code: "006",
  },
  {
    value: "00046",
    label: "Phường Hàng Buồm",
    parent_code: "002",
  },
  {
    value: "03862",
    label: "Xã Hang Chú",
    parent_code: "121",
  },
  {
    value: "00049",
    label: "Phường Hàng Đào",
    parent_code: "002",
  },
  {
    value: "03869",
    label: "Xã Háng Đồng",
    parent_code: "121",
  },
  {
    value: "00064",
    label: "Phường Hàng Gai",
    parent_code: "002",
  },
  {
    value: "26113",
    label: "Xã Hàng Gòn",
    parent_code: "732",
  },
  {
    value: "11392",
    label: "Phường Hàng Kênh",
    parent_code: "305",
  },
  {
    value: "05212",
    label: "Xã Hang Kia",
    parent_code: "156",
  },
  {
    value: "03385",
    label: "Xã Háng Lìa",
    parent_code: "101",
  },
  {
    value: "00043",
    label: "Phường Hàng Mã",
    parent_code: "002",
  },
  {
    value: "05353",
    label: "Thị trấn Hàng Trạm",
    parent_code: "158",
  },
  {
    value: "00070",
    label: "Phường Hàng Trống",
    parent_code: "002",
  },
  {
    value: "32203",
    label: "Xã Hàng Vịnh",
    parent_code: "971",
  },
  {
    value: "08164",
    label: "Xã Hanh Cù",
    parent_code: "232",
  },
  {
    value: "16747",
    label: "Xã Hạnh Dịch",
    parent_code: "415",
  },
  {
    value: "21370",
    label: "Xã Hành Dũng",
    parent_code: "532",
  },
  {
    value: "21379",
    label: "Xã Hành Đức",
    parent_code: "532",
  },
  {
    value: "17722",
    label: "Xã Hạnh Lâm",
    parent_code: "428",
  },
  {
    value: "21382",
    label: "Xã Hành Minh",
    parent_code: "532",
  },
  {
    value: "21376",
    label: "Xã Hành Nhân",
    parent_code: "532",
  },
  {
    value: "01624",
    label: "Xã Hạnh Phúc",
    parent_code: "049",
  },
  {
    value: "21385",
    label: "Xã Hành Phước",
    parent_code: "532",
  },
  {
    value: "04678",
    label: "Xã Hạnh Sơn",
    parent_code: "133",
  },
  {
    value: "21388",
    label: "Xã Hành Thiện",
    parent_code: "532",
  },
  {
    value: "21391",
    label: "Xã Hành Thịnh",
    parent_code: "532",
  },
  {
    value: "21367",
    label: "Xã Hành Thuận",
    parent_code: "532",
  },
  {
    value: "21397",
    label: "Xã Hành Tín  Đông",
    parent_code: "532",
  },
  {
    value: "21394",
    label: "Xã Hành Tín Tây",
    parent_code: "532",
  },
  {
    value: "21373",
    label: "Xã Hành Trung",
    parent_code: "532",
  },
  {
    value: "25588",
    label: "Xã Hảo Đước",
    parent_code: "708",
  },
  {
    value: "02623",
    label: "Xã Hào Phú",
    parent_code: "076",
  },
  {
    value: "09331",
    label: "Phường Hạp Lĩnh",
    parent_code: "256",
  },
  {
    value: "04618",
    label: "Xã Hát Lìu",
    parent_code: "139",
  },
  {
    value: "04105",
    label: "Thị trấn Hát Lót",
    parent_code: "125",
  },
  {
    value: "04135",
    label: "Xã Hát Lót",
    parent_code: "125",
  },
  {
    value: "09751",
    label: "Xã Hát Môn",
    parent_code: "272",
  },
  {
    value: "26725",
    label: "Phường Hắc Dịch",
    parent_code: "754",
  },
  {
    value: "16012",
    label: "Thị trấn Hậu Lộc",
    parent_code: "400",
  },
  {
    value: "29728",
    label: "Xã Hậu Lộc",
    parent_code: "860",
  },
  {
    value: "28366",
    label: "Xã Hậu Mỹ Bắc A",
    parent_code: "819",
  },
  {
    value: "28363",
    label: "Xã Hậu Mỹ Bắc B",
    parent_code: "819",
  },
  {
    value: "28375",
    label: "Xã Hậu Mỹ Phú",
    parent_code: "819",
  },
  {
    value: "28372",
    label: "Xã Hậu Mỹ Trinh",
    parent_code: "819",
  },
  {
    value: "27931",
    label: "Thị trấn Hậu Nghĩa",
    parent_code: "802",
  },
  {
    value: "17524",
    label: "Xã Hậu Thành",
    parent_code: "426",
  },
  {
    value: "28393",
    label: "Xã Hậu Thành",
    parent_code: "819",
  },
  {
    value: "31648",
    label: "Xã Hậu Thạnh",
    parent_code: "946",
  },
  {
    value: "27841",
    label: "Xã Hậu Thạnh Đông",
    parent_code: "799",
  },
  {
    value: "27832",
    label: "Xã Hậu Thạnh Tây",
    parent_code: "799",
  },
  {
    value: "03359",
    label: "Xã Hẹ Muông",
    parent_code: "100",
  },
  {
    value: "14896",
    label: "Xã Hiền Chung",
    parent_code: "385",
  },
  {
    value: "10204",
    label: "Xã Hiền Giang",
    parent_code: "279",
  },
  {
    value: "11938",
    label: "Xã Hiền Hào",
    parent_code: "317",
  },
  {
    value: "13747",
    label: "Xã Hiển Khánh",
    parent_code: "359",
  },
  {
    value: "14899",
    label: "Xã Hiền Kiệt",
    parent_code: "385",
  },
  {
    value: "08080",
    label: "Xã Hiền Lương",
    parent_code: "231",
  },
  {
    value: "04885",
    label: "Xã Hiền Lương",
    parent_code: "150",
  },
  {
    value: "11953",
    label: "Phường Hiến Nam",
    parent_code: "323",
  },
  {
    value: "00412",
    label: "Xã Hiền Ninh",
    parent_code: "016",
  },
  {
    value: "19231",
    label: "Xã Hiền Ninh",
    parent_code: "456",
  },
  {
    value: "08440",
    label: "Xã Hiền Quan",
    parent_code: "236",
  },
  {
    value: "17701",
    label: "Xã Hiến Sơn",
    parent_code: "427",
  },
  {
    value: "19408",
    label: "Xã Hiền Thành",
    parent_code: "464",
  },
  {
    value: "10744",
    label: "Phường Hiến Thành",
    parent_code: "292",
  },
  {
    value: "09337",
    label: "Xã Hiên Vân",
    parent_code: "260",
  },
  {
    value: "10735",
    label: "Phường Hiệp An",
    parent_code: "292",
  },
  {
    value: "24961",
    label: "Xã Hiệp An",
    parent_code: "678",
  },
  {
    value: "25768",
    label: "Phường Hiệp An",
    parent_code: "718",
  },
  {
    value: "26812",
    label: "Phường Hiệp Bình Chánh",
    parent_code: "769",
  },
  {
    value: "26809",
    label: "Phường Hiệp Bình Phước",
    parent_code: "769",
  },
  {
    value: "10618",
    label: "Xã Hiệp Cát",
    parent_code: "291",
  },
  {
    value: "12328",
    label: "Xã Hiệp Cường",
    parent_code: "331",
  },
  {
    value: "28501",
    label: "Xã Hiệp Đức",
    parent_code: "820",
  },
  {
    value: "11848",
    label: "Xã Hiệp Hoà",
    parent_code: "316",
  },
  {
    value: "10708",
    label: "Xã Hiệp Hòa",
    parent_code: "292",
  },
  {
    value: "07147",
    label: "Xã Hiệp Hòa",
    parent_code: "206",
  },
  {
    value: "13204",
    label: "Xã Hiệp Hòa",
    parent_code: "344",
  },
  {
    value: "26065",
    label: "Phường Hiệp Hòa",
    parent_code: "731",
  },
  {
    value: "20758",
    label: "Xã Hiệp Hòa",
    parent_code: "512",
  },
  {
    value: "27934",
    label: "Thị trấn Hiệp Hòa",
    parent_code: "802",
  },
  {
    value: "27952",
    label: "Xã Hiệp Hòa",
    parent_code: "802",
  },
  {
    value: "29437",
    label: "Xã Hiệp Hòa",
    parent_code: "848",
  },
  {
    value: "31429",
    label: "Xã Hiệp Hưng",
    parent_code: "934",
  },
  {
    value: "31344",
    label: "Phường Hiệp Lợi",
    parent_code: "931",
  },
  {
    value: "01960",
    label: "Xã Hiệp Lực",
    parent_code: "062",
  },
  {
    value: "11227",
    label: "Xã Hiệp Lực",
    parent_code: "299",
  },
  {
    value: "29452",
    label: "Xã Hiệp Mỹ Đông",
    parent_code: "848",
  },
  {
    value: "29455",
    label: "Xã Hiệp Mỹ Tây",
    parent_code: "848",
  },
  {
    value: "25465",
    label: "Phường Hiệp Ninh",
    parent_code: "703",
  },
  {
    value: "26839",
    label: "Phường Hiệp Phú",
    parent_code: "769",
  },
  {
    value: "26479",
    label: "Thị trấn Hiệp Phước",
    parent_code: "742",
  },
  {
    value: "27661",
    label: "Xã Hiệp Phước",
    parent_code: "786",
  },
  {
    value: "10726",
    label: "Phường Hiệp Sơn",
    parent_code: "292",
  },
  {
    value: "25633",
    label: "Phường Hiệp Tân",
    parent_code: "709",
  },
  {
    value: "27037",
    label: "Phường Hiệp Tân",
    parent_code: "767",
  },
  {
    value: "25741",
    label: "Phường Hiệp Thành",
    parent_code: "718",
  },
  {
    value: "26770",
    label: "Phường Hiệp Thành",
    parent_code: "761",
  },
  {
    value: "31343",
    label: "Phường Hiệp Thành",
    parent_code: "931",
  },
  {
    value: "31840",
    label: "Xã Hiệp Thành",
    parent_code: "954",
  },
  {
    value: "24967",
    label: "Xã Hiệp Thạnh",
    parent_code: "678",
  },
  {
    value: "25663",
    label: "Xã Hiệp Thạnh",
    parent_code: "710",
  },
  {
    value: "28228",
    label: "Xã Hiệp Thạnh",
    parent_code: "808",
  },
  {
    value: "29539",
    label: "Xã Hiệp Thạnh",
    parent_code: "851",
  },
  {
    value: "09778",
    label: "Xã Hiệp Thuận",
    parent_code: "272",
  },
  {
    value: "20761",
    label: "Xã Hiệp Thuận",
    parent_code: "512",
  },
  {
    value: "32197",
    label: "Xã Hiệp Tùng",
    parent_code: "971",
  },
  {
    value: "30442",
    label: "Xã Hiệp Xương",
    parent_code: "888",
  },
  {
    value: "23476",
    label: "Xã Hiếu",
    parent_code: "613",
  },
  {
    value: "25908",
    label: "Xã Hiếu Liêm",
    parent_code: "726",
  },
  {
    value: "26203",
    label: "Xã Hiếu Liêm",
    parent_code: "735",
  },
  {
    value: "29716",
    label: "Xã Hiếu Nghĩa",
    parent_code: "859",
  },
  {
    value: "29710",
    label: "Xã Hiếu Nhơn",
    parent_code: "859",
  },
  {
    value: "29686",
    label: "Xã Hiếu Phụng",
    parent_code: "859",
  },
  {
    value: "29713",
    label: "Xã Hiếu Thành",
    parent_code: "859",
  },
  {
    value: "29701",
    label: "Xã Hiếu Thuận",
    parent_code: "859",
  },
  {
    value: "29353",
    label: "Xã Hiếu Trung",
    parent_code: "846",
  },
  {
    value: "29350",
    label: "Xã Hiếu Tử",
    parent_code: "846",
  },
  {
    value: "03127",
    label: "Phường Him Lam",
    parent_code: "094",
  },
  {
    value: "23714",
    label: "Xã HNol",
    parent_code: "626",
  },
  {
    value: "30940",
    label: "Xã Hoà An",
    parent_code: "906",
  },
  {
    value: "12922",
    label: "Xã Hòa An",
    parent_code: "341",
  },
  {
    value: "02353",
    label: "Xã Hòa An",
    parent_code: "073",
  },
  {
    value: "22315",
    label: "Xã Hòa An",
    parent_code: "563",
  },
  {
    value: "20306",
    label: "Phường Hòa An",
    parent_code: "495",
  },
  {
    value: "24511",
    label: "Xã Hòa An",
    parent_code: "654",
  },
  {
    value: "29893",
    label: "Xã Hòa An",
    parent_code: "866",
  },
  {
    value: "30679",
    label: "Xã Hòa An",
    parent_code: "893",
  },
  {
    value: "31423",
    label: "Xã Hòa An",
    parent_code: "934",
  },
  {
    value: "26068",
    label: "Phường Hóa An",
    parent_code: "731",
  },
  {
    value: "29311",
    label: "Xã Hòa Ân",
    parent_code: "845",
  },
  {
    value: "25045",
    label: "Xã Hòa Bắc",
    parent_code: "679",
  },
  {
    value: "20293",
    label: "Xã Hòa Bắc",
    parent_code: "497",
  },
  {
    value: "11527",
    label: "Xã Hoà Bình",
    parent_code: "311",
  },
  {
    value: "11890",
    label: "Xã Hoà Bình",
    parent_code: "316",
  },
  {
    value: "30004",
    label: "Xã Hoà Bình",
    parent_code: "871",
  },
  {
    value: "10198",
    label: "Xã Hòa Bình",
    parent_code: "279",
  },
  {
    value: "05671",
    label: "Xã Hòa Bình",
    parent_code: "169",
  },
  {
    value: "06103",
    label: "Xã Hòa Bình",
    parent_code: "181",
  },
  {
    value: "06274",
    label: "Xã Hòa Bình",
    parent_code: "184",
  },
  {
    value: "06397",
    label: "Xã Hòa Bình",
    parent_code: "186",
  },
  {
    value: "06508",
    label: "Xã Hòa Bình",
    parent_code: "187",
  },
  {
    value: "07045",
    label: "Xã Hòa Bình",
    parent_code: "193",
  },
  {
    value: "12655",
    label: "Xã Hòa Bình",
    parent_code: "339",
  },
  {
    value: "13135",
    label: "Xã Hòa Bình",
    parent_code: "343",
  },
  {
    value: "13258",
    label: "Xã Hòa Bình",
    parent_code: "344",
  },
  {
    value: "04825",
    label: "Xã Hòa Bình",
    parent_code: "148",
  },
  {
    value: "26038",
    label: "Phường Hòa Bình",
    parent_code: "731",
  },
  {
    value: "26641",
    label: "Xã Hòa Bình",
    parent_code: "751",
  },
  {
    value: "23338",
    label: "Xã Hòa Bình",
    parent_code: "608",
  },
  {
    value: "24042",
    label: "Phường Hòa Bình",
    parent_code: "624",
  },
  {
    value: "29830",
    label: "Xã Hòa Bình",
    parent_code: "862",
  },
  {
    value: "30676",
    label: "Xã Hòa Bình",
    parent_code: "893",
  },
  {
    value: "31891",
    label: "Thị trấn Hòa Bình",
    parent_code: "961",
  },
  {
    value: "22252",
    label: "Xã Hòa Bình 1",
    parent_code: "562",
  },
  {
    value: "30613",
    label: "Xã Hòa Bình Thạnh",
    parent_code: "892",
  },
  {
    value: "31057",
    label: "Xã Hoà Chánh",
    parent_code: "913",
  },
  {
    value: "20323",
    label: "Xã Hòa Châu",
    parent_code: "497",
  },
  {
    value: "10108",
    label: "Xã Hòa Chính",
    parent_code: "277",
  },
  {
    value: "01285",
    label: "Phường Hoà Chung",
    parent_code: "040",
  },
  {
    value: "04513",
    label: "Xã Hòa Cuông",
    parent_code: "138",
  },
  {
    value: "06223",
    label: "Xã Hòa Cư",
    parent_code: "183",
  },
  {
    value: "20257",
    label: "Phường Hòa Cường Bắc",
    parent_code: "492",
  },
  {
    value: "20258",
    label: "Phường Hòa Cường Nam",
    parent_code: "492",
  },
  {
    value: "30802",
    label: "Xã Hòa Điền",
    parent_code: "902",
  },
  {
    value: "28645",
    label: "Xã Hòa Định",
    parent_code: "822",
  },
  {
    value: "22318",
    label: "Xã Hòa Định Đông",
    parent_code: "563",
  },
  {
    value: "22321",
    label: "Xã Hòa Định Tây",
    parent_code: "563",
  },
  {
    value: "11572",
    label: "Xã Hoa Động",
    parent_code: "311",
  },
  {
    value: "24517",
    label: "Xã Hòa Đông",
    parent_code: "654",
  },
  {
    value: "31786",
    label: "Xã Hòa Đông",
    parent_code: "950",
  },
  {
    value: "22276",
    label: "Xã Hòa Đồng",
    parent_code: "562",
  },
  {
    value: "20290",
    label: "Phường Hoà Hải",
    parent_code: "494",
  },
  {
    value: "18508",
    label: "Xã Hòa Hải",
    parent_code: "444",
  },
  {
    value: "13630",
    label: "Xã Hòa Hậu",
    parent_code: "353",
  },
  {
    value: "25504",
    label: "Xã Hòa Hiệp",
    parent_code: "705",
  },
  {
    value: "26647",
    label: "Xã Hòa Hiệp",
    parent_code: "751",
  },
  {
    value: "24562",
    label: "Xã Hòa Hiệp",
    parent_code: "657",
  },
  {
    value: "29743",
    label: "Xã Hòa Hiệp",
    parent_code: "860",
  },
  {
    value: "22246",
    label: "Phường Hòa Hiệp Bắc",
    parent_code: "564",
  },
  {
    value: "20194",
    label: "Phường Hòa Hiệp Bắc",
    parent_code: "490",
  },
  {
    value: "22282",
    label: "Phường Hòa Hiệp Nam",
    parent_code: "564",
  },
  {
    value: "20195",
    label: "Phường Hòa Hiệp Nam",
    parent_code: "490",
  },
  {
    value: "22261",
    label: "Phường Hoà Hiệp Trung",
    parent_code: "564",
  },
  {
    value: "16939",
    label: "Phường Hoà Hiếu",
    parent_code: "414",
  },
  {
    value: "22309",
    label: "Xã Hòa Hội",
    parent_code: "563",
  },
  {
    value: "25612",
    label: "Xã Hòa Hội",
    parent_code: "708",
  },
  {
    value: "26650",
    label: "Xã Hòa Hội",
    parent_code: "751",
  },
  {
    value: "18922",
    label: "Xã Hóa Hợp",
    parent_code: "452",
  },
  {
    value: "26644",
    label: "Xã Hòa Hưng",
    parent_code: "751",
  },
  {
    value: "28432",
    label: "Xã Hòa Hưng",
    parent_code: "819",
  },
  {
    value: "30934",
    label: "Xã Hòa Hưng",
    parent_code: "906",
  },
  {
    value: "20344",
    label: "Phường Hòa Hương",
    parent_code: "502",
  },
  {
    value: "24175",
    label: "Xã Hòa Khánh",
    parent_code: "643",
  },
  {
    value: "28399",
    label: "Xã Hòa Khánh",
    parent_code: "819",
  },
  {
    value: "20197",
    label: "Phường Hòa Khánh Bắc",
    parent_code: "490",
  },
  {
    value: "27973",
    label: "Xã Hòa Khánh Đông",
    parent_code: "802",
  },
  {
    value: "20198",
    label: "Phường Hòa Khánh Nam",
    parent_code: "490",
  },
  {
    value: "27979",
    label: "Xã Hòa Khánh Nam",
    parent_code: "802",
  },
  {
    value: "27970",
    label: "Xã Hòa Khánh Tây",
    parent_code: "802",
  },
  {
    value: "20225",
    label: "Phường Hòa Khê",
    parent_code: "491",
  },
  {
    value: "20332",
    label: "Xã Hòa Khương",
    parent_code: "497",
  },
  {
    value: "22042",
    label: "Xã Hòa Kiến",
    parent_code: "555",
  },
  {
    value: "06718",
    label: "Phường Hoà Lạc",
    parent_code: "194",
  },
  {
    value: "30430",
    label: "Xã Hoà Lạc",
    parent_code: "888",
  },
  {
    value: "06430",
    label: "Xã Hòa Lạc",
    parent_code: "186",
  },
  {
    value: "18280",
    label: "Xã Hòa Lạc",
    parent_code: "440",
  },
  {
    value: "10402",
    label: "Xã Hòa Lâm",
    parent_code: "281",
  },
  {
    value: "24466",
    label: "Xã Hòa Lễ",
    parent_code: "653",
  },
  {
    value: "20296",
    label: "Xã Hòa Liên",
    parent_code: "497",
  },
  {
    value: "26572",
    label: "Xã Hoà Long",
    parent_code: "748",
  },
  {
    value: "09214",
    label: "Phường Hòa Long",
    parent_code: "256",
  },
  {
    value: "30223",
    label: "Xã Hòa Long",
    parent_code: "876",
  },
  {
    value: "16063",
    label: "Xã Hoa Lộc",
    parent_code: "400",
  },
  {
    value: "29734",
    label: "Xã Hoà Lộc",
    parent_code: "860",
  },
  {
    value: "16075",
    label: "Xã Hòa Lộc",
    parent_code: "400",
  },
  {
    value: "28924",
    label: "Xã Hòa Lộc",
    parent_code: "838",
  },
  {
    value: "30937",
    label: "Xã Hoà Lợi",
    parent_code: "906",
  },
  {
    value: "25849",
    label: "Phường Hòa Lợi",
    parent_code: "721",
  },
  {
    value: "29206",
    label: "Xã Hòa Lợi",
    parent_code: "837",
  },
  {
    value: "29401",
    label: "Xã Hòa Lợi",
    parent_code: "847",
  },
  {
    value: "23572",
    label: "Phường Hoa Lư",
    parent_code: "622",
  },
  {
    value: "31336",
    label: "Xã Hoả Lựu",
    parent_code: "930",
  },
  {
    value: "03097",
    label: "Xã Hoà Mạc",
    parent_code: "089",
  },
  {
    value: "13324",
    label: "Phường Hòa Mạc",
    parent_code: "349",
  },
  {
    value: "22993",
    label: "Xã Hòa Minh",
    parent_code: "595",
  },
  {
    value: "20200",
    label: "Phường Hòa Minh",
    parent_code: "490",
  },
  {
    value: "29410",
    label: "Xã Hòa Minh",
    parent_code: "847",
  },
  {
    value: "02098",
    label: "Xã Hoà Mục",
    parent_code: "065",
  },
  {
    value: "32141",
    label: "Xã Hoà Mỹ",
    parent_code: "969",
  },
  {
    value: "31420",
    label: "Xã Hòa Mỹ",
    parent_code: "934",
  },
  {
    value: "22285",
    label: "Xã Hòa Mỹ Đông",
    parent_code: "562",
  },
  {
    value: "22288",
    label: "Xã Hòa Mỹ Tây",
    parent_code: "562",
  },
  {
    value: "10414",
    label: "Xã Hòa Nam",
    parent_code: "281",
  },
  {
    value: "25042",
    label: "Xã Hòa Nam",
    parent_code: "679",
  },
  {
    value: "11707",
    label: "Phường Hoà Nghĩa",
    parent_code: "309",
  },
  {
    value: "28882",
    label: "Xã Hòa Nghĩa",
    parent_code: "832",
  },
  {
    value: "20308",
    label: "Xã Hòa Nhơn",
    parent_code: "497",
  },
  {
    value: "25036",
    label: "Xã Hòa Ninh",
    parent_code: "679",
  },
  {
    value: "20299",
    label: "Xã Hòa Ninh",
    parent_code: "497",
  },
  {
    value: "29584",
    label: "Xã Hòa Ninh",
    parent_code: "857",
  },
  {
    value: "20305",
    label: "Phường Hòa Phát",
    parent_code: "495",
  },
  {
    value: "12115",
    label: "Xã Hòa Phong",
    parent_code: "328",
  },
  {
    value: "22264",
    label: "Xã Hòa Phong",
    parent_code: "562",
  },
  {
    value: "20320",
    label: "Xã Hòa Phong",
    parent_code: "497",
  },
  {
    value: "24463",
    label: "Xã Hòa Phong",
    parent_code: "653",
  },
  {
    value: "25760",
    label: "Phường Hoà Phú",
    parent_code: "718",
  },
  {
    value: "10417",
    label: "Xã Hòa Phú",
    parent_code: "281",
  },
  {
    value: "02335",
    label: "Xã Hòa Phú",
    parent_code: "073",
  },
  {
    value: "22270",
    label: "Xã Hòa Phú",
    parent_code: "562",
  },
  {
    value: "23743",
    label: "Xã Hòa Phú",
    parent_code: "627",
  },
  {
    value: "27544",
    label: "Xã Hòa Phú",
    parent_code: "783",
  },
  {
    value: "20317",
    label: "Xã Hòa Phú",
    parent_code: "497",
  },
  {
    value: "24172",
    label: "Xã Hòa Phú",
    parent_code: "643",
  },
  {
    value: "28216",
    label: "Xã Hòa Phú",
    parent_code: "808",
  },
  {
    value: "29617",
    label: "Xã Hòa Phú",
    parent_code: "857",
  },
  {
    value: "18910",
    label: "Xã Hóa Phúc",
    parent_code: "452",
  },
  {
    value: "20329",
    label: "Xã Hòa Phước",
    parent_code: "497",
  },
  {
    value: "22303",
    label: "Xã Hòa Quang Bắc",
    parent_code: "563",
  },
  {
    value: "22306",
    label: "Xã Hòa Quang Nam",
    parent_code: "563",
  },
  {
    value: "20287",
    label: "Phường Hoà Quý",
    parent_code: "494",
  },
  {
    value: "16186",
    label: "Xã Hóa Quỳ",
    parent_code: "402",
  },
  {
    value: "10363",
    label: "Xã Hoa Sơn",
    parent_code: "281",
  },
  {
    value: "08789",
    label: "Thị trấn Hoa Sơn",
    parent_code: "246",
  },
  {
    value: "17357",
    label: "Xã Hoa Sơn",
    parent_code: "424",
  },
  {
    value: "06445",
    label: "Xã Hòa Sơn",
    parent_code: "186",
  },
  {
    value: "07837",
    label: "Xã Hòa Sơn",
    parent_code: "223",
  },
  {
    value: "04945",
    label: "Xã Hòa Sơn",
    parent_code: "152",
  },
  {
    value: "17647",
    label: "Xã Hòa Sơn",
    parent_code: "427",
  },
  {
    value: "22825",
    label: "Xã Hòa Sơn",
    parent_code: "585",
  },
  {
    value: "20302",
    label: "Xã Hòa Sơn",
    parent_code: "497",
  },
  {
    value: "24481",
    label: "Xã Hòa Sơn",
    parent_code: "653",
  },
  {
    value: "18937",
    label: "Xã Hóa Sơn",
    parent_code: "452",
  },
  {
    value: "22297",
    label: "Xã Hòa Tâm",
    parent_code: "564",
  },
  {
    value: "29320",
    label: "Xã Hoà Tân",
    parent_code: "845",
  },
  {
    value: "24460",
    label: "Xã Hòa Tân",
    parent_code: "653",
  },
  {
    value: "30277",
    label: "Xã Hòa Tân",
    parent_code: "877",
  },
  {
    value: "32041",
    label: "Xã Hòa Tân",
    parent_code: "964",
  },
  {
    value: "22267",
    label: "Xã Hòa Tân Đông",
    parent_code: "564",
  },
  {
    value: "22273",
    label: "Xã Hòa Tân Tây",
    parent_code: "562",
  },
  {
    value: "09949",
    label: "Xã Hòa Thạch",
    parent_code: "275",
  },
  {
    value: "01765",
    label: "Xã Hoa Thám",
    parent_code: "052",
  },
  {
    value: "06073",
    label: "Xã Hoa Thám",
    parent_code: "181",
  },
  {
    value: "17551",
    label: "Xã Hoa Thành",
    parent_code: "426",
  },
  {
    value: "22243",
    label: "Xã Hòa Thành",
    parent_code: "564",
  },
  {
    value: "24457",
    label: "Xã Hòa Thành",
    parent_code: "653",
  },
  {
    value: "30214",
    label: "Xã Hòa Thành",
    parent_code: "876",
  },
  {
    value: "32038",
    label: "Xã Hòa Thành",
    parent_code: "964",
  },
  {
    value: "25606",
    label: "Xã Hòa Thạnh",
    parent_code: "708",
  },
  {
    value: "27034",
    label: "Phường Hòa Thạnh",
    parent_code: "767",
  },
  {
    value: "29731",
    label: "Xã Hòa Thạnh",
    parent_code: "860",
  },
  {
    value: "18916",
    label: "Xã Hóa Thanh",
    parent_code: "452",
  },
  {
    value: "06460",
    label: "Xã Hòa Thắng",
    parent_code: "186",
  },
  {
    value: "22324",
    label: "Xã Hòa Thắng",
    parent_code: "563",
  },
  {
    value: "23053",
    label: "Xã Hòa Thắng",
    parent_code: "596",
  },
  {
    value: "24166",
    label: "Xã Hòa Thắng",
    parent_code: "643",
  },
  {
    value: "22294",
    label: "Xã Hòa Thịnh",
    parent_code: "562",
  },
  {
    value: "20312",
    label: "Phường Hòa Thọ Đông",
    parent_code: "495",
  },
  {
    value: "20311",
    label: "Phường Hòa Thọ Tây",
    parent_code: "495",
  },
  {
    value: "01648",
    label: "Thị trấn Hoà Thuận",
    parent_code: "049",
  },
  {
    value: "20375",
    label: "Phường Hoà Thuận",
    parent_code: "502",
  },
  {
    value: "29892",
    label: "Phường Hoà Thuận",
    parent_code: "866",
  },
  {
    value: "24157",
    label: "Xã Hòa Thuận",
    parent_code: "643",
  },
  {
    value: "29398",
    label: "Xã Hòa Thuận",
    parent_code: "847",
  },
  {
    value: "20246",
    label: "Phường Hòa Thuận Đông",
    parent_code: "492",
  },
  {
    value: "20245",
    label: "Phường Hòa Thuận Tây",
    parent_code: "492",
  },
  {
    value: "19258",
    label: "Xã Hoa Thủy",
    parent_code: "457",
  },
  {
    value: "05692",
    label: "Xã Hóa Thượng",
    parent_code: "169",
  },
  {
    value: "31339",
    label: "Xã Hoả Tiến",
    parent_code: "930",
  },
  {
    value: "09211",
    label: "Xã Hòa Tiến",
    parent_code: "258",
  },
  {
    value: "12604",
    label: "Xã Hòa Tiến",
    parent_code: "339",
  },
  {
    value: "20326",
    label: "Xã Hòa Tiến",
    parent_code: "497",
  },
  {
    value: "24523",
    label: "Xã Hòa Tiến",
    parent_code: "654",
  },
  {
    value: "18919",
    label: "Xã Hóa Tiến",
    parent_code: "452",
  },
  {
    value: "28600",
    label: "Xã Hòa Tịnh",
    parent_code: "822",
  },
  {
    value: "29638",
    label: "Xã Hòa Tịnh",
    parent_code: "858",
  },
  {
    value: "19183",
    label: "Xã Hòa Trạch",
    parent_code: "455",
  },
  {
    value: "22312",
    label: "Xã Hòa Trị",
    parent_code: "563",
  },
  {
    value: "25039",
    label: "Xã Hòa Trung",
    parent_code: "679",
  },
  {
    value: "05683",
    label: "Xã Hóa Trung",
    parent_code: "169",
  },
  {
    value: "31717",
    label: "Xã Hòa Tú 1",
    parent_code: "947",
  },
  {
    value: "31729",
    label: "Xã Hòa Tú II",
    parent_code: "947",
  },
  {
    value: "22258",
    label: "Phường Hoà Vinh",
    parent_code: "564",
  },
  {
    value: "10405",
    label: "Xã Hòa Xá",
    parent_code: "281",
  },
  {
    value: "20314",
    label: "Phường Hòa Xuân",
    parent_code: "495",
  },
  {
    value: "24178",
    label: "Xã Hòa Xuân",
    parent_code: "643",
  },
  {
    value: "22291",
    label: "Xã Hòa Xuân Đông",
    parent_code: "564",
  },
  {
    value: "22300",
    label: "Xã Hòa Xuân Nam",
    parent_code: "564",
  },
  {
    value: "22279",
    label: "Phường Hòa Xuân Tây",
    parent_code: "564",
  },
  {
    value: "21649",
    label: "Xã Hoài Châu",
    parent_code: "543",
  },
  {
    value: "21646",
    label: "Xã Hoài Châu Bắc",
    parent_code: "543",
  },
  {
    value: "24913",
    label: "Xã Hoài Đức",
    parent_code: "676",
  },
  {
    value: "21685",
    label: "Phường Hoài Đức",
    parent_code: "543",
  },
  {
    value: "21676",
    label: "Xã Hoài Hải",
    parent_code: "543",
  },
  {
    value: "21661",
    label: "Phường Hoài Hảo",
    parent_code: "543",
  },
  {
    value: "21670",
    label: "Phường Hoài Hương",
    parent_code: "543",
  },
  {
    value: "21682",
    label: "Xã Hoài Mỹ",
    parent_code: "543",
  },
  {
    value: "21652",
    label: "Xã Hoài Phú",
    parent_code: "543",
  },
  {
    value: "21643",
    label: "Xã Hoài Sơn",
    parent_code: "543",
  },
  {
    value: "21673",
    label: "Phường Hoài Tân",
    parent_code: "543",
  },
  {
    value: "21667",
    label: "Phường Hoài Thanh",
    parent_code: "543",
  },
  {
    value: "21664",
    label: "Phường Hoài Thanh Tây",
    parent_code: "543",
  },
  {
    value: "09403",
    label: "Xã Hoài Thượng",
    parent_code: "262",
  },
  {
    value: "21679",
    label: "Phường Hoài Xuân",
    parent_code: "543",
  },
  {
    value: "19111",
    label: "Thị trấn Hoàn Lão",
    parent_code: "455",
  },
  {
    value: "12070",
    label: "Xã Hoàn Long",
    parent_code: "327",
  },
  {
    value: "09340",
    label: "Xã Hoàn Sơn",
    parent_code: "260",
  },
  {
    value: "07828",
    label: "Xã Hoàng An",
    parent_code: "223",
  },
  {
    value: "11926",
    label: "Xã Hoàng Châu",
    parent_code: "317",
  },
  {
    value: "08203",
    label: "Xã Hoàng Cương",
    parent_code: "232",
  },
  {
    value: "10078",
    label: "Xã Hoàng Diệu",
    parent_code: "277",
  },
  {
    value: "11047",
    label: "Xã Hoàng Diệu",
    parent_code: "297",
  },
  {
    value: "12460",
    label: "Phường Hoàng Diệu",
    parent_code: "336",
  },
  {
    value: "08896",
    label: "Xã Hoàng Đan",
    parent_code: "247",
  },
  {
    value: "13357",
    label: "Phường Hoàng Đông",
    parent_code: "349",
  },
  {
    value: "05986",
    label: "Xã Hoàng Đồng",
    parent_code: "178",
  },
  {
    value: "11566",
    label: "Xã Hoàng Động",
    parent_code: "311",
  },
  {
    value: "16294",
    label: "Xã Hoàng Giang",
    parent_code: "404",
  },
  {
    value: "12388",
    label: "Xã Hoàng Hanh",
    parent_code: "323",
  },
  {
    value: "08872",
    label: "Xã Hoàng Hoa",
    parent_code: "247",
  },
  {
    value: "10555",
    label: "Xã Hoàng Hoa Thám",
    parent_code: "290",
  },
  {
    value: "12169",
    label: "Xã Hoàng Hoa Thám",
    parent_code: "329",
  },
  {
    value: "02518",
    label: "Xã Hoàng Khai",
    parent_code: "075",
  },
  {
    value: "09016",
    label: "Xã Hoàng Kim",
    parent_code: "250",
  },
  {
    value: "08899",
    label: "Xã Hoàng Lâu",
    parent_code: "247",
  },
  {
    value: "03019",
    label: "Xã Hoàng Liên",
    parent_code: "088",
  },
  {
    value: "00337",
    label: "Phường Hoàng Liệt",
    parent_code: "008",
  },
  {
    value: "10303",
    label: "Xã Hoàng Long",
    parent_code: "280",
  },
  {
    value: "07819",
    label: "Xã Hoàng Lương",
    parent_code: "223",
  },
  {
    value: "13909",
    label: "Xã Hoàng Nam",
    parent_code: "361",
  },
  {
    value: "05818",
    label: "Xã Hoàng Nông",
    parent_code: "171",
  },
  {
    value: "07114",
    label: "Phường Hoàng Quế",
    parent_code: "205",
  },
  {
    value: "16288",
    label: "Xã Hoàng Sơn",
    parent_code: "404",
  },
  {
    value: "10573",
    label: "Phường Hoàng Tân",
    parent_code: "290",
  },
  {
    value: "07156",
    label: "Xã Hoàng Tân",
    parent_code: "206",
  },
  {
    value: "13408",
    label: "Xã Hoàng Tây",
    parent_code: "350",
  },
  {
    value: "07825",
    label: "Xã Hoàng Thanh",
    parent_code: "223",
  },
  {
    value: "03580",
    label: "Xã Hoang Thèn",
    parent_code: "109",
  },
  {
    value: "02863",
    label: "Xã Hoàng Thu Phố",
    parent_code: "085",
  },
  {
    value: "10567",
    label: "Phường Hoàng Tiến",
    parent_code: "290",
  },
  {
    value: "01930",
    label: "Xã Hoàng Trĩ",
    parent_code: "061",
  },
  {
    value: "01696",
    label: "Xã Hoàng Tung",
    parent_code: "051",
  },
  {
    value: "00322",
    label: "Phường Hoàng Văn Thụ",
    parent_code: "008",
  },
  {
    value: "10075",
    label: "Xã Hoàng Văn Thụ",
    parent_code: "277",
  },
  {
    value: "11320",
    label: "Phường Hoàng Văn Thụ",
    parent_code: "303",
  },
  {
    value: "05440",
    label: "Phường Hoàng Văn Thụ",
    parent_code: "164",
  },
  {
    value: "05971",
    label: "Phường Hoàng Văn Thụ",
    parent_code: "178",
  },
  {
    value: "06100",
    label: "Xã Hoàng Văn Thụ",
    parent_code: "181",
  },
  {
    value: "07210",
    label: "Phường Hoàng Văn Thụ",
    parent_code: "213",
  },
  {
    value: "07822",
    label: "Xã Hoàng Vân",
    parent_code: "223",
  },
  {
    value: "06157",
    label: "Xã Hoàng Việt",
    parent_code: "182",
  },
  {
    value: "08689",
    label: "Xã Hoàng Xá",
    parent_code: "239",
  },
  {
    value: "07030",
    label: "Phường Hoành Bồ",
    parent_code: "193",
  },
  {
    value: "06841",
    label: "Xã Hoành Mô",
    parent_code: "198",
  },
  {
    value: "10687",
    label: "Xã Hoành Sơn",
    parent_code: "292",
  },
  {
    value: "14167",
    label: "Xã Hoành Sơn",
    parent_code: "365",
  },
  {
    value: "15283",
    label: "Xã Hoạt Giang",
    parent_code: "392",
  },
  {
    value: "15907",
    label: "Xã Hoằng Cát",
    parent_code: "399",
  },
  {
    value: "15979",
    label: "Xã Hoằng Châu",
    parent_code: "399",
  },
  {
    value: "15970",
    label: "Xã Hoằng Đại",
    parent_code: "380",
  },
  {
    value: "15946",
    label: "Xã Hoằng Đạo",
    parent_code: "399",
  },
  {
    value: "15940",
    label: "Xã Hoằng Đạt",
    parent_code: "399",
  },
  {
    value: "15997",
    label: "Xã Hoằng Đông",
    parent_code: "399",
  },
  {
    value: "15952",
    label: "Xã Hoằng Đồng",
    parent_code: "399",
  },
  {
    value: "15928",
    label: "Xã Hoằng Đức",
    parent_code: "399",
  },
  {
    value: "15871",
    label: "Xã Hoằng Giang",
    parent_code: "399",
  },
  {
    value: "15937",
    label: "Xã Hoằng Hà",
    parent_code: "399",
  },
  {
    value: "15991",
    label: "Xã Hoằng Hải",
    parent_code: "399",
  },
  {
    value: "15919",
    label: "Xã Hoằng Hợp",
    parent_code: "399",
  },
  {
    value: "15889",
    label: "Xã Hoằng Kim",
    parent_code: "399",
  },
  {
    value: "15964",
    label: "Xã Hoằng Lộc",
    parent_code: "399",
  },
  {
    value: "15976",
    label: "Xã Hoằng Lưu",
    parent_code: "399",
  },
  {
    value: "15994",
    label: "Xã Hoằng Ngọc",
    parent_code: "399",
  },
  {
    value: "15973",
    label: "Xã Hoằng Phong",
    parent_code: "399",
  },
  {
    value: "15883",
    label: "Xã Hoằng Phú",
    parent_code: "399",
  },
  {
    value: "16003",
    label: "Xã Hoằng Phụ",
    parent_code: "399",
  },
  {
    value: "15880",
    label: "Xã Hoằng Phượng",
    parent_code: "399",
  },
  {
    value: "15925",
    label: "Xã Hoằng Quang",
    parent_code: "380",
  },
  {
    value: "15886",
    label: "Xã Hoằng Quỳ",
    parent_code: "399",
  },
  {
    value: "15916",
    label: "Xã Hoằng Quý",
    parent_code: "399",
  },
  {
    value: "15901",
    label: "Xã Hoằng Sơn",
    parent_code: "399",
  },
  {
    value: "15982",
    label: "Xã Hoằng Tân",
    parent_code: "399",
  },
  {
    value: "15955",
    label: "Xã Hoằng Thái",
    parent_code: "399",
  },
  {
    value: "16000",
    label: "Xã Hoằng Thanh",
    parent_code: "399",
  },
  {
    value: "15961",
    label: "Xã Hoằng Thành",
    parent_code: "399",
  },
  {
    value: "15949",
    label: "Xã Hoằng Thắng",
    parent_code: "399",
  },
  {
    value: "15958",
    label: "Xã Hoằng Thịnh",
    parent_code: "399",
  },
  {
    value: "15988",
    label: "Xã Hoằng Tiến",
    parent_code: "399",
  },
  {
    value: "15967",
    label: "Xã Hoằng Trạch",
    parent_code: "399",
  },
  {
    value: "15895",
    label: "Xã Hoằng Trinh",
    parent_code: "399",
  },
  {
    value: "15892",
    label: "Xã Hoằng Trung",
    parent_code: "399",
  },
  {
    value: "16006",
    label: "Xã Hoằng Trường",
    parent_code: "399",
  },
  {
    value: "15877",
    label: "Xã Hoằng Xuân",
    parent_code: "399",
  },
  {
    value: "15910",
    label: "Xã Hoằng Xuyên",
    parent_code: "399",
  },
  {
    value: "15985",
    label: "Xã Hoằng Yến",
    parent_code: "399",
  },
  {
    value: "27559",
    label: "Thị trấn Hóc Môn",
    parent_code: "784",
  },
  {
    value: "30817",
    label: "Thị trấn Hòn Đất",
    parent_code: "903",
  },
  {
    value: "30814",
    label: "Xã Hòn Nghệ",
    parent_code: "902",
  },
  {
    value: "31108",
    label: "Xã Hòn Tre",
    parent_code: "912",
  },
  {
    value: "09400",
    label: "Thị trấn Hồ",
    parent_code: "262",
  },
  {
    value: "04459",
    label: "Xã Hồ Bốn",
    parent_code: "137",
  },
  {
    value: "07543",
    label: "Xã Hộ Đáp",
    parent_code: "219",
  },
  {
    value: "31570",
    label: "Xã Hồ Đắc Kiện",
    parent_code: "942",
  },
  {
    value: "18598",
    label: "Xã Hộ Độ",
    parent_code: "448",
  },
  {
    value: "22861",
    label: "Xã Hộ Hải",
    parent_code: "586",
  },
  {
    value: "03607",
    label: "Xã Hố Mít",
    parent_code: "111",
  },
  {
    value: "26002",
    label: "Phường Hố Nai",
    parent_code: "731",
  },
  {
    value: "26272",
    label: "Xã Hố Nai 3",
    parent_code: "737",
  },
  {
    value: "11383",
    label: "Phường Hồ Nam",
    parent_code: "305",
  },
  {
    value: "31945",
    label: "Phường Hộ Phòng",
    parent_code: "959",
  },
  {
    value: "00757",
    label: "Xã Hố Quáng Phìn",
    parent_code: "026",
  },
  {
    value: "08929",
    label: "Xã Hồ Sơn",
    parent_code: "248",
  },
  {
    value: "06451",
    label: "Xã Hồ Sơn",
    parent_code: "186",
  },
  {
    value: "01081",
    label: "Xã Hồ Thầu",
    parent_code: "032",
  },
  {
    value: "03406",
    label: "Xã Hồ Thầu",
    parent_code: "106",
  },
  {
    value: "32092",
    label: "Xã Hồ Thị Kỷ",
    parent_code: "967",
  },
  {
    value: "12190",
    label: "Xã Hồ Tùng Mậu",
    parent_code: "329",
  },
  {
    value: "19363",
    label: "Thị trấn Hồ Xá",
    parent_code: "464",
  },
  {
    value: "30673",
    label: "Xã Hội An",
    parent_code: "893",
  },
  {
    value: "30202",
    label: "Xã Hội An Đông",
    parent_code: "875",
  },
  {
    value: "06151",
    label: "Xã Hội Hoan",
    parent_code: "182",
  },
  {
    value: "08713",
    label: "Phường Hội Hợp",
    parent_code: "243",
  },
  {
    value: "25915",
    label: "Phường Hội Nghĩa",
    parent_code: "723",
  },
  {
    value: "14629",
    label: "Xã Hồi Ninh",
    parent_code: "376",
  },
  {
    value: "23569",
    label: "Phường Hội Phú",
    parent_code: "622",
  },
  {
    value: "17368",
    label: "Xã Hội Sơn",
    parent_code: "424",
  },
  {
    value: "23566",
    label: "Phường Hội Thương",
    parent_code: "622",
  },
  {
    value: "14869",
    label: "Thị trấn Hồi Xuân",
    parent_code: "385",
  },
  {
    value: "28507",
    label: "Xã Hội Xuân",
    parent_code: "820",
  },
  {
    value: "01348",
    label: "Xã Hồng An",
    parent_code: "043",
  },
  {
    value: "12661",
    label: "Xã Hồng An",
    parent_code: "339",
  },
  {
    value: "12778",
    label: "Xã Hồng Bạch",
    parent_code: "340",
  },
  {
    value: "20065",
    label: "Xã Hồng Bắc",
    parent_code: "481",
  },
  {
    value: "04570",
    label: "Xã Hồng Ca",
    parent_code: "138",
  },
  {
    value: "09070",
    label: "Xã Hồng Châu",
    parent_code: "251",
  },
  {
    value: "11968",
    label: "Phường Hồng Châu",
    parent_code: "323",
  },
  {
    value: "11215",
    label: "Xã Hồng Dụ",
    parent_code: "299",
  },
  {
    value: "12841",
    label: "Xã Hồng Dũng",
    parent_code: "341",
  },
  {
    value: "10180",
    label: "Xã Hồng Dương",
    parent_code: "278",
  },
  {
    value: "11167",
    label: "Xã Hồng Đức",
    parent_code: "299",
  },
  {
    value: "06691",
    label: "Phường Hồng Gai",
    parent_code: "193",
  },
  {
    value: "07561",
    label: "Xã Hồng Giang",
    parent_code: "219",
  },
  {
    value: "12790",
    label: "Xã Hồng Giang",
    parent_code: "340",
  },
  {
    value: "09796",
    label: "Xã Hồng Hà",
    parent_code: "273",
  },
  {
    value: "06697",
    label: "Phường Hồng Hà",
    parent_code: "193",
  },
  {
    value: "04267",
    label: "Phường Hồng Hà",
    parent_code: "132",
  },
  {
    value: "20050",
    label: "Xã Hồng Hạ",
    parent_code: "481",
  },
  {
    value: "06688",
    label: "Phường Hồng Hải",
    parent_code: "193",
  },
  {
    value: "18913",
    label: "Xã Hồng Hóa",
    parent_code: "452",
  },
  {
    value: "11050",
    label: "Xã Hồng Hưng",
    parent_code: "297",
  },
  {
    value: "10978",
    label: "Xã Hồng Khê",
    parent_code: "296",
  },
  {
    value: "20053",
    label: "Xã Hồng Kim",
    parent_code: "481",
  },
  {
    value: "00385",
    label: "Xã Hồng Kỳ",
    parent_code: "016",
  },
  {
    value: "07267",
    label: "Xã Hồng Kỳ",
    parent_code: "215",
  },
  {
    value: "10816",
    label: "Xã Hồng Lạc",
    parent_code: "294",
  },
  {
    value: "02608",
    label: "Xã Hồng Lạc",
    parent_code: "076",
  },
  {
    value: "23080",
    label: "Xã Hồng Liêm",
    parent_code: "597",
  },
  {
    value: "12667",
    label: "Xã Hồng Lĩnh",
    parent_code: "339",
  },
  {
    value: "17977",
    label: "Xã Hồng Long",
    parent_code: "430",
  },
  {
    value: "18412",
    label: "Xã Hồng Lộc",
    parent_code: "448",
  },
  {
    value: "13195",
    label: "Xã Hồng Lý",
    parent_code: "344",
  },
  {
    value: "10276",
    label: "Xã Hồng Minh",
    parent_code: "280",
  },
  {
    value: "12685",
    label: "Xã Hồng Minh",
    parent_code: "339",
  },
  {
    value: "01723",
    label: "Xã Hồng Nam",
    parent_code: "051",
  },
  {
    value: "11977",
    label: "Xã Hồng Nam",
    parent_code: "323",
  },
  {
    value: "03886",
    label: "Xã Hồng Ngài",
    parent_code: "121",
  },
  {
    value: "10093",
    label: "Xã Hồng Phong",
    parent_code: "277",
  },
  {
    value: "10654",
    label: "Xã Hồng Phong",
    parent_code: "291",
  },
  {
    value: "11224",
    label: "Xã Hồng Phong",
    parent_code: "299",
  },
  {
    value: "11293",
    label: "Xã Hồng Phong",
    parent_code: "300",
  },
  {
    value: "11593",
    label: "Xã Hồng Phong",
    parent_code: "312",
  },
  {
    value: "06079",
    label: "Xã Hồng Phong",
    parent_code: "181",
  },
  {
    value: "06205",
    label: "Xã Hồng Phong",
    parent_code: "183",
  },
  {
    value: "07120",
    label: "Phường Hồng Phong",
    parent_code: "205",
  },
  {
    value: "13282",
    label: "Xã Hồng Phong",
    parent_code: "344",
  },
  {
    value: "23056",
    label: "Xã Hồng Phong",
    parent_code: "596",
  },
  {
    value: "11230",
    label: "Xã Hồng Phúc",
    parent_code: "299",
  },
  {
    value: "09058",
    label: "Xã Hồng Phương",
    parent_code: "251",
  },
  {
    value: "10438",
    label: "Xã Hồng Quang",
    parent_code: "281",
  },
  {
    value: "01615",
    label: "Xã Hồng Quang",
    parent_code: "049",
  },
  {
    value: "11254",
    label: "Xã Hồng Quang",
    parent_code: "300",
  },
  {
    value: "12199",
    label: "Xã Hồng Quang",
    parent_code: "329",
  },
  {
    value: "13984",
    label: "Xã Hồng Quang",
    parent_code: "362",
  },
  {
    value: "02293",
    label: "Xã Hồng Quang",
    parent_code: "071",
  },
  {
    value: "10465",
    label: "Xã Hồng Sơn",
    parent_code: "282",
  },
  {
    value: "16696",
    label: "Phường Hồng Sơn",
    parent_code: "412",
  },
  {
    value: "17629",
    label: "Xã Hồng Sơn",
    parent_code: "427",
  },
  {
    value: "23086",
    label: "Xã Hồng Sơn",
    parent_code: "597",
  },
  {
    value: "01429",
    label: "Xã Hồng Sỹ",
    parent_code: "045",
  },
  {
    value: "10300",
    label: "Xã Hồng Thái",
    parent_code: "280",
  },
  {
    value: "11626",
    label: "Xã Hồng Thái",
    parent_code: "312",
  },
  {
    value: "06115",
    label: "Xã Hồng Thái",
    parent_code: "181",
  },
  {
    value: "06175",
    label: "Xã Hồng Thái",
    parent_code: "182",
  },
  {
    value: "07783",
    label: "Xã Hồng Thái",
    parent_code: "222",
  },
  {
    value: "13093",
    label: "Xã Hồng Thái",
    parent_code: "343",
  },
  {
    value: "02254",
    label: "Xã Hồng Thái",
    parent_code: "072",
  },
  {
    value: "23041",
    label: "Xã Hồng Thái",
    parent_code: "596",
  },
  {
    value: "20089",
    label: "Xã Hồng Thái",
    parent_code: "481",
  },
  {
    value: "07111",
    label: "Xã Hồng Thái Đông",
    parent_code: "205",
  },
  {
    value: "07108",
    label: "Xã Hồng Thái Tây",
    parent_code: "205",
  },
  {
    value: "17542",
    label: "Xã Hồng Thành",
    parent_code: "426",
  },
  {
    value: "03499",
    label: "Xã Hồng Thu",
    parent_code: "108",
  },
  {
    value: "14158",
    label: "Xã Hồng Thuận",
    parent_code: "365",
  },
  {
    value: "20104",
    label: "Xã Hồng Thủy",
    parent_code: "481",
  },
  {
    value: "19252",
    label: "Xã Hồng Thủy",
    parent_code: "457",
  },
  {
    value: "20086",
    label: "Xã Hồng Thượng",
    parent_code: "481",
  },
  {
    value: "12244",
    label: "Xã Hồng Tiến",
    parent_code: "330",
  },
  {
    value: "05869",
    label: "Xã Hồng Tiến",
    parent_code: "172",
  },
  {
    value: "13189",
    label: "Xã Hồng Tiến",
    parent_code: "343",
  },
  {
    value: "01342",
    label: "Xã Hồng Trị",
    parent_code: "043",
  },
  {
    value: "10207",
    label: "Xã Hồng Vân",
    parent_code: "279",
  },
  {
    value: "12196",
    label: "Xã Hồng Vân",
    parent_code: "329",
  },
  {
    value: "20047",
    label: "Xã Hồng Vân",
    parent_code: "481",
  },
  {
    value: "01687",
    label: "Xã Hồng Việt",
    parent_code: "051",
  },
  {
    value: "12739",
    label: "Xã Hồng Việt",
    parent_code: "340",
  },
  {
    value: "23534",
    label: "Xã Hơ Moong",
    parent_code: "616",
  },
  {
    value: "08911",
    label: "Thị trấn Hợp Châu",
    parent_code: "248",
  },
  {
    value: "10072",
    label: "Xã Hợp Đồng",
    parent_code: "277",
  },
  {
    value: "11737",
    label: "Phường Hợp Đức",
    parent_code: "308",
  },
  {
    value: "07330",
    label: "Xã Hợp Đức",
    parent_code: "216",
  },
  {
    value: "01273",
    label: "Phường Hợp Giang",
    parent_code: "040",
  },
  {
    value: "08869",
    label: "Thị trấn Hợp Hòa",
    parent_code: "247",
  },
  {
    value: "02578",
    label: "Xã Hợp Hòa",
    parent_code: "076",
  },
  {
    value: "13753",
    label: "Xã Hợp Hưng",
    parent_code: "359",
  },
  {
    value: "08770",
    label: "Xã Hợp Lý",
    parent_code: "246",
  },
  {
    value: "13567",
    label: "Xã Hợp Lý",
    parent_code: "353",
  },
  {
    value: "15676",
    label: "Xã Hợp Lý",
    parent_code: "397",
  },
  {
    value: "04546",
    label: "Phường Hợp Minh",
    parent_code: "132",
  },
  {
    value: "08014",
    label: "Xã Hợp Nhất",
    parent_code: "230",
  },
  {
    value: "05104",
    label: "Xã Hợp Phong",
    parent_code: "154",
  },
  {
    value: "10501",
    label: "Xã Hợp Thanh",
    parent_code: "282",
  },
  {
    value: "11515",
    label: "Xã Hợp Thành",
    parent_code: "311",
  },
  {
    value: "05638",
    label: "Xã Hợp Thành",
    parent_code: "168",
  },
  {
    value: "06226",
    label: "Xã Hợp Thành",
    parent_code: "183",
  },
  {
    value: "15682",
    label: "Xã Hợp Thành",
    parent_code: "397",
  },
  {
    value: "02566",
    label: "Xã Hợp Thành",
    parent_code: "076",
  },
  {
    value: "02680",
    label: "Xã Hợp Thành",
    parent_code: "080",
  },
  {
    value: "04903",
    label: "Xã Hợp Thành",
    parent_code: "148",
  },
  {
    value: "17563",
    label: "Xã Hợp Thành",
    parent_code: "426",
  },
  {
    value: "15688",
    label: "Xã Hợp Thắng",
    parent_code: "397",
  },
  {
    value: "08905",
    label: "Xã Hợp Thịnh",
    parent_code: "247",
  },
  {
    value: "07858",
    label: "Xã Hợp Thịnh",
    parent_code: "223",
  },
  {
    value: "10498",
    label: "Xã Hợp Tiến",
    parent_code: "282",
  },
  {
    value: "10615",
    label: "Xã Hợp Tiến",
    parent_code: "291",
  },
  {
    value: "05038",
    label: "Xã Hợp Tiến",
    parent_code: "153",
  },
  {
    value: "05698",
    label: "Xã Hợp Tiến",
    parent_code: "169",
  },
  {
    value: "12736",
    label: "Xã Hợp Tiến",
    parent_code: "340",
  },
  {
    value: "15679",
    label: "Xã Hợp Tiến",
    parent_code: "397",
  },
  {
    value: "23800",
    label: "Xã Hra",
    parent_code: "629",
  },
  {
    value: "03460",
    label: "Xã Hua Bun",
    parent_code: "112",
  },
  {
    value: "03676",
    label: "Xã Hua La",
    parent_code: "116",
  },
  {
    value: "03632",
    label: "Xã Hua Nà",
    parent_code: "110",
  },
  {
    value: "03890",
    label: "Xã Hua Nhàn",
    parent_code: "121",
  },
  {
    value: "04015",
    label: "Xã Hua Păng",
    parent_code: "123",
  },
  {
    value: "03323",
    label: "Xã Hua Thanh",
    parent_code: "100",
  },
  {
    value: "03817",
    label: "Xã Hua Trai",
    parent_code: "120",
  },
  {
    value: "19468",
    label: "Xã Húc",
    parent_code: "465",
  },
  {
    value: "06859",
    label: "Xã Húc Động",
    parent_code: "198",
  },
  {
    value: "19582",
    label: "Xã Húc Nghì",
    parent_code: "467",
  },
  {
    value: "01201",
    label: "Xã Hùng An",
    parent_code: "034",
  },
  {
    value: "12319",
    label: "Xã Hùng An",
    parent_code: "331",
  },
  {
    value: "12334",
    label: "Xã Hùng Cường",
    parent_code: "323",
  },
  {
    value: "12607",
    label: "Xã Hùng Dũng",
    parent_code: "339",
  },
  {
    value: "02425",
    label: "Xã Hùng Đức",
    parent_code: "074",
  },
  {
    value: "29359",
    label: "Xã Hùng Hòa",
    parent_code: "846",
  },
  {
    value: "08029",
    label: "Xã Hùng Long",
    parent_code: "230",
  },
  {
    value: "08287",
    label: "Xã Hùng Lô",
    parent_code: "227",
  },
  {
    value: "02455",
    label: "Xã Hùng Lợi",
    parent_code: "075",
  },
  {
    value: "02314",
    label: "Xã Hùng Mỹ",
    parent_code: "073",
  },
  {
    value: "08498",
    label: "Thị trấn Hùng Sơn",
    parent_code: "237",
  },
  {
    value: "05761",
    label: "Thị trấn Hùng Sơn",
    parent_code: "171",
  },
  {
    value: "06055",
    label: "Xã Hùng Sơn",
    parent_code: "180",
  },
  {
    value: "07849",
    label: "Xã Hùng Sơn",
    parent_code: "223",
  },
  {
    value: "04987",
    label: "Xã Hùng Sơn",
    parent_code: "153",
  },
  {
    value: "17347",
    label: "Xã Hùng Sơn",
    parent_code: "424",
  },
  {
    value: "17525",
    label: "Xã Hùng Thành",
    parent_code: "426",
  },
  {
    value: "10954",
    label: "Xã Hùng Thắng",
    parent_code: "296",
  },
  {
    value: "11809",
    label: "Xã Hùng Thắng",
    parent_code: "315",
  },
  {
    value: "06679",
    label: "Phường Hùng Thắng",
    parent_code: "193",
  },
  {
    value: "10492",
    label: "Xã Hùng Tiến",
    parent_code: "282",
  },
  {
    value: "11851",
    label: "Xã Hùng Tiến",
    parent_code: "316",
  },
  {
    value: "14641",
    label: "Xã Hùng Tiến",
    parent_code: "376",
  },
  {
    value: "17962",
    label: "Xã Hùng Tiến",
    parent_code: "430",
  },
  {
    value: "08416",
    label: "Xã Hùng Việt",
    parent_code: "235",
  },
  {
    value: "06061",
    label: "Xã Hùng Việt",
    parent_code: "180",
  },
  {
    value: "08737",
    label: "Phường Hùng Vương",
    parent_code: "244",
  },
  {
    value: "11299",
    label: "Phường Hùng Vương",
    parent_code: "303",
  },
  {
    value: "07942",
    label: "Phường Hùng Vương",
    parent_code: "228",
  },
  {
    value: "07975",
    label: "Xã Hùng Xuyên",
    parent_code: "230",
  },
  {
    value: "03196",
    label: "Xã Huổi Lèng",
    parent_code: "097",
  },
  {
    value: "03177",
    label: "Xã Huổi Lếnh",
    parent_code: "096",
  },
  {
    value: "03490",
    label: "Xã Huổi Luông",
    parent_code: "109",
  },
  {
    value: "03191",
    label: "Xã Huổi Mí",
    parent_code: "097",
  },
  {
    value: "04210",
    label: "Xã Huổi Một",
    parent_code: "126",
  },
  {
    value: "03220",
    label: "Xã Huổi Só",
    parent_code: "098",
  },
  {
    value: "16828",
    label: "Xã Huồi Tụ",
    parent_code: "417",
  },
  {
    value: "05713",
    label: "Xã Huống Thượng",
    parent_code: "164",
  },
  {
    value: "03913",
    label: "Xã Huy Bắc",
    parent_code: "122",
  },
  {
    value: "01354",
    label: "Xã Huy Giáp",
    parent_code: "043",
  },
  {
    value: "03928",
    label: "Xã Huy Hạ",
    parent_code: "122",
  },
  {
    value: "23164",
    label: "Xã Huy Khiêm",
    parent_code: "599",
  },
  {
    value: "03931",
    label: "Xã Huy Tân",
    parent_code: "122",
  },
  {
    value: "03916",
    label: "Xã Huy Thượng",
    parent_code: "122",
  },
  {
    value: "03940",
    label: "Xã Huy Tường",
    parent_code: "122",
  },
  {
    value: "29278",
    label: "Xã Huyền Hội",
    parent_code: "844",
  },
  {
    value: "07504",
    label: "Xã Huyền Sơn",
    parent_code: "218",
  },
  {
    value: "01846",
    label: "Phường Huyền Tụng",
    parent_code: "058",
  },
  {
    value: "31567",
    label: "Thị trấn Huỳnh Hữu Nghĩa",
    parent_code: "944",
  },
  {
    value: "03190",
    label: "Xã Hừa Ngài",
    parent_code: "097",
  },
  {
    value: "16672",
    label: "Phường Hưng Bình",
    parent_code: "412",
  },
  {
    value: "24761",
    label: "Xã Hưng Bình",
    parent_code: "666",
  },
  {
    value: "25320",
    label: "Phường Hưng Chiến",
    parent_code: "690",
  },
  {
    value: "18013",
    label: "Xã Hưng Chính",
    parent_code: "412",
  },
  {
    value: "13522",
    label: "Xã Hưng Công",
    parent_code: "352",
  },
  {
    value: "16675",
    label: "Phường Hưng Dũng",
    parent_code: "412",
  },
  {
    value: "01705",
    label: "Xã Hưng Đạo",
    parent_code: "040",
  },
  {
    value: "01351",
    label: "Xã Hưng Đạo",
    parent_code: "043",
  },
  {
    value: "01783",
    label: "Xã Hưng Đạo",
    parent_code: "052",
  },
  {
    value: "10561",
    label: "Xã Hưng Đạo",
    parent_code: "290",
  },
  {
    value: "11086",
    label: "Xã Hưng Đạo",
    parent_code: "298",
  },
  {
    value: "11686",
    label: "Phường Hưng Đạo",
    parent_code: "309",
  },
  {
    value: "12340",
    label: "Xã Hưng Đạo",
    parent_code: "332",
  },
  {
    value: "06067",
    label: "Xã Hưng Đạo",
    parent_code: "181",
  },
  {
    value: "07126",
    label: "Phường Hưng Đạo",
    parent_code: "205",
  },
  {
    value: "18016",
    label: "Xã Hưng Đạo",
    parent_code: "431",
  },
  {
    value: "27730",
    label: "Xã Hưng Điền",
    parent_code: "796",
  },
  {
    value: "27760",
    label: "Xã Hưng Điền A",
    parent_code: "797",
  },
  {
    value: "27727",
    label: "Xã Hưng Điền B",
    parent_code: "796",
  },
  {
    value: "25978",
    label: "Phường Hưng Định",
    parent_code: "725",
  },
  {
    value: "16705",
    label: "Xã Hưng Đông",
    parent_code: "412",
  },
  {
    value: "12586",
    label: "Thị trấn Hưng Hà",
    parent_code: "339",
  },
  {
    value: "27724",
    label: "Xã Hưng Hà",
    parent_code: "796",
  },
  {
    value: "08434",
    label: "Thị trấn Hưng Hoá",
    parent_code: "236",
  },
  {
    value: "16711",
    label: "Xã Hưng Hòa",
    parent_code: "412",
  },
  {
    value: "25831",
    label: "Xã Hưng Hòa",
    parent_code: "719",
  },
  {
    value: "31909",
    label: "Xã Hưng Hội",
    parent_code: "958",
  },
  {
    value: "04576",
    label: "Xã Hưng Khánh",
    parent_code: "138",
  },
  {
    value: "28901",
    label: "Xã Hưng Khánh Trung A",
    parent_code: "838",
  },
  {
    value: "28900",
    label: "Xã Hưng Khánh Trung B",
    parent_code: "832",
  },
  {
    value: "29047",
    label: "Xã Hưng Lễ",
    parent_code: "834",
  },
  {
    value: "18025",
    label: "Xã Hưng Lĩnh",
    parent_code: "431",
  },
  {
    value: "11233",
    label: "Xã Hưng Long",
    parent_code: "299",
  },
  {
    value: "12139",
    label: "Xã Hưng Long",
    parent_code: "328",
  },
  {
    value: "08314",
    label: "Xã Hưng Long",
    parent_code: "234",
  },
  {
    value: "22951",
    label: "Phường Hưng Long",
    parent_code: "593",
  },
  {
    value: "27628",
    label: "Xã Hưng Long",
    parent_code: "785",
  },
  {
    value: "16081",
    label: "Xã Hưng Lộc",
    parent_code: "400",
  },
  {
    value: "16708",
    label: "Xã Hưng Lộc",
    parent_code: "412",
  },
  {
    value: "26317",
    label: "Xã Hưng Lộc",
    parent_code: "738",
  },
  {
    value: "18034",
    label: "Xã Hưng Lợi",
    parent_code: "431",
  },
  {
    value: "31147",
    label: "Phường Hưng Lợi",
    parent_code: "916",
  },
  {
    value: "31757",
    label: "Thị trấn Hưng Lợi",
    parent_code: "949",
  },
  {
    value: "18019",
    label: "Xã Hưng Mỹ",
    parent_code: "431",
  },
  {
    value: "29407",
    label: "Xã Hưng Mỹ",
    parent_code: "847",
  },
  {
    value: "32140",
    label: "Xã Hưng Mỹ",
    parent_code: "969",
  },
  {
    value: "18037",
    label: "Xã Hưng Nghĩa",
    parent_code: "431",
  },
  {
    value: "18001",
    label: "Thị trấn Hưng Nguyên",
    parent_code: "431",
  },
  {
    value: "11869",
    label: "Xã Hưng Nhân",
    parent_code: "316",
  },
  {
    value: "12613",
    label: "Thị trấn Hưng Nhân",
    parent_code: "339",
  },
  {
    value: "29044",
    label: "Xã Hưng Nhượng",
    parent_code: "834",
  },
  {
    value: "29023",
    label: "Xã Hưng Phong",
    parent_code: "834",
  },
  {
    value: "31189",
    label: "Phường Hưng Phú",
    parent_code: "919",
  },
  {
    value: "31588",
    label: "Xã Hưng Phú",
    parent_code: "944",
  },
  {
    value: "31879",
    label: "Xã Hưng Phú",
    parent_code: "957",
  },
  {
    value: "16673",
    label: "Phường Hưng Phúc",
    parent_code: "412",
  },
  {
    value: "18040",
    label: "Xã Hưng Phúc",
    parent_code: "431",
  },
  {
    value: "25309",
    label: "Xã Hưng Phước",
    parent_code: "693",
  },
  {
    value: "18031",
    label: "Xã Hưng Tân",
    parent_code: "431",
  },
  {
    value: "18010",
    label: "Xã Hưng Tây",
    parent_code: "431",
  },
  {
    value: "02218",
    label: "Phường Hưng Thành",
    parent_code: "070",
  },
  {
    value: "18064",
    label: "Xã Hưng Thành",
    parent_code: "431",
  },
  {
    value: "31906",
    label: "Xã Hưng Thành",
    parent_code: "958",
  },
  {
    value: "27736",
    label: "Xã Hưng Thạnh",
    parent_code: "796",
  },
  {
    value: "28342",
    label: "Xã Hưng Thạnh",
    parent_code: "818",
  },
  {
    value: "30043",
    label: "Xã Hưng Thạnh",
    parent_code: "872",
  },
  {
    value: "31192",
    label: "Phường Hưng Thạnh",
    parent_code: "919",
  },
  {
    value: "05404",
    label: "Xã Hưng Thi",
    parent_code: "159",
  },
  {
    value: "01352",
    label: "Xã Hưng Thịnh",
    parent_code: "043",
  },
  {
    value: "04573",
    label: "Xã Hưng Thịnh",
    parent_code: "138",
  },
  {
    value: "18022",
    label: "Xã Hưng Thịnh",
    parent_code: "431",
  },
  {
    value: "26287",
    label: "Xã Hưng Thịnh",
    parent_code: "737",
  },
  {
    value: "18028",
    label: "Xã Hưng Thông",
    parent_code: "431",
  },
  {
    value: "25714",
    label: "Xã Hưng Thuận",
    parent_code: "712",
  },
  {
    value: "19288",
    label: "Xã Hưng Thủy",
    parent_code: "457",
  },
  {
    value: "19156",
    label: "Xã Hưng Trạch",
    parent_code: "455",
  },
  {
    value: "18754",
    label: "Phường Hưng Trí",
    parent_code: "449",
  },
  {
    value: "18004",
    label: "Xã Hưng Trung",
    parent_code: "431",
  },
  {
    value: "06349",
    label: "Xã Hưng Vũ",
    parent_code: "185",
  },
  {
    value: "18007",
    label: "Xã Hưng Yên",
    parent_code: "431",
  },
  {
    value: "30997",
    label: "Xã Hưng Yên",
    parent_code: "908",
  },
  {
    value: "18008",
    label: "Xã Hưng Yên Bắc",
    parent_code: "431",
  },
  {
    value: "20023",
    label: "Phường Hương An",
    parent_code: "474",
  },
  {
    value: "20651",
    label: "Thị trấn Hương An",
    parent_code: "509",
  },
  {
    value: "18523",
    label: "Xã Hương Bình",
    parent_code: "444",
  },
  {
    value: "20026",
    label: "Xã Hương Bình",
    parent_code: "480",
  },
  {
    value: "08935",
    label: "Thị trấn Hương Canh",
    parent_code: "249",
  },
  {
    value: "08632",
    label: "Xã Hương Cần",
    parent_code: "238",
  },
  {
    value: "20020",
    label: "Phường Hương Chữ",
    parent_code: "480",
  },
  {
    value: "08881",
    label: "Xã Hướng Đạo",
    parent_code: "247",
  },
  {
    value: "18538",
    label: "Xã Hương Đô",
    parent_code: "444",
  },
  {
    value: "07690",
    label: "Xã Hương Gián",
    parent_code: "221",
  },
  {
    value: "18517",
    label: "Xã Hương Giang",
    parent_code: "444",
  },
  {
    value: "19561",
    label: "Xã Hướng Hiệp",
    parent_code: "467",
  },
  {
    value: "18952",
    label: "Xã Hương Hóa",
    parent_code: "453",
  },
  {
    value: "20029",
    label: "Phường Hương Hồ",
    parent_code: "474",
  },
  {
    value: "20182",
    label: "Xã Hương Hữu",
    parent_code: "483",
  },
  {
    value: "18496",
    label: "Thị trấn Hương Khê",
    parent_code: "444",
  },
  {
    value: "07405",
    label: "Xã Hương Lạc",
    parent_code: "217",
  },
  {
    value: "07876",
    label: "Xã Hương Lâm",
    parent_code: "223",
  },
  {
    value: "18556",
    label: "Xã Hương Lâm",
    parent_code: "444",
  },
  {
    value: "19435",
    label: "Xã Hướng Lập",
    parent_code: "465",
  },
  {
    value: "18559",
    label: "Xã Hương Liên",
    parent_code: "444",
  },
  {
    value: "19447",
    label: "Xã Hướng Linh",
    parent_code: "465",
  },
  {
    value: "18526",
    label: "Xã Hương Long",
    parent_code: "444",
  },
  {
    value: "19810",
    label: "Phường Hương Long",
    parent_code: "474",
  },
  {
    value: "20170",
    label: "Xã Hương Lộc",
    parent_code: "483",
  },
  {
    value: "19474",
    label: "Xã Hướng Lộc",
    parent_code: "465",
  },
  {
    value: "08401",
    label: "Xã Hương Lung",
    parent_code: "235",
  },
  {
    value: "09373",
    label: "Phường Hương Mạc",
    parent_code: "261",
  },
  {
    value: "07771",
    label: "Xã Hương Mai",
    parent_code: "222",
  },
  {
    value: "18340",
    label: "Xã Hương Minh",
    parent_code: "441",
  },
  {
    value: "28981",
    label: "Xã Hương Mỹ",
    parent_code: "833",
  },
  {
    value: "09970",
    label: "Xã Hương Ngải",
    parent_code: "276",
  },
  {
    value: "20059",
    label: "Xã Hương Nguyên",
    parent_code: "481",
  },
  {
    value: "05332",
    label: "Xã Hương Nhượng",
    parent_code: "157",
  },
  {
    value: "08473",
    label: "Xã Hương Nộn",
    parent_code: "236",
  },
  {
    value: "20002",
    label: "Xã Hương Phong",
    parent_code: "474",
  },
  {
    value: "20080",
    label: "Xã Hương Phong",
    parent_code: "481",
  },
  {
    value: "20164",
    label: "Xã Hương Phú",
    parent_code: "483",
  },
  {
    value: "19441",
    label: "Xã Hướng Phùng",
    parent_code: "465",
  },
  {
    value: "19804",
    label: "Phường Hương Sơ",
    parent_code: "474",
  },
  {
    value: "10489",
    label: "Xã Hương Sơn",
    parent_code: "282",
  },
  {
    value: "01252",
    label: "Xã Hương Sơn",
    parent_code: "035",
  },
  {
    value: "08950",
    label: "Xã Hương Sơn",
    parent_code: "249",
  },
  {
    value: "05473",
    label: "Phường Hương Sơn",
    parent_code: "164",
  },
  {
    value: "05908",
    label: "Thị trấn Hương Sơn",
    parent_code: "173",
  },
  {
    value: "07387",
    label: "Xã Hương Sơn",
    parent_code: "217",
  },
  {
    value: "17317",
    label: "Xã Hương Sơn",
    parent_code: "423",
  },
  {
    value: "20167",
    label: "Xã Hương Sơn",
    parent_code: "483",
  },
  {
    value: "19444",
    label: "Xã Hướng Sơn",
    parent_code: "465",
  },
  {
    value: "19453",
    label: "Xã Hướng Tân",
    parent_code: "465",
  },
  {
    value: "20032",
    label: "Xã Hương Thọ",
    parent_code: "474",
  },
  {
    value: "27703",
    label: "Xã Hướng Thọ Phú",
    parent_code: "794",
  },
  {
    value: "18505",
    label: "Xã Hương Thủy",
    parent_code: "444",
  },
  {
    value: "20005",
    label: "Xã Hương Toàn",
    parent_code: "480",
  },
  {
    value: "18550",
    label: "Xã Hương Trà",
    parent_code: "444",
  },
  {
    value: "21157",
    label: "Xã Hương Trà",
    parent_code: "525",
  },
  {
    value: "18553",
    label: "Xã Hương Trạch",
    parent_code: "444",
  },
  {
    value: "20011",
    label: "Phường Hương Văn",
    parent_code: "480",
  },
  {
    value: "20008",
    label: "Phường Hương Vân",
    parent_code: "480",
  },
  {
    value: "07279",
    label: "Xã Hương Vĩ",
    parent_code: "215",
  },
  {
    value: "19438",
    label: "Xã Hướng Việt",
    parent_code: "465",
  },
  {
    value: "20014",
    label: "Phường Hương Vinh",
    parent_code: "474",
  },
  {
    value: "18541",
    label: "Xã Hương Vĩnh",
    parent_code: "444",
  },
  {
    value: "08104",
    label: "Xã Hương Xạ",
    parent_code: "231",
  },
  {
    value: "18544",
    label: "Xã Hương Xuân",
    parent_code: "444",
  },
  {
    value: "20017",
    label: "Phường Hương Xuân",
    parent_code: "480",
  },
  {
    value: "20179",
    label: "Xã Hương Xuân",
    parent_code: "483",
  },
  {
    value: "09994",
    label: "Xã Hữu Bằng",
    parent_code: "276",
  },
  {
    value: "11701",
    label: "Xã Hữu Bằng",
    parent_code: "314",
  },
  {
    value: "28555",
    label: "Xã Hữu Đạo",
    parent_code: "821",
  },
  {
    value: "28858",
    label: "Xã Hữu Định",
    parent_code: "831",
  },
  {
    value: "00652",
    label: "Xã Hữu Hoà",
    parent_code: "020",
  },
  {
    value: "06550",
    label: "Xã Hữu Khánh",
    parent_code: "188",
  },
  {
    value: "16885",
    label: "Xã Hữu Khuông",
    parent_code: "418",
  },
  {
    value: "16861",
    label: "Xã Hữu Kiệm",
    parent_code: "417",
  },
  {
    value: "06514",
    label: "Xã Hữu Kiên",
    parent_code: "187",
  },
  {
    value: "06598",
    label: "Xã Hữu Lân",
    parent_code: "188",
  },
  {
    value: "16849",
    label: "Xã Hữu Lập",
    parent_code: "417",
  },
  {
    value: "06322",
    label: "Xã Hữu Lễ",
    parent_code: "184",
  },
  {
    value: "06388",
    label: "Xã Hữu Liên",
    parent_code: "186",
  },
  {
    value: "05371",
    label: "Xã Hữu Lợi",
    parent_code: "158",
  },
  {
    value: "06385",
    label: "Thị trấn Hữu Lũng",
    parent_code: "186",
  },
  {
    value: "04798",
    label: "Phường Hữu Nghị",
    parent_code: "148",
  },
  {
    value: "01177",
    label: "Xã Hữu Sản",
    parent_code: "034",
  },
  {
    value: "07624",
    label: "Xã Hữu Sản",
    parent_code: "220",
  },
  {
    value: "29842",
    label: "Xã Hựu Thành",
    parent_code: "862",
  },
  {
    value: "27988",
    label: "Xã Hựu Thạnh",
    parent_code: "802",
  },
  {
    value: "10081",
    label: "Xã Hữu Văn",
    parent_code: "277",
  },
  {
    value: "00841",
    label: "Xã Hữu Vinh",
    parent_code: "028",
  },
  {
    value: "08503",
    label: "Xã Hy Cương",
    parent_code: "227",
  },
  {
    value: "31318",
    label: "Phường I",
    parent_code: "930",
  },
  {
    value: "24049",
    label: "Xã Ia Ake",
    parent_code: "638",
  },
  {
    value: "23924",
    label: "Xã Ia Bang",
    parent_code: "632",
  },
  {
    value: "23771",
    label: "Xã Ia Bă",
    parent_code: "628",
  },
  {
    value: "23719",
    label: "Xã Ia Băng",
    parent_code: "626",
  },
  {
    value: "23905",
    label: "Xã Ia Băng",
    parent_code: "632",
  },
  {
    value: "23962",
    label: "Xã Ia Blang",
    parent_code: "633",
  },
  {
    value: "23987",
    label: "Xã Ia BLứ",
    parent_code: "639",
  },
  {
    value: "23911",
    label: "Xã Ia Boòng",
    parent_code: "632",
  },
  {
    value: "24034",
    label: "Xã Ia Broăi",
    parent_code: "635",
  },
  {
    value: "23788",
    label: "Xã Ia Chia",
    parent_code: "628",
  },
  {
    value: "23326",
    label: "Xã Ia Chim",
    parent_code: "608",
  },
  {
    value: "23785",
    label: "Xã Ia Dêr",
    parent_code: "628",
  },
  {
    value: "23866",
    label: "Xã Ia Din",
    parent_code: "631",
  },
  {
    value: "23537",
    label: "Xã Ia Dom",
    parent_code: "618",
  },
  {
    value: "23872",
    label: "Xã Ia Dom",
    parent_code: "631",
  },
  {
    value: "23860",
    label: "Xã Ia Dơk",
    parent_code: "631",
  },
  {
    value: "23893",
    label: "Xã Ia Drăng",
    parent_code: "632",
  },
  {
    value: "23974",
    label: "Xã Ia Dreng",
    parent_code: "639",
  },
  {
    value: "23535",
    label: "Xã Ia Đal",
    parent_code: "618",
  },
  {
    value: "23929",
    label: "Xã Ia Ga",
    parent_code: "632",
  },
  {
    value: "23950",
    label: "Xã Ia Glai",
    parent_code: "633",
  },
  {
    value: "23778",
    label: "Xã Ia Grăng",
    parent_code: "628",
  },
  {
    value: "24100",
    label: "Xã Ia HDreh",
    parent_code: "637",
  },
  {
    value: "24061",
    label: "Xã Ia Hiao",
    parent_code: "638",
  },
  {
    value: "23978",
    label: "Xã Ia Hla",
    parent_code: "639",
  },
  {
    value: "23959",
    label: "Xã Ia HLốp",
    parent_code: "633",
  },
  {
    value: "23971",
    label: "Xã Ia Hrú",
    parent_code: "639",
  },
  {
    value: "23770",
    label: "Xã Ia Hrung",
    parent_code: "628",
  },
  {
    value: "24215",
    label: "Xã Ia JLơi",
    parent_code: "646",
  },
  {
    value: "23749",
    label: "Xã Ia Ka",
    parent_code: "627",
  },
  {
    value: "24019",
    label: "Xã Ia KDăm",
    parent_code: "635",
  },
  {
    value: "23608",
    label: "Xã Ia Kênh",
    parent_code: "622",
  },
  {
    value: "23764",
    label: "Thị trấn Ia Kha",
    parent_code: "628",
  },
  {
    value: "23773",
    label: "Xã Ia Khai",
    parent_code: "628",
  },
  {
    value: "23728",
    label: "Xã Ia Khươl",
    parent_code: "627",
  },
  {
    value: "23869",
    label: "Xã Ia Kla",
    parent_code: "631",
  },
  {
    value: "23888",
    label: "Xã Ia Kly",
    parent_code: "632",
  },
  {
    value: "23977",
    label: "Xã Ia Ko",
    parent_code: "633",
  },
  {
    value: "23776",
    label: "Xã Ia KRai",
    parent_code: "628",
  },
  {
    value: "23738",
    label: "Xã Ia Kreng",
    parent_code: "627",
  },
  {
    value: "23863",
    label: "Xã Ia Krêl",
    parent_code: "631",
  },
  {
    value: "23878",
    label: "Xã Ia Kriêng",
    parent_code: "631",
  },
  {
    value: "23563",
    label: "Phường Ia Kring",
    parent_code: "622",
  },
  {
    value: "23875",
    label: "Xã Ia Lang",
    parent_code: "631",
  },
  {
    value: "23932",
    label: "Xã Ia Lâu",
    parent_code: "632",
  },
  {
    value: "23986",
    label: "Xã Ia Le",
    parent_code: "639",
  },
  {
    value: "24214",
    label: "Xã Ia Lốp",
    parent_code: "646",
  },
  {
    value: "23734",
    label: "Thị trấn Ia Ly",
    parent_code: "627",
  },
  {
    value: "24031",
    label: "Xã Ia Ma Rơn",
    parent_code: "635",
  },
  {
    value: "23920",
    label: "Xã Ia Me",
    parent_code: "632",
  },
  {
    value: "24091",
    label: "Xã Ia Mláh",
    parent_code: "637",
  },
  {
    value: "23938",
    label: "Xã Ia Mơ",
    parent_code: "632",
  },
  {
    value: "23737",
    label: "Xã Ia Mơ Nông",
    parent_code: "627",
  },
  {
    value: "23884",
    label: "Xã Ia Nan",
    parent_code: "631",
  },
  {
    value: "23752",
    label: "Xã Ia Nhin",
    parent_code: "627",
  },
  {
    value: "23782",
    label: "Xã Ia O",
    parent_code: "628",
  },
  {
    value: "23914",
    label: "Xã Ia O",
    parent_code: "632",
  },
  {
    value: "23966",
    label: "Xã Ia Pal",
    parent_code: "633",
  },
  {
    value: "24058",
    label: "Xã Ia Peng",
    parent_code: "638",
  },
  {
    value: "23791",
    label: "Xã Ia Pếch",
    parent_code: "628",
  },
  {
    value: "23716",
    label: "Xã Ia Pết",
    parent_code: "626",
  },
  {
    value: "23983",
    label: "Xã Ia Phang",
    parent_code: "639",
  },
  {
    value: "23731",
    label: "Xã Ia Phí",
    parent_code: "627",
  },
  {
    value: "23902",
    label: "Xã Ia Phìn",
    parent_code: "632",
  },
  {
    value: "23926",
    label: "Xã Ia Pia",
    parent_code: "632",
  },
  {
    value: "24055",
    label: "Xã Ia Piar",
    parent_code: "638",
  },
  {
    value: "23935",
    label: "Xã Ia Piơr",
    parent_code: "632",
  },
  {
    value: "23881",
    label: "Xã Ia Pnôn",
    parent_code: "631",
  },
  {
    value: "23917",
    label: "Xã Ia Púch",
    parent_code: "632",
  },
  {
    value: "24064",
    label: "Xã Ia RBol",
    parent_code: "624",
  },
  {
    value: "24103",
    label: "Xã Ia RMok",
    parent_code: "637",
  },
  {
    value: "23972",
    label: "Xã Ia Rong",
    parent_code: "639",
  },
  {
    value: "24079",
    label: "Xã Ia RSai",
    parent_code: "637",
  },
  {
    value: "24082",
    label: "Xã Ia RSươm",
    parent_code: "637",
  },
  {
    value: "24070",
    label: "Xã Ia RTô",
    parent_code: "624",
  },
  {
    value: "24221",
    label: "Xã Ia RVê",
    parent_code: "646",
  },
  {
    value: "24073",
    label: "Xã Ia Sao",
    parent_code: "624",
  },
  {
    value: "23767",
    label: "Xã Ia Sao",
    parent_code: "628",
  },
  {
    value: "24052",
    label: "Xã Ia Sol",
    parent_code: "638",
  },
  {
    value: "23944",
    label: "Xã Ia Tiêm",
    parent_code: "633",
  },
  {
    value: "23779",
    label: "Xã Ia Tô",
    parent_code: "628",
  },
  {
    value: "23908",
    label: "Xã Ia Tôr",
    parent_code: "632",
  },
  {
    value: "23538",
    label: "Xã Ia Tơi",
    parent_code: "618",
  },
  {
    value: "24037",
    label: "Xã Ia Trok",
    parent_code: "635",
  },
  {
    value: "24028",
    label: "Xã Ia Tul",
    parent_code: "635",
  },
  {
    value: "23923",
    label: "Xã Ia Vê",
    parent_code: "632",
  },
  {
    value: "24067",
    label: "Xã Ia Yeng",
    parent_code: "638",
  },
  {
    value: "23768",
    label: "Xã Ia Yok",
    parent_code: "628",
  },
  {
    value: "18457",
    label: "Xã Ích Hậu",
    parent_code: "448",
  },
  {
    value: "31321",
    label: "Phường III",
    parent_code: "930",
  },
  {
    value: "03808",
    label: "Thị trấn Ít Ong",
    parent_code: "120",
  },
  {
    value: "31324",
    label: "Phường IV",
    parent_code: "930",
  },
  {
    value: "20476",
    label: "Xã Jơ Ngây",
    parent_code: "505",
  },
  {
    value: "23698",
    label: "Xã K' Dang",
    parent_code: "626",
  },
  {
    value: "20497",
    label: "Xã Ka Dăng",
    parent_code: "505",
  },
  {
    value: "24943",
    label: "Xã Ka Đô",
    parent_code: "677",
  },
  {
    value: "24949",
    label: "Xã Ka Đơn",
    parent_code: "677",
  },
  {
    value: "03439",
    label: "Xã Ka Lăng",
    parent_code: "107",
  },
  {
    value: "06709",
    label: "Phường Ka Long",
    parent_code: "194",
  },
  {
    value: "03469",
    label: "Xã Kan Hồ",
    parent_code: "107",
  },
  {
    value: "23638",
    label: "Thị trấn KBang",
    parent_code: "625",
  },
  {
    value: "10945",
    label: "Thị trấn Kẻ Sặt",
    parent_code: "296",
  },
  {
    value: "16822",
    label: "Xã Keng Đu",
    parent_code: "417",
  },
  {
    value: "03376",
    label: "Xã Keo Lôm",
    parent_code: "101",
  },
  {
    value: "07399",
    label: "Thị trấn Kép",
    parent_code: "217",
  },
  {
    value: "31558",
    label: "Xã Kế An",
    parent_code: "943",
  },
  {
    value: "31528",
    label: "Thị trấn Kế Sách",
    parent_code: "943",
  },
  {
    value: "31555",
    label: "Xã Kế Thành",
    parent_code: "943",
  },
  {
    value: "11405",
    label: "Phường Kênh Dương",
    parent_code: "305",
  },
  {
    value: "11512",
    label: "Xã Kênh Giang",
    parent_code: "311",
  },
  {
    value: "08635",
    label: "Xã Khả Cửu",
    parent_code: "238",
  },
  {
    value: "13420",
    label: "Xã Khả Phong",
    parent_code: "350",
  },
  {
    value: "05959",
    label: "Xã Kha Sơn",
    parent_code: "173",
  },
  {
    value: "08728",
    label: "Phường Khai Quang",
    parent_code: "243",
  },
  {
    value: "17380",
    label: "Xã Khai Sơn",
    parent_code: "424",
  },
  {
    value: "10324",
    label: "Xã Khai Thái",
    parent_code: "280",
  },
  {
    value: "04321",
    label: "Xã Khai Trung",
    parent_code: "135",
  },
  {
    value: "08197",
    label: "Xã Khải Xuân",
    parent_code: "232",
  },
  {
    value: "07501",
    label: "Xã Khám Lạng",
    parent_code: "218",
  },
  {
    value: "06049",
    label: "Xã Kháng Chiến",
    parent_code: "180",
  },
  {
    value: "02575",
    label: "Xã Kháng Nhật",
    parent_code: "076",
  },
  {
    value: "01906",
    label: "Xã Khang Ninh",
    parent_code: "061",
  },
  {
    value: "14575",
    label: "Xã Khánh An",
    parent_code: "375",
  },
  {
    value: "30340",
    label: "Xã Khánh An",
    parent_code: "886",
  },
  {
    value: "32059",
    label: "Xã Khánh An",
    parent_code: "966",
  },
  {
    value: "25921",
    label: "Phường Khánh Bình",
    parent_code: "723",
  },
  {
    value: "22615",
    label: "Xã Khánh Bình",
    parent_code: "573",
  },
  {
    value: "30343",
    label: "Xã Khánh Bình",
    parent_code: "886",
  },
  {
    value: "32110",
    label: "Xã Khánh Bình",
    parent_code: "968",
  },
  {
    value: "32116",
    label: "Xã Khánh Bình Đông",
    parent_code: "968",
  },
  {
    value: "32104",
    label: "Xã Khánh Bình Tây",
    parent_code: "968",
  },
  {
    value: "32101",
    label: "Xã Khánh Bình Tây Bắc",
    parent_code: "968",
  },
  {
    value: "14602",
    label: "Xã Khánh Công",
    parent_code: "375",
  },
  {
    value: "14581",
    label: "Xã Khánh Cư",
    parent_code: "375",
  },
  {
    value: "14578",
    label: "Xã Khánh Cường",
    parent_code: "375",
  },
  {
    value: "14707",
    label: "Xã Khánh Dương",
    parent_code: "377",
  },
  {
    value: "22621",
    label: "Xã Khánh Đông",
    parent_code: "573",
  },
  {
    value: "10195",
    label: "Xã Khánh Hà",
    parent_code: "279",
  },
  {
    value: "14587",
    label: "Xã Khánh Hải",
    parent_code: "375",
  },
  {
    value: "22834",
    label: "Thị trấn Khánh Hải",
    parent_code: "586",
  },
  {
    value: "32119",
    label: "Xã Khánh Hải",
    parent_code: "968",
  },
  {
    value: "27715",
    label: "Phường Khánh Hậu",
    parent_code: "794",
  },
  {
    value: "22612",
    label: "Xã Khánh Hiệp",
    parent_code: "573",
  },
  {
    value: "04342",
    label: "Xã Khánh Hoà",
    parent_code: "135",
  },
  {
    value: "14569",
    label: "Xã Khánh Hòa",
    parent_code: "375",
  },
  {
    value: "30466",
    label: "Xã Khánh Hòa",
    parent_code: "889",
  },
  {
    value: "31789",
    label: "Phường Khánh Hòa",
    parent_code: "950",
  },
  {
    value: "32047",
    label: "Xã Khánh Hòa",
    parent_code: "966",
  },
  {
    value: "14599",
    label: "Xã Khánh Hội",
    parent_code: "375",
  },
  {
    value: "32062",
    label: "Xã Khánh Hội",
    parent_code: "966",
  },
  {
    value: "14617",
    label: "Xã Khánh Hồng",
    parent_code: "375",
  },
  {
    value: "17878",
    label: "Xã Khánh Hợp",
    parent_code: "429",
  },
  {
    value: "27763",
    label: "Xã Khánh Hưng",
    parent_code: "797",
  },
  {
    value: "32113",
    label: "Xã Khánh Hưng",
    parent_code: "968",
  },
  {
    value: "06286",
    label: "Xã Khánh Khê",
    parent_code: "184",
  },
  {
    value: "32056",
    label: "Xã Khánh Lâm",
    parent_code: "966",
  },
  {
    value: "05998",
    label: "Xã Khánh Long",
    parent_code: "180",
  },
  {
    value: "32108",
    label: "Xã Khánh Lộc",
    parent_code: "968",
  },
  {
    value: "14572",
    label: "Xã Khánh Lợi",
    parent_code: "375",
  },
  {
    value: "14593",
    label: "Xã Khánh Mậu",
    parent_code: "375",
  },
  {
    value: "22627",
    label: "Xã Khánh Nam",
    parent_code: "573",
  },
  {
    value: "14611",
    label: "Xã Khánh Nhạc",
    parent_code: "375",
  },
  {
    value: "14566",
    label: "Xã Khánh Phú",
    parent_code: "375",
  },
  {
    value: "22645",
    label: "Xã Khánh Phú",
    parent_code: "573",
  },
  {
    value: "17986",
    label: "Xã Khánh Sơn",
    parent_code: "430",
  },
  {
    value: "14608",
    label: "Xã Khánh Thành",
    parent_code: "375",
  },
  {
    value: "17593",
    label: "Xã Khánh Thành",
    parent_code: "426",
  },
  {
    value: "22642",
    label: "Xã Khánh Thành",
    parent_code: "573",
  },
  {
    value: "28948",
    label: "Xã Khánh Thạnh Tân",
    parent_code: "838",
  },
  {
    value: "14584",
    label: "Xã Khánh Thiện",
    parent_code: "375",
  },
  {
    value: "04312",
    label: "Xã Khánh Thiện",
    parent_code: "135",
  },
  {
    value: "14713",
    label: "Xã Khánh Thịnh",
    parent_code: "377",
  },
  {
    value: "32048",
    label: "Xã Khánh Thuận",
    parent_code: "966",
  },
  {
    value: "14614",
    label: "Xã Khánh Thủy",
    parent_code: "375",
  },
  {
    value: "09712",
    label: "Xã Khánh Thượng",
    parent_code: "271",
  },
  {
    value: "14704",
    label: "Xã Khánh Thượng",
    parent_code: "377",
  },
  {
    value: "22624",
    label: "Xã Khánh Thượng",
    parent_code: "573",
  },
  {
    value: "14563",
    label: "Xã Khánh Tiên",
    parent_code: "375",
  },
  {
    value: "32050",
    label: "Xã Khánh Tiến",
    parent_code: "966",
  },
  {
    value: "14590",
    label: "Xã Khánh Trung",
    parent_code: "375",
  },
  {
    value: "22618",
    label: "Xã Khánh Trung",
    parent_code: "573",
  },
  {
    value: "14596",
    label: "Xã Khánh Vân",
    parent_code: "375",
  },
  {
    value: "22609",
    label: "Thị trấn Khánh Vĩnh",
    parent_code: "573",
  },
  {
    value: "18466",
    label: "Xã Khánh Vĩnh Yên",
    parent_code: "443",
  },
  {
    value: "01336",
    label: "Xã Khánh Xuân",
    parent_code: "043",
  },
  {
    value: "06544",
    label: "Xã Khánh Xuân",
    parent_code: "188",
  },
  {
    value: "24154",
    label: "Phường Khánh Xuân",
    parent_code: "643",
  },
  {
    value: "03055",
    label: "Thị trấn Khánh Yên",
    parent_code: "089",
  },
  {
    value: "03103",
    label: "Xã Khánh Yên Hạ",
    parent_code: "089",
  },
  {
    value: "03082",
    label: "Xã Khánh Yên Thượng",
    parent_code: "089",
  },
  {
    value: "03100",
    label: "Xã Khánh Yên Trung",
    parent_code: "089",
  },
  {
    value: "04465",
    label: "Xã Khao Mang",
    parent_code: "137",
  },
  {
    value: "02263",
    label: "Xã Khau Tinh",
    parent_code: "072",
  },
  {
    value: "09325",
    label: "Phường Khắc Niệm",
    parent_code: "256",
  },
  {
    value: "20722",
    label: "Thị trấn Khâm Đức",
    parent_code: "511",
  },
  {
    value: "01498",
    label: "Xã Khâm Thành",
    parent_code: "047",
  },
  {
    value: "00202",
    label: "Phường Khâm Thiên",
    parent_code: "006",
  },
  {
    value: "00814",
    label: "Xã Khâu Vai",
    parent_code: "027",
  },
  {
    value: "05686",
    label: "Xã Khe Mo",
    parent_code: "169",
  },
  {
    value: "19429",
    label: "Thị trấn Khe Sanh",
    parent_code: "465",
  },
  {
    value: "20161",
    label: "Thị trấn Khe Tre",
    parent_code: "483",
  },
  {
    value: "12205",
    label: "Thị trấn Khoái Châu",
    parent_code: "330",
  },
  {
    value: "05413",
    label: "Xã Khoan Dụ",
    parent_code: "159",
  },
  {
    value: "03643",
    label: "Xã Khoen On",
    parent_code: "110",
  },
  {
    value: "05821",
    label: "Xã Khôi Kỳ",
    parent_code: "171",
  },
  {
    value: "03583",
    label: "Xã Khổng Lào",
    parent_code: "109",
  },
  {
    value: "11773",
    label: "Xã Khởi Nghĩa",
    parent_code: "315",
  },
  {
    value: "06565",
    label: "Xã Khuất Xá",
    parent_code: "188",
  },
  {
    value: "09235",
    label: "Phường Khúc Xuyên",
    parent_code: "256",
  },
  {
    value: "20285",
    label: "Phường Khuê Mỹ",
    parent_code: "494",
  },
  {
    value: "24475",
    label: "Xã Khuê Ngọc Điền",
    parent_code: "653",
  },
  {
    value: "20260",
    label: "Phường Khuê Trung",
    parent_code: "495",
  },
  {
    value: "03430",
    label: "Xã Khun Há",
    parent_code: "106",
  },
  {
    value: "02251",
    label: "Xã Khuôn Hà",
    parent_code: "071",
  },
  {
    value: "01150",
    label: "Xã Khuôn Lùng",
    parent_code: "033",
  },
  {
    value: "15733",
    label: "Xã Khuyến Nông",
    parent_code: "397",
  },
  {
    value: "00364",
    label: "Phường Khương Đình",
    parent_code: "009",
  },
  {
    value: "00352",
    label: "Phường Khương Mai",
    parent_code: "009",
  },
  {
    value: "00238",
    label: "Phường Khương Thượng",
    parent_code: "006",
  },
  {
    value: "00349",
    label: "Phường Khương Trung",
    parent_code: "009",
  },
  {
    value: "30634",
    label: "Xã Kiến An",
    parent_code: "893",
  },
  {
    value: "11554",
    label: "Xã Kiền Bái",
    parent_code: "311",
  },
  {
    value: "30790",
    label: "Xã Kiên Bình",
    parent_code: "902",
  },
  {
    value: "27847",
    label: "Xã Kiến Bình",
    parent_code: "799",
  },
  {
    value: "02341",
    label: "Xã Kiên Đài",
    parent_code: "073",
  },
  {
    value: "24733",
    label: "Thị trấn Kiến Đức",
    parent_code: "666",
  },
  {
    value: "19249",
    label: "Thị trấn Kiến Giang",
    parent_code: "457",
  },
  {
    value: "09565",
    label: "Phường Kiến Hưng",
    parent_code: "268",
  },
  {
    value: "13441",
    label: "Thị trấn Kiện Khê",
    parent_code: "351",
  },
  {
    value: "07552",
    label: "Xã Kiên Lao",
    parent_code: "219",
  },
  {
    value: "30787",
    label: "Thị trấn Kiên Lương",
    parent_code: "902",
  },
  {
    value: "06625",
    label: "Xã Kiên Mộc",
    parent_code: "189",
  },
  {
    value: "11209",
    label: "Xã Kiến Quốc",
    parent_code: "299",
  },
  {
    value: "11713",
    label: "Xã Kiến Quốc",
    parent_code: "314",
  },
  {
    value: "07558",
    label: "Xã Kiên Thành",
    parent_code: "219",
  },
  {
    value: "04525",
    label: "Xã Kiên Thành",
    parent_code: "138",
  },
  {
    value: "24754",
    label: "Xã Kiến Thành",
    parent_code: "666",
  },
  {
    value: "30649",
    label: "Xã Kiến Thành",
    parent_code: "893",
  },
  {
    value: "11782",
    label: "Xã Kiến Thiết",
    parent_code: "315",
  },
  {
    value: "02437",
    label: "Xã Kiến Thiết",
    parent_code: "075",
  },
  {
    value: "15118",
    label: "Xã Kiên Thọ",
    parent_code: "389",
  },
  {
    value: "13075",
    label: "Thị trấn Kiến Xương",
    parent_code: "343",
  },
  {
    value: "28726",
    label: "Xã Kiểng Phước",
    parent_code: "824",
  },
  {
    value: "08554",
    label: "Xã Kiệt Sơn",
    parent_code: "240",
  },
  {
    value: "00580",
    label: "Xã Kiêu Kỵ",
    parent_code: "018",
  },
  {
    value: "10156",
    label: "Xã Kim An",
    parent_code: "278",
  },
  {
    value: "10780",
    label: "Xã Kim Anh",
    parent_code: "293",
  },
  {
    value: "10114",
    label: "Thị trấn Kim Bài",
    parent_code: "278",
  },
  {
    value: "13426",
    label: "Xã Kim Bình",
    parent_code: "347",
  },
  {
    value: "02350",
    label: "Xã Kim Bình",
    parent_code: "073",
  },
  {
    value: "03961",
    label: "Xã Kim Bon",
    parent_code: "122",
  },
  {
    value: "05065",
    label: "Xã Kim Bôi",
    parent_code: "153",
  },
  {
    value: "09256",
    label: "Phường Kim Chân",
    parent_code: "256",
  },
  {
    value: "14659",
    label: "Xã Kim Chính",
    parent_code: "376",
  },
  {
    value: "00493",
    label: "Xã Kim Chung",
    parent_code: "017",
  },
  {
    value: "09853",
    label: "Xã Kim Chung",
    parent_code: "274",
  },
  {
    value: "12664",
    label: "Xã Kim Chung",
    parent_code: "339",
  },
  {
    value: "01343",
    label: "Xã Kim Cúc",
    parent_code: "043",
  },
  {
    value: "26566",
    label: "Phường Kim Dinh",
    parent_code: "748",
  },
  {
    value: "10792",
    label: "Xã Kim Đính",
    parent_code: "293",
  },
  {
    value: "14635",
    label: "Xã Kim Định",
    parent_code: "376",
  },
  {
    value: "14698",
    label: "Xã Kim Đông",
    parent_code: "376",
  },
  {
    value: "01792",
    label: "Xã Kim Đồng",
    parent_code: "053",
  },
  {
    value: "06031",
    label: "Xã Kim Đồng",
    parent_code: "180",
  },
  {
    value: "08281",
    label: "Xã Kim Đức",
    parent_code: "227",
  },
  {
    value: "10411",
    label: "Xã Kim Đường",
    parent_code: "281",
  },
  {
    value: "00373",
    label: "Phường Kim Giang",
    parent_code: "009",
  },
  {
    value: "14692",
    label: "Xã Kim Hải",
    parent_code: "376",
  },
  {
    value: "08977",
    label: "Xã Kim Hoa",
    parent_code: "250",
  },
  {
    value: "18211",
    label: "Xã Kim Hoa",
    parent_code: "439",
  },
  {
    value: "29434",
    label: "Xã Kim Hòa",
    parent_code: "848",
  },
  {
    value: "18955",
    label: "Xã Kim Hóa",
    parent_code: "453",
  },
  {
    value: "02146",
    label: "Xã Kim Hỷ",
    parent_code: "066",
  },
  {
    value: "00586",
    label: "Xã Kim Lan",
    parent_code: "018",
  },
  {
    value: "05035",
    label: "Xã Kim Lập",
    parent_code: "153",
  },
  {
    value: "00229",
    label: "Phường Kim Liên",
    parent_code: "006",
  },
  {
    value: "10783",
    label: "Xã Kim Liên",
    parent_code: "293",
  },
  {
    value: "17971",
    label: "Xã Kim Liên",
    parent_code: "430",
  },
  {
    value: "00709",
    label: "Xã Kim Linh",
    parent_code: "030",
  },
  {
    value: "01549",
    label: "Xã Kim Loan",
    parent_code: "048",
  },
  {
    value: "08878",
    label: "Xã Kim Long",
    parent_code: "247",
  },
  {
    value: "26608",
    label: "Xã Kim Long",
    parent_code: "750",
  },
  {
    value: "19774",
    label: "Phường Kim Long",
    parent_code: "474",
  },
  {
    value: "00439",
    label: "Xã Kim Lũ",
    parent_code: "016",
  },
  {
    value: "02158",
    label: "Xã Kim Lư",
    parent_code: "066",
  },
  {
    value: "00028",
    label: "Phường Kim Mã",
    parent_code: "001",
  },
  {
    value: "14686",
    label: "Xã Kim Mỹ",
    parent_code: "376",
  },
  {
    value: "01180",
    label: "Xã Kim Ngọc",
    parent_code: "034",
  },
  {
    value: "04477",
    label: "Xã Kim Nọi",
    parent_code: "137",
  },
  {
    value: "00490",
    label: "Xã Kim Nỗ",
    parent_code: "017",
  },
  {
    value: "02497",
    label: "Xã Kim Phú",
    parent_code: "070",
  },
  {
    value: "05551",
    label: "Xã Kim Phượng",
    parent_code: "167",
  },
  {
    value: "09976",
    label: "Xã Kim Quan",
    parent_code: "276",
  },
  {
    value: "02476",
    label: "Xã Kim Quan",
    parent_code: "075",
  },
  {
    value: "18436",
    label: "Xã Kim Song Trường",
    parent_code: "443",
  },
  {
    value: "00562",
    label: "Xã Kim Sơn",
    parent_code: "018",
  },
  {
    value: "09610",
    label: "Xã Kim Sơn",
    parent_code: "269",
  },
  {
    value: "07123",
    label: "Phường Kim Sơn",
    parent_code: "205",
  },
  {
    value: "07564",
    label: "Xã Kim Sơn",
    parent_code: "219",
  },
  {
    value: "02971",
    label: "Xã Kim Sơn",
    parent_code: "087",
  },
  {
    value: "16738",
    label: "Thị trấn Kim Sơn",
    parent_code: "415",
  },
  {
    value: "28585",
    label: "Xã Kim Sơn",
    parent_code: "821",
  },
  {
    value: "29482",
    label: "Xã Kim Sơn",
    parent_code: "849",
  },
  {
    value: "10786",
    label: "Xã Kim Tân",
    parent_code: "293",
  },
  {
    value: "14683",
    label: "Xã Kim Tân",
    parent_code: "376",
  },
  {
    value: "15187",
    label: "Thị trấn Kim Tân",
    parent_code: "391",
  },
  {
    value: "02647",
    label: "Phường Kim Tân",
    parent_code: "080",
  },
  {
    value: "24022",
    label: "Xã Kim Tân",
    parent_code: "635",
  },
  {
    value: "00703",
    label: "Xã Kim Thạch",
    parent_code: "030",
  },
  {
    value: "19384",
    label: "Xã Kim Thạch",
    parent_code: "464",
  },
  {
    value: "13780",
    label: "Xã Kim Thái",
    parent_code: "359",
  },
  {
    value: "17521",
    label: "Xã Kim Thành",
    parent_code: "426",
  },
  {
    value: "19318",
    label: "Xã Kim Thủy",
    parent_code: "457",
  },
  {
    value: "10159",
    label: "Xã Kim Thư",
    parent_code: "278",
  },
  {
    value: "08617",
    label: "Xã Kim Thượng",
    parent_code: "240",
  },
  {
    value: "14695",
    label: "Xã Kim Trung",
    parent_code: "376",
  },
  {
    value: "09079",
    label: "Xã Kim Xá",
    parent_code: "252",
  },
  {
    value: "10771",
    label: "Xã Kim Xuyên",
    parent_code: "293",
  },
  {
    value: "09172",
    label: "Phường Kinh Bắc",
    parent_code: "256",
  },
  {
    value: "31393",
    label: "Thị trấn Kinh Cùng",
    parent_code: "934",
  },
  {
    value: "22759",
    label: "Phường Kinh Dinh",
    parent_code: "582",
  },
  {
    value: "23818",
    label: "Xã Kon Chiêng",
    parent_code: "629",
  },
  {
    value: "23794",
    label: "Thị trấn Kon Dơng",
    parent_code: "629",
  },
  {
    value: "23434",
    label: "Xã Kon Đào",
    parent_code: "612",
  },
  {
    value: "23689",
    label: "Xã Kon Gang",
    parent_code: "626",
  },
  {
    value: "23641",
    label: "Xã Kon Pne",
    parent_code: "625",
  },
  {
    value: "23812",
    label: "Xã Kon Thụp",
    parent_code: "629",
  },
  {
    value: "23824",
    label: "Thị trấn Kông Chro",
    parent_code: "630",
  },
  {
    value: "23954",
    label: "Xã Kông HTok",
    parent_code: "633",
  },
  {
    value: "23668",
    label: "Xã Kông Lơng Khơng",
    parent_code: "625",
  },
  {
    value: "23671",
    label: "Xã Kông Pla",
    parent_code: "625",
  },
  {
    value: "23833",
    label: "Xã Kông Yang",
    parent_code: "630",
  },
  {
    value: "23650",
    label: "Xã KRong",
    parent_code: "625",
  },
  {
    value: "23314",
    label: "Xã Kroong",
    parent_code: "608",
  },
  {
    value: "24442",
    label: "Xã Krông Á",
    parent_code: "652",
  },
  {
    value: "24493",
    label: "Xã KRông Búk",
    parent_code: "654",
  },
  {
    value: "24427",
    label: "Xã Krông Jing",
    parent_code: "652",
  },
  {
    value: "19555",
    label: "Thị trấn Krông Klang",
    parent_code: "467",
  },
  {
    value: "24448",
    label: "Thị trấn Krông Kmar",
    parent_code: "653",
  },
  {
    value: "24235",
    label: "Xã Krông Na",
    parent_code: "647",
  },
  {
    value: "24115",
    label: "Xã Krông Năng",
    parent_code: "637",
  },
  {
    value: "24343",
    label: "Thị trấn Krông Năng",
    parent_code: "650",
  },
  {
    value: "24604",
    label: "Xã Krông Nô",
    parent_code: "656",
  },
  {
    value: "22195",
    label: "Xã Krông Pa",
    parent_code: "560",
  },
  {
    value: "12442",
    label: "Phường Kỳ Bá",
    parent_code: "336",
  },
  {
    value: "18760",
    label: "Xã Kỳ Bắc",
    parent_code: "447",
  },
  {
    value: "18811",
    label: "Xã Kỳ Châu",
    parent_code: "447",
  },
  {
    value: "18775",
    label: "Xã Kỳ Đồng",
    parent_code: "447",
  },
  {
    value: "18772",
    label: "Xã Kỳ Giang",
    parent_code: "447",
  },
  {
    value: "18808",
    label: "Xã Kỳ Hà",
    parent_code: "449",
  },
  {
    value: "18802",
    label: "Xã Kỳ Hải",
    parent_code: "447",
  },
  {
    value: "18829",
    label: "Xã Kỳ Hoa",
    parent_code: "449",
  },
  {
    value: "18778",
    label: "Xã Kỳ Khang",
    parent_code: "447",
  },
  {
    value: "18850",
    label: "Xã Kỳ Lạc",
    parent_code: "447",
  },
  {
    value: "18841",
    label: "Phường Kỳ Liên",
    parent_code: "449",
  },
  {
    value: "18835",
    label: "Phường Kỳ Long",
    parent_code: "449",
  },
  {
    value: "18796",
    label: "Xã Kỳ Lợi",
    parent_code: "449",
  },
  {
    value: "18847",
    label: "Xã Kỳ Nam",
    parent_code: "449",
  },
  {
    value: "18781",
    label: "Xã Kỳ Ninh",
    parent_code: "449",
  },
  {
    value: "18766",
    label: "Xã Kỳ Phong",
    parent_code: "447",
  },
  {
    value: "14449",
    label: "Xã Kỳ Phú",
    parent_code: "372",
  },
  {
    value: "18763",
    label: "Xã Kỳ Phú",
    parent_code: "447",
  },
  {
    value: "05845",
    label: "Xã Ký Phú",
    parent_code: "171",
  },
  {
    value: "18832",
    label: "Phường Kỳ Phương",
    parent_code: "449",
  },
  {
    value: "11482",
    label: "Xã Kỳ Sơn",
    parent_code: "311",
  },
  {
    value: "04894",
    label: "Phường Kỳ Sơn",
    parent_code: "148",
  },
  {
    value: "17314",
    label: "Xã Kỳ Sơn",
    parent_code: "423",
  },
  {
    value: "18844",
    label: "Xã Kỳ Sơn",
    parent_code: "447",
  },
  {
    value: "14974",
    label: "Xã Kỳ Tân",
    parent_code: "386",
  },
  {
    value: "17320",
    label: "Xã Kỳ Tân",
    parent_code: "423",
  },
  {
    value: "18814",
    label: "Xã Kỳ Tân",
    parent_code: "447",
  },
  {
    value: "18793",
    label: "Xã Kỳ Tây",
    parent_code: "447",
  },
  {
    value: "18823",
    label: "Phường Kỳ Thịnh",
    parent_code: "449",
  },
  {
    value: "18790",
    label: "Xã Kỳ Thọ",
    parent_code: "447",
  },
  {
    value: "18805",
    label: "Xã Kỳ Thư",
    parent_code: "447",
  },
  {
    value: "07033",
    label: "Xã Kỳ Thượng",
    parent_code: "193",
  },
  {
    value: "18799",
    label: "Xã Kỳ Thượng",
    parent_code: "447",
  },
  {
    value: "18769",
    label: "Xã Kỳ Tiến",
    parent_code: "447",
  },
  {
    value: "18820",
    label: "Phường Kỳ Trinh",
    parent_code: "449",
  },
  {
    value: "18787",
    label: "Xã Kỳ Trung",
    parent_code: "447",
  },
  {
    value: "18784",
    label: "Xã Kỳ Văn",
    parent_code: "447",
  },
  {
    value: "18757",
    label: "Xã Kỳ Xuân",
    parent_code: "447",
  },
  {
    value: "05815",
    label: "Xã La Bằng",
    parent_code: "171",
  },
  {
    value: "23065",
    label: "Xã La Dạ",
    parent_code: "597",
  },
  {
    value: "20704",
    label: "Xã La Dêê",
    parent_code: "510",
  },
  {
    value: "21235",
    label: "Thị trấn La Hà",
    parent_code: "528",
  },
  {
    value: "22081",
    label: "Thị trấn La Hai",
    parent_code: "558",
  },
  {
    value: "05740",
    label: "Xã La Hiên",
    parent_code: "170",
  },
  {
    value: "09551",
    label: "Phường La Khê",
    parent_code: "268",
  },
  {
    value: "26227",
    label: "Xã La Ngà",
    parent_code: "736",
  },
  {
    value: "23161",
    label: "Xã La Ngâu",
    parent_code: "599",
  },
  {
    value: "03391",
    label: "Xã Lả Nhì Thàng",
    parent_code: "109",
  },
  {
    value: "02791",
    label: "Xã La Pan Tẩn",
    parent_code: "083",
  },
  {
    value: "04483",
    label: "Xã La Pán Tẩn",
    parent_code: "137",
  },
  {
    value: "09889",
    label: "Xã La Phù",
    parent_code: "274",
  },
  {
    value: "13555",
    label: "Xã La Sơn",
    parent_code: "352",
  },
  {
    value: "25909",
    label: "Xã Lạc An",
    parent_code: "726",
  },
  {
    value: "24846",
    label: "Thị trấn Lạc Dương",
    parent_code: "675",
  },
  {
    value: "11989",
    label: "Xã Lạc Đạo",
    parent_code: "325",
  },
  {
    value: "22945",
    label: "Phường Lạc Đạo",
    parent_code: "593",
  },
  {
    value: "31798",
    label: "Xã Lạc Hòa",
    parent_code: "950",
  },
  {
    value: "12016",
    label: "Xã Lạc Hồng",
    parent_code: "325",
  },
  {
    value: "24940",
    label: "Xã Lạc Lâm",
    parent_code: "677",
  },
  {
    value: "10720",
    label: "Xã Lạc Long",
    parent_code: "292",
  },
  {
    value: "05362",
    label: "Xã Lạc Lương",
    parent_code: "158",
  },
  {
    value: "01000",
    label: "Xã Lạc Nông",
    parent_code: "031",
  },
  {
    value: "30550",
    label: "Xã Lạc Quới",
    parent_code: "891",
  },
  {
    value: "17671",
    label: "Xã Lạc Sơn",
    parent_code: "427",
  },
  {
    value: "05356",
    label: "Xã Lạc Sỹ",
    parent_code: "158",
  },
  {
    value: "23149",
    label: "Thị trấn Lạc Tánh",
    parent_code: "599",
  },
  {
    value: "28087",
    label: "Xã Lạc Tấn",
    parent_code: "805",
  },
  {
    value: "05374",
    label: "Xã Lạc Thịnh",
    parent_code: "158",
  },
  {
    value: "14413",
    label: "Xã Lạc Vân",
    parent_code: "372",
  },
  {
    value: "09343",
    label: "Xã Lạc Vệ",
    parent_code: "260",
  },
  {
    value: "11341",
    label: "Phường Lạc Viên",
    parent_code: "304",
  },
  {
    value: "24934",
    label: "Xã Lạc Xuân",
    parent_code: "677",
  },
  {
    value: "11362",
    label: "Phường Lạch Tray",
    parent_code: "304",
  },
  {
    value: "20698",
    label: "Xã Laêê",
    parent_code: "510",
  },
  {
    value: "10891",
    label: "Thị trấn Lai Cách",
    parent_code: "295",
  },
  {
    value: "08560",
    label: "Xã Lai Đồng",
    parent_code: "240",
  },
  {
    value: "09520",
    label: "Xã Lai Hạ",
    parent_code: "264",
  },
  {
    value: "31341",
    label: "Phường Lái Hiếu",
    parent_code: "931",
  },
  {
    value: "31810",
    label: "Xã Lai Hòa",
    parent_code: "950",
  },
  {
    value: "25834",
    label: "Xã Lai Hưng",
    parent_code: "719",
  },
  {
    value: "31111",
    label: "Xã Lại Sơn",
    parent_code: "912",
  },
  {
    value: "14674",
    label: "Xã Lai Thành",
    parent_code: "376",
  },
  {
    value: "25966",
    label: "Phường Lái Thiêu",
    parent_code: "725",
  },
  {
    value: "09964",
    label: "Xã Lại Thượng",
    parent_code: "276",
  },
  {
    value: "25822",
    label: "Thị trấn Lai Uyên",
    parent_code: "719",
  },
  {
    value: "10753",
    label: "Xã Lai Vu",
    parent_code: "293",
  },
  {
    value: "30208",
    label: "Thị trấn Lai Vung",
    parent_code: "876",
  },
  {
    value: "11476",
    label: "Xã Lại Xuân",
    parent_code: "311",
  },
  {
    value: "09868",
    label: "Xã Lại Yên",
    parent_code: "274",
  },
  {
    value: "07333",
    label: "Xã Lam Cốt",
    parent_code: "216",
  },
  {
    value: "10063",
    label: "Xã Lam Điền",
    parent_code: "277",
  },
  {
    value: "13303",
    label: "Phường Lam Hạ",
    parent_code: "347",
  },
  {
    value: "11429",
    label: "Phường Lãm Hà",
    parent_code: "307",
  },
  {
    value: "08461",
    label: "Xã Lam Sơn",
    parent_code: "236",
  },
  {
    value: "11260",
    label: "Xã Lam Sơn",
    parent_code: "300",
  },
  {
    value: "11374",
    label: "Phường Lam Sơn",
    parent_code: "305",
  },
  {
    value: "11950",
    label: "Phường Lam Sơn",
    parent_code: "323",
  },
  {
    value: "14773",
    label: "Phường Lam Sơn",
    parent_code: "380",
  },
  {
    value: "14815",
    label: "Phường Lam Sơn",
    parent_code: "381",
  },
  {
    value: "15064",
    label: "Xã Lam Sơn",
    parent_code: "389",
  },
  {
    value: "15556",
    label: "Thị trấn Lam Sơn",
    parent_code: "395",
  },
  {
    value: "17623",
    label: "Xã Lam Sơn",
    parent_code: "427",
  },
  {
    value: "05542",
    label: "Xã Lam Vỹ",
    parent_code: "167",
  },
  {
    value: "07303",
    label: "Xã Lan Giới",
    parent_code: "216",
  },
  {
    value: "07495",
    label: "Xã Lan Mẫu",
    parent_code: "218",
  },
  {
    value: "30070",
    label: "Xã Láng Biển",
    parent_code: "872",
  },
  {
    value: "15055",
    label: "Thị trấn Lang Chánh",
    parent_code: "388",
  },
  {
    value: "03874",
    label: "Xã Làng Chếu",
    parent_code: "121",
  },
  {
    value: "08773",
    label: "Xã Lãng Công",
    parent_code: "253",
  },
  {
    value: "26698",
    label: "Xã Láng Dài",
    parent_code: "753",
  },
  {
    value: "03094",
    label: "Xã Làng Giàng",
    parent_code: "089",
  },
  {
    value: "00199",
    label: "Phường Láng Hạ",
    parent_code: "006",
  },
  {
    value: "17233",
    label: "Xã Lạng Khê",
    parent_code: "422",
  },
  {
    value: "26602",
    label: "Xã Láng Lớn",
    parent_code: "750",
  },
  {
    value: "26467",
    label: "Xã Lang Minh",
    parent_code: "741",
  },
  {
    value: "03529",
    label: "Xã Làng Mô",
    parent_code: "108",
  },
  {
    value: "09478",
    label: "Xã Lãng Ngâm",
    parent_code: "263",
  },
  {
    value: "04609",
    label: "Xã Làng Nhì",
    parent_code: "139",
  },
  {
    value: "14422",
    label: "Xã Lạng Phong",
    parent_code: "372",
  },
  {
    value: "02479",
    label: "Xã Lang Quán",
    parent_code: "075",
  },
  {
    value: "08122",
    label: "Xã Lang Sơn",
    parent_code: "231",
  },
  {
    value: "07723",
    label: "Xã Lãng Sơn",
    parent_code: "221",
  },
  {
    value: "17365",
    label: "Xã Lạng Sơn",
    parent_code: "424",
  },
  {
    value: "04378",
    label: "Xã Lang Thíp",
    parent_code: "136",
  },
  {
    value: "00187",
    label: "Phường Láng Thượng",
    parent_code: "006",
  },
  {
    value: "31951",
    label: "Phường Láng Tròn",
    parent_code: "959",
  },
  {
    value: "19432",
    label: "Thị trấn Lao Bảo",
    parent_code: "465",
  },
  {
    value: "02641",
    label: "Phường Lào Cai",
    parent_code: "080",
  },
  {
    value: "00943",
    label: "Xã Lao Chải",
    parent_code: "030",
  },
  {
    value: "04474",
    label: "Xã Lao Chải",
    parent_code: "137",
  },
  {
    value: "07684",
    label: "Xã Lão Hộ",
    parent_code: "221",
  },
  {
    value: "00844",
    label: "Xã Lao Và Chải",
    parent_code: "028",
  },
  {
    value: "03229",
    label: "Xã Lao Xả Phình",
    parent_code: "098",
  },
  {
    value: "24862",
    label: "Xã Lát",
    parent_code: "675",
  },
  {
    value: "03184",
    label: "Xã Lay Nưa",
    parent_code: "095",
  },
  {
    value: "20449",
    label: "Xã Lăng",
    parent_code: "504",
  },
  {
    value: "02266",
    label: "Thị trấn Lăng Can",
    parent_code: "071",
  },
  {
    value: "20110",
    label: "Thị trấn Lăng Cô",
    parent_code: "482",
  },
  {
    value: "01504",
    label: "Xã Lăng Hiếu",
    parent_code: "047",
  },
  {
    value: "17512",
    label: "Xã Lăng Thành",
    parent_code: "426",
  },
  {
    value: "13795",
    label: "Thị trấn Lâm",
    parent_code: "360",
  },
  {
    value: "06640",
    label: "Xã Lâm Ca",
    parent_code: "189",
  },
  {
    value: "11569",
    label: "Xã Lâm Động",
    parent_code: "311",
  },
  {
    value: "20101",
    label: "Xã Lâm Đớt",
    parent_code: "481",
  },
  {
    value: "04381",
    label: "Xã Lâm Giang",
    parent_code: "136",
  },
  {
    value: "32201",
    label: "Xã Lâm Hải",
    parent_code: "971",
  },
  {
    value: "18967",
    label: "Xã Lâm Hóa",
    parent_code: "453",
  },
  {
    value: "18838",
    label: "Xã Lâm Hợp",
    parent_code: "447",
  },
  {
    value: "31765",
    label: "Xã Lâm Kiết",
    parent_code: "949",
  },
  {
    value: "15052",
    label: "Xã Lâm Phú",
    parent_code: "388",
  },
  {
    value: "26365",
    label: "Xã Lâm San",
    parent_code: "739",
  },
  {
    value: "06499",
    label: "Xã Lâm Sơn",
    parent_code: "187",
  },
  {
    value: "04942",
    label: "Xã Lâm Sơn",
    parent_code: "152",
  },
  {
    value: "22813",
    label: "Xã Lâm Sơn",
    parent_code: "585",
  },
  {
    value: "31759",
    label: "Xã Lâm Tân",
    parent_code: "949",
  },
  {
    value: "08494",
    label: "Thị trấn Lâm Thao",
    parent_code: "237",
  },
  {
    value: "09535",
    label: "Xã Lâm Thao",
    parent_code: "264",
  },
  {
    value: "19327",
    label: "Xã Lâm Thủy",
    parent_code: "457",
  },
  {
    value: "04309",
    label: "Xã Lâm Thượng",
    parent_code: "135",
  },
  {
    value: "19129",
    label: "Xã Lâm Trạch",
    parent_code: "455",
  },
  {
    value: "18277",
    label: "Xã Lâm Trung Thủy",
    parent_code: "440",
  },
  {
    value: "11551",
    label: "Xã Lập Lễ",
    parent_code: "311",
  },
  {
    value: "08761",
    label: "Thị trấn Lập Thạch",
    parent_code: "246",
  },
  {
    value: "30169",
    label: "Thị trấn Lấp Vò",
    parent_code: "875",
  },
  {
    value: "05743",
    label: "Xã Lâu Thượng",
    parent_code: "170",
  },
  {
    value: "03158",
    label: "Xã Leng Su Sìn",
    parent_code: "096",
  },
  {
    value: "31186",
    label: "Phường Lê Bình",
    parent_code: "919",
  },
  {
    value: "30403",
    label: "Xã Lê Chánh",
    parent_code: "887",
  },
  {
    value: "00550",
    label: "Xã Lệ Chi",
    parent_code: "018",
  },
  {
    value: "01714",
    label: "Xã Lê Chung",
    parent_code: "051",
  },
  {
    value: "00256",
    label: "Phường Lê Đại Hành",
    parent_code: "007",
  },
  {
    value: "18970",
    label: "Xã Lê Hóa",
    parent_code: "453",
  },
  {
    value: "13393",
    label: "Xã Lê Hồ",
    parent_code: "350",
  },
  {
    value: "11266",
    label: "Xã Lê Hồng",
    parent_code: "300",
  },
  {
    value: "12433",
    label: "Phường Lê Hồng Phong",
    parent_code: "336",
  },
  {
    value: "13291",
    label: "Phường Lê Hồng Phong",
    parent_code: "347",
  },
  {
    value: "21010",
    label: "Phường Lê Hồng Phong",
    parent_code: "522",
  },
  {
    value: "21571",
    label: "Phường Lê Hồng Phong",
    parent_code: "540",
  },
  {
    value: "01819",
    label: "Xã Lê Lai",
    parent_code: "053",
  },
  {
    value: "09574",
    label: "Phường Lê Lợi",
    parent_code: "269",
  },
  {
    value: "10243",
    label: "Xã Lê Lợi",
    parent_code: "279",
  },
  {
    value: "01828",
    label: "Xã Lê Lợi",
    parent_code: "053",
  },
  {
    value: "10564",
    label: "Xã Lê Lợi",
    parent_code: "290",
  },
  {
    value: "11041",
    label: "Xã Lê Lợi",
    parent_code: "297",
  },
  {
    value: "11356",
    label: "Phường Lê Lợi",
    parent_code: "304",
  },
  {
    value: "11611",
    label: "Xã Lê Lợi",
    parent_code: "312",
  },
  {
    value: "11959",
    label: "Phường Lê Lợi",
    parent_code: "323",
  },
  {
    value: "07066",
    label: "Xã Lê Lợi",
    parent_code: "193",
  },
  {
    value: "07219",
    label: "Phường Lê Lợi",
    parent_code: "213",
  },
  {
    value: "13102",
    label: "Xã Lê Lợi",
    parent_code: "343",
  },
  {
    value: "03481",
    label: "Xã Lê Lợi",
    parent_code: "112",
  },
  {
    value: "16669",
    label: "Phường Lê Lợi",
    parent_code: "412",
  },
  {
    value: "23302",
    label: "Phường Lê Lợi",
    parent_code: "608",
  },
  {
    value: "21583",
    label: "Phường Lê Lợi",
    parent_code: "540",
  },
  {
    value: "16687",
    label: "Phường Lê Mao",
    parent_code: "412",
  },
  {
    value: "27610",
    label: "Xã Lê Minh Xuân",
    parent_code: "785",
  },
  {
    value: "08234",
    label: "Xã Lệ Mỹ",
    parent_code: "233",
  },
  {
    value: "10684",
    label: "Xã Lê Ninh",
    parent_code: "292",
  },
  {
    value: "10468",
    label: "Xã Lê Thanh",
    parent_code: "282",
  },
  {
    value: "10534",
    label: "Phường Lê Thanh Nghị",
    parent_code: "288",
  },
  {
    value: "11584",
    label: "Xã Lê Thiện",
    parent_code: "312",
  },
  {
    value: "30553",
    label: "Xã Lê Trì",
    parent_code: "891",
  },
  {
    value: "07654",
    label: "Xã Lệ Viễn",
    parent_code: "220",
  },
  {
    value: "12352",
    label: "Xã Lệ Xá",
    parent_code: "332",
  },
  {
    value: "19489",
    label: "Xã Lìa",
    parent_code: "465",
  },
  {
    value: "31678",
    label: "Xã Lịch Hội Thượng",
    parent_code: "951",
  },
  {
    value: "31679",
    label: "Thị trấn Lịch Hội Thượng",
    parent_code: "951",
  },
  {
    value: "13456",
    label: "Xã Liêm Cần",
    parent_code: "351",
  },
  {
    value: "13309",
    label: "Phường Liêm Chính",
    parent_code: "347",
  },
  {
    value: "13312",
    label: "Xã Liêm Chung",
    parent_code: "347",
  },
  {
    value: "14038",
    label: "Xã Liêm Hải",
    parent_code: "363",
  },
  {
    value: "13450",
    label: "Xã Liêm Phong",
    parent_code: "351",
  },
  {
    value: "03118",
    label: "Xã Liêm Phú",
    parent_code: "089",
  },
  {
    value: "13483",
    label: "Xã Liêm Sơn",
    parent_code: "351",
  },
  {
    value: "13465",
    label: "Xã Liêm Thuận",
    parent_code: "351",
  },
  {
    value: "02197",
    label: "Xã Liêm Thuỷ",
    parent_code: "066",
  },
  {
    value: "13447",
    label: "Xã Liêm Tiết",
    parent_code: "347",
  },
  {
    value: "13480",
    label: "Xã Liêm Túc",
    parent_code: "351",
  },
  {
    value: "13444",
    label: "Xã Liêm Tuyền",
    parent_code: "347",
  },
  {
    value: "11881",
    label: "Xã Liên Am",
    parent_code: "316",
  },
  {
    value: "08710",
    label: "Phường Liên Bảo",
    parent_code: "243",
  },
  {
    value: "13774",
    label: "Xã Liên Bảo",
    parent_code: "359",
  },
  {
    value: "09334",
    label: "Xã Liên Bão",
    parent_code: "260",
  },
  {
    value: "10375",
    label: "Xã Liên Bạt",
    parent_code: "281",
  },
  {
    value: "10171",
    label: "Xã Liên Châu",
    parent_code: "278",
  },
  {
    value: "09064",
    label: "Xã Liên Châu",
    parent_code: "251",
  },
  {
    value: "07357",
    label: "Xã Liên Chung",
    parent_code: "216",
  },
  {
    value: "25027",
    label: "Xã Liên Đầm",
    parent_code: "679",
  },
  {
    value: "12697",
    label: "Xã Liên Giang",
    parent_code: "340",
  },
  {
    value: "00484",
    label: "Xã Liên Hà",
    parent_code: "017",
  },
  {
    value: "09802",
    label: "Xã Liên Hà",
    parent_code: "273",
  },
  {
    value: "24919",
    label: "Xã Liên Hà",
    parent_code: "676",
  },
  {
    value: "09781",
    label: "Xã Liên Hiệp",
    parent_code: "272",
  },
  {
    value: "01192",
    label: "Xã Liên Hiệp",
    parent_code: "034",
  },
  {
    value: "12637",
    label: "Xã Liên Hiệp",
    parent_code: "339",
  },
  {
    value: "24964",
    label: "Xã Liên Hiệp",
    parent_code: "678",
  },
  {
    value: "08236",
    label: "Xã Liên Hoa",
    parent_code: "233",
  },
  {
    value: "12763",
    label: "Xã Liên Hoa",
    parent_code: "340",
  },
  {
    value: "04009",
    label: "Xã Liên Hoà",
    parent_code: "128",
  },
  {
    value: "08812",
    label: "Xã Liên Hòa",
    parent_code: "246",
  },
  {
    value: "10807",
    label: "Xã Liên Hòa",
    parent_code: "293",
  },
  {
    value: "07180",
    label: "Xã Liên Hòa",
    parent_code: "206",
  },
  {
    value: "06268",
    label: "Xã Liên Hội",
    parent_code: "184",
  },
  {
    value: "09799",
    label: "Xã Liên Hồng",
    parent_code: "273",
  },
  {
    value: "11005",
    label: "Xã Liên Hồng",
    parent_code: "288",
  },
  {
    value: "17053",
    label: "Xã Liên Hợp",
    parent_code: "420",
  },
  {
    value: "22969",
    label: "Thị trấn Liên Hương",
    parent_code: "595",
  },
  {
    value: "11485",
    label: "Xã Liên Khê",
    parent_code: "311",
  },
  {
    value: "12250",
    label: "Xã Liên Khê",
    parent_code: "330",
  },
  {
    value: "16066",
    label: "Xã Liên Lộc",
    parent_code: "400",
  },
  {
    value: "00598",
    label: "Phường Liên Mạc",
    parent_code: "021",
  },
  {
    value: "08998",
    label: "Xã Liên Mạc",
    parent_code: "250",
  },
  {
    value: "10843",
    label: "Xã Liên Mạc",
    parent_code: "294",
  },
  {
    value: "05752",
    label: "Xã Liên Minh",
    parent_code: "170",
  },
  {
    value: "13783",
    label: "Xã Liên Minh",
    parent_code: "359",
  },
  {
    value: "03052",
    label: "Xã Liên Minh",
    parent_code: "088",
  },
  {
    value: "18247",
    label: "Xã Liên Minh",
    parent_code: "440",
  },
  {
    value: "12040",
    label: "Xã Liên Nghĩa",
    parent_code: "326",
  },
  {
    value: "24958",
    label: "Thị trấn Liên Nghĩa",
    parent_code: "678",
  },
  {
    value: "00682",
    label: "Xã Liên Ninh",
    parent_code: "020",
  },
  {
    value: "10213",
    label: "Xã Liên Phương",
    parent_code: "279",
  },
  {
    value: "11974",
    label: "Xã Liên Phương",
    parent_code: "323",
  },
  {
    value: "09955",
    label: "Thị trấn Liên Quan",
    parent_code: "276",
  },
  {
    value: "22639",
    label: "Xã Liên Sang",
    parent_code: "573",
  },
  {
    value: "06502",
    label: "Xã Liên Sơn",
    parent_code: "187",
  },
  {
    value: "07327",
    label: "Xã Liên Sơn",
    parent_code: "216",
  },
  {
    value: "13432",
    label: "Xã Liên Sơn",
    parent_code: "350",
  },
  {
    value: "14473",
    label: "Xã Liên Sơn",
    parent_code: "373",
  },
  {
    value: "04969",
    label: "Xã Liên Sơn",
    parent_code: "152",
  },
  {
    value: "24580",
    label: "Thị trấn Liên Sơn",
    parent_code: "656",
  },
  {
    value: "08791",
    label: "Xã Liễn Sơn",
    parent_code: "246",
  },
  {
    value: "17602",
    label: "Xã Liên Thành",
    parent_code: "426",
  },
  {
    value: "19285",
    label: "Xã Liên Thủy",
    parent_code: "457",
  },
  {
    value: "19135",
    label: "Xã Liên Trạch",
    parent_code: "455",
  },
  {
    value: "09808",
    label: "Xã Liên Trung",
    parent_code: "273",
  },
  {
    value: "19051",
    label: "Xã Liên Trường",
    parent_code: "454",
  },
  {
    value: "07186",
    label: "Xã Liên Vị",
    parent_code: "206",
  },
  {
    value: "24874",
    label: "Xã Liêng Srônh",
    parent_code: "674",
  },
  {
    value: "03739",
    label: "Xã Liệp Tè",
    parent_code: "119",
  },
  {
    value: "09913",
    label: "Xã Liệp Tuyết",
    parent_code: "275",
  },
  {
    value: "13891",
    label: "Thị trấn Liễu Đề",
    parent_code: "361",
  },
  {
    value: "04348",
    label: "Xã Liễu Đô",
    parent_code: "135",
  },
  {
    value: "00008",
    label: "Phường Liễu Giai",
    parent_code: "001",
  },
  {
    value: "31675",
    label: "Xã Liêu Tú",
    parent_code: "951",
  },
  {
    value: "12067",
    label: "Xã Liêu Xá",
    parent_code: "327",
  },
  {
    value: "09319",
    label: "Thị trấn Lim",
    parent_code: "260",
  },
  {
    value: "26815",
    label: "Phường Linh Chiểu",
    parent_code: "769",
  },
  {
    value: "26821",
    label: "Phường Linh Đông",
    parent_code: "769",
  },
  {
    value: "19549",
    label: "Xã Linh Hải",
    parent_code: "466",
  },
  {
    value: "00961",
    label: "Xã Linh Hồ",
    parent_code: "030",
  },
  {
    value: "30840",
    label: "Xã Lình Huỳnh",
    parent_code: "903",
  },
  {
    value: "00328",
    label: "Phường Lĩnh Nam",
    parent_code: "008",
  },
  {
    value: "02368",
    label: "Xã Linh Phú",
    parent_code: "073",
  },
  {
    value: "05701",
    label: "Xã Linh Sơn",
    parent_code: "164",
  },
  {
    value: "17383",
    label: "Xã Lĩnh Sơn",
    parent_code: "424",
  },
  {
    value: "26818",
    label: "Phường Linh Tây",
    parent_code: "769",
  },
  {
    value: "05539",
    label: "Xã Linh Thông",
    parent_code: "167",
  },
  {
    value: "15298",
    label: "Xã Lĩnh Toại",
    parent_code: "392",
  },
  {
    value: "26800",
    label: "Phường Linh Trung",
    parent_code: "769",
  },
  {
    value: "19534",
    label: "Xã Linh Trường",
    parent_code: "466",
  },
  {
    value: "26794",
    label: "Phường Linh Xuân",
    parent_code: "769",
  },
  {
    value: "29761",
    label: "Xã Loan Mỹ",
    parent_code: "860",
  },
  {
    value: "26404",
    label: "Xã Long An",
    parent_code: "740",
  },
  {
    value: "28198",
    label: "Xã Long An",
    parent_code: "807",
  },
  {
    value: "28558",
    label: "Xã Long An",
    parent_code: "821",
  },
  {
    value: "29608",
    label: "Xã Long An",
    parent_code: "857",
  },
  {
    value: "30391",
    label: "Xã Long An",
    parent_code: "887",
  },
  {
    value: "15922",
    label: "Phường Long Anh",
    parent_code: "380",
  },
  {
    value: "00145",
    label: "Phường Long Biên",
    parent_code: "004",
  },
  {
    value: "25240",
    label: "Xã Long Bình",
    parent_code: "698",
  },
  {
    value: "26020",
    label: "Phường Long Bình",
    parent_code: "731",
  },
  {
    value: "26830",
    label: "Phường Long Bình",
    parent_code: "769",
  },
  {
    value: "28687",
    label: "Xã Long Bình",
    parent_code: "823",
  },
  {
    value: "30341",
    label: "Thị Trấn Long Bình",
    parent_code: "886",
  },
  {
    value: "31474",
    label: "Xã Long Bình",
    parent_code: "937",
  },
  {
    value: "31744",
    label: "Xã Long Bình",
    parent_code: "948",
  },
  {
    value: "28636",
    label: "Xã Long Bình Điền",
    parent_code: "822",
  },
  {
    value: "26056",
    label: "Phường Long Bình Tân",
    parent_code: "731",
  },
  {
    value: "28126",
    label: "Xã Long Cang",
    parent_code: "806",
  },
  {
    value: "28315",
    label: "Xã Long Chánh",
    parent_code: "816",
  },
  {
    value: "09232",
    label: "Xã Long Châu",
    parent_code: "258",
  },
  {
    value: "30378",
    label: "Phường Long Châu",
    parent_code: "887",
  },
  {
    value: "25684",
    label: "Xã Long Chữ",
    parent_code: "711",
  },
  {
    value: "08608",
    label: "Xã Long Cốc",
    parent_code: "240",
  },
  {
    value: "26659",
    label: "Thị trấn Long Điền",
    parent_code: "752",
  },
  {
    value: "31981",
    label: "Xã Long Điền",
    parent_code: "960",
  },
  {
    value: "30640",
    label: "Xã Long Điền A",
    parent_code: "893",
  },
  {
    value: "30646",
    label: "Xã Long Điền B",
    parent_code: "893",
  },
  {
    value: "31975",
    label: "Xã Long Điền Đông",
    parent_code: "960",
  },
  {
    value: "31978",
    label: "Xã Long Điền Đông A",
    parent_code: "960",
  },
  {
    value: "31984",
    label: "Xã Long Điền Tây",
    parent_code: "960",
  },
  {
    value: "28117",
    label: "Xã Long Định",
    parent_code: "806",
  },
  {
    value: "28552",
    label: "Xã Long Định",
    parent_code: "821",
  },
  {
    value: "29056",
    label: "Xã Long Định",
    parent_code: "835",
  },
  {
    value: "06328",
    label: "Xã Long Đống",
    parent_code: "185",
  },
  {
    value: "26389",
    label: "Xã Long Đức",
    parent_code: "740",
  },
  {
    value: "29263",
    label: "Xã Long Đức",
    parent_code: "842",
  },
  {
    value: "31651",
    label: "Xã Long Đức",
    parent_code: "946",
  },
  {
    value: "25245",
    label: "Xã Long Giang",
    parent_code: "688",
  },
  {
    value: "25690",
    label: "Xã Long Giang",
    parent_code: "711",
  },
  {
    value: "30661",
    label: "Xã Long Giang",
    parent_code: "893",
  },
  {
    value: "26341",
    label: "Thị trấn Long Giao",
    parent_code: "739",
  },
  {
    value: "25255",
    label: "Xã Long Hà",
    parent_code: "698",
  },
  {
    value: "26662",
    label: "Thị trấn Long Hải",
    parent_code: "752",
  },
  {
    value: "23275",
    label: "Xã Long Hải",
    parent_code: "602",
  },
  {
    value: "28168",
    label: "Xã Long Hậu",
    parent_code: "807",
  },
  {
    value: "30217",
    label: "Xã Long Hậu",
    parent_code: "876",
  },
  {
    value: "03763",
    label: "Xã Long Hẹ",
    parent_code: "119",
  },
  {
    value: "21361",
    label: "Xã Long Hiệp",
    parent_code: "531",
  },
  {
    value: "28024",
    label: "Xã Long Hiệp",
    parent_code: "803",
  },
  {
    value: "29506",
    label: "Xã Long Hiệp",
    parent_code: "849",
  },
  {
    value: "25630",
    label: "Phường Long Hoa",
    parent_code: "709",
  },
  {
    value: "25792",
    label: "Xã Long Hoà",
    parent_code: "720",
  },
  {
    value: "30415",
    label: "Xã Long Hoà",
    parent_code: "888",
  },
  {
    value: "27679",
    label: "Xã Long Hòa",
    parent_code: "787",
  },
  {
    value: "28123",
    label: "Xã Long Hòa",
    parent_code: "806",
  },
  {
    value: "28318",
    label: "Xã Long Hòa",
    parent_code: "816",
  },
  {
    value: "29059",
    label: "Xã Long Hòa",
    parent_code: "835",
  },
  {
    value: "29413",
    label: "Xã Long Hòa",
    parent_code: "847",
  },
  {
    value: "31180",
    label: "Phường Long Hòa",
    parent_code: "918",
  },
  {
    value: "29575",
    label: "Thị trấn Long Hồ",
    parent_code: "857",
  },
  {
    value: "12034",
    label: "Xã Long Hưng",
    parent_code: "326",
  },
  {
    value: "25246",
    label: "Xã Long Hưng",
    parent_code: "698",
  },
  {
    value: "26380",
    label: "Xã Long Hưng",
    parent_code: "731",
  },
  {
    value: "28309",
    label: "Xã Long Hưng",
    parent_code: "816",
  },
  {
    value: "28561",
    label: "Xã Long Hưng",
    parent_code: "821",
  },
  {
    value: "30377",
    label: "Phường Long Hưng",
    parent_code: "887",
  },
  {
    value: "31157",
    label: "Phường Long Hưng",
    parent_code: "917",
  },
  {
    value: "31579",
    label: "Xã Long Hưng",
    parent_code: "944",
  },
  {
    value: "30184",
    label: "Xã Long Hưng A",
    parent_code: "875",
  },
  {
    value: "30190",
    label: "Xã Long Hưng B",
    parent_code: "875",
  },
  {
    value: "26563",
    label: "Phường Long Hương",
    parent_code: "748",
  },
  {
    value: "29518",
    label: "Xã Long Hữu",
    parent_code: "851",
  },
  {
    value: "28144",
    label: "Xã Long Hựu Đông",
    parent_code: "806",
  },
  {
    value: "28153",
    label: "Xã Long Hựu Tây",
    parent_code: "806",
  },
  {
    value: "25696",
    label: "Xã Long Khánh",
    parent_code: "711",
  },
  {
    value: "28486",
    label: "Xã Long Khánh",
    parent_code: "817",
  },
  {
    value: "29521",
    label: "Xã Long Khánh",
    parent_code: "850",
  },
  {
    value: "29980",
    label: "Xã Long Khánh A",
    parent_code: "870",
  },
  {
    value: "29983",
    label: "Xã Long Khánh B",
    parent_code: "870",
  },
  {
    value: "28114",
    label: "Xã Long Khê",
    parent_code: "806",
  },
  {
    value: "30664",
    label: "Xã Long Kiến",
    parent_code: "893",
  },
  {
    value: "04051",
    label: "Xã Lóng Luông",
    parent_code: "128",
  },
  {
    value: "21352",
    label: "Xã Long Mai",
    parent_code: "531",
  },
  {
    value: "21358",
    label: "Xã Long Môn",
    parent_code: "531",
  },
  {
    value: "26689",
    label: "Xã Long Mỹ",
    parent_code: "753",
  },
  {
    value: "29026",
    label: "Xã Long Mỹ",
    parent_code: "834",
  },
  {
    value: "29635",
    label: "Xã Long Mỹ",
    parent_code: "858",
  },
  {
    value: "25828",
    label: "Xã Long Nguyên",
    parent_code: "719",
  },
  {
    value: "04096",
    label: "Xã Lóng Phiêng",
    parent_code: "124",
  },
  {
    value: "29752",
    label: "Xã Long Phú",
    parent_code: "860",
  },
  {
    value: "30394",
    label: "Phường Long Phú",
    parent_code: "887",
  },
  {
    value: "31480",
    label: "Xã Long Phú",
    parent_code: "937",
  },
  {
    value: "31639",
    label: "Thị trấn Long Phú",
    parent_code: "946",
  },
  {
    value: "31669",
    label: "Xã Long Phú",
    parent_code: "946",
  },
  {
    value: "28201",
    label: "Xã Long Phụng",
    parent_code: "807",
  },
  {
    value: "25220",
    label: "Phường Long Phước",
    parent_code: "688",
  },
  {
    value: "25687",
    label: "Xã Long Phước",
    parent_code: "711",
  },
  {
    value: "26413",
    label: "Xã Long Phước",
    parent_code: "740",
  },
  {
    value: "26569",
    label: "Xã Long Phước",
    parent_code: "748",
  },
  {
    value: "26857",
    label: "Phường Long Phước",
    parent_code: "769",
  },
  {
    value: "29599",
    label: "Xã Long Phước",
    parent_code: "857",
  },
  {
    value: "04045",
    label: "Xã Lóng Sập",
    parent_code: "123",
  },
  {
    value: "07672",
    label: "Xã Long Sơn",
    parent_code: "220",
  },
  {
    value: "17003",
    label: "Phường Long Sơn",
    parent_code: "414",
  },
  {
    value: "17377",
    label: "Xã Long Sơn",
    parent_code: "424",
  },
  {
    value: "26545",
    label: "Xã Long Sơn",
    parent_code: "747",
  },
  {
    value: "24678",
    label: "Xã Long Sơn",
    parent_code: "663",
  },
  {
    value: "21349",
    label: "Xã Long Sơn",
    parent_code: "531",
  },
  {
    value: "28129",
    label: "Xã Long Sơn",
    parent_code: "806",
  },
  {
    value: "29443",
    label: "Xã Long Sơn",
    parent_code: "848",
  },
  {
    value: "30412",
    label: "Phường Long Sơn",
    parent_code: "887",
  },
  {
    value: "26558",
    label: "Phường Long Tâm",
    parent_code: "748",
  },
  {
    value: "25258",
    label: "Xã Long Tân",
    parent_code: "698",
  },
  {
    value: "25804",
    label: "Xã Long Tân",
    parent_code: "720",
  },
  {
    value: "26473",
    label: "Xã Long Tân",
    parent_code: "742",
  },
  {
    value: "26695",
    label: "Xã Long Tân",
    parent_code: "753",
  },
  {
    value: "17578",
    label: "Xã Long Thành",
    parent_code: "426",
  },
  {
    value: "26368",
    label: "Thị trấn Long Thành",
    parent_code: "740",
  },
  {
    value: "29513",
    label: "Thị trấn Long Thành",
    parent_code: "850",
  },
  {
    value: "28039",
    label: "Xã Long Thạnh",
    parent_code: "804",
  },
  {
    value: "30376",
    label: "Phường Long Thạnh",
    parent_code: "887",
  },
  {
    value: "30943",
    label: "Xã Long Thạnh",
    parent_code: "906",
  },
  {
    value: "31408",
    label: "Xã Long Thạnh",
    parent_code: "934",
  },
  {
    value: "31921",
    label: "Xã Long Thạnh",
    parent_code: "958",
  },
  {
    value: "25636",
    label: "Phường Long Thành Bắc",
    parent_code: "709",
  },
  {
    value: "26833",
    label: "Phường Long Thạnh Mỹ",
    parent_code: "769",
  },
  {
    value: "25651",
    label: "Xã Long Thành Nam",
    parent_code: "709",
  },
  {
    value: "25645",
    label: "Phường Long Thành Trung",
    parent_code: "709",
  },
  {
    value: "30229",
    label: "Xã Long Thắng",
    parent_code: "876",
  },
  {
    value: "26494",
    label: "Xã Long Thọ",
    parent_code: "742",
  },
  {
    value: "27658",
    label: "Xã Long Thới",
    parent_code: "786",
  },
  {
    value: "28885",
    label: "Xã Long Thới",
    parent_code: "832",
  },
  {
    value: "29356",
    label: "Xã Long Thới",
    parent_code: "846",
  },
  {
    value: "25702",
    label: "Xã Long Thuận",
    parent_code: "711",
  },
  {
    value: "28045",
    label: "Xã Long Thuận",
    parent_code: "804",
  },
  {
    value: "28312",
    label: "Xã Long Thuận",
    parent_code: "816",
  },
  {
    value: "29992",
    label: "Xã Long Thuận",
    parent_code: "870",
  },
  {
    value: "25217",
    label: "Phường Long Thủy",
    parent_code: "688",
  },
  {
    value: "28165",
    label: "Xã Long Thượng",
    parent_code: "807",
  },
  {
    value: "28498",
    label: "Xã Long Tiên",
    parent_code: "820",
  },
  {
    value: "26557",
    label: "Phường Long Toàn",
    parent_code: "748",
  },
  {
    value: "29515",
    label: "Xã Long Toàn",
    parent_code: "851",
  },
  {
    value: "28111",
    label: "Xã Long Trạch",
    parent_code: "806",
  },
  {
    value: "28243",
    label: "Xã Long Trì",
    parent_code: "808",
  },
  {
    value: "31477",
    label: "Xã Long Trị",
    parent_code: "937",
  },
  {
    value: "31478",
    label: "Xã Long Trị A",
    parent_code: "937",
  },
  {
    value: "28504",
    label: "Xã Long Trung",
    parent_code: "820",
  },
  {
    value: "26860",
    label: "Phường Long Trường",
    parent_code: "769",
  },
  {
    value: "31183",
    label: "Phường Long Tuyền",
    parent_code: "918",
  },
  {
    value: "25627",
    label: "Xã Long Vĩnh",
    parent_code: "708",
  },
  {
    value: "28678",
    label: "Xã Long Vĩnh",
    parent_code: "823",
  },
  {
    value: "29533",
    label: "Xã Long Vĩnh",
    parent_code: "850",
  },
  {
    value: "18043",
    label: "Xã Long Xá",
    parent_code: "431",
  },
  {
    value: "09745",
    label: "Xã Long Xuyên",
    parent_code: "272",
  },
  {
    value: "10738",
    label: "Phường Long Xuyên",
    parent_code: "292",
  },
  {
    value: "10963",
    label: "Xã Long Xuyên",
    parent_code: "296",
  },
  {
    value: "26320",
    label: "Xã Lộ 25",
    parent_code: "738",
  },
  {
    value: "12715",
    label: "Xã Lô Giang",
    parent_code: "340",
  },
  {
    value: "05191",
    label: "Xã Lỗ Sơn",
    parent_code: "155",
  },
  {
    value: "13702",
    label: "Xã Lộc An",
    parent_code: "356",
  },
  {
    value: "25084",
    label: "Xã Lộc An",
    parent_code: "680",
  },
  {
    value: "25276",
    label: "Xã Lộc An",
    parent_code: "692",
  },
  {
    value: "26392",
    label: "Xã Lộc An",
    parent_code: "740",
  },
  {
    value: "26701",
    label: "Xã Lộc An",
    parent_code: "753",
  },
  {
    value: "20140",
    label: "Xã Lộc An",
    parent_code: "482",
  },
  {
    value: "25057",
    label: "Xã Lộc Bảo",
    parent_code: "680",
  },
  {
    value: "25066",
    label: "Xã Lộc Bắc",
    parent_code: "680",
  },
  {
    value: "06529",
    label: "Thị trấn Lộc Bình",
    parent_code: "188",
  },
  {
    value: "20134",
    label: "Xã Lộc Bình",
    parent_code: "482",
  },
  {
    value: "20128",
    label: "Xã Lộc Bổn",
    parent_code: "482",
  },
  {
    value: "24841",
    label: "Xã Lộc Châu",
    parent_code: "673",
  },
  {
    value: "25300",
    label: "Xã Lộc Điền",
    parent_code: "692",
  },
  {
    value: "20143",
    label: "Xã Lộc Điền",
    parent_code: "482",
  },
  {
    value: "25081",
    label: "Xã Lộc Đức",
    parent_code: "680",
  },
  {
    value: "27940",
    label: "Xã Lộc Giang",
    parent_code: "802",
  },
  {
    value: "18568",
    label: "Thị trấn Lộc Hà",
    parent_code: "448",
  },
  {
    value: "13684",
    label: "Phường Lộc Hạ",
    parent_code: "356",
  },
  {
    value: "25282",
    label: "Xã Lộc Hiệp",
    parent_code: "692",
  },
  {
    value: "13693",
    label: "Phường Lộc Hòa",
    parent_code: "356",
  },
  {
    value: "25273",
    label: "Xã Lộc Hòa",
    parent_code: "692",
  },
  {
    value: "20155",
    label: "Xã Lộc Hòa",
    parent_code: "482",
  },
  {
    value: "29605",
    label: "Xã Lộc Hòa",
    parent_code: "857",
  },
  {
    value: "25303",
    label: "Xã Lộc Hưng",
    parent_code: "692",
  },
  {
    value: "25717",
    label: "Phường Lộc Hưng",
    parent_code: "712",
  },
  {
    value: "25306",
    label: "Xã Lộc Khánh",
    parent_code: "692",
  },
  {
    value: "25060",
    label: "Xã Lộc Lâm",
    parent_code: "680",
  },
  {
    value: "25093",
    label: "Xã Lộc Nam",
    parent_code: "680",
  },
  {
    value: "24838",
    label: "Xã Lộc Nga",
    parent_code: "673",
  },
  {
    value: "25072",
    label: "Xã Lộc Ngãi",
    parent_code: "680",
  },
  {
    value: "18886",
    label: "Xã Lộc Ninh",
    parent_code: "450",
  },
  {
    value: "25270",
    label: "Thị trấn Lộc Ninh",
    parent_code: "692",
  },
  {
    value: "25579",
    label: "Xã Lộc Ninh",
    parent_code: "707",
  },
  {
    value: "31855",
    label: "Xã Lộc Ninh",
    parent_code: "956",
  },
  {
    value: "24814",
    label: "Phường Lộc Phát",
    parent_code: "673",
  },
  {
    value: "25063",
    label: "Xã Lộc Phú",
    parent_code: "680",
  },
  {
    value: "25292",
    label: "Xã Lộc Phú",
    parent_code: "692",
  },
  {
    value: "25291",
    label: "Xã Lộc Quang",
    parent_code: "692",
  },
  {
    value: "25075",
    label: "Xã Lộc Quảng",
    parent_code: "680",
  },
  {
    value: "16030",
    label: "Xã Lộc Sơn",
    parent_code: "400",
  },
  {
    value: "24829",
    label: "Phường Lộc Sơn",
    parent_code: "673",
  },
  {
    value: "20131",
    label: "Xã Lộc Sơn",
    parent_code: "482",
  },
  {
    value: "25078",
    label: "Xã Lộc Tân",
    parent_code: "680",
  },
  {
    value: "25279",
    label: "Xã Lộc Tấn",
    parent_code: "692",
  },
  {
    value: "25297",
    label: "Xã Lộc Thái",
    parent_code: "692",
  },
  {
    value: "24835",
    label: "Xã Lộc Thanh",
    parent_code: "673",
  },
  {
    value: "25090",
    label: "Xã Lộc Thành",
    parent_code: "680",
  },
  {
    value: "25294",
    label: "Xã Lộc Thành",
    parent_code: "692",
  },
  {
    value: "25280",
    label: "Xã Lộc Thạnh",
    parent_code: "692",
  },
  {
    value: "25054",
    label: "Thị trấn Lộc Thắng",
    parent_code: "680",
  },
  {
    value: "25285",
    label: "Xã Lộc Thiện",
    parent_code: "692",
  },
  {
    value: "15097",
    label: "Xã Lộc Thịnh",
    parent_code: "389",
  },
  {
    value: "25305",
    label: "Xã Lộc Thịnh",
    parent_code: "692",
  },
  {
    value: "22363",
    label: "Phường Lộc Thọ",
    parent_code: "568",
  },
  {
    value: "25288",
    label: "Xã Lộc Thuận",
    parent_code: "692",
  },
  {
    value: "29077",
    label: "Xã Lộc Thuận",
    parent_code: "835",
  },
  {
    value: "20146",
    label: "Xã Lộc Thủy",
    parent_code: "482",
  },
  {
    value: "19279",
    label: "Xã Lộc Thủy",
    parent_code: "457",
  },
  {
    value: "24817",
    label: "Phường Lộc Tiến",
    parent_code: "673",
  },
  {
    value: "20152",
    label: "Xã Lộc Tiến",
    parent_code: "482",
  },
  {
    value: "20149",
    label: "Xã Lộc Trì",
    parent_code: "482",
  },
  {
    value: "20137",
    label: "Xã Lộc Vĩnh",
    parent_code: "482",
  },
  {
    value: "13687",
    label: "Phường Lộc Vượng",
    parent_code: "356",
  },
  {
    value: "06211",
    label: "Xã Lộc Yên",
    parent_code: "183",
  },
  {
    value: "18520",
    label: "Xã Lộc Yên",
    parent_code: "444",
  },
  {
    value: "23656",
    label: "Xã Lơ Ku",
    parent_code: "625",
  },
  {
    value: "23809",
    label: "Xã Lơ Pang",
    parent_code: "629",
  },
  {
    value: "32122",
    label: "Xã Lợi An",
    parent_code: "968",
  },
  {
    value: "06601",
    label: "Xã Lợi Bác",
    parent_code: "188",
  },
  {
    value: "27709",
    label: "Xã Lợi Bình Nhơn",
    parent_code: "794",
  },
  {
    value: "22849",
    label: "Xã Lợi Hải",
    parent_code: "588",
  },
  {
    value: "25699",
    label: "Xã Lợi Thuận",
    parent_code: "711",
  },
  {
    value: "03379",
    label: "Xã Luân Giới",
    parent_code: "101",
  },
  {
    value: "15637",
    label: "Xã Luận Khê",
    parent_code: "396",
  },
  {
    value: "15634",
    label: "Xã Luận Thành",
    parent_code: "396",
  },
  {
    value: "05833",
    label: "Xã Lục Ba",
    parent_code: "171",
  },
  {
    value: "01990",
    label: "Xã Lục Bình",
    parent_code: "063",
  },
  {
    value: "17260",
    label: "Xã Lục Dạ",
    parent_code: "422",
  },
  {
    value: "06856",
    label: "Xã Lục Hồn",
    parent_code: "198",
  },
  {
    value: "07510",
    label: "Xã Lục Sơn",
    parent_code: "218",
  },
  {
    value: "29857",
    label: "Xã Lục Sỹ Thành",
    parent_code: "862",
  },
  {
    value: "02842",
    label: "Xã Lùng Cải",
    parent_code: "085",
  },
  {
    value: "14959",
    label: "Xã Lũng Cao",
    parent_code: "386",
  },
  {
    value: "00805",
    label: "Xã Lũng Chinh",
    parent_code: "027",
  },
  {
    value: "00715",
    label: "Xã Lũng Cú",
    parent_code: "026",
  },
  {
    value: "09106",
    label: "Xã Lũng Hoà",
    parent_code: "252",
  },
  {
    value: "00865",
    label: "Xã Lũng Hồ",
    parent_code: "028",
  },
  {
    value: "02776",
    label: "Xã Lùng Khấu Nhin",
    parent_code: "083",
  },
  {
    value: "01393",
    label: "Xã Lũng Nặm",
    parent_code: "045",
  },
  {
    value: "14956",
    label: "Xã Lũng Niêm",
    parent_code: "386",
  },
  {
    value: "00763",
    label: "Xã Lũng Phìn",
    parent_code: "026",
  },
  {
    value: "02848",
    label: "Xã Lùng Phình",
    parent_code: "085",
  },
  {
    value: "00802",
    label: "Xã Lũng Pù",
    parent_code: "027",
  },
  {
    value: "00901",
    label: "Xã Lùng Tám",
    parent_code: "029",
  },
  {
    value: "00724",
    label: "Xã Lũng Táo",
    parent_code: "026",
  },
  {
    value: "03509",
    label: "Xã Lùng Thàng",
    parent_code: "108",
  },
  {
    value: "02818",
    label: "Xã Lùng Thẩn",
    parent_code: "084",
  },
  {
    value: "00754",
    label: "Xã Lũng Thầu",
    parent_code: "026",
  },
  {
    value: "02785",
    label: "Xã Lùng Vai",
    parent_code: "083",
  },
  {
    value: "02434",
    label: "Xã Lực Hành",
    parent_code: "075",
  },
  {
    value: "30568",
    label: "Xã Lương An Trà",
    parent_code: "891",
  },
  {
    value: "12280",
    label: "Thị trấn Lương Bằng",
    parent_code: "331",
  },
  {
    value: "02062",
    label: "Xã Lương Bằng",
    parent_code: "064",
  },
  {
    value: "27997",
    label: "Xã Lương Bình",
    parent_code: "803",
  },
  {
    value: "01384",
    label: "Xã Lương Can",
    parent_code: "045",
  },
  {
    value: "10924",
    label: "Xã Lương Điền",
    parent_code: "295",
  },
  {
    value: "28003",
    label: "Xã Lương Hòa",
    parent_code: "803",
  },
  {
    value: "28999",
    label: "Xã Lương Hòa",
    parent_code: "834",
  },
  {
    value: "29389",
    label: "Xã Lương Hòa",
    parent_code: "847",
  },
  {
    value: "29386",
    label: "Xã Lương Hoà A",
    parent_code: "847",
  },
  {
    value: "28612",
    label: "Xã Lương Hòa Lạc",
    parent_code: "822",
  },
  {
    value: "13288",
    label: "Phường Lương Khánh Thiện",
    parent_code: "347",
  },
  {
    value: "08227",
    label: "Xã Lương Lỗ",
    parent_code: "232",
  },
  {
    value: "16906",
    label: "Xã Lưỡng Minh",
    parent_code: "418",
  },
  {
    value: "06985",
    label: "Xã Lương Mông",
    parent_code: "202",
  },
  {
    value: "06292",
    label: "Xã Lương Năng",
    parent_code: "184",
  },
  {
    value: "31493",
    label: "Xã Lương Nghĩa",
    parent_code: "936",
  },
  {
    value: "14941",
    label: "Xã Lương Ngoại",
    parent_code: "386",
  },
  {
    value: "08653",
    label: "Xã Lương Nha",
    parent_code: "238",
  },
  {
    value: "19207",
    label: "Xã Lương Ninh",
    parent_code: "456",
  },
  {
    value: "14947",
    label: "Xã Lương Nội",
    parent_code: "386",
  },
  {
    value: "30565",
    label: "Xã Lương Phi",
    parent_code: "891",
  },
  {
    value: "07846",
    label: "Xã Lương Phong",
    parent_code: "223",
  },
  {
    value: "05953",
    label: "Xã Lương Phú",
    parent_code: "173",
  },
  {
    value: "29005",
    label: "Xã Lương Phú",
    parent_code: "834",
  },
  {
    value: "29002",
    label: "Xã Lương Quới",
    parent_code: "834",
  },
  {
    value: "05506",
    label: "Phường Lương Sơn",
    parent_code: "165",
  },
  {
    value: "08299",
    label: "Xã Lương Sơn",
    parent_code: "234",
  },
  {
    value: "15628",
    label: "Xã Lương Sơn",
    parent_code: "396",
  },
  {
    value: "02992",
    label: "Xã Lương Sơn",
    parent_code: "087",
  },
  {
    value: "04924",
    label: "Thị trấn Lương Sơn",
    parent_code: "152",
  },
  {
    value: "22816",
    label: "Xã Lương Sơn",
    parent_code: "585",
  },
  {
    value: "23032",
    label: "Thị trấn Lương Sơn",
    parent_code: "596",
  },
  {
    value: "12010",
    label: "Xã Lương Tài",
    parent_code: "325",
  },
  {
    value: "31492",
    label: "Xã Lương Tâm",
    parent_code: "936",
  },
  {
    value: "32131",
    label: "Xã Lương Thế Trân",
    parent_code: "969",
  },
  {
    value: "02557",
    label: "Xã Lương Thiện",
    parent_code: "076",
  },
  {
    value: "04537",
    label: "Xã Lương Thịnh",
    parent_code: "138",
  },
  {
    value: "01372",
    label: "Xã Lương Thông",
    parent_code: "045",
  },
  {
    value: "02143",
    label: "Xã Lương Thượng",
    parent_code: "066",
  },
  {
    value: "14953",
    label: "Xã Lương Trung",
    parent_code: "386",
  },
  {
    value: "02515",
    label: "Xã Lưỡng Vượng",
    parent_code: "070",
  },
  {
    value: "10435",
    label: "Xã Lưu Hoàng",
    parent_code: "281",
  },
  {
    value: "11488",
    label: "Xã Lưu Kiếm",
    parent_code: "311",
  },
  {
    value: "16915",
    label: "Xã Lưu Kiền",
    parent_code: "418",
  },
  {
    value: "11491",
    label: "Xã Lưu Kỳ",
    parent_code: "311",
  },
  {
    value: "29476",
    label: "Xã Lưu Nghiệp Anh",
    parent_code: "849",
  },
  {
    value: "14665",
    label: "Xã Lưu Phương",
    parent_code: "376",
  },
  {
    value: "17659",
    label: "Xã Lưu Sơn",
    parent_code: "427",
  },
  {
    value: "18634",
    label: "Xã Lưu Vĩnh Sơn",
    parent_code: "445",
  },
  {
    value: "01294",
    label: "Xã Lý Bôn",
    parent_code: "042",
  },
  {
    value: "11884",
    label: "Xã Lý Học",
    parent_code: "316",
  },
  {
    value: "09133",
    label: "Xã Lý Nhân",
    parent_code: "252",
  },
  {
    value: "27682",
    label: "Xã Lý Nhơn",
    parent_code: "787",
  },
  {
    value: "01537",
    label: "Xã Lý Quốc",
    parent_code: "048",
  },
  {
    value: "00058",
    label: "Phường Lý Thái Tổ",
    parent_code: "002",
  },
  {
    value: "17590",
    label: "Xã Lý Thành",
    parent_code: "426",
  },
  {
    value: "12097",
    label: "Xã Lý Thường Kiệt",
    parent_code: "327",
  },
  {
    value: "21580",
    label: "Phường Lý Thường Kiệt",
    parent_code: "540",
  },
  {
    value: "19198",
    label: "Xã Lý Trạch",
    parent_code: "455",
  },
  {
    value: "32032",
    label: "Xã Lý Văn Lâm",
    parent_code: "964",
  },
  {
    value: "24412",
    label: "Thị trấn M'Đrắk",
    parent_code: "652",
  },
  {
    value: "01435",
    label: "Xã Mã Ba",
    parent_code: "045",
  },
  {
    value: "20494",
    label: "Xã Mà Cooi",
    parent_code: "505",
  },
  {
    value: "26200",
    label: "Xã Mã Đà",
    parent_code: "735",
  },
  {
    value: "25099",
    label: "Thị trấn Ma Đa Guôi",
    parent_code: "681",
  },
  {
    value: "25117",
    label: "Xã Ma Đa Guôi",
    parent_code: "681",
  },
  {
    value: "23059",
    label: "Thị trấn Ma Lâm",
    parent_code: "597",
  },
  {
    value: "00718",
    label: "Xã Má Lé",
    parent_code: "026",
  },
  {
    value: "03574",
    label: "Xã Ma Ly Pho",
    parent_code: "109",
  },
  {
    value: "22828",
    label: "Xã Ma Nới",
    parent_code: "585",
  },
  {
    value: "03508",
    label: "Xã Ma Quai",
    parent_code: "108",
  },
  {
    value: "17509",
    label: "Xã Mã Thành",
    parent_code: "426",
  },
  {
    value: "03200",
    label: "Xã Ma Thì Hồ",
    parent_code: "097",
  },
  {
    value: "05200",
    label: "Thị trấn Mai Châu",
    parent_code: "156",
  },
  {
    value: "31381",
    label: "Thị trấn Mái Dầm",
    parent_code: "933",
  },
  {
    value: "00163",
    label: "Phường Mai Dịch",
    parent_code: "005",
  },
  {
    value: "00427",
    label: "Xã Mai Đình",
    parent_code: "016",
  },
  {
    value: "07885",
    label: "Xã Mai Đình",
    parent_code: "223",
  },
  {
    value: "00310",
    label: "Phường Mai Động",
    parent_code: "008",
  },
  {
    value: "12313",
    label: "Xã Mai Động",
    parent_code: "331",
  },
  {
    value: "05251",
    label: "Xã Mai Hạ",
    parent_code: "156",
  },
  {
    value: "05257",
    label: "Xã Mai Hịch",
    parent_code: "156",
  },
  {
    value: "18994",
    label: "Xã Mai Hóa",
    parent_code: "453",
  },
  {
    value: "17125",
    label: "Phường Mai Hùng",
    parent_code: "432",
  },
  {
    value: "02095",
    label: "Xã Mai Lạp",
    parent_code: "065",
  },
  {
    value: "00520",
    label: "Xã Mai Lâm",
    parent_code: "017",
  },
  {
    value: "16645",
    label: "Phường Mai Lâm",
    parent_code: "407",
  },
  {
    value: "01756",
    label: "Xã Mai Long",
    parent_code: "052",
  },
  {
    value: "05992",
    label: "Xã Mai Pha",
    parent_code: "178",
  },
  {
    value: "18670",
    label: "Xã Mai Phụ",
    parent_code: "448",
  },
  {
    value: "06484",
    label: "Xã Mai Sao",
    parent_code: "187",
  },
  {
    value: "14710",
    label: "Xã Mai Sơn",
    parent_code: "377",
  },
  {
    value: "04318",
    label: "Xã Mai Sơn",
    parent_code: "135",
  },
  {
    value: "16879",
    label: "Xã Mai Sơn",
    parent_code: "418",
  },
  {
    value: "19309",
    label: "Xã Mai Thủy",
    parent_code: "457",
  },
  {
    value: "07864",
    label: "Xã Mai Trung",
    parent_code: "223",
  },
  {
    value: "05128",
    label: "Thị trấn Mãn Đức",
    parent_code: "155",
  },
  {
    value: "08200",
    label: "Xã Mạn Lạn",
    parent_code: "232",
  },
  {
    value: "09409",
    label: "Xã Mão Điền",
    parent_code: "262",
  },
  {
    value: "07069",
    label: "Phường Mạo Khê",
    parent_code: "205",
  },
  {
    value: "11329",
    label: "Phường Máy Chai",
    parent_code: "304",
  },
  {
    value: "11332",
    label: "Phường Máy Tơ",
    parent_code: "304",
  },
  {
    value: "23458",
    label: "Xã Măng Buk",
    parent_code: "613",
  },
  {
    value: "23470",
    label: "Xã Măng Cành",
    parent_code: "613",
  },
  {
    value: "23473",
    label: "Thị trấn Măng Đen",
    parent_code: "613",
  },
  {
    value: "23410",
    label: "Xã Măng Ri",
    parent_code: "617",
  },
  {
    value: "23167",
    label: "Xã Măng Tố",
    parent_code: "599",
  },
  {
    value: "20269",
    label: "Phường Mân Thái",
    parent_code: "493",
  },
  {
    value: "04375",
    label: "Thị trấn Mậu A",
    parent_code: "136",
  },
  {
    value: "00847",
    label: "Xã Mậu Duệ",
    parent_code: "028",
  },
  {
    value: "04405",
    label: "Xã Mậu Đông",
    parent_code: "136",
  },
  {
    value: "17245",
    label: "Xã Mậu Đức",
    parent_code: "422",
  },
  {
    value: "16243",
    label: "Xã Mậu Lâm",
    parent_code: "403",
  },
  {
    value: "00853",
    label: "Xã Mậu Long",
    parent_code: "028",
  },
  {
    value: "06238",
    label: "Xã Mẫu Sơn",
    parent_code: "183",
  },
  {
    value: "06532",
    label: "Xã Mẫu Sơn",
    parent_code: "188",
  },
  {
    value: "14464",
    label: "Thị trấn Me",
    parent_code: "373",
  },
  {
    value: "00769",
    label: "Thị trấn Mèo Vạc",
    parent_code: "027",
  },
  {
    value: "09010",
    label: "Xã Mê Linh",
    parent_code: "250",
  },
  {
    value: "12712",
    label: "Xã Mê Linh",
    parent_code: "340",
  },
  {
    value: "24892",
    label: "Xã Mê Linh",
    parent_code: "676",
  },
  {
    value: "23203",
    label: "Xã Mê Pu",
    parent_code: "600",
  },
  {
    value: "12049",
    label: "Xã Mễ Sở",
    parent_code: "326",
  },
  {
    value: "00631",
    label: "Phường Mễ Trì",
    parent_code: "019",
  },
  {
    value: "05083",
    label: "Xã Mi Hòa",
    parent_code: "153",
  },
  {
    value: "05272",
    label: "Xã Miền Đồi",
    parent_code: "157",
  },
  {
    value: "04708",
    label: "Xã Minh An",
    parent_code: "140",
  },
  {
    value: "20398",
    label: "Phường Minh An",
    parent_code: "503",
  },
  {
    value: "04270",
    label: "Xã Minh Bảo",
    parent_code: "132",
  },
  {
    value: "06991",
    label: "Xã Minh Cầm",
    parent_code: "202",
  },
  {
    value: "09661",
    label: "Xã Minh Châu",
    parent_code: "271",
  },
  {
    value: "12091",
    label: "Xã Minh Châu",
    parent_code: "327",
  },
  {
    value: "07006",
    label: "Xã Minh Châu",
    parent_code: "203",
  },
  {
    value: "17485",
    label: "Xã Minh Châu",
    parent_code: "425",
  },
  {
    value: "04315",
    label: "Xã Minh Chuẩn",
    parent_code: "135",
  },
  {
    value: "08140",
    label: "Xã Minh Côi",
    parent_code: "231",
  },
  {
    value: "10267",
    label: "Xã Minh Cường",
    parent_code: "279",
  },
  {
    value: "02389",
    label: "Xã Minh Dân",
    parent_code: "074",
  },
  {
    value: "31915",
    label: "Xã Minh Diệu",
    parent_code: "961",
  },
  {
    value: "08593",
    label: "Xã Minh Đài",
    parent_code: "240",
  },
  {
    value: "09361",
    label: "Xã Minh Đạo",
    parent_code: "260",
  },
  {
    value: "10399",
    label: "Xã Minh Đức",
    parent_code: "281",
  },
  {
    value: "11128",
    label: "Xã Minh Đức",
    parent_code: "298",
  },
  {
    value: "11465",
    label: "Phường Minh Đức",
    parent_code: "308",
  },
  {
    value: "11473",
    label: "Thị trấn Minh Đức",
    parent_code: "311",
  },
  {
    value: "12127",
    label: "Phường Minh Đức",
    parent_code: "328",
  },
  {
    value: "05872",
    label: "Xã Minh Đức",
    parent_code: "172",
  },
  {
    value: "07768",
    label: "Xã Minh Đức",
    parent_code: "222",
  },
  {
    value: "25348",
    label: "Xã Minh Đức",
    parent_code: "694",
  },
  {
    value: "28972",
    label: "Xã Minh Đức",
    parent_code: "833",
  },
  {
    value: "08119",
    label: "Xã Minh Hạc",
    parent_code: "231",
  },
  {
    value: "12007",
    label: "Xã Minh Hải",
    parent_code: "325",
  },
  {
    value: "06595",
    label: "Xã Minh Hiệp",
    parent_code: "188",
  },
  {
    value: "25780",
    label: "Xã Minh Hoà",
    parent_code: "720",
  },
  {
    value: "10747",
    label: "Xã Minh Hòa",
    parent_code: "292",
  },
  {
    value: "06457",
    label: "Xã Minh Hòa",
    parent_code: "186",
  },
  {
    value: "08332",
    label: "Xã Minh Hòa",
    parent_code: "234",
  },
  {
    value: "12682",
    label: "Xã Minh Hòa",
    parent_code: "339",
  },
  {
    value: "30895",
    label: "Xã Minh Hòa",
    parent_code: "905",
  },
  {
    value: "18931",
    label: "Xã Minh Hóa",
    parent_code: "452",
  },
  {
    value: "12403",
    label: "Xã Minh Hoàng",
    parent_code: "333",
  },
  {
    value: "17071",
    label: "Xã Minh Hợp",
    parent_code: "420",
  },
  {
    value: "25408",
    label: "Xã Minh Hưng",
    parent_code: "696",
  },
  {
    value: "25441",
    label: "Xã Minh Hưng",
    parent_code: "697",
  },
  {
    value: "02395",
    label: "Xã Minh Hương",
    parent_code: "074",
  },
  {
    value: "00295",
    label: "Phường Minh Khai",
    parent_code: "007",
  },
  {
    value: "00613",
    label: "Phường Minh Khai",
    parent_code: "021",
  },
  {
    value: "09838",
    label: "Xã Minh Khai",
    parent_code: "274",
  },
  {
    value: "00697",
    label: "Phường Minh Khai",
    parent_code: "024",
  },
  {
    value: "01795",
    label: "Xã Minh Khai",
    parent_code: "053",
  },
  {
    value: "11311",
    label: "Phường Minh Khai",
    parent_code: "303",
  },
  {
    value: "11962",
    label: "Phường Minh Khai",
    parent_code: "323",
  },
  {
    value: "06094",
    label: "Xã Minh Khai",
    parent_code: "181",
  },
  {
    value: "12658",
    label: "Xã Minh Khai",
    parent_code: "339",
  },
  {
    value: "13228",
    label: "Xã Minh Khai",
    parent_code: "344",
  },
  {
    value: "13294",
    label: "Phường Minh Khai",
    parent_code: "347",
  },
  {
    value: "16324",
    label: "Xã Minh Khôi",
    parent_code: "404",
  },
  {
    value: "02383",
    label: "Xã Minh Khương",
    parent_code: "074",
  },
  {
    value: "13222",
    label: "Xã Minh Lãng",
    parent_code: "344",
  },
  {
    value: "05677",
    label: "Xã Minh Lập",
    parent_code: "169",
  },
  {
    value: "25435",
    label: "Xã Minh Lập",
    parent_code: "697",
  },
  {
    value: "01534",
    label: "Xã Minh Long",
    parent_code: "048",
  },
  {
    value: "25444",
    label: "Xã Minh Long",
    parent_code: "697",
  },
  {
    value: "16078",
    label: "Xã Minh Lộc",
    parent_code: "400",
  },
  {
    value: "07993",
    label: "Xã Minh Lương",
    parent_code: "230",
  },
  {
    value: "03112",
    label: "Xã Minh Lương",
    parent_code: "089",
  },
  {
    value: "30880",
    label: "Thị trấn Minh Lương",
    parent_code: "905",
  },
  {
    value: "16321",
    label: "Xã Minh Nghĩa",
    parent_code: "404",
  },
  {
    value: "00994",
    label: "Xã Minh Ngọc",
    parent_code: "031",
  },
  {
    value: "07933",
    label: "Phường Minh Nông",
    parent_code: "227",
  },
  {
    value: "00397",
    label: "Xã Minh Phú",
    parent_code: "016",
  },
  {
    value: "08044",
    label: "Xã Minh Phú",
    parent_code: "230",
  },
  {
    value: "12823",
    label: "Xã Minh Phú",
    parent_code: "340",
  },
  {
    value: "07927",
    label: "Phường Minh Phương",
    parent_code: "227",
  },
  {
    value: "12379",
    label: "Xã Minh Phượng",
    parent_code: "332",
  },
  {
    value: "04516",
    label: "Xã Minh Quán",
    parent_code: "138",
  },
  {
    value: "09700",
    label: "Xã Minh Quang",
    parent_code: "271",
  },
  {
    value: "08932",
    label: "Xã Minh Quang",
    parent_code: "248",
  },
  {
    value: "13171",
    label: "Xã Minh Quang",
    parent_code: "343",
  },
  {
    value: "13234",
    label: "Xã Minh Quang",
    parent_code: "344",
  },
  {
    value: "02302",
    label: "Xã Minh Quang",
    parent_code: "071",
  },
  {
    value: "04567",
    label: "Xã Minh Quân",
    parent_code: "138",
  },
  {
    value: "00982",
    label: "Xã Minh Sơn",
    parent_code: "031",
  },
  {
    value: "06448",
    label: "Xã Minh Sơn",
    parent_code: "186",
  },
  {
    value: "15124",
    label: "Xã Minh Sơn",
    parent_code: "389",
  },
  {
    value: "15691",
    label: "Xã Minh Sơn",
    parent_code: "397",
  },
  {
    value: "17692",
    label: "Xã Minh Sơn",
    parent_code: "427",
  },
  {
    value: "01747",
    label: "Xã Minh Tâm",
    parent_code: "052",
  },
  {
    value: "15829",
    label: "Xã Minh Tâm",
    parent_code: "398",
  },
  {
    value: "25349",
    label: "Xã Minh Tâm",
    parent_code: "694",
  },
  {
    value: "10351",
    label: "Xã Minh Tân",
    parent_code: "280",
  },
  {
    value: "00919",
    label: "Xã Minh Tân",
    parent_code: "030",
  },
  {
    value: "09526",
    label: "Xã Minh Tân",
    parent_code: "264",
  },
  {
    value: "10666",
    label: "Xã Minh Tân",
    parent_code: "291",
  },
  {
    value: "10702",
    label: "Phường Minh Tân",
    parent_code: "292",
  },
  {
    value: "11500",
    label: "Xã Minh Tân",
    parent_code: "311",
  },
  {
    value: "11725",
    label: "Xã Minh Tân",
    parent_code: "314",
  },
  {
    value: "12394",
    label: "Xã Minh Tân",
    parent_code: "333",
  },
  {
    value: "08353",
    label: "Xã Minh Tân",
    parent_code: "235",
  },
  {
    value: "12670",
    label: "Xã Minh Tân",
    parent_code: "339",
  },
  {
    value: "12721",
    label: "Xã Minh Tân",
    parent_code: "340",
  },
  {
    value: "13177",
    label: "Xã Minh Tân",
    parent_code: "343",
  },
  {
    value: "13771",
    label: "Xã Minh Tân",
    parent_code: "359",
  },
  {
    value: "15382",
    label: "Xã Minh Tân",
    parent_code: "393",
  },
  {
    value: "02977",
    label: "Xã Minh Tân",
    parent_code: "087",
  },
  {
    value: "04255",
    label: "Phường Minh Tân",
    parent_code: "132",
  },
  {
    value: "25786",
    label: "Xã Minh Tân",
    parent_code: "720",
  },
  {
    value: "02542",
    label: "Xã Minh Thanh",
    parent_code: "076",
  },
  {
    value: "07138",
    label: "Phường Minh Thành",
    parent_code: "206",
  },
  {
    value: "17581",
    label: "Xã Minh Thành",
    parent_code: "426",
  },
  {
    value: "25447",
    label: "Xã Minh Thành",
    parent_code: "697",
  },
  {
    value: "25783",
    label: "Xã Minh Thạnh",
    parent_code: "720",
  },
  {
    value: "25453",
    label: "Xã Minh Thắng",
    parent_code: "697",
  },
  {
    value: "13744",
    label: "Xã Minh Thuận",
    parent_code: "359",
  },
  {
    value: "31066",
    label: "Xã Minh Thuận",
    parent_code: "913",
  },
  {
    value: "12424",
    label: "Xã Minh Tiến",
    parent_code: "333",
  },
  {
    value: "05770",
    label: "Xã Minh Tiến",
    parent_code: "171",
  },
  {
    value: "06415",
    label: "Xã Minh Tiến",
    parent_code: "186",
  },
  {
    value: "08041",
    label: "Xã Minh Tiến",
    parent_code: "230",
  },
  {
    value: "15121",
    label: "Xã Minh Tiến",
    parent_code: "389",
  },
  {
    value: "04357",
    label: "Xã Minh Tiến",
    parent_code: "135",
  },
  {
    value: "00382",
    label: "Xã Minh Trí",
    parent_code: "016",
  },
  {
    value: "02203",
    label: "Phường Minh Xuân",
    parent_code: "070",
  },
  {
    value: "04330",
    label: "Xã Minh Xuân",
    parent_code: "135",
  },
  {
    value: "28903",
    label: "Thị trấn Mỏ Cày",
    parent_code: "833",
  },
  {
    value: "05512",
    label: "Phường Mỏ Chè",
    parent_code: "165",
  },
  {
    value: "25510",
    label: "Xã Mỏ Công",
    parent_code: "705",
  },
  {
    value: "19558",
    label: "Xã Mò Ó",
    parent_code: "467",
  },
  {
    value: "04450",
    label: "Xã Mỏ Vàng",
    parent_code: "136",
  },
  {
    value: "30887",
    label: "Xã Mong Thọ",
    parent_code: "905",
  },
  {
    value: "30883",
    label: "Xã Mong Thọ A",
    parent_code: "905",
  },
  {
    value: "30886",
    label: "Xã Mong Thọ B",
    parent_code: "905",
  },
  {
    value: "04468",
    label: "Xã Mồ Dề",
    parent_code: "137",
  },
  {
    value: "09307",
    label: "Xã Mộ Đạo",
    parent_code: "259",
  },
  {
    value: "21400",
    label: "Thị trấn Mộ Đức",
    parent_code: "533",
  },
  {
    value: "09541",
    label: "Phường Mộ Lao",
    parent_code: "268",
  },
  {
    value: "23536",
    label: "Xã Mô Rai",
    parent_code: "616",
  },
  {
    value: "03553",
    label: "Xã Mồ Sì San",
    parent_code: "109",
  },
  {
    value: "13327",
    label: "Xã Mộc Bắc",
    parent_code: "349",
  },
  {
    value: "03979",
    label: "Thị trấn Mộc Châu",
    parent_code: "123",
  },
  {
    value: "13339",
    label: "Xã Mộc Nam",
    parent_code: "349",
  },
  {
    value: "17263",
    label: "Xã Môn Sơn",
    parent_code: "422",
  },
  {
    value: "01312",
    label: "Xã Mông Ân",
    parent_code: "042",
  },
  {
    value: "06106",
    label: "Xã Mông Ân",
    parent_code: "181",
  },
  {
    value: "06760",
    label: "Phường Mông Dương",
    parent_code: "195",
  },
  {
    value: "04912",
    label: "Xã Mông Hóa",
    parent_code: "148",
  },
  {
    value: "04747",
    label: "Xã Mông Sơn",
    parent_code: "141",
  },
  {
    value: "31342",
    label: "Thị trấn Một Ngàn",
    parent_code: "932",
  },
  {
    value: "03451",
    label: "Xã Mù Cả",
    parent_code: "107",
  },
  {
    value: "04456",
    label: "Thị trấn Mù Căng Chải",
    parent_code: "137",
  },
  {
    value: "03568",
    label: "Xã Mù Sang",
    parent_code: "109",
  },
  {
    value: "22915",
    label: "Phường Mũi Né",
    parent_code: "593",
  },
  {
    value: "03262",
    label: "Xã Mùn Chung",
    parent_code: "099",
  },
  {
    value: "03799",
    label: "Xã Muổi Nọi",
    parent_code: "119",
  },
  {
    value: "16867",
    label: "Xã Mường Ải",
    parent_code: "417",
  },
  {
    value: "03256",
    label: "Thị trấn Mường Ảng",
    parent_code: "102",
  },
  {
    value: "03760",
    label: "Xã Mường Bám",
    parent_code: "119",
  },
  {
    value: "03964",
    label: "Xã Mường Bang",
    parent_code: "122",
  },
  {
    value: "03250",
    label: "Xã Mường Báng",
    parent_code: "098",
  },
  {
    value: "04111",
    label: "Xã Mường Bằng",
    parent_code: "125",
  },
  {
    value: "03043",
    label: "Xã Mường Bo",
    parent_code: "088",
  },
  {
    value: "04126",
    label: "Xã Mường Bon",
    parent_code: "125",
  },
  {
    value: "03847",
    label: "Xã Mường Bú",
    parent_code: "120",
  },
  {
    value: "04216",
    label: "Xã Mường Cai",
    parent_code: "126",
  },
  {
    value: "03631",
    label: "Xã Mường Cang",
    parent_code: "110",
  },
  {
    value: "03172",
    label: "Thị Trấn Mường Chà",
    parent_code: "097",
  },
  {
    value: "04117",
    label: "Xã Mương Chanh",
    parent_code: "125",
  },
  {
    value: "14866",
    label: "Xã Mường Chanh",
    parent_code: "384",
  },
  {
    value: "03682",
    label: "Xã Mường Chiên",
    parent_code: "118",
  },
  {
    value: "04846",
    label: "Xã Mường Chiềng",
    parent_code: "150",
  },
  {
    value: "03853",
    label: "Xã Mường Chùm",
    parent_code: "120",
  },
  {
    value: "03907",
    label: "Xã Mường Cơi",
    parent_code: "122",
  },
  {
    value: "03943",
    label: "Xã Mường Do",
    parent_code: "122",
  },
  {
    value: "03286",
    label: "Xã Mường Đăng",
    parent_code: "102",
  },
  {
    value: "03247",
    label: "Xã Mường Đun",
    parent_code: "098",
  },
  {
    value: "03727",
    label: "Xã Mường é",
    parent_code: "119",
  },
  {
    value: "03703",
    label: "Xã Mường Giàng",
    parent_code: "118",
  },
  {
    value: "03694",
    label: "Xã Mường Giôn",
    parent_code: "118",
  },
  {
    value: "03037",
    label: "Xã Mường Hoa",
    parent_code: "088",
  },
  {
    value: "23362",
    label: "Xã Mường Hoong",
    parent_code: "610",
  },
  {
    value: "02728",
    label: "Xã Mường Hum",
    parent_code: "082",
  },
  {
    value: "04219",
    label: "Xã Mường Hung",
    parent_code: "126",
  },
  {
    value: "03757",
    label: "Xã Mường Khiêng",
    parent_code: "119",
  },
  {
    value: "03601",
    label: "Xã Mường Khoa",
    parent_code: "111",
  },
  {
    value: "03880",
    label: "Xã Mường Khoa",
    parent_code: "121",
  },
  {
    value: "03284",
    label: "Xã Mường Khong",
    parent_code: "099",
  },
  {
    value: "02761",
    label: "Thị trấn Mường Khương",
    parent_code: "083",
  },
  {
    value: "03637",
    label: "Xã Mường Kim",
    parent_code: "110",
  },
  {
    value: "04324",
    label: "Xã Mường Lai",
    parent_code: "135",
  },
  {
    value: "03313",
    label: "Xã Mường Lạn",
    parent_code: "102",
  },
  {
    value: "04246",
    label: "Xã Mường Lạn",
    parent_code: "127",
  },
  {
    value: "03934",
    label: "Xã Mường Lang",
    parent_code: "122",
  },
  {
    value: "14845",
    label: "Thị trấn Mường Lát",
    parent_code: "384",
  },
  {
    value: "04183",
    label: "Xã Mường Lầm",
    parent_code: "126",
  },
  {
    value: "04240",
    label: "Xã Mường Lèo",
    parent_code: "127",
  },
  {
    value: "03367",
    label: "Xã Mường Lói",
    parent_code: "100",
  },
  {
    value: "16831",
    label: "Xã Mường Lống",
    parent_code: "417",
  },
  {
    value: "03214",
    label: "Xã Mường Luân",
    parent_code: "101",
  },
  {
    value: "04081",
    label: "Xã Mường Lựm",
    parent_code: "124",
  },
  {
    value: "14854",
    label: "Xã Mường Lý",
    parent_code: "384",
  },
  {
    value: "23119",
    label: "Xã Mương Mán",
    parent_code: "598",
  },
  {
    value: "04039",
    label: "Xã Mường Men",
    parent_code: "128",
  },
  {
    value: "15025",
    label: "Xã Mường Mìn",
    parent_code: "387",
  },
  {
    value: "03625",
    label: "Xã Mường Mít",
    parent_code: "110",
  },
  {
    value: "03472",
    label: "Xã Mường Mô",
    parent_code: "112",
  },
  {
    value: "03268",
    label: "Xã Mường Mùn",
    parent_code: "099",
  },
  {
    value: "03202",
    label: "Xã Mường Mươn",
    parent_code: "097",
  },
  {
    value: "03364",
    label: "Xã Mường Nhà",
    parent_code: "100",
  },
  {
    value: "03160",
    label: "Xã Mường Nhé",
    parent_code: "096",
  },
  {
    value: "16763",
    label: "Xã Mường Nọc",
    parent_code: "415",
  },
  {
    value: "03325",
    label: "Xã Mường Phăng",
    parent_code: "094",
  },
  {
    value: "03319",
    label: "Xã Mường Pồn",
    parent_code: "100",
  },
  {
    value: "04213",
    label: "Xã Mường Sai",
    parent_code: "126",
  },
  {
    value: "03709",
    label: "Xã Mường Sại",
    parent_code: "118",
  },
  {
    value: "04027",
    label: "Xã Mường Sang",
    parent_code: "123",
  },
  {
    value: "03589",
    label: "Xã Mường So",
    parent_code: "109",
  },
  {
    value: "03433",
    label: "Thị trấn Mường Tè",
    parent_code: "107",
  },
  {
    value: "03445",
    label: "Xã Mường Tè",
    parent_code: "107",
  },
  {
    value: "04021",
    label: "Xã Mường Tè",
    parent_code: "128",
  },
  {
    value: "03904",
    label: "Xã Mường Thải",
    parent_code: "122",
  },
  {
    value: "03619",
    label: "Xã Mường Than",
    parent_code: "110",
  },
  {
    value: "03136",
    label: "Phường Mường Thanh",
    parent_code: "094",
  },
  {
    value: "03277",
    label: "Xã Mường Thín",
    parent_code: "099",
  },
  {
    value: "16858",
    label: "Xã Mường Típ",
    parent_code: "417",
  },
  {
    value: "03163",
    label: "Xã Mường Toong",
    parent_code: "096",
  },
  {
    value: "03823",
    label: "Xã Mường Trai",
    parent_code: "120",
  },
  {
    value: "03181",
    label: "Xã Mường Tùng",
    parent_code: "097",
  },
  {
    value: "04243",
    label: "Xã Mường Và",
    parent_code: "127",
  },
  {
    value: "02719",
    label: "Xã Mường Vi",
    parent_code: "082",
  },
  {
    value: "16813",
    label: "Thị trấn Mường Xén",
    parent_code: "417",
  },
  {
    value: "07600",
    label: "Xã Mỹ An",
    parent_code: "219",
  },
  {
    value: "20284",
    label: "Phường Mỹ An",
    parent_code: "494",
  },
  {
    value: "21751",
    label: "Xã Mỹ An",
    parent_code: "545",
  },
  {
    value: "28060",
    label: "Xã Mỹ An",
    parent_code: "804",
  },
  {
    value: "29233",
    label: "Xã Mỹ An",
    parent_code: "837",
  },
  {
    value: "29623",
    label: "Xã Mỹ An",
    parent_code: "858",
  },
  {
    value: "30037",
    label: "Thị trấn Mỹ An",
    parent_code: "872",
  },
  {
    value: "30064",
    label: "Xã Mỹ An",
    parent_code: "872",
  },
  {
    value: "30655",
    label: "Xã Mỹ An",
    parent_code: "893",
  },
  {
    value: "30172",
    label: "Xã Mỹ An Hưng A",
    parent_code: "875",
  },
  {
    value: "30178",
    label: "Xã Mỹ An Hưng B",
    parent_code: "875",
  },
  {
    value: "02506",
    label: "Xã Mỹ Bằng",
    parent_code: "075",
  },
  {
    value: "22779",
    label: "Phường Mỹ Bình",
    parent_code: "582",
  },
  {
    value: "27928",
    label: "Xã Mỹ Bình",
    parent_code: "801",
  },
  {
    value: "30280",
    label: "Phường Mỹ Bình",
    parent_code: "883",
  },
  {
    value: "31750",
    label: "Xã Mỹ Bình",
    parent_code: "948",
  },
  {
    value: "21781",
    label: "Xã Mỹ Cát",
    parent_code: "545",
  },
  {
    value: "29269",
    label: "Xã Mỹ Cẩm",
    parent_code: "844",
  },
  {
    value: "21769",
    label: "Xã Mỹ Chánh",
    parent_code: "545",
  },
  {
    value: "29122",
    label: "Xã Mỹ Chánh",
    parent_code: "836",
  },
  {
    value: "29380",
    label: "Xã Mỹ Chánh",
    parent_code: "847",
  },
  {
    value: "21784",
    label: "Xã Mỹ Chánh Tây",
    parent_code: "545",
  },
  {
    value: "21739",
    label: "Xã Mỹ Châu",
    parent_code: "545",
  },
  {
    value: "00625",
    label: "Phường Mỹ Đình 1",
    parent_code: "019",
  },
  {
    value: "00626",
    label: "Phường Mỹ Đình 2",
    parent_code: "019",
  },
  {
    value: "07216",
    label: "Phường Mỹ Độ",
    parent_code: "213",
  },
  {
    value: "22771",
    label: "Phường Mỹ Đông",
    parent_code: "582",
  },
  {
    value: "30058",
    label: "Xã Mỹ Đông",
    parent_code: "872",
  },
  {
    value: "11521",
    label: "Xã Mỹ Đồng",
    parent_code: "311",
  },
  {
    value: "11668",
    label: "Xã Mỹ Đức",
    parent_code: "313",
  },
  {
    value: "25135",
    label: "Xã Mỹ Đức",
    parent_code: "682",
  },
  {
    value: "21736",
    label: "Xã Mỹ Đức",
    parent_code: "545",
  },
  {
    value: "30469",
    label: "Xã Mỹ Đức",
    parent_code: "889",
  },
  {
    value: "30778",
    label: "Phường Mỹ Đức",
    parent_code: "900",
  },
  {
    value: "28405",
    label: "Xã Mỹ Đức Đông",
    parent_code: "819",
  },
  {
    value: "28408",
    label: "Xã Mỹ Đức Tây",
    parent_code: "819",
  },
  {
    value: "04741",
    label: "Xã Mỹ Gia",
    parent_code: "141",
  },
  {
    value: "07402",
    label: "Xã Mỹ Hà",
    parent_code: "217",
  },
  {
    value: "13711",
    label: "Xã Mỹ Hà",
    parent_code: "358",
  },
  {
    value: "22780",
    label: "Phường Mỹ Hải",
    parent_code: "582",
  },
  {
    value: "27964",
    label: "Xã Mỹ Hạnh Bắc",
    parent_code: "802",
  },
  {
    value: "28450",
    label: "Xã Mỹ Hạnh Đông",
    parent_code: "817",
  },
  {
    value: "27976",
    label: "Xã Mỹ Hạnh Nam",
    parent_code: "802",
  },
  {
    value: "28453",
    label: "Xã Mỹ Hạnh Trung",
    parent_code: "817",
  },
  {
    value: "21775",
    label: "Xã Mỹ Hiệp",
    parent_code: "545",
  },
  {
    value: "30112",
    label: "Xã Mỹ Hiệp",
    parent_code: "873",
  },
  {
    value: "30652",
    label: "Xã Mỹ Hiệp",
    parent_code: "893",
  },
  {
    value: "30832",
    label: "Xã Mỹ Hiệp Sơn",
    parent_code: "903",
  },
  {
    value: "05143",
    label: "Xã Mỹ Hòa",
    parent_code: "155",
  },
  {
    value: "21763",
    label: "Xã Mỹ Hòa",
    parent_code: "545",
  },
  {
    value: "29116",
    label: "Xã Mỹ Hòa",
    parent_code: "836",
  },
  {
    value: "29428",
    label: "Xã Mỹ Hòa",
    parent_code: "848",
  },
  {
    value: "29815",
    label: "Xã Mỹ Hòa",
    parent_code: "861",
  },
  {
    value: "30052",
    label: "Xã Mỹ Hòa",
    parent_code: "872",
  },
  {
    value: "30307",
    label: "Phường Mỹ Hòa",
    parent_code: "883",
  },
  {
    value: "30313",
    label: "Xã Mỹ Hoà Hưng",
    parent_code: "883",
  },
  {
    value: "28387",
    label: "Xã Mỹ Hội",
    parent_code: "819",
  },
  {
    value: "30109",
    label: "Xã Mỹ Hội",
    parent_code: "873",
  },
  {
    value: "30637",
    label: "Xã Mỹ Hội Đông",
    parent_code: "893",
  },
  {
    value: "10129",
    label: "Xã Mỹ Hưng",
    parent_code: "278",
  },
  {
    value: "01651",
    label: "Xã Mỹ Hưng",
    parent_code: "049",
  },
  {
    value: "13729",
    label: "Xã Mỹ Hưng",
    parent_code: "358",
  },
  {
    value: "29197",
    label: "Xã Mỹ Hưng",
    parent_code: "837",
  },
  {
    value: "09508",
    label: "Xã Mỹ Hương",
    parent_code: "264",
  },
  {
    value: "22753",
    label: "Phường Mỹ Hương",
    parent_code: "582",
  },
  {
    value: "31591",
    label: "Xã Mỹ Hương",
    parent_code: "944",
  },
  {
    value: "30310",
    label: "Xã Mỹ Khánh",
    parent_code: "883",
  },
  {
    value: "31312",
    label: "Xã Mỹ Khánh",
    parent_code: "926",
  },
  {
    value: "28048",
    label: "Xã Mỹ Lạc",
    parent_code: "804",
  },
  {
    value: "02509",
    label: "Phường Mỹ Lâm",
    parent_code: "070",
  },
  {
    value: "30844",
    label: "Xã Mỹ Lâm",
    parent_code: "903",
  },
  {
    value: "28135",
    label: "Xã Mỹ Lệ",
    parent_code: "806",
  },
  {
    value: "28495",
    label: "Xã Mỹ Long",
    parent_code: "820",
  },
  {
    value: "29419",
    label: "Thị trấn Mỹ Long",
    parent_code: "848",
  },
  {
    value: "30115",
    label: "Xã Mỹ Long",
    parent_code: "873",
  },
  {
    value: "30283",
    label: "Phường Mỹ Long",
    parent_code: "883",
  },
  {
    value: "29422",
    label: "Xã Mỹ Long Bắc",
    parent_code: "848",
  },
  {
    value: "29425",
    label: "Xã Mỹ Long Nam",
    parent_code: "848",
  },
  {
    value: "13708",
    label: "Thị trấn Mỹ Lộc",
    parent_code: "358",
  },
  {
    value: "16045",
    label: "Xã Mỹ Lộc",
    parent_code: "400",
  },
  {
    value: "18487",
    label: "Xã Mỹ Lộc",
    parent_code: "443",
  },
  {
    value: "21745",
    label: "Xã Mỹ Lộc",
    parent_code: "545",
  },
  {
    value: "28177",
    label: "Xã Mỹ Lộc",
    parent_code: "807",
  },
  {
    value: "29746",
    label: "Xã Mỹ Lộc",
    parent_code: "860",
  },
  {
    value: "21748",
    label: "Xã Mỹ Lợi",
    parent_code: "545",
  },
  {
    value: "28396",
    label: "Xã Mỹ Lợi A",
    parent_code: "819",
  },
  {
    value: "28381",
    label: "Xã Mỹ Lợi B",
    parent_code: "819",
  },
  {
    value: "08293",
    label: "Xã Mỹ Lung",
    parent_code: "234",
  },
  {
    value: "30631",
    label: "Thị trấn Mỹ Luông",
    parent_code: "893",
  },
  {
    value: "10087",
    label: "Xã Mỹ Lương",
    parent_code: "277",
  },
  {
    value: "08296",
    label: "Xã Mỹ Lương",
    parent_code: "234",
  },
  {
    value: "28420",
    label: "Xã Mỹ Lương",
    parent_code: "819",
  },
  {
    value: "16816",
    label: "Xã Mỹ Lý",
    parent_code: "417",
  },
  {
    value: "29881",
    label: "Xã Mỹ Ngãi",
    parent_code: "866",
  },
  {
    value: "29134",
    label: "Xã Mỹ Nhơn",
    parent_code: "836",
  },
  {
    value: "21754",
    label: "Xã Mỹ Phong",
    parent_code: "545",
  },
  {
    value: "28288",
    label: "Xã Mỹ Phong",
    parent_code: "815",
  },
  {
    value: "28066",
    label: "Xã Mỹ Phú",
    parent_code: "804",
  },
  {
    value: "29888",
    label: "Phường Mỹ Phú",
    parent_code: "866",
  },
  {
    value: "30472",
    label: "Xã Mỹ Phú",
    parent_code: "889",
  },
  {
    value: "30712",
    label: "Xã Mỹ Phú Đông",
    parent_code: "894",
  },
  {
    value: "13726",
    label: "Xã Mỹ Phúc",
    parent_code: "358",
  },
  {
    value: "25813",
    label: "Phường Mỹ Phước",
    parent_code: "721",
  },
  {
    value: "28321",
    label: "Thị trấn Mỹ Phước",
    parent_code: "818",
  },
  {
    value: "29626",
    label: "Xã Mỹ Phước",
    parent_code: "858",
  },
  {
    value: "30295",
    label: "Phường Mỹ Phước",
    parent_code: "883",
  },
  {
    value: "30847",
    label: "Xã Mỹ Phước",
    parent_code: "903",
  },
  {
    value: "31603",
    label: "Xã Mỹ Phước",
    parent_code: "944",
  },
  {
    value: "28447",
    label: "Xã Mỹ Phước Tây",
    parent_code: "817",
  },
  {
    value: "01927",
    label: "Xã Mỹ Phương",
    parent_code: "061",
  },
  {
    value: "21772",
    label: "Xã Mỹ Quang",
    parent_code: "545",
  },
  {
    value: "31753",
    label: "Xã Mỹ Quới",
    parent_code: "948",
  },
  {
    value: "30055",
    label: "Xã Mỹ Quý",
    parent_code: "872",
  },
  {
    value: "30298",
    label: "Phường Mỹ Quý",
    parent_code: "883",
  },
  {
    value: "27901",
    label: "Xã Mỹ Quý Đông",
    parent_code: "801",
  },
  {
    value: "27907",
    label: "Xã Mỹ Quý Tây",
    parent_code: "801",
  },
  {
    value: "17704",
    label: "Xã Mỹ Sơn",
    parent_code: "427",
  },
  {
    value: "22822",
    label: "Xã Mỹ Sơn",
    parent_code: "585",
  },
  {
    value: "21778",
    label: "Xã Mỹ Tài",
    parent_code: "545",
  },
  {
    value: "13723",
    label: "Xã Mỹ Tân",
    parent_code: "358",
  },
  {
    value: "15067",
    label: "Xã Mỹ Tân",
    parent_code: "389",
  },
  {
    value: "28378",
    label: "Xã Mỹ Tân",
    parent_code: "819",
  },
  {
    value: "29884",
    label: "Xã Mỹ Tân",
    parent_code: "866",
  },
  {
    value: "07420",
    label: "Xã Mỹ Thái",
    parent_code: "217",
  },
  {
    value: "30828",
    label: "Xã Mỹ Thái",
    parent_code: "903",
  },
  {
    value: "02011",
    label: "Xã Mỹ Thanh",
    parent_code: "063",
  },
  {
    value: "10456",
    label: "Xã Mỹ Thành",
    parent_code: "282",
  },
  {
    value: "05275",
    label: "Xã Mỹ Thành",
    parent_code: "157",
  },
  {
    value: "13738",
    label: "Xã Mỹ Thành",
    parent_code: "358",
  },
  {
    value: "17608",
    label: "Xã Mỹ Thành",
    parent_code: "426",
  },
  {
    value: "21766",
    label: "Xã Mỹ Thành",
    parent_code: "545",
  },
  {
    value: "23113",
    label: "Xã Mỹ Thạnh",
    parent_code: "598",
  },
  {
    value: "28051",
    label: "Xã Mỹ Thạnh",
    parent_code: "804",
  },
  {
    value: "28993",
    label: "Xã Mỹ Thạnh",
    parent_code: "834",
  },
  {
    value: "29131",
    label: "Xã Mỹ Thạnh",
    parent_code: "836",
  },
  {
    value: "30304",
    label: "Phường Mỹ Thạnh",
    parent_code: "883",
  },
  {
    value: "28792",
    label: "Xã Mỹ Thạnh An",
    parent_code: "829",
  },
  {
    value: "28441",
    label: "Xã Mỹ Thành Bắc",
    parent_code: "820",
  },
  {
    value: "27904",
    label: "Xã Mỹ Thạnh Bắc",
    parent_code: "801",
  },
  {
    value: "27913",
    label: "Xã Mỹ Thạnh Đông",
    parent_code: "801",
  },
  {
    value: "28456",
    label: "Xã Mỹ Thành Nam",
    parent_code: "820",
  },
  {
    value: "27910",
    label: "Xã Mỹ Thạnh Tây",
    parent_code: "801",
  },
  {
    value: "29755",
    label: "Xã Mỹ Thạnh Trung",
    parent_code: "860",
  },
  {
    value: "13717",
    label: "Xã Mỹ Thắng",
    parent_code: "358",
  },
  {
    value: "21742",
    label: "Xã Mỹ Thắng",
    parent_code: "545",
  },
  {
    value: "13735",
    label: "Xã Mỹ Thịnh",
    parent_code: "358",
  },
  {
    value: "21760",
    label: "Xã Mỹ Thọ",
    parent_code: "545",
  },
  {
    value: "30076",
    label: "Thị trấn Mỹ Thọ",
    parent_code: "873",
  },
  {
    value: "30100",
    label: "Xã Mỹ Thọ",
    parent_code: "873",
  },
  {
    value: "30301",
    label: "Phường Mỹ Thới",
    parent_code: "883",
  },
  {
    value: "08569",
    label: "Xã Mỹ Thuận",
    parent_code: "240",
  },
  {
    value: "13732",
    label: "Xã Mỹ Thuận",
    parent_code: "358",
  },
  {
    value: "29794",
    label: "Xã Mỹ Thuận",
    parent_code: "863",
  },
  {
    value: "30838",
    label: "Xã Mỹ Thuận",
    parent_code: "903",
  },
  {
    value: "31609",
    label: "Xã Mỹ Thuận",
    parent_code: "944",
  },
  {
    value: "19303",
    label: "Xã Mỹ Thủy",
    parent_code: "457",
  },
  {
    value: "13714",
    label: "Xã Mỹ Tiến",
    parent_code: "358",
  },
  {
    value: "28603",
    label: "Xã Mỹ Tịnh An",
    parent_code: "822",
  },
  {
    value: "29887",
    label: "Xã Mỹ Trà",
    parent_code: "866",
  },
  {
    value: "19120",
    label: "Xã Mỹ Trạch",
    parent_code: "455",
  },
  {
    value: "21757",
    label: "Xã Mỹ Trinh",
    parent_code: "545",
  },
  {
    value: "13720",
    label: "Xã Mỹ Trung",
    parent_code: "358",
  },
  {
    value: "28369",
    label: "Xã Mỹ Trung",
    parent_code: "819",
  },
  {
    value: "31597",
    label: "Xã Mỹ Tú",
    parent_code: "944",
  },
  {
    value: "13699",
    label: "Phường Mỹ Xá",
    parent_code: "356",
  },
  {
    value: "26719",
    label: "Phường Mỹ Xuân",
    parent_code: "754",
  },
  {
    value: "30286",
    label: "Phường Mỹ Xuyên",
    parent_code: "883",
  },
  {
    value: "31684",
    label: "Thị trấn Mỹ Xuyên",
    parent_code: "947",
  },
  {
    value: "30121",
    label: "Xã Mỹ Xương",
    parent_code: "873",
  },
  {
    value: "05836",
    label: "Xã Mỹ Yên",
    parent_code: "171",
  },
  {
    value: "28018",
    label: "Xã Mỹ Yên",
    parent_code: "803",
  },
  {
    value: "02902",
    label: "Thị trấn N.T Phong Hải",
    parent_code: "086",
  },
  {
    value: "24973",
    label: "Xã N'Thol Hạ",
    parent_code: "678",
  },
  {
    value: "03170",
    label: "Xã Nà Bủng",
    parent_code: "103",
  },
  {
    value: "01147",
    label: "Xã Nà Chì",
    parent_code: "033",
  },
  {
    value: "03167",
    label: "Xã Na Cô Sa",
    parent_code: "103",
  },
  {
    value: "06526",
    label: "Thị trấn Na Dương",
    parent_code: "188",
  },
  {
    value: "02221",
    label: "Thị trấn Na Hang",
    parent_code: "072",
  },
  {
    value: "04453",
    label: "Xã Nà Hẩu",
    parent_code: "136",
  },
  {
    value: "02875",
    label: "Xã Na Hối",
    parent_code: "085",
  },
  {
    value: "03169",
    label: "Xã Nà Hỳ",
    parent_code: "103",
  },
  {
    value: "00835",
    label: "Xã Na Khê",
    parent_code: "028",
  },
  {
    value: "03168",
    label: "Xã Nà Khoa",
    parent_code: "103",
  },
  {
    value: "01258",
    label: "Xã Nà Khương",
    parent_code: "035",
  },
  {
    value: "03151",
    label: "Phường Na Lay",
    parent_code: "095",
  },
  {
    value: "16834",
    label: "Xã Na Loi",
    parent_code: "417",
  },
  {
    value: "05782",
    label: "Xã Na Mao",
    parent_code: "171",
  },
  {
    value: "15013",
    label: "Xã Na Mèo",
    parent_code: "387",
  },
  {
    value: "04000",
    label: "Xã Nà Mường",
    parent_code: "123",
  },
  {
    value: "04198",
    label: "Xã Nà Nghịu",
    parent_code: "126",
  },
  {
    value: "16870",
    label: "Xã Na Ngoi",
    parent_code: "417",
  },
  {
    value: "03317",
    label: "Xã Nà Nhạn",
    parent_code: "094",
  },
  {
    value: "04162",
    label: "Xã Nà Ơt",
    parent_code: "125",
  },
  {
    value: "01936",
    label: "Thị trấn Nà Phặc",
    parent_code: "062",
  },
  {
    value: "05242",
    label: "Xã Nà Phòn",
    parent_code: "156",
  },
  {
    value: "04136",
    label: "Xã Nà Pó",
    parent_code: "125",
  },
  {
    value: "03201",
    label: "Xã Na Sang",
    parent_code: "097",
  },
  {
    value: "03283",
    label: "Xã Nà Sáy",
    parent_code: "099",
  },
  {
    value: "06124",
    label: "Thị trấn Na Sầm",
    parent_code: "182",
  },
  {
    value: "03205",
    label: "Xã Na Son",
    parent_code: "101",
  },
  {
    value: "03427",
    label: "Xã Nà Tăm",
    parent_code: "106",
  },
  {
    value: "03316",
    label: "Xã Nà Tấu",
    parent_code: "094",
  },
  {
    value: "03263",
    label: "Xã Nà Tòng",
    parent_code: "099",
  },
  {
    value: "03365",
    label: "Xã Na Tông",
    parent_code: "100",
  },
  {
    value: "03361",
    label: "Xã Na Ư",
    parent_code: "100",
  },
  {
    value: "20266",
    label: "Phường Nại Hiên Đông",
    parent_code: "493",
  },
  {
    value: "17941",
    label: "Xã Nam Anh",
    parent_code: "430",
  },
  {
    value: "24868",
    label: "Thị trấn Nam Ban",
    parent_code: "676",
  },
  {
    value: "13180",
    label: "Xã Nam Bình",
    parent_code: "343",
  },
  {
    value: "14338",
    label: "Phường Nam Bình",
    parent_code: "369",
  },
  {
    value: "24721",
    label: "Xã Nam Bình",
    parent_code: "665",
  },
  {
    value: "01296",
    label: "Xã Nam Cao",
    parent_code: "042",
  },
  {
    value: "13120",
    label: "Xã Nam Cao",
    parent_code: "343",
  },
  {
    value: "17983",
    label: "Xã Nam Cát",
    parent_code: "430",
  },
  {
    value: "26122",
    label: "Xã Nam Cát Tiên",
    parent_code: "734",
  },
  {
    value: "10627",
    label: "Xã Nam Chính",
    parent_code: "291",
  },
  {
    value: "13045",
    label: "Xã Nam Chính",
    parent_code: "342",
  },
  {
    value: "23206",
    label: "Xã Nam Chính",
    parent_code: "600",
  },
  {
    value: "02026",
    label: "Xã Nam Cường",
    parent_code: "064",
  },
  {
    value: "13036",
    label: "Xã Nam Cường",
    parent_code: "342",
  },
  {
    value: "13990",
    label: "Xã Nam Cường",
    parent_code: "362",
  },
  {
    value: "02671",
    label: "Phường Nam Cường",
    parent_code: "080",
  },
  {
    value: "04273",
    label: "Phường Nam Cường",
    parent_code: "132",
  },
  {
    value: "24649",
    label: "Xã Nam Dong",
    parent_code: "662",
  },
  {
    value: "31115",
    label: "Xã Nam Du",
    parent_code: "912",
  },
  {
    value: "07603",
    label: "Xã Nam Dương",
    parent_code: "219",
  },
  {
    value: "14002",
    label: "Xã Nam Dương",
    parent_code: "362",
  },
  {
    value: "20248",
    label: "Phường Nam Dương",
    parent_code: "492",
  },
  {
    value: "24697",
    label: "Xã Nam Đà",
    parent_code: "664",
  },
  {
    value: "17950",
    label: "Thị trấn Nam Đàn",
    parent_code: "430",
  },
  {
    value: "13963",
    label: "Xã Nam Điền",
    parent_code: "361",
  },
  {
    value: "18667",
    label: "Xã Nam Điền",
    parent_code: "445",
  },
  {
    value: "00208",
    label: "Phường Nam Đồng",
    parent_code: "006",
  },
  {
    value: "10672",
    label: "Phường Nam Đồng",
    parent_code: "288",
  },
  {
    value: "14917",
    label: "Xã Nam Động",
    parent_code: "385",
  },
  {
    value: "13966",
    label: "Thị trấn Nam Giang",
    parent_code: "362",
  },
  {
    value: "15505",
    label: "Xã Nam Giang",
    parent_code: "395",
  },
  {
    value: "17956",
    label: "Xã Nam Giang",
    parent_code: "430",
  },
  {
    value: "13054",
    label: "Xã Nam Hà",
    parent_code: "342",
  },
  {
    value: "18073",
    label: "Phường Nam Hà",
    parent_code: "436",
  },
  {
    value: "24925",
    label: "Xã Nam Hà",
    parent_code: "676",
  },
  {
    value: "11419",
    label: "Phường Nam Hải",
    parent_code: "306",
  },
  {
    value: "13069",
    label: "Xã Nam Hải",
    parent_code: "342",
  },
  {
    value: "14020",
    label: "Xã Nam Hải",
    parent_code: "362",
  },
  {
    value: "13999",
    label: "Xã Nam Hoa",
    parent_code: "362",
  },
  {
    value: "07165",
    label: "Phường Nam Hoà",
    parent_code: "206",
  },
  {
    value: "05707",
    label: "Xã Nam Hòa",
    parent_code: "169",
  },
  {
    value: "00469",
    label: "Xã Nam Hồng",
    parent_code: "017",
  },
  {
    value: "10651",
    label: "Xã Nam Hồng",
    parent_code: "291",
  },
  {
    value: "13063",
    label: "Xã Nam Hồng",
    parent_code: "342",
  },
  {
    value: "13993",
    label: "Xã Nam Hồng",
    parent_code: "362",
  },
  {
    value: "18118",
    label: "Phường Nam Hồng",
    parent_code: "437",
  },
  {
    value: "13996",
    label: "Xã Nam Hùng",
    parent_code: "362",
  },
  {
    value: "10609",
    label: "Xã Nam Hưng",
    parent_code: "291",
  },
  {
    value: "11806",
    label: "Xã Nam Hưng",
    parent_code: "315",
  },
  {
    value: "13066",
    label: "Xã Nam Hưng",
    parent_code: "342",
  },
  {
    value: "17932",
    label: "Xã Nam Hưng",
    parent_code: "430",
  },
  {
    value: "24607",
    label: "Xã Nam Ka",
    parent_code: "656",
  },
  {
    value: "06823",
    label: "Phường Nam Khê",
    parent_code: "196",
  },
  {
    value: "17998",
    label: "Xã Nam Kim",
    parent_code: "430",
  },
  {
    value: "17953",
    label: "Xã Nam Lĩnh",
    parent_code: "430",
  },
  {
    value: "14008",
    label: "Xã Nam Lợi",
    parent_code: "362",
  },
  {
    value: "18865",
    label: "Phường Nam Lý",
    parent_code: "450",
  },
  {
    value: "01909",
    label: "Xã Nam Mẫu",
    parent_code: "061",
  },
  {
    value: "13969",
    label: "Xã Nam Mỹ",
    parent_code: "362",
  },
  {
    value: "14761",
    label: "Phường Nam Ngạn",
    parent_code: "380",
  },
  {
    value: "17935",
    label: "Xã Nam Nghĩa",
    parent_code: "430",
  },
  {
    value: "25171",
    label: "Xã Nam Ninh",
    parent_code: "683",
  },
  {
    value: "10309",
    label: "Xã Nam Phong",
    parent_code: "280",
  },
  {
    value: "05119",
    label: "Xã Nam Phong",
    parent_code: "154",
  },
  {
    value: "13696",
    label: "Xã Nam Phong",
    parent_code: "356",
  },
  {
    value: "03973",
    label: "Xã Nam Phong",
    parent_code: "122",
  },
  {
    value: "13072",
    label: "Xã Nam Phú",
    parent_code: "342",
  },
  {
    value: "18712",
    label: "Xã Nam Phúc Thăng",
    parent_code: "446",
  },
  {
    value: "20599",
    label: "Thị trấn Nam Phước",
    parent_code: "508",
  },
  {
    value: "10069",
    label: "Xã Nam Phương Tiến",
    parent_code: "277",
  },
  {
    value: "06604",
    label: "Xã Nam Quan",
    parent_code: "188",
  },
  {
    value: "01297",
    label: "Xã Nam Quang",
    parent_code: "042",
  },
  {
    value: "10606",
    label: "Thị trấn Nam Sách",
    parent_code: "291",
  },
  {
    value: "00388",
    label: "Xã Nam Sơn",
    parent_code: "016",
  },
  {
    value: "01084",
    label: "Xã Nam Sơn",
    parent_code: "032",
  },
  {
    value: "09286",
    label: "Phường Nam Sơn",
    parent_code: "256",
  },
  {
    value: "11437",
    label: "Phường Nam Sơn",
    parent_code: "307",
  },
  {
    value: "11608",
    label: "Xã Nam Sơn",
    parent_code: "312",
  },
  {
    value: "06982",
    label: "Xã Nam Sơn",
    parent_code: "202",
  },
  {
    value: "14368",
    label: "Phường Nam Sơn",
    parent_code: "370",
  },
  {
    value: "17086",
    label: "Xã Nam Sơn",
    parent_code: "420",
  },
  {
    value: "17656",
    label: "Xã Nam Sơn",
    parent_code: "427",
  },
  {
    value: "10612",
    label: "Xã Nam Tân",
    parent_code: "291",
  },
  {
    value: "14023",
    label: "Xã Nam Thái",
    parent_code: "362",
  },
  {
    value: "17947",
    label: "Xã Nam Thái",
    parent_code: "430",
  },
  {
    value: "31000",
    label: "Xã Nam Thái",
    parent_code: "908",
  },
  {
    value: "31003",
    label: "Xã Nam Thái A",
    parent_code: "908",
  },
  {
    value: "30829",
    label: "Xã Nam Thái Sơn",
    parent_code: "903",
  },
  {
    value: "13057",
    label: "Xã Nam Thanh",
    parent_code: "342",
  },
  {
    value: "14005",
    label: "Xã Nam Thanh",
    parent_code: "362",
  },
  {
    value: "03139",
    label: "Phường Nam Thanh",
    parent_code: "094",
  },
  {
    value: "17938",
    label: "Xã Nam Thanh",
    parent_code: "430",
  },
  {
    value: "14341",
    label: "Phường Nam Thành",
    parent_code: "369",
  },
  {
    value: "17584",
    label: "Xã Nam Thành",
    parent_code: "426",
  },
  {
    value: "13042",
    label: "Xã Nam Thắng",
    parent_code: "342",
  },
  {
    value: "13978",
    label: "Xã Nam Thắng",
    parent_code: "362",
  },
  {
    value: "13051",
    label: "Xã Nam Thịnh",
    parent_code: "342",
  },
  {
    value: "05068",
    label: "Xã Nam Thượng",
    parent_code: "153",
  },
  {
    value: "10282",
    label: "Xã Nam Tiến",
    parent_code: "280",
  },
  {
    value: "05890",
    label: "Xã Nam Tiến",
    parent_code: "172",
  },
  {
    value: "14017",
    label: "Xã Nam Tiến",
    parent_code: "362",
  },
  {
    value: "14902",
    label: "Xã Nam Tiến",
    parent_code: "385",
  },
  {
    value: "13981",
    label: "Xã Nam Toàn",
    parent_code: "362",
  },
  {
    value: "19195",
    label: "Xã Nam Trạch",
    parent_code: "455",
  },
  {
    value: "10312",
    label: "Xã Nam Triều",
    parent_code: "280",
  },
  {
    value: "10633",
    label: "Xã Nam Trung",
    parent_code: "291",
  },
  {
    value: "13060",
    label: "Xã Nam Trung",
    parent_code: "342",
  },
  {
    value: "01660",
    label: "Xã Nam Tuấn",
    parent_code: "051",
  },
  {
    value: "13705",
    label: "Xã Nam Vân",
    parent_code: "356",
  },
  {
    value: "08755",
    label: "Phường Nam Viêm",
    parent_code: "244",
  },
  {
    value: "14914",
    label: "Xã Nam Xuân",
    parent_code: "385",
  },
  {
    value: "17944",
    label: "Xã Nam Xuân",
    parent_code: "430",
  },
  {
    value: "24692",
    label: "Xã Nam Xuân",
    parent_code: "664",
  },
  {
    value: "23695",
    label: "Xã Nam Yang",
    parent_code: "626",
  },
  {
    value: "30994",
    label: "Xã Nam Yên",
    parent_code: "908",
  },
  {
    value: "01129",
    label: "Xã Nàn Ma",
    parent_code: "033",
  },
  {
    value: "02800",
    label: "Xã Nàn Sán",
    parent_code: "084",
  },
  {
    value: "01099",
    label: "Xã Nàn Xỉn",
    parent_code: "033",
  },
  {
    value: "02836",
    label: "Xã Nàn Xín",
    parent_code: "084",
  },
  {
    value: "01054",
    label: "Xã Nàng Đôn",
    parent_code: "032",
  },
  {
    value: "31441",
    label: "Thị trấn Nàng Mau",
    parent_code: "935",
  },
  {
    value: "04834",
    label: "Xã Nánh Nghê",
    parent_code: "150",
  },
  {
    value: "32191",
    label: "Thị Trấn Năm Căn",
    parent_code: "971",
  },
  {
    value: "03312",
    label: "Xã Nặm Lịch",
    parent_code: "102",
  },
  {
    value: "02281",
    label: "Xã Năng Khả",
    parent_code: "072",
  },
  {
    value: "13672",
    label: "Phường Năng Tĩnh",
    parent_code: "356",
  },
  {
    value: "00811",
    label: "Xã Nậm Ban",
    parent_code: "027",
  },
  {
    value: "03502",
    label: "Xã Nậm Ban",
    parent_code: "112",
  },
  {
    value: "04633",
    label: "Xã Nậm Búng",
    parent_code: "140",
  },
  {
    value: "16873",
    label: "Xã Nậm Càn",
    parent_code: "417",
  },
  {
    value: "16837",
    label: "Xã Nậm Cắn",
    parent_code: "417",
  },
  {
    value: "03610",
    label: "Xã Nậm Cần",
    parent_code: "111",
  },
  {
    value: "03526",
    label: "Xã Nậm Cha",
    parent_code: "108",
  },
  {
    value: "03473",
    label: "Xã Nậm Chà",
    parent_code: "112",
  },
  {
    value: "02689",
    label: "Xã Nậm Chạc",
    parent_code: "082",
  },
  {
    value: "02770",
    label: "Xã Nậm Chảy",
    parent_code: "083",
  },
  {
    value: "03076",
    label: "Xã Nậm Chầy",
    parent_code: "089",
  },
  {
    value: "03173",
    label: "Xã Nậm Chua",
    parent_code: "103",
  },
  {
    value: "04462",
    label: "Xã Nậm Có",
    parent_code: "137",
  },
  {
    value: "03544",
    label: "Xã Nậm Cuổi",
    parent_code: "108",
  },
  {
    value: "01141",
    label: "Xã Nấm Dẩn",
    parent_code: "033",
  },
  {
    value: "01075",
    label: "Xã Nậm Dịch",
    parent_code: "032",
  },
  {
    value: "02884",
    label: "Xã Nậm Đét",
    parent_code: "085",
  },
  {
    value: "03712",
    label: "Xã Nậm ét",
    parent_code: "118",
  },
  {
    value: "16753",
    label: "Xã Nậm Giải",
    parent_code: "415",
  },
  {
    value: "03811",
    label: "Xã Nậm Giôn",
    parent_code: "120",
  },
  {
    value: "03475",
    label: "Xã Nậm Hàng",
    parent_code: "112",
  },
  {
    value: "03547",
    label: "Xã Nậm Hăn",
    parent_code: "108",
  },
  {
    value: "03162",
    label: "Xã Nậm Kè",
    parent_code: "096",
  },
  {
    value: "02887",
    label: "Xã Nậm Khánh",
    parent_code: "085",
  },
  {
    value: "03457",
    label: "Xã Nậm Khao",
    parent_code: "107",
  },
  {
    value: "03174",
    label: "Xã Nậm Khăn",
    parent_code: "103",
  },
  {
    value: "04495",
    label: "Xã Nậm Khắt",
    parent_code: "137",
  },
  {
    value: "01093",
    label: "Xã Nậm Khòa",
    parent_code: "032",
  },
  {
    value: "04648",
    label: "Xã Nậm Lành",
    parent_code: "140",
  },
  {
    value: "04237",
    label: "Xã Nậm Lạnh",
    parent_code: "127",
  },
  {
    value: "03790",
    label: "Xã Nậm Lầu",
    parent_code: "119",
  },
  {
    value: "02893",
    label: "Xã Nậm Lúc",
    parent_code: "085",
  },
  {
    value: "02773",
    label: "Xã Nấm Lư",
    parent_code: "083",
  },
  {
    value: "03067",
    label: "Xã Nậm Mả",
    parent_code: "089",
  },
  {
    value: "03535",
    label: "Xã Nậm Mạ",
    parent_code: "108",
  },
  {
    value: "03474",
    label: "Xã Nậm Manh",
    parent_code: "112",
  },
  {
    value: "04201",
    label: "Xã Nậm Mằn",
    parent_code: "126",
  },
  {
    value: "02881",
    label: "Xã Nậm Mòn",
    parent_code: "085",
  },
  {
    value: "04642",
    label: "Xã Nậm Mười",
    parent_code: "140",
  },
  {
    value: "24715",
    label: "Xã Nâm N'Đir",
    parent_code: "664",
  },
  {
    value: "24728",
    label: "Xã Nâm N'Jang",
    parent_code: "665",
  },
  {
    value: "03194",
    label: "Xã Nậm Nèn",
    parent_code: "097",
  },
  {
    value: "16768",
    label: "Xã Nậm Nhoóng",
    parent_code: "415",
  },
  {
    value: "03434",
    label: "Thị trấn Nậm Nhùn",
    parent_code: "112",
  },
  {
    value: "03171",
    label: "Xã Nậm Nhừ",
    parent_code: "103",
  },
  {
    value: "24703",
    label: "Xã Nâm Nung",
    parent_code: "664",
  },
  {
    value: "03826",
    label: "Xã Nậm Păm",
    parent_code: "120",
  },
  {
    value: "03488",
    label: "Xã Nậm Pì",
    parent_code: "112",
  },
  {
    value: "02740",
    label: "Xã Nậm Pung",
    parent_code: "082",
  },
  {
    value: "03073",
    label: "Xã Nậm Rạng",
    parent_code: "089",
  },
  {
    value: "03613",
    label: "Xã Nậm Sỏ",
    parent_code: "111",
  },
  {
    value: "03517",
    label: "Xã Nậm Tăm",
    parent_code: "108",
  },
  {
    value: "03109",
    label: "Xã Nậm Tha",
    parent_code: "089",
  },
  {
    value: "03156",
    label: "Xã Nậm Tin",
    parent_code: "103",
  },
  {
    value: "04186",
    label: "Xã Nậm Ty",
    parent_code: "126",
  },
  {
    value: "01087",
    label: "Xã Nậm Tỵ",
    parent_code: "032",
  },
  {
    value: "03161",
    label: "Xã Nậm Vì",
    parent_code: "096",
  },
  {
    value: "03121",
    label: "Xã Nậm Xây",
    parent_code: "089",
  },
  {
    value: "03586",
    label: "Xã Nậm Xe",
    parent_code: "109",
  },
  {
    value: "03085",
    label: "Xã Nậm Xé",
    parent_code: "089",
  },
  {
    value: "07795",
    label: "Thị trấn Nếnh",
    parent_code: "222",
  },
  {
    value: "16144",
    label: "Xã Nga An",
    parent_code: "401",
  },
  {
    value: "16120",
    label: "Xã Nga Bạch",
    parent_code: "401",
  },
  {
    value: "31340",
    label: "Phường Ngã Bảy",
    parent_code: "931",
  },
  {
    value: "16150",
    label: "Xã Nga Điền",
    parent_code: "401",
  },
  {
    value: "16135",
    label: "Xã Nga Giáp",
    parent_code: "401",
  },
  {
    value: "16138",
    label: "Xã Nga Hải",
    parent_code: "401",
  },
  {
    value: "08317",
    label: "Xã Nga Hoàng",
    parent_code: "234",
  },
  {
    value: "16159",
    label: "Xã Nga Liên",
    parent_code: "401",
  },
  {
    value: "05956",
    label: "Xã Nga My",
    parent_code: "173",
  },
  {
    value: "16903",
    label: "Xã Nga My",
    parent_code: "418",
  },
  {
    value: "16147",
    label: "Xã Nga Phú",
    parent_code: "401",
  },
  {
    value: "16114",
    label: "Xã Nga Phượng",
    parent_code: "401",
  },
  {
    value: "04528",
    label: "Xã Nga Quán",
    parent_code: "138",
  },
  {
    value: "31366",
    label: "Thị Trấn Ngã Sáu",
    parent_code: "933",
  },
  {
    value: "16093",
    label: "Thị trấn Nga Sơn",
    parent_code: "401",
  },
  {
    value: "16153",
    label: "Xã Nga Tân",
    parent_code: "401",
  },
  {
    value: "16165",
    label: "Xã Nga Thạch",
    parent_code: "401",
  },
  {
    value: "16162",
    label: "Xã Nga Thái",
    parent_code: "401",
  },
  {
    value: "16123",
    label: "Xã Nga Thanh",
    parent_code: "401",
  },
  {
    value: "16141",
    label: "Xã Nga Thành",
    parent_code: "401",
  },
  {
    value: "16168",
    label: "Xã Nga Thắng",
    parent_code: "401",
  },
  {
    value: "16105",
    label: "Xã Nga Thiện",
    parent_code: "401",
  },
  {
    value: "16156",
    label: "Xã Nga Thủy",
    parent_code: "401",
  },
  {
    value: "16108",
    label: "Xã Nga Tiến",
    parent_code: "401",
  },
  {
    value: "16117",
    label: "Xã Nga Trung",
    parent_code: "401",
  },
  {
    value: "16171",
    label: "Xã Nga Trường",
    parent_code: "401",
  },
  {
    value: "00235",
    label: "Phường Ngã Tư Sở",
    parent_code: "006",
  },
  {
    value: "16102",
    label: "Xã Nga Văn",
    parent_code: "401",
  },
  {
    value: "16099",
    label: "Xã Nga Vịnh",
    parent_code: "401",
  },
  {
    value: "16132",
    label: "Xã Nga Yên",
    parent_code: "401",
  },
  {
    value: "28975",
    label: "Xã Ngãi Đăng",
    parent_code: "833",
  },
  {
    value: "26575",
    label: "Thị trấn Ngãi Giao",
    parent_code: "750",
  },
  {
    value: "29368",
    label: "Xã Ngãi Hùng",
    parent_code: "846",
  },
  {
    value: "29764",
    label: "Xã Ngãi Tứ",
    parent_code: "860",
  },
  {
    value: "29479",
    label: "Xã Ngãi Xuyên",
    parent_code: "849",
  },
  {
    value: "01066",
    label: "Xã Ngàm Đăng Vài",
    parent_code: "032",
  },
  {
    value: "00856",
    label: "Xã Ngam La",
    parent_code: "028",
  },
  {
    value: "31843",
    label: "Thị trấn Ngan Dừa",
    parent_code: "956",
  },
  {
    value: "19273",
    label: "Xã Ngân Thủy",
    parent_code: "457",
  },
  {
    value: "18406",
    label: "Thị trấn Nghèn",
    parent_code: "443",
  },
  {
    value: "17914",
    label: "Xã Nghi Ân",
    parent_code: "412",
  },
  {
    value: "17884",
    label: "Xã Nghi Công Bắc",
    parent_code: "429",
  },
  {
    value: "17887",
    label: "Xã Nghi Công Nam",
    parent_code: "429",
  },
  {
    value: "17899",
    label: "Xã Nghi Diên",
    parent_code: "429",
  },
  {
    value: "17842",
    label: "Xã Nghi Đồng",
    parent_code: "429",
  },
  {
    value: "17923",
    label: "Xã Nghi Đức",
    parent_code: "412",
  },
  {
    value: "23158",
    label: "Xã Nghị Đức",
    parent_code: "599",
  },
  {
    value: "16729",
    label: "Phường Nghi Hải",
    parent_code: "413",
  },
  {
    value: "17875",
    label: "Xã Nghi Hoa",
    parent_code: "429",
  },
  {
    value: "16726",
    label: "Phường Nghi Hòa",
    parent_code: "413",
  },
  {
    value: "17839",
    label: "Xã Nghi Hưng",
    parent_code: "429",
  },
  {
    value: "16732",
    label: "Phường Nghi Hương",
    parent_code: "413",
  },
  {
    value: "17854",
    label: "Xã Nghi Kiều",
    parent_code: "429",
  },
  {
    value: "17920",
    label: "Xã Nghi Kim",
    parent_code: "412",
  },
  {
    value: "17848",
    label: "Xã Nghi Lâm",
    parent_code: "429",
  },
  {
    value: "17908",
    label: "Xã Nghi Liên",
    parent_code: "412",
  },
  {
    value: "17866",
    label: "Xã Nghi Long",
    parent_code: "429",
  },
  {
    value: "17857",
    label: "Xã Nghi Mỹ",
    parent_code: "429",
  },
  {
    value: "17902",
    label: "Xã Nghi Phong",
    parent_code: "429",
  },
  {
    value: "16702",
    label: "Xã Nghi Phú",
    parent_code: "412",
  },
  {
    value: "17860",
    label: "Xã Nghi Phương",
    parent_code: "429",
  },
  {
    value: "17851",
    label: "Xã Nghi Quang",
    parent_code: "429",
  },
  {
    value: "16657",
    label: "Xã Nghi Sơn",
    parent_code: "407",
  },
  {
    value: "16720",
    label: "Phường Nghi Tân",
    parent_code: "413",
  },
  {
    value: "17890",
    label: "Xã Nghi Thạch",
    parent_code: "429",
  },
  {
    value: "17926",
    label: "Xã Nghi Thái",
    parent_code: "429",
  },
  {
    value: "17845",
    label: "Xã Nghi Thiết",
    parent_code: "429",
  },
  {
    value: "17881",
    label: "Xã Nghi Thịnh",
    parent_code: "429",
  },
  {
    value: "16735",
    label: "Phường Nghi Thu",
    parent_code: "413",
  },
  {
    value: "17863",
    label: "Xã Nghi Thuận",
    parent_code: "429",
  },
  {
    value: "16717",
    label: "Phường Nghi Thuỷ",
    parent_code: "413",
  },
  {
    value: "17836",
    label: "Xã Nghi Tiến",
    parent_code: "429",
  },
  {
    value: "17893",
    label: "Xã Nghi Trung",
    parent_code: "429",
  },
  {
    value: "17896",
    label: "Xã Nghi Trường",
    parent_code: "429",
  },
  {
    value: "17911",
    label: "Xã Nghi Vạn",
    parent_code: "429",
  },
  {
    value: "17830",
    label: "Xã Nghi Văn",
    parent_code: "429",
  },
  {
    value: "17869",
    label: "Xã Nghi Xá",
    parent_code: "429",
  },
  {
    value: "17905",
    label: "Xã Nghi Xuân",
    parent_code: "429",
  },
  {
    value: "17833",
    label: "Xã Nghi Yên",
    parent_code: "429",
  },
  {
    value: "11164",
    label: "Xã Nghĩa An",
    parent_code: "299",
  },
  {
    value: "13975",
    label: "Xã Nghĩa An",
    parent_code: "362",
  },
  {
    value: "04300",
    label: "Xã Nghĩa An",
    parent_code: "133",
  },
  {
    value: "17023",
    label: "Xã Nghĩa An",
    parent_code: "419",
  },
  {
    value: "23662",
    label: "Xã Nghĩa An",
    parent_code: "625",
  },
  {
    value: "21262",
    label: "Xã Nghĩa An",
    parent_code: "522",
  },
  {
    value: "13933",
    label: "Xã Nghĩa Bình",
    parent_code: "361",
  },
  {
    value: "16960",
    label: "Xã Nghĩa Bình",
    parent_code: "419",
  },
  {
    value: "17281",
    label: "Xã Nghĩa Bình",
    parent_code: "423",
  },
  {
    value: "25424",
    label: "Xã Nghĩa Bình",
    parent_code: "696",
  },
  {
    value: "21019",
    label: "Phường Nghĩa Chánh",
    parent_code: "522",
  },
  {
    value: "13912",
    label: "Xã Nghĩa Châu",
    parent_code: "361",
  },
  {
    value: "12283",
    label: "Xã Nghĩa Dân",
    parent_code: "331",
  },
  {
    value: "21037",
    label: "Xã Nghĩa Dõng",
    parent_code: "522",
  },
  {
    value: "17308",
    label: "Xã Nghĩa Dũng",
    parent_code: "423",
  },
  {
    value: "21034",
    label: "Xã Nghĩa Dũng",
    parent_code: "522",
  },
  {
    value: "16941",
    label: "Thị trấn Nghĩa Đàn",
    parent_code: "419",
  },
  {
    value: "09448",
    label: "Xã Nghĩa Đạo",
    parent_code: "262",
  },
  {
    value: "21271",
    label: "Xã Nghĩa Điền",
    parent_code: "528",
  },
  {
    value: "00157",
    label: "Phường Nghĩa Đô",
    parent_code: "005",
  },
  {
    value: "02953",
    label: "Xã Nghĩa Đô",
    parent_code: "087",
  },
  {
    value: "13897",
    label: "Xã Nghĩa Đồng",
    parent_code: "361",
  },
  {
    value: "17284",
    label: "Xã Nghĩa Đồng",
    parent_code: "423",
  },
  {
    value: "17020",
    label: "Xã Nghĩa Đức",
    parent_code: "419",
  },
  {
    value: "24611",
    label: "Phường Nghĩa Đức",
    parent_code: "660",
  },
  {
    value: "21256",
    label: "Xã Nghĩa Hà",
    parent_code: "522",
  },
  {
    value: "13957",
    label: "Xã Nghĩa Hải",
    parent_code: "361",
  },
  {
    value: "17326",
    label: "Xã Nghĩa Hành",
    parent_code: "423",
  },
  {
    value: "12058",
    label: "Xã Nghĩa Hiệp",
    parent_code: "327",
  },
  {
    value: "21280",
    label: "Xã Nghĩa Hiệp",
    parent_code: "528",
  },
  {
    value: "16996",
    label: "Xã Nghĩa Hiếu",
    parent_code: "419",
  },
  {
    value: "07378",
    label: "Xã Nghĩa Hòa",
    parent_code: "217",
  },
  {
    value: "23755",
    label: "Xã Nghĩa Hòa",
    parent_code: "627",
  },
  {
    value: "21268",
    label: "Xã Nghĩa Hòa",
    parent_code: "528",
  },
  {
    value: "17296",
    label: "Xã Nghĩa Hoàn",
    parent_code: "423",
  },
  {
    value: "16984",
    label: "Xã Nghĩa Hội",
    parent_code: "419",
  },
  {
    value: "13924",
    label: "Xã Nghĩa Hồng",
    parent_code: "361",
  },
  {
    value: "16975",
    label: "Xã Nghĩa Hồng",
    parent_code: "419",
  },
  {
    value: "17293",
    label: "Xã Nghĩa Hợp",
    parent_code: "423",
  },
  {
    value: "13942",
    label: "Xã Nghĩa Hùng",
    parent_code: "361",
  },
  {
    value: "09088",
    label: "Xã Nghĩa Hưng",
    parent_code: "252",
  },
  {
    value: "07381",
    label: "Xã Nghĩa Hưng",
    parent_code: "217",
  },
  {
    value: "16972",
    label: "Xã Nghĩa Hưng",
    parent_code: "419",
  },
  {
    value: "23761",
    label: "Xã Nghĩa Hưng",
    parent_code: "627",
  },
  {
    value: "09928",
    label: "Xã Nghĩa Hương",
    parent_code: "275",
  },
  {
    value: "17032",
    label: "Xã Nghĩa Khánh",
    parent_code: "419",
  },
  {
    value: "21250",
    label: "Xã Nghĩa Kỳ",
    parent_code: "528",
  },
  {
    value: "13921",
    label: "Xã Nghĩa Lạc",
    parent_code: "361",
  },
  {
    value: "16948",
    label: "Xã Nghĩa Lạc",
    parent_code: "419",
  },
  {
    value: "13945",
    label: "Xã Nghĩa Lâm",
    parent_code: "361",
  },
  {
    value: "16951",
    label: "Xã Nghĩa Lâm",
    parent_code: "419",
  },
  {
    value: "21241",
    label: "Xã Nghĩa Lâm",
    parent_code: "528",
  },
  {
    value: "17026",
    label: "Xã Nghĩa Long",
    parent_code: "419",
  },
  {
    value: "11920",
    label: "Xã Nghĩa Lộ",
    parent_code: "317",
  },
  {
    value: "04624",
    label: "Xã Nghĩa Lộ",
    parent_code: "133",
  },
  {
    value: "21028",
    label: "Phường Nghĩa Lộ",
    parent_code: "522",
  },
  {
    value: "17029",
    label: "Xã Nghĩa Lộc",
    parent_code: "419",
  },
  {
    value: "13954",
    label: "Xã Nghĩa Lợi",
    parent_code: "361",
  },
  {
    value: "04294",
    label: "Xã Nghĩa Lợi",
    parent_code: "133",
  },
  {
    value: "16957",
    label: "Xã Nghĩa Lợi",
    parent_code: "419",
  },
  {
    value: "16942",
    label: "Xã Nghĩa Mai",
    parent_code: "419",
  },
  {
    value: "13903",
    label: "Xã Nghĩa Minh",
    parent_code: "361",
  },
  {
    value: "16966",
    label: "Xã Nghĩa Minh",
    parent_code: "419",
  },
  {
    value: "17008",
    label: "Xã Nghĩa Mỹ",
    parent_code: "414",
  },
  {
    value: "21286",
    label: "Xã Nghĩa Mỹ",
    parent_code: "528",
  },
  {
    value: "18892",
    label: "Xã Nghĩa Ninh",
    parent_code: "450",
  },
  {
    value: "13927",
    label: "Xã Nghĩa Phong",
    parent_code: "361",
  },
  {
    value: "13930",
    label: "Xã Nghĩa Phú",
    parent_code: "361",
  },
  {
    value: "16969",
    label: "Xã Nghĩa Phú",
    parent_code: "419",
  },
  {
    value: "24614",
    label: "Phường Nghĩa Phú",
    parent_code: "660",
  },
  {
    value: "21253",
    label: "Xã Nghĩa Phú",
    parent_code: "522",
  },
  {
    value: "04297",
    label: "Xã Nghĩa Phúc",
    parent_code: "133",
  },
  {
    value: "17299",
    label: "Xã Nghĩa Phúc",
    parent_code: "423",
  },
  {
    value: "07486",
    label: "Xã Nghĩa Phương",
    parent_code: "218",
  },
  {
    value: "21283",
    label: "Xã Nghĩa Phương",
    parent_code: "528",
  },
  {
    value: "13918",
    label: "Xã Nghĩa Sơn",
    parent_code: "361",
  },
  {
    value: "04666",
    label: "Xã Nghĩa Sơn",
    parent_code: "140",
  },
  {
    value: "16954",
    label: "Xã Nghĩa Sơn",
    parent_code: "419",
  },
  {
    value: "21259",
    label: "Xã Nghĩa Sơn",
    parent_code: "528",
  },
  {
    value: "02071",
    label: "Xã Nghĩa Tá",
    parent_code: "064",
  },
  {
    value: "04711",
    label: "Xã Nghĩa Tâm",
    parent_code: "140",
  },
  {
    value: "00160",
    label: "Phường Nghĩa Tân",
    parent_code: "005",
  },
  {
    value: "13939",
    label: "Xã Nghĩa Tân",
    parent_code: "361",
  },
  {
    value: "24615",
    label: "Phường Nghĩa Tân",
    parent_code: "660",
  },
  {
    value: "13906",
    label: "Xã Nghĩa Thái",
    parent_code: "361",
  },
  {
    value: "17290",
    label: "Xã Nghĩa Thái",
    parent_code: "423",
  },
  {
    value: "13948",
    label: "Xã Nghĩa Thành",
    parent_code: "361",
  },
  {
    value: "16987",
    label: "Xã Nghĩa Thành",
    parent_code: "419",
  },
  {
    value: "26617",
    label: "Xã Nghĩa Thành",
    parent_code: "750",
  },
  {
    value: "24612",
    label: "Phường Nghĩa Thành",
    parent_code: "660",
  },
  {
    value: "24756",
    label: "Xã Nghĩa Thắng",
    parent_code: "666",
  },
  {
    value: "21244",
    label: "Xã Nghĩa Thắng",
    parent_code: "528",
  },
  {
    value: "13900",
    label: "Xã Nghĩa Thịnh",
    parent_code: "361",
  },
  {
    value: "16978",
    label: "Xã Nghĩa Thịnh",
    parent_code: "419",
  },
  {
    value: "16963",
    label: "Xã Nghĩa Thọ",
    parent_code: "419",
  },
  {
    value: "00880",
    label: "Xã Nghĩa Thuận",
    parent_code: "029",
  },
  {
    value: "17014",
    label: "Xã Nghĩa Thuận",
    parent_code: "414",
  },
  {
    value: "21247",
    label: "Xã Nghĩa Thuận",
    parent_code: "528",
  },
  {
    value: "21274",
    label: "Xã Nghĩa Thương",
    parent_code: "528",
  },
  {
    value: "17005",
    label: "Xã Nghĩa Tiến",
    parent_code: "414",
  },
  {
    value: "12031",
    label: "Xã Nghĩa Trụ",
    parent_code: "326",
  },
  {
    value: "07765",
    label: "Xã Nghĩa Trung",
    parent_code: "222",
  },
  {
    value: "13915",
    label: "Xã Nghĩa Trung",
    parent_code: "361",
  },
  {
    value: "16981",
    label: "Xã Nghĩa Trung",
    parent_code: "419",
  },
  {
    value: "25423",
    label: "Xã Nghĩa Trung",
    parent_code: "696",
  },
  {
    value: "24617",
    label: "Phường Nghĩa Trung",
    parent_code: "660",
  },
  {
    value: "21277",
    label: "Xã Nghĩa Trung",
    parent_code: "528",
  },
  {
    value: "11401",
    label: "Phường Nghĩa Xá",
    parent_code: "305",
  },
  {
    value: "17074",
    label: "Xã Nghĩa Xuân",
    parent_code: "420",
  },
  {
    value: "16945",
    label: "Xã Nghĩa Yên",
    parent_code: "419",
  },
  {
    value: "10255",
    label: "Xã Nghiêm Xuyên",
    parent_code: "279",
  },
  {
    value: "01882",
    label: "Xã Nghiên Loan",
    parent_code: "060",
  },
  {
    value: "05722",
    label: "Xã Nghinh Tường",
    parent_code: "170",
  },
  {
    value: "29503",
    label: "Xã Ngọc Biên",
    parent_code: "849",
  },
  {
    value: "32186",
    label: "Xã Ngọc Chánh",
    parent_code: "970",
  },
  {
    value: "04729",
    label: "Xã Ngọc Chấn",
    parent_code: "141",
  },
  {
    value: "10513",
    label: "Phường Ngọc Châu",
    parent_code: "288",
  },
  {
    value: "07348",
    label: "Xã Ngọc Châu",
    parent_code: "216",
  },
  {
    value: "03820",
    label: "Xã Ngọc Chiến",
    parent_code: "120",
  },
  {
    value: "30928",
    label: "Xã Ngọc Chúc",
    parent_code: "906",
  },
  {
    value: "01481",
    label: "Xã Ngọc Côn",
    parent_code: "047",
  },
  {
    value: "01438",
    label: "Xã Ngọc Đào",
    parent_code: "045",
  },
  {
    value: "26224",
    label: "Xã Ngọc Định",
    parent_code: "736",
  },
  {
    value: "31711",
    label: "Xã Ngọc Đông",
    parent_code: "947",
  },
  {
    value: "08338",
    label: "Xã Ngọc Đồng",
    parent_code: "234",
  },
  {
    value: "01378",
    label: "Xã Ngọc Động",
    parent_code: "045",
  },
  {
    value: "01618",
    label: "Xã Ngọc Động",
    parent_code: "049",
  },
  {
    value: "00700",
    label: "Xã Ngọc Đường",
    parent_code: "024",
  },
  {
    value: "00016",
    label: "Phường Ngọc Hà",
    parent_code: "001",
  },
  {
    value: "00692",
    label: "Phường Ngọc Hà",
    parent_code: "024",
  },
  {
    value: "22336",
    label: "Phường Ngọc Hiệp",
    parent_code: "568",
  },
  {
    value: "30950",
    label: "Xã Ngọc Hoà",
    parent_code: "906",
  },
  {
    value: "10042",
    label: "Xã Ngọc Hòa",
    parent_code: "277",
  },
  {
    value: "00673",
    label: "Xã Ngọc Hồi",
    parent_code: "020",
  },
  {
    value: "02329",
    label: "Xã Ngọc Hội",
    parent_code: "073",
  },
  {
    value: "00025",
    label: "Phường Ngọc Khánh",
    parent_code: "001",
  },
  {
    value: "01480",
    label: "Xã Ngọc Khê",
    parent_code: "047",
  },
  {
    value: "11089",
    label: "Xã Ngọc Kỳ",
    parent_code: "298",
  },
  {
    value: "15061",
    label: "Thị Trấn Ngọc Lặc",
    parent_code: "389",
  },
  {
    value: "00133",
    label: "Phường Ngọc Lâm",
    parent_code: "004",
  },
  {
    value: "12136",
    label: "Xã Ngọc Lâm",
    parent_code: "328",
  },
  {
    value: "17759",
    label: "Xã Ngọc Lâm",
    parent_code: "428",
  },
  {
    value: "08335",
    label: "Xã Ngọc Lập",
    parent_code: "234",
  },
  {
    value: "05350",
    label: "Xã Ngọc Lâu",
    parent_code: "157",
  },
  {
    value: "23404",
    label: "Xã Ngọc Lây",
    parent_code: "617",
  },
  {
    value: "10903",
    label: "Xã Ngọc Liên",
    parent_code: "295",
  },
  {
    value: "15091",
    label: "Xã Ngọc Liên",
    parent_code: "389",
  },
  {
    value: "09907",
    label: "Xã Ngọc Liệp",
    parent_code: "275",
  },
  {
    value: "00970",
    label: "Xã Ngọc Linh",
    parent_code: "030",
  },
  {
    value: "23365",
    label: "Xã Ngọc Linh",
    parent_code: "610",
  },
  {
    value: "16582",
    label: "Xã Ngọc Lĩnh",
    parent_code: "407",
  },
  {
    value: "00859",
    label: "Xã Ngọc Long",
    parent_code: "028",
  },
  {
    value: "12064",
    label: "Xã Ngọc Long",
    parent_code: "327",
  },
  {
    value: "13519",
    label: "Xã Ngọc Lũ",
    parent_code: "352",
  },
  {
    value: "05389",
    label: "Xã Ngọc Lương",
    parent_code: "158",
  },
  {
    value: "07363",
    label: "Xã Ngọc Lý",
    parent_code: "216",
  },
  {
    value: "00973",
    label: "Xã Ngọc Minh",
    parent_code: "030",
  },
  {
    value: "09910",
    label: "Xã Ngọc Mỹ",
    parent_code: "275",
  },
  {
    value: "08767",
    label: "Xã Ngọc Mỹ",
    parent_code: "246",
  },
  {
    value: "05170",
    label: "Xã Ngọc Mỹ",
    parent_code: "155",
  },
  {
    value: "02053",
    label: "Xã Ngọc Phái",
    parent_code: "064",
  },
  {
    value: "15655",
    label: "Xã Ngọc Phụng",
    parent_code: "396",
  },
  {
    value: "08008",
    label: "Xã Ngọc Quan",
    parent_code: "230",
  },
  {
    value: "11077",
    label: "Xã Ngọc Sơn",
    parent_code: "288",
  },
  {
    value: "11440",
    label: "Phường Ngọc Sơn",
    parent_code: "307",
  },
  {
    value: "05329",
    label: "Xã Ngọc Sơn",
    parent_code: "157",
  },
  {
    value: "07831",
    label: "Xã Ngọc Sơn",
    parent_code: "223",
  },
  {
    value: "13423",
    label: "Xã Ngọc Sơn",
    parent_code: "350",
  },
  {
    value: "15094",
    label: "Xã Ngọc Sơn",
    parent_code: "389",
  },
  {
    value: "17146",
    label: "Xã Ngọc Sơn",
    parent_code: "421",
  },
  {
    value: "17635",
    label: "Xã Ngọc Sơn",
    parent_code: "427",
  },
  {
    value: "17767",
    label: "Xã Ngọc Sơn",
    parent_code: "428",
  },
  {
    value: "18565",
    label: "Xã Ngọc Sơn",
    parent_code: "445",
  },
  {
    value: "09766",
    label: "Xã Ngọc Tảo",
    parent_code: "272",
  },
  {
    value: "08749",
    label: "Xã Ngọc Thanh",
    parent_code: "244",
  },
  {
    value: "12322",
    label: "Xã Ngọc Thanh",
    parent_code: "331",
  },
  {
    value: "30925",
    label: "Xã Ngọc Thành",
    parent_code: "906",
  },
  {
    value: "07360",
    label: "Xã Ngọc Thiện",
    parent_code: "216",
  },
  {
    value: "30931",
    label: "Xã Ngọc Thuận",
    parent_code: "906",
  },
  {
    value: "00118",
    label: "Phường Ngọc Thụy",
    parent_code: "004",
  },
  {
    value: "31723",
    label: "Xã Ngọc Tố",
    parent_code: "947",
  },
  {
    value: "14779",
    label: "Phường Ngọc Trạo",
    parent_code: "380",
  },
  {
    value: "14818",
    label: "Phường Ngọc Trạo",
    parent_code: "381",
  },
  {
    value: "15268",
    label: "Xã Ngọc Trạo",
    parent_code: "391",
  },
  {
    value: "15103",
    label: "Xã Ngọc Trung",
    parent_code: "389",
  },
  {
    value: "07351",
    label: "Xã Ngọc Vân",
    parent_code: "216",
  },
  {
    value: "07027",
    label: "Xã Ngọc Vừng",
    parent_code: "203",
  },
  {
    value: "09289",
    label: "Xã Ngọc Xá",
    parent_code: "259",
  },
  {
    value: "01279",
    label: "Phường Ngọc Xuân",
    parent_code: "040",
  },
  {
    value: "11455",
    label: "Phường Ngọc Xuyên",
    parent_code: "308",
  },
  {
    value: "23413",
    label: "Xã Ngọc Yêu",
    parent_code: "617",
  },
  {
    value: "04408",
    label: "Xã Ngòi A",
    parent_code: "136",
  },
  {
    value: "23317",
    label: "Xã Ngọk Bay",
    parent_code: "608",
  },
  {
    value: "23518",
    label: "Xã Ngok Réo",
    parent_code: "615",
  },
  {
    value: "23464",
    label: "Xã Ngok Tem",
    parent_code: "613",
  },
  {
    value: "23428",
    label: "Xã Ngọk Tụ",
    parent_code: "612",
  },
  {
    value: "23515",
    label: "Xã Ngok Wang",
    parent_code: "615",
  },
  {
    value: "14149",
    label: "Thị trấn Ngô Đồng",
    parent_code: "365",
  },
  {
    value: "05194",
    label: "Xã Ngổ Luông",
    parent_code: "155",
  },
  {
    value: "23296",
    label: "Phường Ngô Mây",
    parent_code: "608",
  },
  {
    value: "23633",
    label: "Phường Ngô Mây",
    parent_code: "623",
  },
  {
    value: "21577",
    label: "Phường Ngô Mây",
    parent_code: "540",
  },
  {
    value: "21853",
    label: "Thị trấn Ngô Mây",
    parent_code: "548",
  },
  {
    value: "09580",
    label: "Phường Ngô Quyền",
    parent_code: "269",
  },
  {
    value: "08719",
    label: "Phường Ngô Quyền",
    parent_code: "243",
  },
  {
    value: "11248",
    label: "Xã Ngô Quyền",
    parent_code: "300",
  },
  {
    value: "12343",
    label: "Xã Ngô Quyền",
    parent_code: "332",
  },
  {
    value: "07207",
    label: "Phường Ngô Quyền",
    parent_code: "213",
  },
  {
    value: "13663",
    label: "Phường Ngô Quyền",
    parent_code: "356",
  },
  {
    value: "08350",
    label: "Xã Ngô Xá",
    parent_code: "235",
  },
  {
    value: "03287",
    label: "Xã Ngối Cáy",
    parent_code: "102",
  },
  {
    value: "03004",
    label: "Xã Ngũ Chỉ Sơn",
    parent_code: "088",
  },
  {
    value: "11731",
    label: "Xã Ngũ Đoan",
    parent_code: "314",
  },
  {
    value: "00667",
    label: "Xã Ngũ Hiệp",
    parent_code: "020",
  },
  {
    value: "28516",
    label: "Xã Ngũ Hiệp",
    parent_code: "820",
  },
  {
    value: "11275",
    label: "Xã Ngũ Hùng",
    parent_code: "300",
  },
  {
    value: "09148",
    label: "Xã Ngũ Kiên",
    parent_code: "252",
  },
  {
    value: "29530",
    label: "Xã Ngũ Lạc",
    parent_code: "850",
  },
  {
    value: "01672",
    label: "Xã Ngũ Lão",
    parent_code: "051",
  },
  {
    value: "11539",
    label: "Xã Ngũ Lão",
    parent_code: "311",
  },
  {
    value: "10777",
    label: "Xã Ngũ Phúc",
    parent_code: "293",
  },
  {
    value: "11710",
    label: "Xã Ngũ Phúc",
    parent_code: "314",
  },
  {
    value: "23272",
    label: "Xã Ngũ Phụng",
    parent_code: "602",
  },
  {
    value: "09439",
    label: "Xã Ngũ Thái",
    parent_code: "262",
  },
  {
    value: "26526",
    label: "Phường Nguyễn An Ninh",
    parent_code: "747",
  },
  {
    value: "01726",
    label: "Thị trấn Nguyên Bình",
    parent_code: "052",
  },
  {
    value: "16609",
    label: "Phường Nguyên Bình",
    parent_code: "407",
  },
  {
    value: "26758",
    label: "Phường Nguyễn Cư Trinh",
    parent_code: "760",
  },
  {
    value: "00241",
    label: "Phường Nguyễn Du",
    parent_code: "007",
  },
  {
    value: "13651",
    label: "Phường Nguyễn Du",
    parent_code: "356",
  },
  {
    value: "18077",
    label: "Phường Nguyễn Du",
    parent_code: "436",
  },
  {
    value: "11146",
    label: "Xã Nguyên Giáp",
    parent_code: "298",
  },
  {
    value: "12427",
    label: "Xã Nguyên Hòa",
    parent_code: "333",
  },
  {
    value: "32188",
    label: "Xã Nguyễn Huân",
    parent_code: "970",
  },
  {
    value: "01699",
    label: "Xã Nguyễn Huệ",
    parent_code: "051",
  },
  {
    value: "07099",
    label: "Xã Nguyễn Huệ",
    parent_code: "205",
  },
  {
    value: "00466",
    label: "Xã Nguyên Khê",
    parent_code: "017",
  },
  {
    value: "13570",
    label: "Xã Nguyên Lý",
    parent_code: "353",
  },
  {
    value: "21025",
    label: "Phường Nguyễn Nghiêm",
    parent_code: "522",
  },
  {
    value: "21439",
    label: "Phường Nguyễn Nghiêm",
    parent_code: "534",
  },
  {
    value: "32053",
    label: "Xã Nguyễn Phích",
    parent_code: "966",
  },
  {
    value: "01999",
    label: "Xã Nguyên Phúc",
    parent_code: "063",
  },
  {
    value: "04264",
    label: "Phường Nguyễn Phúc",
    parent_code: "132",
  },
  {
    value: "26746",
    label: "Phường Nguyễn Thái Bình",
    parent_code: "760",
  },
  {
    value: "04258",
    label: "Phường Nguyễn Thái Học",
    parent_code: "132",
  },
  {
    value: "01834",
    label: "Phường Nguyễn Thị Minh Khai",
    parent_code: "058",
  },
  {
    value: "09538",
    label: "Phường Nguyễn Trãi",
    parent_code: "268",
  },
  {
    value: "10231",
    label: "Xã Nguyễn Trãi",
    parent_code: "279",
  },
  {
    value: "00694",
    label: "Phường Nguyễn Trãi",
    parent_code: "024",
  },
  {
    value: "10519",
    label: "Phường Nguyễn Trãi",
    parent_code: "288",
  },
  {
    value: "12184",
    label: "Xã Nguyễn Trãi",
    parent_code: "329",
  },
  {
    value: "23305",
    label: "Phường Nguyễn Trãi",
    parent_code: "608",
  },
  {
    value: "00010",
    label: "Phường Nguyễn Trung Trực",
    parent_code: "001",
  },
  {
    value: "13387",
    label: "Xã Nguyễn Úy",
    parent_code: "350",
  },
  {
    value: "21592",
    label: "Phường Nguyễn Văn Cừ",
    parent_code: "540",
  },
  {
    value: "29788",
    label: "Xã Nguyễn Văn Thảnh",
    parent_code: "863",
  },
  {
    value: "32230",
    label: "Xã Nguyễn Việt Khái",
    parent_code: "972",
  },
  {
    value: "12730",
    label: "Xã Nguyên Xá",
    parent_code: "340",
  },
  {
    value: "13261",
    label: "Xã Nguyên Xá",
    parent_code: "344",
  },
  {
    value: "15115",
    label: "Xã Nguyệt Ấn",
    parent_code: "389",
  },
  {
    value: "09052",
    label: "Xã Nguyệt Đức",
    parent_code: "251",
  },
  {
    value: "09442",
    label: "Xã Nguyệt Đức",
    parent_code: "262",
  },
  {
    value: "29395",
    label: "Xã Nguyệt Hóa",
    parent_code: "847",
  },
  {
    value: "18979",
    label: "Xã Ngư Hóa",
    parent_code: "453",
  },
  {
    value: "16090",
    label: "Xã Ngư Lộc",
    parent_code: "400",
  },
  {
    value: "19306",
    label: "Xã Ngư Thủy ",
    parent_code: "457",
  },
  {
    value: "19255",
    label: "Xã Ngư Thủy Bắc",
    parent_code: "457",
  },
  {
    value: "30502",
    label: "Thị trấn Nhà Bàng",
    parent_code: "890",
  },
  {
    value: "27643",
    label: "Thị trấn Nhà Bè",
    parent_code: "786",
  },
  {
    value: "25450",
    label: "Xã Nha Bích",
    parent_code: "697",
  },
  {
    value: "05938",
    label: "Xã Nhã Lộng",
    parent_code: "173",
  },
  {
    value: "31831",
    label: "Phường Nhà Mát",
    parent_code: "954",
  },
  {
    value: "07306",
    label: "Thị trấn Nhã Nam",
    parent_code: "216",
  },
  {
    value: "06181",
    label: "Xã Nhạc Kỳ",
    parent_code: "182",
  },
  {
    value: "07681",
    label: "Thị trấn Nham Biền",
    parent_code: "221",
  },
  {
    value: "01861",
    label: "Xã Nhạn Môn",
    parent_code: "060",
  },
  {
    value: "08821",
    label: "Xã Nhạo Sơn",
    parent_code: "253",
  },
  {
    value: "13618",
    label: "Xã Nhân Bình",
    parent_code: "353",
  },
  {
    value: "00343",
    label: "Phường Nhân Chính",
    parent_code: "009",
  },
  {
    value: "13615",
    label: "Xã Nhân Chính",
    parent_code: "353",
  },
  {
    value: "24751",
    label: "Xã Nhân Cơ",
    parent_code: "666",
  },
  {
    value: "08803",
    label: "Xã Nhân Đạo",
    parent_code: "253",
  },
  {
    value: "24766",
    label: "Xã Nhân Đạo",
    parent_code: "666",
  },
  {
    value: "11863",
    label: "Xã Nhân Hoà",
    parent_code: "316",
  },
  {
    value: "09259",
    label: "Xã Nhân Hòa",
    parent_code: "259",
  },
  {
    value: "12118",
    label: "Phường Nhân Hòa",
    parent_code: "328",
  },
  {
    value: "10591",
    label: "Xã Nhân Huệ",
    parent_code: "290",
  },
  {
    value: "13606",
    label: "Xã Nhân Khang",
    parent_code: "353",
  },
  {
    value: "12307",
    label: "Xã Nhân La",
    parent_code: "331",
  },
  {
    value: "06496",
    label: "Xã Nhân Lý",
    parent_code: "187",
  },
  {
    value: "02362",
    label: "Xã Nhân Lý",
    parent_code: "073",
  },
  {
    value: "02410",
    label: "Xã Nhân Mục",
    parent_code: "074",
  },
  {
    value: "05182",
    label: "Xã Nhân Mỹ",
    parent_code: "155",
  },
  {
    value: "13609",
    label: "Xã Nhân Mỹ",
    parent_code: "353",
  },
  {
    value: "05290",
    label: "Xã Nhân Nghĩa",
    parent_code: "157",
  },
  {
    value: "13612",
    label: "Xã Nhân Nghĩa",
    parent_code: "353",
  },
  {
    value: "26335",
    label: "Xã Nhân Nghĩa",
    parent_code: "739",
  },
  {
    value: "10987",
    label: "Xã Nhân Quyền",
    parent_code: "296",
  },
  {
    value: "17698",
    label: "Xã Nhân Sơn",
    parent_code: "427",
  },
  {
    value: "17572",
    label: "Xã Nhân Thành",
    parent_code: "426",
  },
  {
    value: "09481",
    label: "Xã Nhân Thắng",
    parent_code: "263",
  },
  {
    value: "13600",
    label: "Xã Nhân Thịnh",
    parent_code: "353",
  },
  {
    value: "19189",
    label: "Xã Nhân Trạch",
    parent_code: "455",
  },
  {
    value: "06376",
    label: "Xã Nhất Hòa",
    parent_code: "185",
  },
  {
    value: "12415",
    label: "Xã Nhật Quang",
    parent_code: "333",
  },
  {
    value: "00094",
    label: "Phường Nhật Tân",
    parent_code: "003",
  },
  {
    value: "11068",
    label: "Xã Nhật Tân",
    parent_code: "297",
  },
  {
    value: "12346",
    label: "Xã Nhật Tân",
    parent_code: "332",
  },
  {
    value: "13402",
    label: "Xã Nhật Tân",
    parent_code: "350",
  },
  {
    value: "06382",
    label: "Xã Nhất Tiến",
    parent_code: "185",
  },
  {
    value: "06418",
    label: "Xã Nhật Tiến",
    parent_code: "186",
  },
  {
    value: "13399",
    label: "Xã Nhật Tựu",
    parent_code: "350",
  },
  {
    value: "27565",
    label: "Xã Nhị Bình",
    parent_code: "784",
  },
  {
    value: "28543",
    label: "Xã Nhị Bình",
    parent_code: "821",
  },
  {
    value: "10514",
    label: "Phường Nhị Châu",
    parent_code: "288",
  },
  {
    value: "22900",
    label: "Xã Nhị Hà",
    parent_code: "589",
  },
  {
    value: "10189",
    label: "Xã Nhị Khê",
    parent_code: "279",
  },
  {
    value: "29302",
    label: "Xã Nhị Long",
    parent_code: "844",
  },
  {
    value: "29299",
    label: "Xã Nhị Long Phú",
    parent_code: "844",
  },
  {
    value: "28474",
    label: "Phường Nhị Mỹ",
    parent_code: "817",
  },
  {
    value: "30097",
    label: "Xã Nhị Mỹ",
    parent_code: "873",
  },
  {
    value: "28477",
    label: "Xã Nhị Quý",
    parent_code: "817",
  },
  {
    value: "14864",
    label: "Xã Nhi Sơn",
    parent_code: "384",
  },
  {
    value: "28057",
    label: "Xã Nhị Thành",
    parent_code: "804",
  },
  {
    value: "29446",
    label: "Xã Nhị Trường",
    parent_code: "848",
  },
  {
    value: "14383",
    label: "Thị trấn Nho Quan",
    parent_code: "372",
  },
  {
    value: "16882",
    label: "Xã Nhôn Mai",
    parent_code: "418",
  },
  {
    value: "31300",
    label: "Xã Nhơn Ái",
    parent_code: "926",
  },
  {
    value: "21928",
    label: "Xã Nhơn An",
    parent_code: "549",
  },
  {
    value: "21550",
    label: "Phường Nhơn Bình",
    parent_code: "540",
  },
  {
    value: "29827",
    label: "Xã Nhơn Bình",
    parent_code: "862",
  },
  {
    value: "21607",
    label: "Xã Nhơn Châu",
    parent_code: "540",
  },
  {
    value: "27652",
    label: "Xã Nhơn Đức",
    parent_code: "786",
  },
  {
    value: "22867",
    label: "Xã Nhơn Hải",
    parent_code: "586",
  },
  {
    value: "21604",
    label: "Xã Nhơn Hải",
    parent_code: "540",
  },
  {
    value: "21919",
    label: "Xã Nhơn Hạnh",
    parent_code: "549",
  },
  {
    value: "21922",
    label: "Xã Nhơn Hậu",
    parent_code: "549",
  },
  {
    value: "23942",
    label: "Thị trấn Nhơn Hoà",
    parent_code: "639",
  },
  {
    value: "27844",
    label: "Xã Nhơn Hoà",
    parent_code: "799",
  },
  {
    value: "21943",
    label: "Phường Nhơn Hoà",
    parent_code: "549",
  },
  {
    value: "27835",
    label: "Xã Nhơn Hòa Lập",
    parent_code: "799",
  },
  {
    value: "21601",
    label: "Xã Nhơn Hội",
    parent_code: "540",
  },
  {
    value: "30349",
    label: "Xã Nhơn Hội",
    parent_code: "886",
  },
  {
    value: "21934",
    label: "Phường Nhơn Hưng",
    parent_code: "549",
  },
  {
    value: "30511",
    label: "Xã Nhơn Hưng",
    parent_code: "890",
  },
  {
    value: "21937",
    label: "Xã Nhơn Khánh",
    parent_code: "549",
  },
  {
    value: "21940",
    label: "Xã Nhơn Lộc",
    parent_code: "549",
  },
  {
    value: "21598",
    label: "Xã Nhơn Lý",
    parent_code: "540",
  },
  {
    value: "21913",
    label: "Xã Nhơn Mỹ",
    parent_code: "549",
  },
  {
    value: "30658",
    label: "Xã Nhơn Mỹ",
    parent_code: "893",
  },
  {
    value: "31552",
    label: "Xã Nhơn Mỹ",
    parent_code: "943",
  },
  {
    value: "31315",
    label: "Xã Nhơn Nghĩa",
    parent_code: "926",
  },
  {
    value: "31357",
    label: "Xã Nhơn Nghĩa A",
    parent_code: "932",
  },
  {
    value: "27859",
    label: "Xã Nhơn Ninh",
    parent_code: "799",
  },
  {
    value: "21925",
    label: "Xã Nhơn Phong",
    parent_code: "549",
  },
  {
    value: "21553",
    label: "Phường Nhơn Phú",
    parent_code: "540",
  },
  {
    value: "29632",
    label: "Xã Nhơn Phú",
    parent_code: "858",
  },
  {
    value: "21931",
    label: "Xã Nhơn Phúc",
    parent_code: "549",
  },
  {
    value: "22831",
    label: "Xã Nhơn Sơn",
    parent_code: "585",
  },
  {
    value: "21946",
    label: "Xã Nhơn Tân",
    parent_code: "549",
  },
  {
    value: "21916",
    label: "Phường Nhơn Thành",
    parent_code: "549",
  },
  {
    value: "28795",
    label: "Xã Nhơn Thạnh",
    parent_code: "829",
  },
  {
    value: "27706",
    label: "Xã Nhơn Thạnh Trung",
    parent_code: "794",
  },
  {
    value: "21949",
    label: "Xã Nhơn Thọ",
    parent_code: "549",
  },
  {
    value: "27511",
    label: "Xã Nhuận Đức",
    parent_code: "783",
  },
  {
    value: "28936",
    label: "Xã Nhuận Phú Tân",
    parent_code: "838",
  },
  {
    value: "04954",
    label: "Xã Nhuận Trạch",
    parent_code: "152",
  },
  {
    value: "12277",
    label: "Xã Nhuế Dương",
    parent_code: "330",
  },
  {
    value: "02122",
    label: "Xã Như Cố",
    parent_code: "065",
  },
  {
    value: "02527",
    label: "Xã Nhữ Hán",
    parent_code: "075",
  },
  {
    value: "14650",
    label: "Xã Như Hòa",
    parent_code: "376",
  },
  {
    value: "02530",
    label: "Xã Nhữ Khê",
    parent_code: "075",
  },
  {
    value: "11986",
    label: "Thị trấn Như Quỳnh",
    parent_code: "325",
  },
  {
    value: "08827",
    label: "Xã Như Thụy",
    parent_code: "253",
  },
  {
    value: "28033",
    label: "Xã Nhựt Chánh",
    parent_code: "803",
  },
  {
    value: "28105",
    label: "Xã Nhựt Ninh",
    parent_code: "805",
  },
  {
    value: "11398",
    label: "Phường Niệm Nghĩa",
    parent_code: "305",
  },
  {
    value: "00817",
    label: "Xã Niêm Sơn",
    parent_code: "027",
  },
  {
    value: "00815",
    label: "Xã Niêm Tòng",
    parent_code: "027",
  },
  {
    value: "14557",
    label: "Xã Ninh An",
    parent_code: "374",
  },
  {
    value: "22540",
    label: "Xã Ninh An",
    parent_code: "572",
  },
  {
    value: "22576",
    label: "Xã Ninh Bình",
    parent_code: "572",
  },
  {
    value: "14077",
    label: "Thị trấn Ninh Cường",
    parent_code: "363",
  },
  {
    value: "08179",
    label: "Xã Ninh Dân",
    parent_code: "232",
  },
  {
    value: "22561",
    label: "Phường Ninh Diêm",
    parent_code: "572",
  },
  {
    value: "06715",
    label: "Phường Ninh Dương",
    parent_code: "194",
  },
  {
    value: "22570",
    label: "Phường Ninh Đa",
    parent_code: "572",
  },
  {
    value: "25624",
    label: "Xã Ninh Điền",
    parent_code: "708",
  },
  {
    value: "22564",
    label: "Xã Ninh Đông",
    parent_code: "572",
  },
  {
    value: "24985",
    label: "Xã Ninh Gia",
    parent_code: "678",
  },
  {
    value: "11155",
    label: "Thị trấn Ninh Giang",
    parent_code: "299",
  },
  {
    value: "14530",
    label: "Xã Ninh Giang",
    parent_code: "374",
  },
  {
    value: "22591",
    label: "Phường Ninh Giang",
    parent_code: "572",
  },
  {
    value: "22594",
    label: "Phường Ninh Hà",
    parent_code: "572",
  },
  {
    value: "11200",
    label: "Xã Ninh Hải",
    parent_code: "299",
  },
  {
    value: "14548",
    label: "Xã Ninh Hải",
    parent_code: "374",
  },
  {
    value: "16606",
    label: "Phường Ninh Hải",
    parent_code: "407",
  },
  {
    value: "22543",
    label: "Phường Ninh Hải",
    parent_code: "572",
  },
  {
    value: "00535",
    label: "Xã Ninh Hiệp",
    parent_code: "018",
  },
  {
    value: "22528",
    label: "Phường Ninh Hiệp",
    parent_code: "572",
  },
  {
    value: "14542",
    label: "Xã Ninh Hòa",
    parent_code: "374",
  },
  {
    value: "31852",
    label: "Xã Ninh Hòa",
    parent_code: "956",
  },
  {
    value: "22597",
    label: "Xã Ninh Hưng",
    parent_code: "572",
  },
  {
    value: "22603",
    label: "Xã Ninh Ích",
    parent_code: "572",
  },
  {
    value: "14536",
    label: "Xã Ninh Khang",
    parent_code: "374",
  },
  {
    value: "15385",
    label: "Xã Ninh Khang",
    parent_code: "393",
  },
  {
    value: "14344",
    label: "Phường Ninh Khánh",
    parent_code: "369",
  },
  {
    value: "02614",
    label: "Xã Ninh Lai",
    parent_code: "076",
  },
  {
    value: "24997",
    label: "Xã Ninh Loan",
    parent_code: "678",
  },
  {
    value: "22600",
    label: "Xã Ninh Lộc",
    parent_code: "572",
  },
  {
    value: "14539",
    label: "Xã Ninh Mỹ",
    parent_code: "374",
  },
  {
    value: "14347",
    label: "Xã Ninh Nhất",
    parent_code: "369",
  },
  {
    value: "14359",
    label: "Phường Ninh Phong",
    parent_code: "369",
  },
  {
    value: "22582",
    label: "Xã Ninh Phú",
    parent_code: "572",
  },
  {
    value: "14353",
    label: "Xã Ninh Phúc",
    parent_code: "369",
  },
  {
    value: "22573",
    label: "Xã Ninh Phụng",
    parent_code: "572",
  },
  {
    value: "22579",
    label: "Xã Ninh Phước",
    parent_code: "572",
  },
  {
    value: "20668",
    label: "Xã Ninh Phước",
    parent_code: "519",
  },
  {
    value: "22588",
    label: "Xã Ninh Quang",
    parent_code: "572",
  },
  {
    value: "31846",
    label: "Xã Ninh Quới",
    parent_code: "956",
  },
  {
    value: "31849",
    label: "Xã Ninh Quới A",
    parent_code: "956",
  },
  {
    value: "22552",
    label: "Xã Ninh Sim",
    parent_code: "572",
  },
  {
    value: "10186",
    label: "Xã Ninh Sở",
    parent_code: "279",
  },
  {
    value: "07798",
    label: "Xã Ninh Sơn",
    parent_code: "222",
  },
  {
    value: "14356",
    label: "Phường Ninh Sơn",
    parent_code: "369",
  },
  {
    value: "25480",
    label: "Phường Ninh Sơn",
    parent_code: "703",
  },
  {
    value: "22531",
    label: "Xã Ninh Sơn",
    parent_code: "572",
  },
  {
    value: "22585",
    label: "Xã Ninh Tân",
    parent_code: "572",
  },
  {
    value: "22534",
    label: "Xã Ninh Tây",
    parent_code: "572",
  },
  {
    value: "25483",
    label: "Phường Ninh Thạnh",
    parent_code: "703",
  },
  {
    value: "31864",
    label: "Xã Ninh Thạnh Lợi",
    parent_code: "956",
  },
  {
    value: "31863",
    label: "Xã Ninh Thạnh Lợi A",
    parent_code: "956",
  },
  {
    value: "14551",
    label: "Xã Ninh Thắng",
    parent_code: "374",
  },
  {
    value: "22558",
    label: "Xã Ninh Thân",
    parent_code: "572",
  },
  {
    value: "22546",
    label: "Xã Ninh Thọ",
    parent_code: "572",
  },
  {
    value: "29323",
    label: "Xã Ninh Thới",
    parent_code: "845",
  },
  {
    value: "22567",
    label: "Phường Ninh Thủy",
    parent_code: "572",
  },
  {
    value: "22537",
    label: "Xã Ninh Thượng",
    parent_code: "572",
  },
  {
    value: "14350",
    label: "Xã Ninh Tiến",
    parent_code: "369",
  },
  {
    value: "22549",
    label: "Xã Ninh Trung",
    parent_code: "572",
  },
  {
    value: "14554",
    label: "Xã Ninh Vân",
    parent_code: "374",
  },
  {
    value: "22606",
    label: "Xã Ninh Vân",
    parent_code: "572",
  },
  {
    value: "09184",
    label: "Phường Ninh Xá",
    parent_code: "256",
  },
  {
    value: "09445",
    label: "Xã Ninh Xá",
    parent_code: "262",
  },
  {
    value: "14545",
    label: "Xã Ninh Xuân",
    parent_code: "374",
  },
  {
    value: "22555",
    label: "Xã Ninh Xuân",
    parent_code: "572",
  },
  {
    value: "03371",
    label: "Xã Nong U",
    parent_code: "101",
  },
  {
    value: "03124",
    label: "Phường Noong Bua",
    parent_code: "094",
  },
  {
    value: "03532",
    label: "Xã Noong Hẻo",
    parent_code: "108",
  },
  {
    value: "03352",
    label: "Xã Noọng Hẹt",
    parent_code: "100",
  },
  {
    value: "03754",
    label: "Xã Noong Lay",
    parent_code: "119",
  },
  {
    value: "03349",
    label: "Xã Noong Luống",
    parent_code: "100",
  },
  {
    value: "09328",
    label: "Xã Nội Duệ",
    parent_code: "260",
  },
  {
    value: "07708",
    label: "Xã Nội Hoàng",
    parent_code: "221",
  },
  {
    value: "01411",
    label: "Xã Nội Thôn",
    parent_code: "045",
  },
  {
    value: "16279",
    label: "Thị trấn Nông Cống",
    parent_code: "404",
  },
  {
    value: "02107",
    label: "Xã Nông Hạ",
    parent_code: "065",
  },
  {
    value: "01852",
    label: "Xã Nông Thượng",
    parent_code: "058",
  },
  {
    value: "02212",
    label: "Phường Nông Tiến",
    parent_code: "070",
  },
  {
    value: "07894",
    label: "Phường Nông Trang",
    parent_code: "227",
  },
  {
    value: "15766",
    label: "Xã Nông Trường",
    parent_code: "397",
  },
  {
    value: "00916",
    label: "Thị trấn Nông Trường Việt Lâm",
    parent_code: "030",
  },
  {
    value: "19246",
    label: "Thị trấn NT Lệ Ninh",
    parent_code: "457",
  },
  {
    value: "04621",
    label: "Thị trấn NT Liên Sơn",
    parent_code: "140",
  },
  {
    value: "03982",
    label: "Thị trấn NT Mộc Châu",
    parent_code: "123",
  },
  {
    value: "06616",
    label: "Thị trấn NT Thái Bình",
    parent_code: "189",
  },
  {
    value: "04627",
    label: "Thị trấn NT Trần Phú",
    parent_code: "140",
  },
  {
    value: "19114",
    label: "Thị trấn NT Việt Trung",
    parent_code: "455",
  },
  {
    value: "03358",
    label: "Xã Núa Ngam",
    parent_code: "100",
  },
  {
    value: "11470",
    label: "Thị trấn Núi Đèo",
    parent_code: "311",
  },
  {
    value: "11680",
    label: "Thị trấn Núi Đối",
    parent_code: "314",
  },
  {
    value: "30325",
    label: "Phường Núi Sam",
    parent_code: "884",
  },
  {
    value: "30682",
    label: "Thị trấn Núi Sập",
    parent_code: "894",
  },
  {
    value: "20965",
    label: "Thị trấn Núi Thành",
    parent_code: "517",
  },
  {
    value: "30574",
    label: "Xã Núi Tô",
    parent_code: "891",
  },
  {
    value: "26128",
    label: "Xã Núi Tượng",
    parent_code: "734",
  },
  {
    value: "30508",
    label: "Xã Núi Voi",
    parent_code: "890",
  },
  {
    value: "03415",
    label: "Xã Nùng Nàng",
    parent_code: "106",
  },
  {
    value: "05086",
    label: "Xã Nuông Dăm",
    parent_code: "153",
  },
  {
    value: "15718",
    label: "Thị trấn Nưa",
    parent_code: "397",
  },
  {
    value: "01654",
    label: "Thị trấn Nước Hai",
    parent_code: "051",
  },
  {
    value: "30688",
    label: "Thị Trấn Óc Eo",
    parent_code: "894",
  },
  {
    value: "00190",
    label: "Phường Ô Chợ Dừa",
    parent_code: "006",
  },
  {
    value: "30586",
    label: "Xã Ô Lâm",
    parent_code: "891",
  },
  {
    value: "30475",
    label: "Xã Ô Long Vỹ",
    parent_code: "889",
  },
  {
    value: "03003",
    label: "Phường Ô Quý Hồ",
    parent_code: "088",
  },
  {
    value: "05626",
    label: "Xã Ôn Lương",
    parent_code: "168",
  },
  {
    value: "12220",
    label: "Xã Ông Đình",
    parent_code: "330",
  },
  {
    value: "20467",
    label: "Thị trấn P Rao",
    parent_code: "505",
  },
  {
    value: "02737",
    label: "Xã Pa Cheo",
    parent_code: "082",
  },
  {
    value: "05209",
    label: "Xã Pà Cò",
    parent_code: "156",
  },
  {
    value: "03193",
    label: "Xã Pa Ham",
    parent_code: "097",
  },
  {
    value: "04606",
    label: "Xã Pá Hu",
    parent_code: "139",
  },
  {
    value: "03527",
    label: "Xã Pa Khoá",
    parent_code: "108",
  },
  {
    value: "03326",
    label: "Xã Pá Khoang",
    parent_code: "094",
  },
  {
    value: "04591",
    label: "Xã Pá Lau",
    parent_code: "139",
  },
  {
    value: "03802",
    label: "Xã Pá Lông",
    parent_code: "119",
  },
  {
    value: "03697",
    label: "Xã Pá Ma Pha Khinh",
    parent_code: "118",
  },
  {
    value: "03159",
    label: "Xã Pá Mỳ",
    parent_code: "096",
  },
  {
    value: "03165",
    label: "Xã Pa Tần",
    parent_code: "103",
  },
  {
    value: "03493",
    label: "Xã Pa Tần",
    parent_code: "108",
  },
  {
    value: "03340",
    label: "Xã Pa Thơm",
    parent_code: "100",
  },
  {
    value: "03442",
    label: "Xã Pa ủ",
    parent_code: "107",
  },
  {
    value: "01120",
    label: "Xã Pà Vầy Sủ",
    parent_code: "033",
  },
  {
    value: "03559",
    label: "Xã Pa Vây Sử",
    parent_code: "109",
  },
  {
    value: "03448",
    label: "Xã Pa Vệ Sử",
    parent_code: "107",
  },
  {
    value: "00781",
    label: "Xã Pả Vi",
    parent_code: "027",
  },
  {
    value: "01290",
    label: "Thị trấn Pác Miầu",
    parent_code: "042",
  },
  {
    value: "00775",
    label: "Xã Pải Lủng",
    parent_code: "027",
  },
  {
    value: "03871",
    label: "Xã Pắc Ngà",
    parent_code: "121",
  },
  {
    value: "03616",
    label: "Xã Pắc Ta",
    parent_code: "111",
  },
  {
    value: "16843",
    label: "Xã Phà Đánh",
    parent_code: "417",
  },
  {
    value: "10546",
    label: "Phường Phả Lại",
    parent_code: "290",
  },
  {
    value: "11548",
    label: "Xã Phả Lễ",
    parent_code: "311",
  },
  {
    value: "02752",
    label: "Xã Pha Long",
    parent_code: "083",
  },
  {
    value: "03628",
    label: "Xã Pha Mu",
    parent_code: "110",
  },
  {
    value: "00247",
    label: "Phường Phạm Đình Hổ",
    parent_code: "007",
  },
  {
    value: "11245",
    label: "Xã Phạm Kha",
    parent_code: "300",
  },
  {
    value: "10522",
    label: "Phường Phạm Ngũ Lão",
    parent_code: "288",
  },
  {
    value: "12292",
    label: "Xã Phạm Ngũ Lão",
    parent_code: "331",
  },
  {
    value: "26749",
    label: "Phường Phạm Ngũ Lão",
    parent_code: "760",
  },
  {
    value: "10693",
    label: "Phường Phạm Thái",
    parent_code: "292",
  },
  {
    value: "11053",
    label: "Xã Phạm Trấn",
    parent_code: "297",
  },
  {
    value: "27514",
    label: "Xã Phạm Văn Cội",
    parent_code: "783",
  },
  {
    value: "27598",
    label: "Xã Phạm Văn Hai",
    parent_code: "785",
  },
  {
    value: "25558",
    label: "Xã Phan",
    parent_code: "707",
  },
  {
    value: "11323",
    label: "Phường Phan Bội Châu",
    parent_code: "303",
  },
  {
    value: "00085",
    label: "Phường Phan Chu Trinh",
    parent_code: "002",
  },
  {
    value: "22975",
    label: "Xã Phan Dũng",
    parent_code: "595",
  },
  {
    value: "23017",
    label: "Xã Phan Điền",
    parent_code: "596",
  },
  {
    value: "12106",
    label: "Phường Phan Đình Phùng",
    parent_code: "328",
  },
  {
    value: "05449",
    label: "Phường Phan Đình Phùng",
    parent_code: "164",
  },
  {
    value: "13660",
    label: "Phường Phan Đình Phùng",
    parent_code: "356",
  },
  {
    value: "23044",
    label: "Xã Phan Hiệp",
    parent_code: "596",
  },
  {
    value: "23035",
    label: "Xã Phan Hòa",
    parent_code: "596",
  },
  {
    value: "23011",
    label: "Xã Phan Lâm",
    parent_code: "596",
  },
  {
    value: "22972",
    label: "Thị trấn Phan Rí Cửa",
    parent_code: "595",
  },
  {
    value: "23050",
    label: "Xã Phan Rí Thành",
    parent_code: "596",
  },
  {
    value: "12397",
    label: "Xã Phan Sào Nam",
    parent_code: "333",
  },
  {
    value: "03006",
    label: "Phường Phan Si Păng",
    parent_code: "088",
  },
  {
    value: "23008",
    label: "Xã Phan Sơn",
    parent_code: "596",
  },
  {
    value: "01345",
    label: "Xã Phan Thanh",
    parent_code: "043",
  },
  {
    value: "01768",
    label: "Xã Phan Thanh",
    parent_code: "052",
  },
  {
    value: "04366",
    label: "Xã Phan Thanh",
    parent_code: "135",
  },
  {
    value: "23038",
    label: "Xã Phan Thanh",
    parent_code: "596",
  },
  {
    value: "02200",
    label: "Phường Phan Thiết",
    parent_code: "070",
  },
  {
    value: "23026",
    label: "Xã Phan Tiến",
    parent_code: "596",
  },
  {
    value: "30775",
    label: "Phường Pháo Đài",
    parent_code: "900",
  },
  {
    value: "14620",
    label: "Thị trấn Phát Diệm",
    parent_code: "376",
  },
  {
    value: "03505",
    label: "Xã Phăng Sô Lin",
    parent_code: "108",
  },
  {
    value: "05644",
    label: "Xã Phấn Mễ",
    parent_code: "168",
  },
  {
    value: "09349",
    label: "Xã Phật Tích",
    parent_code: "260",
  },
  {
    value: "07582",
    label: "Xã Phì Điền",
    parent_code: "219",
  },
  {
    value: "01579",
    label: "Xã Phi Hải",
    parent_code: "049",
  },
  {
    value: "24886",
    label: "Xã Phi Liêng",
    parent_code: "674",
  },
  {
    value: "03208",
    label: "Xã Phì Nhừ",
    parent_code: "101",
  },
  {
    value: "30763",
    label: "Xã Phi Thông",
    parent_code: "899",
  },
  {
    value: "24883",
    label: "Xã Phi Tô",
    parent_code: "676",
  },
  {
    value: "03859",
    label: "Xã Phiêng Ban",
    parent_code: "121",
  },
  {
    value: "04144",
    label: "Xã Phiêng Cằm",
    parent_code: "125",
  },
  {
    value: "03892",
    label: "Xã Phiêng Côn",
    parent_code: "121",
  },
  {
    value: "04099",
    label: "Xã Phiêng Khoài",
    parent_code: "124",
  },
  {
    value: "01018",
    label: "Xã Phiêng Luông",
    parent_code: "031",
  },
  {
    value: "04033",
    label: "Xã Phiêng Luông",
    parent_code: "123",
  },
  {
    value: "04159",
    label: "Xã Phiêng Pằn",
    parent_code: "125",
  },
  {
    value: "03198",
    label: "Xã Phìn Hồ",
    parent_code: "103",
  },
  {
    value: "03496",
    label: "Xã Phìn Hồ",
    parent_code: "108",
  },
  {
    value: "02743",
    label: "Xã Phìn Ngan",
    parent_code: "082",
  },
  {
    value: "03382",
    label: "Xã Phình Giàng",
    parent_code: "101",
  },
  {
    value: "04597",
    label: "Xã Phình Hồ",
    parent_code: "139",
  },
  {
    value: "03259",
    label: "Xã Phình Sáng",
    parent_code: "099",
  },
  {
    value: "00712",
    label: "Thị trấn Phó Bảng",
    parent_code: "026",
  },
  {
    value: "19858",
    label: "Xã Phong An",
    parent_code: "476",
  },
  {
    value: "19507",
    label: "Xã Phong Bình",
    parent_code: "466",
  },
  {
    value: "19831",
    label: "Xã Phong Bình",
    parent_code: "476",
  },
  {
    value: "01507",
    label: "Xã Phong Châu",
    parent_code: "047",
  },
  {
    value: "07945",
    label: "Phường Phong Châu",
    parent_code: "228",
  },
  {
    value: "08230",
    label: "Thị trấn Phong Châu",
    parent_code: "233",
  },
  {
    value: "12733",
    label: "Xã Phong Châu",
    parent_code: "340",
  },
  {
    value: "19837",
    label: "Xã Phong Chương",
    parent_code: "476",
  },
  {
    value: "07183",
    label: "Phường Phong Cốc",
    parent_code: "206",
  },
  {
    value: "06871",
    label: "Xã Phong Dụ",
    parent_code: "199",
  },
  {
    value: "04402",
    label: "Xã Phong Dụ Hạ",
    parent_code: "136",
  },
  {
    value: "04423",
    label: "Xã Phong Dụ Thượng",
    parent_code: "136",
  },
  {
    value: "19819",
    label: "Thị trấn Phong Điền",
    parent_code: "476",
  },
  {
    value: "31299",
    label: "Thị trấn Phong Điền",
    parent_code: "926",
  },
  {
    value: "32124",
    label: "Xã Phong Điền",
    parent_code: "968",
  },
  {
    value: "31074",
    label: "Xã Phong Đông",
    parent_code: "910",
  },
  {
    value: "07174",
    label: "Phường Phong Hải",
    parent_code: "206",
  },
  {
    value: "19840",
    label: "Xã Phong Hải",
    parent_code: "476",
  },
  {
    value: "19852",
    label: "Xã Phong Hiền",
    parent_code: "476",
  },
  {
    value: "19846",
    label: "Xã Phong Hòa",
    parent_code: "476",
  },
  {
    value: "30241",
    label: "Xã Phong Hòa",
    parent_code: "876",
  },
  {
    value: "18991",
    label: "Xã Phong Hóa",
    parent_code: "453",
  },
  {
    value: "09244",
    label: "Phường Phong Khê",
    parent_code: "256",
  },
  {
    value: "32125",
    label: "Xã Phong Lạc",
    parent_code: "968",
  },
  {
    value: "16042",
    label: "Xã Phong Lộc",
    parent_code: "400",
  },
  {
    value: "07534",
    label: "Xã Phong Minh",
    parent_code: "219",
  },
  {
    value: "19855",
    label: "Xã Phong Mỹ",
    parent_code: "476",
  },
  {
    value: "30088",
    label: "Xã Phong Mỹ",
    parent_code: "873",
  },
  {
    value: "22960",
    label: "Xã Phong Nẫm",
    parent_code: "593",
  },
  {
    value: "28987",
    label: "Xã Phong Nẫm",
    parent_code: "834",
  },
  {
    value: "31537",
    label: "Xã Phong Nẫm",
    parent_code: "943",
  },
  {
    value: "01483",
    label: "Xã Phong Nậm",
    parent_code: "047",
  },
  {
    value: "19165",
    label: "Thị trấn Phong Nha",
    parent_code: "455",
  },
  {
    value: "02920",
    label: "Xã Phong Niên",
    parent_code: "086",
  },
  {
    value: "05158",
    label: "Xã Phong Phú",
    parent_code: "155",
  },
  {
    value: "22978",
    label: "Xã Phong Phú",
    parent_code: "595",
  },
  {
    value: "27622",
    label: "Xã Phong Phú",
    parent_code: "785",
  },
  {
    value: "29326",
    label: "Xã Phong Phú",
    parent_code: "845",
  },
  {
    value: "00934",
    label: "Xã Phong Quang",
    parent_code: "030",
  },
  {
    value: "15127",
    label: "Thị trấn Phong Sơn",
    parent_code: "390",
  },
  {
    value: "19864",
    label: "Xã Phong Sơn",
    parent_code: "476",
  },
  {
    value: "31954",
    label: "Xã Phong Tân",
    parent_code: "959",
  },
  {
    value: "29329",
    label: "Xã Phong Thạnh",
    parent_code: "845",
  },
  {
    value: "31960",
    label: "Xã Phong Thạnh",
    parent_code: "959",
  },
  {
    value: "31963",
    label: "Xã Phong Thạnh A",
    parent_code: "959",
  },
  {
    value: "31948",
    label: "Xã Phong Thạnh Đông",
    parent_code: "959",
  },
  {
    value: "31966",
    label: "Xã Phong Thạnh Tây",
    parent_code: "959",
  },
  {
    value: "31885",
    label: "Xã Phong Thạnh Tây A",
    parent_code: "957",
  },
  {
    value: "31888",
    label: "Xã Phong Thạnh Tây B",
    parent_code: "957",
  },
  {
    value: "17728",
    label: "Xã Phong Thịnh",
    parent_code: "428",
  },
  {
    value: "03549",
    label: "Thị trấn Phong Thổ",
    parent_code: "109",
  },
  {
    value: "19849",
    label: "Xã Phong Thu",
    parent_code: "476",
  },
  {
    value: "19267",
    label: "Xã Phong Thủy",
    parent_code: "457",
  },
  {
    value: "09640",
    label: "Xã Phong Vân",
    parent_code: "271",
  },
  {
    value: "07537",
    label: "Xã Phong Vân",
    parent_code: "219",
  },
  {
    value: "19861",
    label: "Xã Phong Xuân",
    parent_code: "476",
  },
  {
    value: "21442",
    label: "Xã Phổ An",
    parent_code: "534",
  },
  {
    value: "00745",
    label: "Xã Phố Cáo",
    parent_code: "026",
  },
  {
    value: "21481",
    label: "Xã Phổ Châu",
    parent_code: "534",
  },
  {
    value: "18133",
    label: "Thị trấn Phố Châu",
    parent_code: "439",
  },
  {
    value: "05521",
    label: "Phường Phố Cò",
    parent_code: "165",
  },
  {
    value: "21472",
    label: "Xã Phổ Cường",
    parent_code: "534",
  },
  {
    value: "21469",
    label: "Phường Phổ Hòa",
    parent_code: "534",
  },
  {
    value: "00262",
    label: "Phường Phố Huế",
    parent_code: "007",
  },
  {
    value: "21475",
    label: "Xã Phổ Khánh",
    parent_code: "534",
  },
  {
    value: "00727",
    label: "Xã Phố Là",
    parent_code: "026",
  },
  {
    value: "02905",
    label: "Thị trấn Phố Lu",
    parent_code: "086",
  },
  {
    value: "21463",
    label: "Phường Phổ Minh",
    parent_code: "534",
  },
  {
    value: "09247",
    label: "Thị trấn Phố Mới",
    parent_code: "259",
  },
  {
    value: "21457",
    label: "Xã Phổ Nhơn",
    parent_code: "534",
  },
  {
    value: "21460",
    label: "Phường Phổ Ninh",
    parent_code: "534",
  },
  {
    value: "21445",
    label: "Xã Phổ Phong",
    parent_code: "534",
  },
  {
    value: "21454",
    label: "Phường Phổ Quang",
    parent_code: "534",
  },
  {
    value: "02947",
    label: "Thị trấn Phố Ràng",
    parent_code: "087",
  },
  {
    value: "21478",
    label: "Phường Phổ Thạnh",
    parent_code: "534",
  },
  {
    value: "21448",
    label: "Xã Phổ Thuận",
    parent_code: "534",
  },
  {
    value: "21451",
    label: "Phường Phổ Văn",
    parent_code: "534",
  },
  {
    value: "21466",
    label: "Phường Phổ Vinh",
    parent_code: "534",
  },
  {
    value: "07288",
    label: "Thị trấn Phồn Xương",
    parent_code: "215",
  },
  {
    value: "03724",
    label: "Xã Phổng Lái",
    parent_code: "119",
  },
  {
    value: "03748",
    label: "Xã Phổng Lăng",
    parent_code: "119",
  },
  {
    value: "03745",
    label: "Xã Phổng Lập",
    parent_code: "119",
  },
  {
    value: "25855",
    label: "Xã Phú An",
    parent_code: "721",
  },
  {
    value: "26125",
    label: "Xã Phú An",
    parent_code: "734",
  },
  {
    value: "19912",
    label: "Xã Phú An",
    parent_code: "478",
  },
  {
    value: "24007",
    label: "Xã Phú An",
    parent_code: "634",
  },
  {
    value: "28492",
    label: "Xã Phú An",
    parent_code: "820",
  },
  {
    value: "30436",
    label: "Xã Phú An",
    parent_code: "888",
  },
  {
    value: "28825",
    label: "Xã Phú An Hòa",
    parent_code: "831",
  },
  {
    value: "19960",
    label: "Phường Phú Bài",
    parent_code: "479",
  },
  {
    value: "02332",
    label: "Xã Phú Bình",
    parent_code: "073",
  },
  {
    value: "26086",
    label: "Phường Phú Bình",
    parent_code: "732",
  },
  {
    value: "26158",
    label: "Xã Phú Bình",
    parent_code: "734",
  },
  {
    value: "30445",
    label: "Xã Phú Bình",
    parent_code: "888",
  },
  {
    value: "09922",
    label: "Xã Phú Cát",
    parent_code: "275",
  },
  {
    value: "24097",
    label: "Xã Phú Cần",
    parent_code: "637",
  },
  {
    value: "29347",
    label: "Xã Phú Cần",
    parent_code: "846",
  },
  {
    value: "25924",
    label: "Phường Phú Chánh",
    parent_code: "723",
  },
  {
    value: "09397",
    label: "Phường Phù Chẩn",
    parent_code: "261",
  },
  {
    value: "09649",
    label: "Xã Phú Châu",
    parent_code: "271",
  },
  {
    value: "12760",
    label: "Xã Phú Châu",
    parent_code: "340",
  },
  {
    value: "00442",
    label: "Xã Phú Cường",
    parent_code: "016",
  },
  {
    value: "09625",
    label: "Xã Phú Cường",
    parent_code: "271",
  },
  {
    value: "12331",
    label: "Xã Phú Cường",
    parent_code: "323",
  },
  {
    value: "05140",
    label: "Xã Phú Cường",
    parent_code: "155",
  },
  {
    value: "05779",
    label: "Xã Phú Cường",
    parent_code: "171",
  },
  {
    value: "25747",
    label: "Phường Phú Cường",
    parent_code: "718",
  },
  {
    value: "26236",
    label: "Xã Phú Cường",
    parent_code: "736",
  },
  {
    value: "28444",
    label: "Xã Phú Cường",
    parent_code: "820",
  },
  {
    value: "30025",
    label: "Xã Phú Cường",
    parent_code: "871",
  },
  {
    value: "19921",
    label: "Xã Phú Diên",
    parent_code: "478",
  },
  {
    value: "00619",
    label: "Phường Phú Diễn",
    parent_code: "021",
  },
  {
    value: "19906",
    label: "Xã Phú Dương",
    parent_code: "474",
  },
  {
    value: "09157",
    label: "Xã Phú Đa",
    parent_code: "252",
  },
  {
    value: "19942",
    label: "Thị trấn Phú Đa",
    parent_code: "478",
  },
  {
    value: "10648",
    label: "Xã Phú Điền",
    parent_code: "291",
  },
  {
    value: "26167",
    label: "Xã Phú Điền",
    parent_code: "734",
  },
  {
    value: "30067",
    label: "Xã Phú Điền",
    parent_code: "872",
  },
  {
    value: "05602",
    label: "Xã Phú Đình",
    parent_code: "167",
  },
  {
    value: "19174",
    label: "Xã Phú Định",
    parent_code: "455",
  },
  {
    value: "00632",
    label: "Phường Phú Đô",
    parent_code: "019",
  },
  {
    value: "05635",
    label: "Xã Phú Đô",
    parent_code: "168",
  },
  {
    value: "00544",
    label: "Xã Phù Đổng",
    parent_code: "018",
  },
  {
    value: "23570",
    label: "Phường Phù Đổng",
    parent_code: "622",
  },
  {
    value: "09643",
    label: "Xã Phú Đông",
    parent_code: "271",
  },
  {
    value: "26491",
    label: "Xã Phú Đông",
    parent_code: "742",
  },
  {
    value: "22041",
    label: "Phường Phú Đông",
    parent_code: "555",
  },
  {
    value: "28750",
    label: "Xã Phú Đông",
    parent_code: "825",
  },
  {
    value: "25326",
    label: "Phường Phú Đức",
    parent_code: "690",
  },
  {
    value: "28822",
    label: "Xã Phú Đức",
    parent_code: "831",
  },
  {
    value: "29602",
    label: "Xã Phú Đức",
    parent_code: "857",
  },
  {
    value: "30013",
    label: "Xã Phú Đức",
    parent_code: "871",
  },
  {
    value: "18529",
    label: "Xã Phú Gia",
    parent_code: "444",
  },
  {
    value: "19954",
    label: "Xã Phú Gia",
    parent_code: "478",
  },
  {
    value: "22747",
    label: "Phường Phủ Hà",
    parent_code: "582",
  },
  {
    value: "22921",
    label: "Phường Phú Hài",
    parent_code: "593",
  },
  {
    value: "18874",
    label: "Phường Phú Hải",
    parent_code: "450",
  },
  {
    value: "19915",
    label: "Xã Phú Hải",
    parent_code: "478",
  },
  {
    value: "19759",
    label: "Phường Phú Hậu",
    parent_code: "474",
  },
  {
    value: "30010",
    label: "Xã Phú Hiệp",
    parent_code: "871",
  },
  {
    value: "30424",
    label: "Xã Phú Hiệp",
    parent_code: "888",
  },
  {
    value: "19063",
    label: "Xã Phù Hóa",
    parent_code: "454",
  },
  {
    value: "22319",
    label: "Thị Trấn Phú Hoà",
    parent_code: "563",
  },
  {
    value: "30685",
    label: "Thị trấn Phú Hoà",
    parent_code: "894",
  },
  {
    value: "09505",
    label: "Xã Phú Hòa",
    parent_code: "264",
  },
  {
    value: "25750",
    label: "Phường Phú Hòa",
    parent_code: "718",
  },
  {
    value: "26221",
    label: "Xã Phú Hòa",
    parent_code: "736",
  },
  {
    value: "23722",
    label: "Thị trấn Phú Hòa",
    parent_code: "627",
  },
  {
    value: "27517",
    label: "Xã Phú Hòa Đông",
    parent_code: "783",
  },
  {
    value: "19933",
    label: "Xã Phú Hồ",
    parent_code: "478",
  },
  {
    value: "07954",
    label: "Xã Phú Hộ",
    parent_code: "228",
  },
  {
    value: "24982",
    label: "Xã Phú Hội",
    parent_code: "678",
  },
  {
    value: "26485",
    label: "Xã Phú Hội",
    parent_code: "742",
  },
  {
    value: "19786",
    label: "Phường Phú Hội",
    parent_code: "474",
  },
  {
    value: "30355",
    label: "Xã Phú Hội",
    parent_code: "886",
  },
  {
    value: "28786",
    label: "Xã Phú Hưng",
    parent_code: "829",
  },
  {
    value: "30451",
    label: "Xã Phú Hưng",
    parent_code: "888",
  },
  {
    value: "32134",
    label: "Xã Phú Hưng",
    parent_code: "969",
  },
  {
    value: "26482",
    label: "Xã Phú Hữu",
    parent_code: "742",
  },
  {
    value: "26866",
    label: "Phường Phú Hữu",
    parent_code: "769",
  },
  {
    value: "30352",
    label: "Xã Phú Hữu",
    parent_code: "886",
  },
  {
    value: "31378",
    label: "Xã Phú Hữu",
    parent_code: "933",
  },
  {
    value: "31657",
    label: "Xã Phú Hữu",
    parent_code: "946",
  },
  {
    value: "30268",
    label: "Xã Phú Hựu",
    parent_code: "877",
  },
  {
    value: "12448",
    label: "Phường Phú Khánh",
    parent_code: "336",
  },
  {
    value: "29185",
    label: "Xã Phú Khánh",
    parent_code: "837",
  },
  {
    value: "09379",
    label: "Phường Phù Khê",
    parent_code: "261",
  },
  {
    value: "08392",
    label: "Xã Phú Khê",
    parent_code: "235",
  },
  {
    value: "28756",
    label: "Phường Phú Khương",
    parent_code: "829",
  },
  {
    value: "28609",
    label: "Xã Phú Kiết",
    parent_code: "822",
  },
  {
    value: "09967",
    label: "Xã Phú Kim",
    parent_code: "276",
  },
  {
    value: "09552",
    label: "Phường Phú La",
    parent_code: "268",
  },
  {
    value: "08407",
    label: "Xã Phú Lạc",
    parent_code: "235",
  },
  {
    value: "05785",
    label: "Xã Phú Lạc",
    parent_code: "171",
  },
  {
    value: "22987",
    label: "Xã Phú Lạc",
    parent_code: "595",
  },
  {
    value: "05383",
    label: "Xã Phú Lai",
    parent_code: "158",
  },
  {
    value: "09568",
    label: "Phường Phú Lãm",
    parent_code: "268",
  },
  {
    value: "09277",
    label: "Xã Phù Lãng",
    parent_code: "259",
  },
  {
    value: "09322",
    label: "Xã Phú Lâm",
    parent_code: "260",
  },
  {
    value: "07987",
    label: "Xã Phú Lâm",
    parent_code: "230",
  },
  {
    value: "16624",
    label: "Xã Phú Lâm",
    parent_code: "407",
  },
  {
    value: "26155",
    label: "Xã Phú Lâm",
    parent_code: "734",
  },
  {
    value: "22240",
    label: "Phường Phú Lâm",
    parent_code: "555",
  },
  {
    value: "30421",
    label: "Xã Phú Lâm",
    parent_code: "888",
  },
  {
    value: "26134",
    label: "Xã Phú Lập",
    parent_code: "734",
  },
  {
    value: "29146",
    label: "Xã Phú Lễ",
    parent_code: "836",
  },
  {
    value: "14884",
    label: "Xã Phú Lệ",
    parent_code: "385",
  },
  {
    value: "11449",
    label: "Phường Phù Liễn",
    parent_code: "307",
  },
  {
    value: "00400",
    label: "Xã Phù Linh",
    parent_code: "016",
  },
  {
    value: "00706",
    label: "Xã Phú Linh",
    parent_code: "030",
  },
  {
    value: "11932",
    label: "Xã Phù Long",
    parent_code: "317",
  },
  {
    value: "14458",
    label: "Xã Phú Long",
    parent_code: "372",
  },
  {
    value: "23062",
    label: "Thị trấn Phú Long",
    parent_code: "597",
  },
  {
    value: "29089",
    label: "Xã Phú Long",
    parent_code: "835",
  },
  {
    value: "30262",
    label: "Xã Phú Long",
    parent_code: "877",
  },
  {
    value: "30418",
    label: "Xã Phú Long",
    parent_code: "888",
  },
  {
    value: "00448",
    label: "Xã Phù Lỗ",
    parent_code: "016",
  },
  {
    value: "08257",
    label: "Xã Phú Lộc",
    parent_code: "233",
  },
  {
    value: "14446",
    label: "Xã Phú Lộc",
    parent_code: "372",
  },
  {
    value: "16072",
    label: "Xã Phú Lộc",
    parent_code: "400",
  },
  {
    value: "18454",
    label: "Xã Phú Lộc",
    parent_code: "443",
  },
  {
    value: "26152",
    label: "Xã Phú Lộc",
    parent_code: "734",
  },
  {
    value: "20107",
    label: "Thị trấn Phú Lộc",
    parent_code: "482",
  },
  {
    value: "24355",
    label: "Xã Phú Lộc",
    parent_code: "650",
  },
  {
    value: "29737",
    label: "Xã Phú Lộc",
    parent_code: "860",
  },
  {
    value: "30379",
    label: "Xã Phú Lộc",
    parent_code: "887",
  },
  {
    value: "31756",
    label: "Thị trấn Phú Lộc",
    parent_code: "949",
  },
  {
    value: "25744",
    label: "Phường Phú Lợi",
    parent_code: "718",
  },
  {
    value: "26218",
    label: "Xã Phú Lợi",
    parent_code: "736",
  },
  {
    value: "30142",
    label: "Xã Phú Lợi",
    parent_code: "874",
  },
  {
    value: "30797",
    label: "Xã Phú Lợi",
    parent_code: "914",
  },
  {
    value: "00826",
    label: "Xã Phú Lũng",
    parent_code: "028",
  },
  {
    value: "03368",
    label: "Xã Phu Luông",
    parent_code: "100",
  },
  {
    value: "09274",
    label: "Xã Phù Lương",
    parent_code: "259",
  },
  {
    value: "09571",
    label: "Phường Phú Lương",
    parent_code: "268",
  },
  {
    value: "09532",
    label: "Xã Phú Lương",
    parent_code: "264",
  },
  {
    value: "12709",
    label: "Xã Phú Lương",
    parent_code: "340",
  },
  {
    value: "02611",
    label: "Xã Phú Lương",
    parent_code: "076",
  },
  {
    value: "19939",
    label: "Xã Phú Lương",
    parent_code: "478",
  },
  {
    value: "10429",
    label: "Xã Phù Lưu",
    parent_code: "281",
  },
  {
    value: "02392",
    label: "Xã Phù Lưu",
    parent_code: "074",
  },
  {
    value: "18493",
    label: "Xã Phù Lưu",
    parent_code: "448",
  },
  {
    value: "10477",
    label: "Xã Phù Lưu Tế",
    parent_code: "282",
  },
  {
    value: "05632",
    label: "Xã Phủ Lý",
    parent_code: "168",
  },
  {
    value: "26173",
    label: "Xã Phú Lý",
    parent_code: "735",
  },
  {
    value: "09940",
    label: "Xã Phú Mãn",
    parent_code: "275",
  },
  {
    value: "19909",
    label: "Xã Phú Mậu",
    parent_code: "474",
  },
  {
    value: "00445",
    label: "Xã Phú Minh",
    parent_code: "016",
  },
  {
    value: "10270",
    label: "Thị trấn Phú Minh",
    parent_code: "280",
  },
  {
    value: "22087",
    label: "Xã Phú Mỡ",
    parent_code: "558",
  },
  {
    value: "21730",
    label: "Thị trấn Phù Mỹ",
    parent_code: "545",
  },
  {
    value: "08233",
    label: "Xã Phú Mỹ",
    parent_code: "233",
  },
  {
    value: "25762",
    label: "Phường Phú Mỹ",
    parent_code: "718",
  },
  {
    value: "26704",
    label: "Phường Phú Mỹ",
    parent_code: "754",
  },
  {
    value: "19927",
    label: "Xã Phú Mỹ",
    parent_code: "478",
  },
  {
    value: "27493",
    label: "Phường Phú Mỹ",
    parent_code: "778",
  },
  {
    value: "28336",
    label: "Xã Phú Mỹ",
    parent_code: "818",
  },
  {
    value: "28889",
    label: "Xã Phú Mỹ",
    parent_code: "838",
  },
  {
    value: "30406",
    label: "Thị trấn Phú Mỹ",
    parent_code: "888",
  },
  {
    value: "30799",
    label: "Xã Phú Mỹ",
    parent_code: "914",
  },
  {
    value: "31612",
    label: "Xã Phú Mỹ",
    parent_code: "944",
  },
  {
    value: "32215",
    label: "Xã Phú Mỹ",
    parent_code: "972",
  },
  {
    value: "27499",
    label: "Xã Phú Mỹ Hưng",
    parent_code: "783",
  },
  {
    value: "01003",
    label: "Xã Phú Nam",
    parent_code: "031",
  },
  {
    value: "10111",
    label: "Xã Phú Nam An",
    parent_code: "277",
  },
  {
    value: "28219",
    label: "Xã Phú Ngãi Trị",
    parent_code: "808",
  },
  {
    value: "10033",
    label: "Xã Phú Nghĩa",
    parent_code: "277",
  },
  {
    value: "05395",
    label: "Xã Phú Nghĩa",
    parent_code: "159",
  },
  {
    value: "25267",
    label: "Xã Phú Nghĩa",
    parent_code: "691",
  },
  {
    value: "14911",
    label: "Xã Phú Nghiêm",
    parent_code: "385",
  },
  {
    value: "26233",
    label: "Xã Phú Ngọc",
    parent_code: "736",
  },
  {
    value: "04663",
    label: "Xã Phù Nham",
    parent_code: "133",
  },
  {
    value: "08266",
    label: "Xã Phú Nham",
    parent_code: "233",
  },
  {
    value: "07597",
    label: "Xã Phú Nhuận",
    parent_code: "219",
  },
  {
    value: "02944",
    label: "Xã Phú Nhuận",
    parent_code: "086",
  },
  {
    value: "16249",
    label: "Xã Phú Nhuận",
    parent_code: "403",
  },
  {
    value: "19789",
    label: "Phường Phú Nhuận",
    parent_code: "474",
  },
  {
    value: "28465",
    label: "Xã Phú Nhuận",
    parent_code: "820",
  },
  {
    value: "28798",
    label: "Xã Phú Nhuận",
    parent_code: "829",
  },
  {
    value: "11503",
    label: "Xã Phù Ninh",
    parent_code: "311",
  },
  {
    value: "08278",
    label: "Xã Phù Ninh",
    parent_code: "233",
  },
  {
    value: "30028",
    label: "Xã Phú Ninh",
    parent_code: "871",
  },
  {
    value: "18535",
    label: "Xã Phú Phong",
    parent_code: "444",
  },
  {
    value: "21808",
    label: "Thị trấn Phú Phong",
    parent_code: "547",
  },
  {
    value: "28588",
    label: "Xã Phú Phong",
    parent_code: "821",
  },
  {
    value: "13621",
    label: "Xã Phú Phúc",
    parent_code: "353",
  },
  {
    value: "28873",
    label: "Xã Phú Phụng",
    parent_code: "832",
  },
  {
    value: "09646",
    label: "Xã Phú Phương",
    parent_code: "271",
  },
  {
    value: "29611",
    label: "Xã Phú Quới",
    parent_code: "857",
  },
  {
    value: "28483",
    label: "Xã Phú Quý",
    parent_code: "817",
  },
  {
    value: "25264",
    label: "Xã Phú Riềng",
    parent_code: "698",
  },
  {
    value: "09658",
    label: "Xã Phú Sơn",
    parent_code: "271",
  },
  {
    value: "14407",
    label: "Xã Phú Sơn",
    parent_code: "372",
  },
  {
    value: "14770",
    label: "Phường Phú Sơn",
    parent_code: "380",
  },
  {
    value: "14823",
    label: "Phường Phú Sơn",
    parent_code: "381",
  },
  {
    value: "14887",
    label: "Xã Phú Sơn",
    parent_code: "385",
  },
  {
    value: "16603",
    label: "Xã Phú Sơn",
    parent_code: "407",
  },
  {
    value: "17323",
    label: "Xã Phú Sơn",
    parent_code: "423",
  },
  {
    value: "24880",
    label: "Xã Phú Sơn",
    parent_code: "676",
  },
  {
    value: "25400",
    label: "Xã Phú Sơn",
    parent_code: "696",
  },
  {
    value: "26137",
    label: "Xã Phú Sơn",
    parent_code: "734",
  },
  {
    value: "19990",
    label: "Xã Phú Sơn",
    parent_code: "479",
  },
  {
    value: "28888",
    label: "Xã Phú Sơn",
    parent_code: "832",
  },
  {
    value: "22927",
    label: "Phường Phú Tài",
    parent_code: "593",
  },
  {
    value: "31573",
    label: "Xã Phú Tâm",
    parent_code: "942",
  },
  {
    value: "25763",
    label: "Phường Phú Tân",
    parent_code: "718",
  },
  {
    value: "26212",
    label: "Xã Phú Tân",
    parent_code: "736",
  },
  {
    value: "28753",
    label: "Xã Phú Tân",
    parent_code: "825",
  },
  {
    value: "28757",
    label: "Phường Phú Tân",
    parent_code: "829",
  },
  {
    value: "31379",
    label: "Xã Phú Tân",
    parent_code: "933",
  },
  {
    value: "31582",
    label: "Xã Phú Tân",
    parent_code: "942",
  },
  {
    value: "32218",
    label: "Xã Phú Tân",
    parent_code: "972",
  },
  {
    value: "10750",
    label: "Thị trấn Phú Thái",
    parent_code: "293",
  },
  {
    value: "14878",
    label: "Xã Phú Thanh",
    parent_code: "385",
  },
  {
    value: "26161",
    label: "Xã Phú Thanh",
    parent_code: "734",
  },
  {
    value: "19924",
    label: "Xã Phú Thanh",
    parent_code: "474",
  },
  {
    value: "05398",
    label: "Xã Phú Thành",
    parent_code: "159",
  },
  {
    value: "17548",
    label: "Xã Phú Thành",
    parent_code: "426",
  },
  {
    value: "29851",
    label: "Xã Phú Thành",
    parent_code: "862",
  },
  {
    value: "30433",
    label: "Xã Phú Thành",
    parent_code: "888",
  },
  {
    value: "26488",
    label: "Xã Phú Thạnh",
    parent_code: "742",
  },
  {
    value: "27028",
    label: "Phường Phú Thạnh",
    parent_code: "767",
  },
  {
    value: "22040",
    label: "Phường Phú Thạnh",
    parent_code: "555",
  },
  {
    value: "28696",
    label: "Xã Phú Thạnh",
    parent_code: "825",
  },
  {
    value: "30427",
    label: "Xã Phú Thạnh",
    parent_code: "888",
  },
  {
    value: "30034",
    label: "Xã Phú Thành A",
    parent_code: "871",
  },
  {
    value: "30016",
    label: "Xã Phú Thành B",
    parent_code: "871",
  },
  {
    value: "00559",
    label: "Xã Phú Thị",
    parent_code: "018",
  },
  {
    value: "24043",
    label: "Thị trấn Phú Thiện",
    parent_code: "638",
  },
  {
    value: "09577",
    label: "Phường Phú Thịnh",
    parent_code: "269",
  },
  {
    value: "12310",
    label: "Xã Phú Thịnh",
    parent_code: "331",
  },
  {
    value: "05791",
    label: "Xã Phú Thịnh",
    parent_code: "171",
  },
  {
    value: "02482",
    label: "Xã Phú Thịnh",
    parent_code: "075",
  },
  {
    value: "04783",
    label: "Xã Phú Thịnh",
    parent_code: "141",
  },
  {
    value: "25325",
    label: "Phường Phú Thịnh",
    parent_code: "690",
  },
  {
    value: "26140",
    label: "Xã Phú Thịnh",
    parent_code: "734",
  },
  {
    value: "20364",
    label: "Thị trấn Phú Thịnh",
    parent_code: "518",
  },
  {
    value: "29725",
    label: "Xã Phú Thịnh",
    parent_code: "860",
  },
  {
    value: "25753",
    label: "Phường Phú Thọ",
    parent_code: "718",
  },
  {
    value: "30031",
    label: "Xã Phú Thọ",
    parent_code: "871",
  },
  {
    value: "30448",
    label: "Xã Phú Thọ",
    parent_code: "888",
  },
  {
    value: "27025",
    label: "Phường Phú Thọ Hòa",
    parent_code: "767",
  },
  {
    value: "01969",
    label: "Thị trấn Phủ Thông",
    parent_code: "063",
  },
  {
    value: "19903",
    label: "Xã Phú Thuận",
    parent_code: "478",
  },
  {
    value: "27484",
    label: "Phường Phú Thuận",
    parent_code: "778",
  },
  {
    value: "29062",
    label: "Xã Phú Thuận",
    parent_code: "835",
  },
  {
    value: "30700",
    label: "Xã Phú Thuận",
    parent_code: "894",
  },
  {
    value: "32214",
    label: "Xã Phú Thuận",
    parent_code: "972",
  },
  {
    value: "29998",
    label: "Xã Phú Thuận A",
    parent_code: "870",
  },
  {
    value: "29995",
    label: "Xã Phú Thuận B",
    parent_code: "870",
  },
  {
    value: "22924",
    label: "Phường Phú Thủy",
    parent_code: "593",
  },
  {
    value: "19297",
    label: "Xã Phú Thủy",
    parent_code: "457",
  },
  {
    value: "10714",
    label: "Phường Phú Thứ",
    parent_code: "292",
  },
  {
    value: "22255",
    label: "Thị trấn Phú Thứ",
    parent_code: "562",
  },
  {
    value: "31201",
    label: "Phường Phú Thứ",
    parent_code: "919",
  },
  {
    value: "00091",
    label: "Phường Phú Thượng",
    parent_code: "003",
  },
  {
    value: "05734",
    label: "Xã Phú Thượng",
    parent_code: "170",
  },
  {
    value: "19930",
    label: "Phường Phú Thượng",
    parent_code: "474",
  },
  {
    value: "05593",
    label: "Xã Phú Tiến",
    parent_code: "167",
  },
  {
    value: "22930",
    label: "Phường Phú Trinh",
    parent_code: "593",
  },
  {
    value: "25261",
    label: "Xã Phú Trung",
    parent_code: "698",
  },
  {
    value: "26146",
    label: "Xã Phú Trung",
    parent_code: "734",
  },
  {
    value: "27031",
    label: "Phường Phú Trung",
    parent_code: "767",
  },
  {
    value: "10294",
    label: "Xã Phú Túc",
    parent_code: "280",
  },
  {
    value: "26242",
    label: "Xã Phú Túc",
    parent_code: "736",
  },
  {
    value: "24076",
    label: "Thị trấn Phú Túc",
    parent_code: "637",
  },
  {
    value: "28819",
    label: "Xã Phú Túc",
    parent_code: "831",
  },
  {
    value: "12145",
    label: "Xã Phù Ủng",
    parent_code: "329",
  },
  {
    value: "29074",
    label: "Xã Phú Vang",
    parent_code: "835",
  },
  {
    value: "25229",
    label: "Xã Phú Văn",
    parent_code: "691",
  },
  {
    value: "13306",
    label: "Xã Phù Vân",
    parent_code: "347",
  },
  {
    value: "05137",
    label: "Xã Phú Vinh",
    parent_code: "155",
  },
  {
    value: "26215",
    label: "Xã Phú Vinh",
    parent_code: "736",
  },
  {
    value: "20074",
    label: "Xã Phú Vinh",
    parent_code: "481",
  },
  {
    value: "30400",
    label: "Xã Phú Vĩnh",
    parent_code: "887",
  },
  {
    value: "05470",
    label: "Phường Phú Xá",
    parent_code: "164",
  },
  {
    value: "06214",
    label: "Xã Phú Xá",
    parent_code: "183",
  },
  {
    value: "08971",
    label: "Xã Phú Xuân",
    parent_code: "249",
  },
  {
    value: "12463",
    label: "Xã Phú Xuân",
    parent_code: "336",
  },
  {
    value: "14890",
    label: "Xã Phú Xuân",
    parent_code: "385",
  },
  {
    value: "15577",
    label: "Xã Phú Xuân",
    parent_code: "395",
  },
  {
    value: "26149",
    label: "Xã Phú Xuân",
    parent_code: "734",
  },
  {
    value: "19918",
    label: "Xã Phú Xuân",
    parent_code: "478",
  },
  {
    value: "27655",
    label: "Xã Phú Xuân",
    parent_code: "786",
  },
  {
    value: "24364",
    label: "Xã Phú Xuân",
    parent_code: "650",
  },
  {
    value: "30439",
    label: "Xã Phú Xuân",
    parent_code: "888",
  },
  {
    value: "10273",
    label: "Thị trấn Phú Xuyên",
    parent_code: "280",
  },
  {
    value: "05797",
    label: "Xã Phú Xuyên",
    parent_code: "171",
  },
  {
    value: "03898",
    label: "Thị trấn Phù Yên",
    parent_code: "122",
  },
  {
    value: "10339",
    label: "Xã Phú Yên",
    parent_code: "280",
  },
  {
    value: "04759",
    label: "Xã Phúc An",
    parent_code: "141",
  },
  {
    value: "05560",
    label: "Xã Phúc Chu",
    parent_code: "167",
  },
  {
    value: "00620",
    label: "Phường Phúc Diễn",
    parent_code: "021",
  },
  {
    value: "00151",
    label: "Phường Phúc Đồng",
    parent_code: "004",
  },
  {
    value: "18514",
    label: "Xã Phúc Đồng",
    parent_code: "444",
  },
  {
    value: "05485",
    label: "Xã Phúc Hà",
    parent_code: "164",
  },
  {
    value: "09763",
    label: "Xã Phúc Hòa",
    parent_code: "272",
  },
  {
    value: "07324",
    label: "Xã Phúc Hòa",
    parent_code: "216",
  },
  {
    value: "08329",
    label: "Xã Phúc Khánh",
    parent_code: "234",
  },
  {
    value: "12634",
    label: "Xã Phúc Khánh",
    parent_code: "339",
  },
  {
    value: "02998",
    label: "Xã Phúc Khánh",
    parent_code: "087",
  },
  {
    value: "03602",
    label: "Xã Phúc Khoa",
    parent_code: "111",
  },
  {
    value: "09553",
    label: "Phường Phúc La",
    parent_code: "268",
  },
  {
    value: "08005",
    label: "Xã Phúc Lai",
    parent_code: "230",
  },
  {
    value: "10453",
    label: "Xã Phúc Lâm",
    parent_code: "282",
  },
  {
    value: "11542",
    label: "Xã Phục Lễ",
    parent_code: "311",
  },
  {
    value: "05794",
    label: "Xã Phục Linh",
    parent_code: "171",
  },
  {
    value: "01894",
    label: "Xã Phúc Lộc",
    parent_code: "061",
  },
  {
    value: "00136",
    label: "Phường Phúc Lợi",
    parent_code: "004",
  },
  {
    value: "04363",
    label: "Xã Phúc Lợi",
    parent_code: "135",
  },
  {
    value: "05767",
    label: "Xã Phúc Lương",
    parent_code: "171",
  },
  {
    value: "02452",
    label: "Xã Phúc Ninh",
    parent_code: "075",
  },
  {
    value: "04735",
    label: "Xã Phúc Ninh",
    parent_code: "141",
  },
  {
    value: "01603",
    label: "Xã Phúc Sen",
    parent_code: "049",
  },
  {
    value: "07318",
    label: "Xã Phúc Sơn",
    parent_code: "216",
  },
  {
    value: "07630",
    label: "Xã Phúc Sơn",
    parent_code: "220",
  },
  {
    value: "02299",
    label: "Xã Phúc Sơn",
    parent_code: "071",
  },
  {
    value: "04681",
    label: "Xã Phúc Sơn",
    parent_code: "133",
  },
  {
    value: "17374",
    label: "Xã Phúc Sơn",
    parent_code: "424",
  },
  {
    value: "00037",
    label: "Phường Phúc Tân",
    parent_code: "002",
  },
  {
    value: "05863",
    label: "Xã Phúc Tân",
    parent_code: "172",
  },
  {
    value: "03618",
    label: "Xã Phúc Than",
    parent_code: "110",
  },
  {
    value: "13207",
    label: "Xã Phúc Thành",
    parent_code: "344",
  },
  {
    value: "14335",
    label: "Phường Phúc Thành",
    parent_code: "369",
  },
  {
    value: "17539",
    label: "Xã Phúc Thành",
    parent_code: "426",
  },
  {
    value: "10774",
    label: "Xã Phúc Thành A",
    parent_code: "293",
  },
  {
    value: "08743",
    label: "Phường Phúc Thắng",
    parent_code: "244",
  },
  {
    value: "13951",
    label: "Xã Phúc Thắng",
    parent_code: "361",
  },
  {
    value: "15112",
    label: "Xã Phúc Thịnh",
    parent_code: "389",
  },
  {
    value: "02338",
    label: "Xã Phúc Thịnh",
    parent_code: "073",
  },
  {
    value: "09715",
    label: "Thị trấn Phúc Thọ",
    parent_code: "272",
  },
  {
    value: "17917",
    label: "Xã Phúc Thọ",
    parent_code: "429",
  },
  {
    value: "24898",
    label: "Xã Phúc Thọ",
    parent_code: "676",
  },
  {
    value: "05866",
    label: "Xã Phúc Thuận",
    parent_code: "172",
  },
  {
    value: "10327",
    label: "Xã Phúc Tiến",
    parent_code: "280",
  },
  {
    value: "18547",
    label: "Xã Phúc Trạch",
    parent_code: "444",
  },
  {
    value: "19138",
    label: "Xã Phúc Trạch",
    parent_code: "455",
  },
  {
    value: "05494",
    label: "Xã Phúc Trìu",
    parent_code: "164",
  },
  {
    value: "02569",
    label: "Xã Phúc Ứng",
    parent_code: "076",
  },
  {
    value: "00001",
    label: "Phường Phúc Xá",
    parent_code: "001",
  },
  {
    value: "05488",
    label: "Xã Phúc Xuân",
    parent_code: "164",
  },
  {
    value: "02233",
    label: "Xã Phúc Yên",
    parent_code: "071",
  },
  {
    value: "09784",
    label: "Thị trấn Phùng",
    parent_code: "273",
  },
  {
    value: "10021",
    label: "Xã Phụng Châu",
    parent_code: "277",
  },
  {
    value: "01843",
    label: "Phường Phùng Chí Kiên",
    parent_code: "058",
  },
  {
    value: "12130",
    label: "Phường Phùng Chí Kiên",
    parent_code: "328",
  },
  {
    value: "12028",
    label: "Xã Phụng Công",
    parent_code: "326",
  },
  {
    value: "15106",
    label: "Xã Phùng Giáo",
    parent_code: "389",
  },
  {
    value: "31417",
    label: "Xã Phụng Hiệp",
    parent_code: "934",
  },
  {
    value: "12253",
    label: "Xã Phùng Hưng",
    parent_code: "330",
  },
  {
    value: "15109",
    label: "Xã Phùng Minh",
    parent_code: "389",
  },
  {
    value: "08521",
    label: "Xã Phùng Nguyên",
    parent_code: "237",
  },
  {
    value: "09769",
    label: "Xã Phụng Thượng",
    parent_code: "272",
  },
  {
    value: "09997",
    label: "Xã Phùng Xá",
    parent_code: "276",
  },
  {
    value: "10474",
    label: "Xã Phùng Xá",
    parent_code: "282",
  },
  {
    value: "25351",
    label: "Xã Phước An",
    parent_code: "694",
  },
  {
    value: "26503",
    label: "Xã Phước An",
    parent_code: "742",
  },
  {
    value: "24490",
    label: "Thị trấn Phước An",
    parent_code: "654",
  },
  {
    value: "21985",
    label: "Xã Phước An",
    parent_code: "550",
  },
  {
    value: "25219",
    label: "Phường Phước Bình",
    parent_code: "688",
  },
  {
    value: "25729",
    label: "Xã Phước Bình",
    parent_code: "712",
  },
  {
    value: "22783",
    label: "Xã Phước Bình",
    parent_code: "584",
  },
  {
    value: "26416",
    label: "Xã Phước Bình",
    parent_code: "740",
  },
  {
    value: "26863",
    label: "Phường Phước Bình",
    parent_code: "769",
  },
  {
    value: "26620",
    label: "Thị trấn Phước Bửu",
    parent_code: "751",
  },
  {
    value: "25180",
    label: "Thị trấn Phước Cát ",
    parent_code: "683",
  },
  {
    value: "25165",
    label: "Xã Phước Cát 2",
    parent_code: "683",
  },
  {
    value: "20740",
    label: "Xã Phước Chánh",
    parent_code: "511",
  },
  {
    value: "25738",
    label: "Xã Phước Chỉ",
    parent_code: "712",
  },
  {
    value: "22837",
    label: "Xã Phước Chiến",
    parent_code: "588",
  },
  {
    value: "22804",
    label: "Xã Phước Chính",
    parent_code: "584",
  },
  {
    value: "20743",
    label: "Xã Phước Công",
    parent_code: "511",
  },
  {
    value: "22870",
    label: "Thị trấn Phước Dân",
    parent_code: "587",
  },
  {
    value: "22909",
    label: "Xã Phước Diêm",
    parent_code: "589",
  },
  {
    value: "22903",
    label: "Xã Phước Dinh",
    parent_code: "589",
  },
  {
    value: "22801",
    label: "Xã Phước Đại",
    parent_code: "584",
  },
  {
    value: "25672",
    label: "Xã Phước Đông",
    parent_code: "710",
  },
  {
    value: "28150",
    label: "Xã Phước Đông",
    parent_code: "806",
  },
  {
    value: "22405",
    label: "Xã Phước Đồng",
    parent_code: "568",
  },
  {
    value: "20731",
    label: "Xã Phước Đức",
    parent_code: "511",
  },
  {
    value: "20776",
    label: "Xã Phước Gia",
    parent_code: "512",
  },
  {
    value: "22885",
    label: "Xã Phước Hà",
    parent_code: "589",
  },
  {
    value: "22357",
    label: "Phường Phước Hải",
    parent_code: "568",
  },
  {
    value: "22894",
    label: "Xã Phước Hải",
    parent_code: "587",
  },
  {
    value: "26692",
    label: "Thị trấn Phước Hải",
    parent_code: "753",
  },
  {
    value: "29404",
    label: "Xã Phước Hảo",
    parent_code: "847",
  },
  {
    value: "22879",
    label: "Xã Phước Hậu",
    parent_code: "587",
  },
  {
    value: "28174",
    label: "Xã Phước Hậu",
    parent_code: "807",
  },
  {
    value: "29596",
    label: "Xã Phước Hậu",
    parent_code: "857",
  },
  {
    value: "26551",
    label: "Phường Phước Hiệp",
    parent_code: "748",
  },
  {
    value: "27529",
    label: "Xã Phước Hiệp",
    parent_code: "783",
  },
  {
    value: "20728",
    label: "Xã Phước Hiệp",
    parent_code: "511",
  },
  {
    value: "21973",
    label: "Xã Phước Hiệp",
    parent_code: "550",
  },
  {
    value: "28942",
    label: "Xã Phước Hiệp",
    parent_code: "833",
  },
  {
    value: "25885",
    label: "Xã Phước Hoà",
    parent_code: "722",
  },
  {
    value: "26713",
    label: "Phường Phước Hoà",
    parent_code: "754",
  },
  {
    value: "20729",
    label: "Xã Phước Hoà",
    parent_code: "511",
  },
  {
    value: "22372",
    label: "Phường Phước Hòa",
    parent_code: "568",
  },
  {
    value: "22786",
    label: "Xã Phước Hòa",
    parent_code: "584",
  },
  {
    value: "20338",
    label: "Phường Phước Hòa",
    parent_code: "502",
  },
  {
    value: "21967",
    label: "Xã Phước Hòa",
    parent_code: "550",
  },
  {
    value: "23231",
    label: "Phường Phước Hội",
    parent_code: "594",
  },
  {
    value: "26686",
    label: "Xã Phước Hội",
    parent_code: "753",
  },
  {
    value: "26548",
    label: "Phường Phước Hưng",
    parent_code: "748",
  },
  {
    value: "26677",
    label: "Xã Phước Hưng",
    parent_code: "752",
  },
  {
    value: "21961",
    label: "Xã Phước Hưng",
    parent_code: "550",
  },
  {
    value: "29464",
    label: "Xã Phước Hưng",
    parent_code: "849",
  },
  {
    value: "30358",
    label: "Xã Phước Hưng",
    parent_code: "886",
  },
  {
    value: "22891",
    label: "Xã Phước Hữu",
    parent_code: "587",
  },
  {
    value: "22843",
    label: "Xã Phước Kháng",
    parent_code: "588",
  },
  {
    value: "26500",
    label: "Xã Phước Khánh",
    parent_code: "742",
  },
  {
    value: "27646",
    label: "Xã Phước Kiển",
    parent_code: "786",
  },
  {
    value: "20746",
    label: "Xã Phước Kim",
    parent_code: "511",
  },
  {
    value: "28180",
    label: "Xã Phước Lại",
    parent_code: "807",
  },
  {
    value: "28183",
    label: "Xã Phước Lâm",
    parent_code: "807",
  },
  {
    value: "28357",
    label: "Xã Phước Lập",
    parent_code: "818",
  },
  {
    value: "22378",
    label: "Phường Phước Long",
    parent_code: "568",
  },
  {
    value: "29020",
    label: "Xã Phước Long",
    parent_code: "834",
  },
  {
    value: "31867",
    label: "Thị trấn Phước Long",
    parent_code: "957",
  },
  {
    value: "31876",
    label: "Xã Phước Long",
    parent_code: "957",
  },
  {
    value: "26851",
    label: "Phường Phước Long A",
    parent_code: "769",
  },
  {
    value: "26848",
    label: "Phường Phước Long B",
    parent_code: "769",
  },
  {
    value: "26683",
    label: "Xã Phước Long Thọ",
    parent_code: "753",
  },
  {
    value: "25123",
    label: "Xã Phước Lộc",
    parent_code: "681",
  },
  {
    value: "23232",
    label: "Phường Phước Lộc",
    parent_code: "594",
  },
  {
    value: "27649",
    label: "Xã Phước Lộc",
    parent_code: "786",
  },
  {
    value: "20749",
    label: "Xã Phước Lộc",
    parent_code: "511",
  },
  {
    value: "21976",
    label: "Xã Phước Lộc",
    parent_code: "550",
  },
  {
    value: "28030",
    label: "Xã Phước Lợi",
    parent_code: "803",
  },
  {
    value: "28162",
    label: "Xã Phước Lý",
    parent_code: "807",
  },
  {
    value: "25232",
    label: "Xã Phước Minh",
    parent_code: "691",
  },
  {
    value: "25564",
    label: "Xã Phước Minh",
    parent_code: "707",
  },
  {
    value: "22906",
    label: "Xã Phước Minh",
    parent_code: "589",
  },
  {
    value: "22741",
    label: "Phường Phước Mỹ",
    parent_code: "582",
  },
  {
    value: "20275",
    label: "Phường Phước Mỹ",
    parent_code: "493",
  },
  {
    value: "20737",
    label: "Xã Phước Mỹ",
    parent_code: "511",
  },
  {
    value: "21991",
    label: "Xã Phước Mỹ",
    parent_code: "540",
  },
  {
    value: "28915",
    label: "Xã Phước Mỹ Trung",
    parent_code: "838",
  },
  {
    value: "22897",
    label: "Xã Phước Nam",
    parent_code: "589",
  },
  {
    value: "20734",
    label: "Xã Phước Năng",
    parent_code: "511",
  },
  {
    value: "29137",
    label: "Xã Phước Ngãi",
    parent_code: "836",
  },
  {
    value: "21979",
    label: "Xã Phước Nghĩa",
    parent_code: "550",
  },
  {
    value: "26554",
    label: "Phường Phước Nguyên",
    parent_code: "748",
  },
  {
    value: "25561",
    label: "Xã Phước Ninh",
    parent_code: "707",
  },
  {
    value: "22898",
    label: "Xã Phước Ninh",
    parent_code: "589",
  },
  {
    value: "20242",
    label: "Phường Phước Ninh",
    parent_code: "492",
  },
  {
    value: "20669",
    label: "Xã Phước Ninh",
    parent_code: "519",
  },
  {
    value: "21964",
    label: "Xã Phước Quang",
    parent_code: "550",
  },
  {
    value: "25864",
    label: "Xã Phước Sang",
    parent_code: "722",
  },
  {
    value: "25429",
    label: "Xã Phước Sơn",
    parent_code: "696",
  },
  {
    value: "22873",
    label: "Xã Phước Sơn",
    parent_code: "587",
  },
  {
    value: "21970",
    label: "Xã Phước Sơn",
    parent_code: "550",
  },
  {
    value: "25250",
    label: "Xã Phước Tân",
    parent_code: "698",
  },
  {
    value: "22168",
    label: "Xã Phước Tân",
    parent_code: "560",
  },
  {
    value: "22360",
    label: "Phường Phước Tân",
    parent_code: "568",
  },
  {
    value: "26377",
    label: "Phường Phước Tân",
    parent_code: "731",
  },
  {
    value: "22789",
    label: "Xã Phước Tân",
    parent_code: "584",
  },
  {
    value: "26626",
    label: "Xã Phước Tân",
    parent_code: "751",
  },
  {
    value: "28231",
    label: "Xã Phước Tân Hưng",
    parent_code: "808",
  },
  {
    value: "22876",
    label: "Xã Phước Thái",
    parent_code: "587",
  },
  {
    value: "26422",
    label: "Xã Phước Thái",
    parent_code: "740",
  },
  {
    value: "22798",
    label: "Xã Phước Thành",
    parent_code: "584",
  },
  {
    value: "20752",
    label: "Xã Phước Thành",
    parent_code: "511",
  },
  {
    value: "21988",
    label: "Xã Phước Thành",
    parent_code: "550",
  },
  {
    value: "25669",
    label: "Xã Phước Thạnh",
    parent_code: "710",
  },
  {
    value: "27526",
    label: "Xã Phước Thạnh",
    parent_code: "783",
  },
  {
    value: "28567",
    label: "Xã Phước Thạnh",
    parent_code: "815",
  },
  {
    value: "28846",
    label: "Xã Phước Thạnh",
    parent_code: "831",
  },
  {
    value: "22795",
    label: "Xã Phước Thắng",
    parent_code: "584",
  },
  {
    value: "21958",
    label: "Xã Phước Thắng",
    parent_code: "550",
  },
  {
    value: "22990",
    label: "Xã Phước Thể",
    parent_code: "595",
  },
  {
    value: "26470",
    label: "Xã Phước Thiền",
    parent_code: "742",
  },
  {
    value: "25310",
    label: "Xã Phước Thiện",
    parent_code: "693",
  },
  {
    value: "31162",
    label: "Phường Phước Thới",
    parent_code: "917",
  },
  {
    value: "22882",
    label: "Xã Phước Thuận",
    parent_code: "587",
  },
  {
    value: "26623",
    label: "Xã Phước Thuận",
    parent_code: "751",
  },
  {
    value: "21982",
    label: "Xã Phước Thuận",
    parent_code: "550",
  },
  {
    value: "22366",
    label: "Phường Phước Tiến",
    parent_code: "568",
  },
  {
    value: "22792",
    label: "Xã Phước Tiến",
    parent_code: "584",
  },
  {
    value: "25249",
    label: "Xã Phước Tín",
    parent_code: "688",
  },
  {
    value: "20773",
    label: "Xã Phước Trà",
    parent_code: "512",
  },
  {
    value: "25675",
    label: "Xã Phước Trạch",
    parent_code: "710",
  },
  {
    value: "22807",
    label: "Xã Phước Trung",
    parent_code: "584",
  },
  {
    value: "26560",
    label: "Phường Phước Trung",
    parent_code: "748",
  },
  {
    value: "28744",
    label: "Xã Phước Trung",
    parent_code: "824",
  },
  {
    value: "28141",
    label: "Xã Phước Tuy",
    parent_code: "806",
  },
  {
    value: "28120",
    label: "Xã Phước Vân",
    parent_code: "806",
  },
  {
    value: "25591",
    label: "Xã Phước Vinh",
    parent_code: "708",
  },
  {
    value: "22912",
    label: "Xã Phước Vinh",
    parent_code: "587",
  },
  {
    value: "25858",
    label: "Thị trấn Phước Vĩnh",
    parent_code: "722",
  },
  {
    value: "19798",
    label: "Phường Phước Vĩnh",
    parent_code: "474",
  },
  {
    value: "27535",
    label: "Xã Phước Vĩnh An",
    parent_code: "783",
  },
  {
    value: "28195",
    label: "Xã Phước Vĩnh Đông",
    parent_code: "807",
  },
  {
    value: "28192",
    label: "Xã Phước Vĩnh Tây",
    parent_code: "807",
  },
  {
    value: "20725",
    label: "Xã Phước Xuân",
    parent_code: "511",
  },
  {
    value: "31426",
    label: "Xã Phương Bình",
    parent_code: "934",
  },
  {
    value: "09901",
    label: "Xã Phượng Cách",
    parent_code: "275",
  },
  {
    value: "00623",
    label: "Phường Phương Canh",
    parent_code: "019",
  },
  {
    value: "12382",
    label: "Xã Phương Chiểu",
    parent_code: "323",
  },
  {
    value: "13027",
    label: "Xã Phương Công",
    parent_code: "342",
  },
  {
    value: "10279",
    label: "Xã Phượng Dực",
    parent_code: "280",
  },
  {
    value: "09811",
    label: "Xã Phương Đình",
    parent_code: "273",
  },
  {
    value: "14029",
    label: "Xã Phương Định",
    parent_code: "363",
  },
  {
    value: "00946",
    label: "Xã Phương Độ",
    parent_code: "024",
  },
  {
    value: "06832",
    label: "Phường Phương Đông",
    parent_code: "196",
  },
  {
    value: "05749",
    label: "Xã Phương Giao",
    parent_code: "170",
  },
  {
    value: "22852",
    label: "Xã Phương Hải",
    parent_code: "586",
  },
  {
    value: "08809",
    label: "Xã Phương Khoan",
    parent_code: "253",
  },
  {
    value: "11137",
    label: "Xã Phượng Kỳ",
    parent_code: "298",
  },
  {
    value: "04807",
    label: "Phường Phương Lâm",
    parent_code: "148",
  },
  {
    value: "07921",
    label: "Xã Phượng Lâu",
    parent_code: "227",
  },
  {
    value: "00220",
    label: "Phường Phương Liên",
    parent_code: "006",
  },
  {
    value: "00358",
    label: "Phường Phương Liệt",
    parent_code: "009",
  },
  {
    value: "09265",
    label: "Xã Phương Liễu",
    parent_code: "259",
  },
  {
    value: "00232",
    label: "Phường Phương Mai",
    parent_code: "006",
  },
  {
    value: "09280",
    label: "Xã Phượng Mao",
    parent_code: "259",
  },
  {
    value: "06835",
    label: "Phường Phương Nam",
    parent_code: "196",
  },
  {
    value: "16240",
    label: "Xã Phượng Nghi",
    parent_code: "403",
  },
  {
    value: "31435",
    label: "Xã Phương Phú",
    parent_code: "934",
  },
  {
    value: "22351",
    label: "Phường Phương Sài",
    parent_code: "568",
  },
  {
    value: "07477",
    label: "Xã Phương Sơn",
    parent_code: "218",
  },
  {
    value: "22354",
    label: "Phường Phương Sơn",
    parent_code: "568",
  },
  {
    value: "07612",
    label: "Xã Phượng Sơn",
    parent_code: "219",
  },
  {
    value: "29290",
    label: "Xã Phương Thạnh",
    parent_code: "844",
  },
  {
    value: "00949",
    label: "Xã Phương Thiện",
    parent_code: "024",
  },
  {
    value: "30082",
    label: "Xã Phương Thịnh",
    parent_code: "873",
  },
  {
    value: "00940",
    label: "Xã Phương Tiến",
    parent_code: "030",
  },
  {
    value: "05566",
    label: "Xã Phượng Tiến",
    parent_code: "167",
  },
  {
    value: "30094",
    label: "Xã Phương Trà",
    parent_code: "873",
  },
  {
    value: "10162",
    label: "Xã Phương Trung",
    parent_code: "278",
  },
  {
    value: "10384",
    label: "Xã Phương Tú",
    parent_code: "281",
  },
  {
    value: "08356",
    label: "Xã Phượng Vĩ",
    parent_code: "235",
  },
  {
    value: "08089",
    label: "Xã Phương Viên",
    parent_code: "231",
  },
  {
    value: "02050",
    label: "Xã Phương Viên",
    parent_code: "064",
  },
  {
    value: "03835",
    label: "Xã Pi Toong",
    parent_code: "120",
  },
  {
    value: "23377",
    label: "Thị trấn Plei Kần",
    parent_code: "611",
  },
  {
    value: "02653",
    label: "Phường Pom Hán",
    parent_code: "080",
  },
  {
    value: "03356",
    label: "Xã Pom Lót",
    parent_code: "100",
  },
  {
    value: "23443",
    label: "Xã Pô Kô",
    parent_code: "612",
  },
  {
    value: "01033",
    label: "Xã Pố Lồ",
    parent_code: "032",
  },
  {
    value: "23467",
    label: "Xã Pờ Ê",
    parent_code: "613",
  },
  {
    value: "01057",
    label: "Xã Pờ Ly Ngài",
    parent_code: "032",
  },
  {
    value: "24013",
    label: "Xã Pờ Tó",
    parent_code: "635",
  },
  {
    value: "24316",
    label: "Xã Pơng Drang",
    parent_code: "649",
  },
  {
    value: "24955",
    label: "Xã Pró",
    parent_code: "677",
  },
  {
    value: "03484",
    label: "Xã Pú Đao",
    parent_code: "112",
  },
  {
    value: "03383",
    label: "Xã Pú Hồng",
    parent_code: "101",
  },
  {
    value: "14863",
    label: "Xã Pù Nhi",
    parent_code: "384",
  },
  {
    value: "03370",
    label: "Xã Pú Nhi",
    parent_code: "101",
  },
  {
    value: "03271",
    label: "Xã Pú Nhung",
    parent_code: "099",
  },
  {
    value: "04174",
    label: "Xã Pú Pẩu",
    parent_code: "126",
  },
  {
    value: "03523",
    label: "Xã Pu Sam Cáp",
    parent_code: "108",
  },
  {
    value: "04282",
    label: "Phường Pú Trạng",
    parent_code: "133",
  },
  {
    value: "03269",
    label: "Xã Pú Xi",
    parent_code: "099",
  },
  {
    value: "04228",
    label: "Xã Púng Bánh",
    parent_code: "127",
  },
  {
    value: "04492",
    label: "Xã Púng Luông",
    parent_code: "137",
  },
  {
    value: "03784",
    label: "Xã Púng Tra",
    parent_code: "119",
  },
  {
    value: "32182",
    label: "Xã Quách Phẩm",
    parent_code: "970",
  },
  {
    value: "32179",
    label: "Xã Quách Phẩm Bắc",
    parent_code: "970",
  },
  {
    value: "03289",
    label: "Xã Quài Cang",
    parent_code: "099",
  },
  {
    value: "03274",
    label: "Xã Quài Nưa",
    parent_code: "099",
  },
  {
    value: "03295",
    label: "Xã Quài Tở",
    parent_code: "099",
  },
  {
    value: "00898",
    label: "Xã Quản Bạ",
    parent_code: "029",
  },
  {
    value: "16670",
    label: "Phường Quán Bàu",
    parent_code: "412",
  },
  {
    value: "17827",
    label: "Thị trấn Quán Hành",
    parent_code: "429",
  },
  {
    value: "19201",
    label: "Thị trấn Quán Hàu",
    parent_code: "456",
  },
  {
    value: "00169",
    label: "Phường Quan Hoa",
    parent_code: "005",
  },
  {
    value: "02827",
    label: "Xã Quan Hồ Thẩn",
    parent_code: "084",
  },
  {
    value: "07024",
    label: "Xã Quan Lạn",
    parent_code: "203",
  },
  {
    value: "15469",
    label: "Thị trấn Quán Lào",
    parent_code: "394",
  },
  {
    value: "06517",
    label: "Xã Quan Sơn",
    parent_code: "187",
  },
  {
    value: "00013",
    label: "Phường Quán Thánh",
    parent_code: "001",
  },
  {
    value: "11296",
    label: "Phường Quán Toan",
    parent_code: "303",
  },
  {
    value: "05431",
    label: "Phường Quán Triều",
    parent_code: "164",
  },
  {
    value: "11428",
    label: "Phường Quán Trữ",
    parent_code: "307",
  },
  {
    value: "00100",
    label: "Phường Quảng An",
    parent_code: "003",
  },
  {
    value: "06901",
    label: "Xã Quảng An",
    parent_code: "200",
  },
  {
    value: "19888",
    label: "Xã Quảng An",
    parent_code: "477",
  },
  {
    value: "02038",
    label: "Xã Quảng Bạch",
    parent_code: "064",
  },
  {
    value: "10084",
    label: "Xã Quảng Bị",
    parent_code: "277",
  },
  {
    value: "13144",
    label: "Xã Quang Bình",
    parent_code: "343",
  },
  {
    value: "16468",
    label: "Xã Quảng Bình",
    parent_code: "406",
  },
  {
    value: "16507",
    label: "Phường Quảng Cát",
    parent_code: "380",
  },
  {
    value: "07807",
    label: "Xã Quang Châu",
    parent_code: "222",
  },
  {
    value: "11980",
    label: "Xã Quảng Châu",
    parent_code: "323",
  },
  {
    value: "16531",
    label: "Phường Quảng Châu",
    parent_code: "382",
  },
  {
    value: "19024",
    label: "Xã Quảng Châu",
    parent_code: "454",
  },
  {
    value: "14860",
    label: "Xã Quang Chiểu",
    parent_code: "384",
  },
  {
    value: "06943",
    label: "Xã Quảng Chính",
    parent_code: "201",
  },
  {
    value: "16495",
    label: "Xã Quảng Chính",
    parent_code: "406",
  },
  {
    value: "02131",
    label: "Xã Quảng Chu",
    parent_code: "065",
  },
  {
    value: "19879",
    label: "Xã Quảng Công",
    parent_code: "477",
  },
  {
    value: "14839",
    label: "Phường Quảng Cư",
    parent_code: "382",
  },
  {
    value: "18184",
    label: "Xã Quang Diệm",
    parent_code: "439",
  },
  {
    value: "16537",
    label: "Xã Quảng Đại",
    parent_code: "382",
  },
  {
    value: "24577",
    label: "Xã Quảng Điền",
    parent_code: "655",
  },
  {
    value: "16456",
    label: "Xã Quảng Định",
    parent_code: "406",
  },
  {
    value: "16459",
    label: "Phường Quảng Đông",
    parent_code: "380",
  },
  {
    value: "19018",
    label: "Xã Quảng Đông",
    parent_code: "454",
  },
  {
    value: "06925",
    label: "Xã Quảng Đức",
    parent_code: "201",
  },
  {
    value: "16453",
    label: "Xã Quảng Đức",
    parent_code: "406",
  },
  {
    value: "16519",
    label: "Xã Quảng Giao",
    parent_code: "406",
  },
  {
    value: "06922",
    label: "Thị trấn Quảng Hà",
    parent_code: "201",
  },
  {
    value: "16540",
    label: "Xã Quảng Hải",
    parent_code: "406",
  },
  {
    value: "19087",
    label: "Xã Quảng Hải",
    parent_code: "458",
  },
  {
    value: "01456",
    label: "Xã Quang Hán",
    parent_code: "047",
  },
  {
    value: "06778",
    label: "Phường Quang Hanh",
    parent_code: "195",
  },
  {
    value: "24286",
    label: "Xã Quảng Hiệp",
    parent_code: "648",
  },
  {
    value: "24620",
    label: "Xã Quảng Hoà",
    parent_code: "661",
  },
  {
    value: "16483",
    label: "Xã Quảng Hòa",
    parent_code: "406",
  },
  {
    value: "19105",
    label: "Xã Quảng Hòa",
    parent_code: "458",
  },
  {
    value: "16471",
    label: "Xã Quảng Hợp",
    parent_code: "406",
  },
  {
    value: "19012",
    label: "Xã Quảng Hợp",
    parent_code: "454",
  },
  {
    value: "08470",
    label: "Xã Quang Húc",
    parent_code: "236",
  },
  {
    value: "16516",
    label: "Xã Quảng Hùng",
    parent_code: "382",
  },
  {
    value: "03910",
    label: "Xã Quang Huy",
    parent_code: "122",
  },
  {
    value: "11644",
    label: "Xã Quang Hưng",
    parent_code: "313",
  },
  {
    value: "12400",
    label: "Xã Quang Hưng",
    parent_code: "333",
  },
  {
    value: "01582",
    label: "Xã Quảng Hưng",
    parent_code: "049",
  },
  {
    value: "14800",
    label: "Phường Quảng Hưng",
    parent_code: "380",
  },
  {
    value: "19042",
    label: "Xã Quảng Hưng",
    parent_code: "454",
  },
  {
    value: "11116",
    label: "Xã Quang Khải",
    parent_code: "298",
  },
  {
    value: "01924",
    label: "Xã Quảng Khê",
    parent_code: "061",
  },
  {
    value: "16489",
    label: "Xã Quảng Khê",
    parent_code: "406",
  },
  {
    value: "24631",
    label: "Xã Quảng Khê",
    parent_code: "661",
  },
  {
    value: "02734",
    label: "Xã Quang Kim",
    parent_code: "082",
  },
  {
    value: "19015",
    label: "Xã Quảng Kim",
    parent_code: "454",
  },
  {
    value: "07054",
    label: "Xã Quảng La",
    parent_code: "193",
  },
  {
    value: "05989",
    label: "Xã Quảng Lạc",
    parent_code: "178",
  },
  {
    value: "14461",
    label: "Xã Quảng Lạc",
    parent_code: "372",
  },
  {
    value: "10345",
    label: "Xã Quang Lãng",
    parent_code: "280",
  },
  {
    value: "12172",
    label: "Xã Quảng Lãng",
    parent_code: "329",
  },
  {
    value: "01303",
    label: "Xã Quảng Lâm",
    parent_code: "042",
  },
  {
    value: "06898",
    label: "Xã Quảng Lâm",
    parent_code: "200",
  },
  {
    value: "03164",
    label: "Xã Quảng Lâm",
    parent_code: "096",
  },
  {
    value: "24946",
    label: "Xã Quảng Lập",
    parent_code: "677",
  },
  {
    value: "13132",
    label: "Xã Quang Lịch",
    parent_code: "343",
  },
  {
    value: "01552",
    label: "Xã Quang Long",
    parent_code: "048",
  },
  {
    value: "06946",
    label: "Xã Quảng Long",
    parent_code: "201",
  },
  {
    value: "16477",
    label: "Xã Quảng Long",
    parent_code: "406",
  },
  {
    value: "19060",
    label: "Phường Quảng Long",
    parent_code: "458",
  },
  {
    value: "16069",
    label: "Xã Quang Lộc",
    parent_code: "400",
  },
  {
    value: "18481",
    label: "Xã Quang Lộc",
    parent_code: "443",
  },
  {
    value: "16546",
    label: "Xã Quảng Lộc",
    parent_code: "406",
  },
  {
    value: "19093",
    label: "Xã Quảng Lộc",
    parent_code: "458",
  },
  {
    value: "19876",
    label: "Xã Quảng Lợi",
    parent_code: "477",
  },
  {
    value: "16543",
    label: "Xã Quảng Lưu",
    parent_code: "406",
  },
  {
    value: "19030",
    label: "Xã Quảng Lưu",
    parent_code: "454",
  },
  {
    value: "08989",
    label: "Thị trấn Quang Minh",
    parent_code: "250",
  },
  {
    value: "01189",
    label: "Xã Quang Minh",
    parent_code: "034",
  },
  {
    value: "11062",
    label: "Xã Quang Minh",
    parent_code: "297",
  },
  {
    value: "07843",
    label: "Xã Quang Minh",
    parent_code: "223",
  },
  {
    value: "13162",
    label: "Xã Quang Minh",
    parent_code: "343",
  },
  {
    value: "04042",
    label: "Xã Quang Minh",
    parent_code: "128",
  },
  {
    value: "04393",
    label: "Xã Quang Minh",
    parent_code: "136",
  },
  {
    value: "25439",
    label: "Xã Quang Minh",
    parent_code: "697",
  },
  {
    value: "06940",
    label: "Xã Quảng Minh",
    parent_code: "201",
  },
  {
    value: "07792",
    label: "Xã Quảng Minh",
    parent_code: "222",
  },
  {
    value: "16513",
    label: "Xã Quảng Minh",
    parent_code: "382",
  },
  {
    value: "19108",
    label: "Xã Quảng Minh",
    parent_code: "458",
  },
  {
    value: "25189",
    label: "Xã Quảng Ngãi",
    parent_code: "683",
  },
  {
    value: "19873",
    label: "Xã Quảng Ngạn",
    parent_code: "477",
  },
  {
    value: "00964",
    label: "Xã Quảng Ngần",
    parent_code: "030",
  },
  {
    value: "06739",
    label: "Xã Quảng Nghĩa",
    parent_code: "194",
  },
  {
    value: "11122",
    label: "Xã Quảng Nghiệp",
    parent_code: "298",
  },
  {
    value: "16498",
    label: "Xã Quảng Ngọc",
    parent_code: "406",
  },
  {
    value: "01144",
    label: "Xã Quảng Nguyên",
    parent_code: "033",
  },
  {
    value: "16552",
    label: "Xã Quảng Nham",
    parent_code: "406",
  },
  {
    value: "20083",
    label: "Xã Quảng Nhâm",
    parent_code: "481",
  },
  {
    value: "16462",
    label: "Xã Quảng Nhân",
    parent_code: "406",
  },
  {
    value: "16465",
    label: "Xã Quảng Ninh",
    parent_code: "406",
  },
  {
    value: "02185",
    label: "Xã Quang Phong",
    parent_code: "066",
  },
  {
    value: "16993",
    label: "Phường Quang Phong",
    parent_code: "414",
  },
  {
    value: "16771",
    label: "Xã Quang Phong",
    parent_code: "415",
  },
  {
    value: "06952",
    label: "Xã Quảng Phong",
    parent_code: "201",
  },
  {
    value: "19078",
    label: "Phường Quảng Phong",
    parent_code: "458",
  },
  {
    value: "18883",
    label: "Xã Quang Phú",
    parent_code: "450",
  },
  {
    value: "09514",
    label: "Xã Quảng Phú",
    parent_code: "264",
  },
  {
    value: "16522",
    label: "Phường Quảng Phú",
    parent_code: "380",
  },
  {
    value: "15571",
    label: "Xã Quảng Phú",
    parent_code: "395",
  },
  {
    value: "19021",
    label: "Xã Quảng Phú",
    parent_code: "454",
  },
  {
    value: "24712",
    label: "Xã Quảng Phú",
    parent_code: "664",
  },
  {
    value: "19897",
    label: "Xã Quảng Phú",
    parent_code: "477",
  },
  {
    value: "24259",
    label: "Thị trấn Quảng Phú",
    parent_code: "648",
  },
  {
    value: "21016",
    label: "Phường Quảng Phú",
    parent_code: "522",
  },
  {
    value: "10366",
    label: "Xã Quảng Phú Cầu",
    parent_code: "281",
  },
  {
    value: "11101",
    label: "Xã Quang Phục",
    parent_code: "298",
  },
  {
    value: "11791",
    label: "Xã Quang Phục",
    parent_code: "315",
  },
  {
    value: "16510",
    label: "Xã Quảng Phúc",
    parent_code: "406",
  },
  {
    value: "19102",
    label: "Phường Quảng Phúc",
    parent_code: "458",
  },
  {
    value: "19882",
    label: "Xã Quảng Phước",
    parent_code: "477",
  },
  {
    value: "19057",
    label: "Xã Quảng Phương",
    parent_code: "454",
  },
  {
    value: "08764",
    label: "Xã Quang Sơn",
    parent_code: "246",
  },
  {
    value: "05674",
    label: "Xã Quang Sơn",
    parent_code: "169",
  },
  {
    value: "14377",
    label: "Xã Quang Sơn",
    parent_code: "370",
  },
  {
    value: "17680",
    label: "Xã Quang Sơn",
    parent_code: "427",
  },
  {
    value: "06928",
    label: "Xã Quảng Sơn",
    parent_code: "201",
  },
  {
    value: "22819",
    label: "Xã Quảng Sơn",
    parent_code: "585",
  },
  {
    value: "24616",
    label: "Xã Quảng Sơn",
    parent_code: "661",
  },
  {
    value: "19090",
    label: "Xã Quảng Sơn",
    parent_code: "458",
  },
  {
    value: "16525",
    label: "Phường Quảng Tâm",
    parent_code: "380",
  },
  {
    value: "24740",
    label: "Xã Quảng Tâm",
    parent_code: "667",
  },
  {
    value: "06913",
    label: "Xã Quảng Tân",
    parent_code: "200",
  },
  {
    value: "24748",
    label: "Xã Quảng Tân",
    parent_code: "667",
  },
  {
    value: "19084",
    label: "Xã Quảng Tân",
    parent_code: "458",
  },
  {
    value: "16555",
    label: "Xã Quảng Thạch",
    parent_code: "406",
  },
  {
    value: "19027",
    label: "Xã Quảng Thạch",
    parent_code: "454",
  },
  {
    value: "16558",
    label: "Xã Quảng Thái",
    parent_code: "406",
  },
  {
    value: "19870",
    label: "Xã Quảng Thái",
    parent_code: "477",
  },
  {
    value: "01771",
    label: "Xã Quang Thành",
    parent_code: "052",
  },
  {
    value: "10705",
    label: "Xã Quang Thành",
    parent_code: "292",
  },
  {
    value: "17533",
    label: "Xã Quang Thành",
    parent_code: "426",
  },
  {
    value: "11506",
    label: "Xã Quảng Thanh",
    parent_code: "311",
  },
  {
    value: "19072",
    label: "Xã Quảng Thanh",
    parent_code: "454",
  },
  {
    value: "06931",
    label: "Xã Quảng Thành",
    parent_code: "201",
  },
  {
    value: "14806",
    label: "Phường Quảng Thành",
    parent_code: "380",
  },
  {
    value: "26605",
    label: "Xã Quảng Thành",
    parent_code: "750",
  },
  {
    value: "24619",
    label: "Phường Quảng Thành",
    parent_code: "660",
  },
  {
    value: "19891",
    label: "Xã Quảng Thành",
    parent_code: "477",
  },
  {
    value: "14803",
    label: "Phường Quảng Thắng",
    parent_code: "380",
  },
  {
    value: "14647",
    label: "Xã Quang Thiện",
    parent_code: "376",
  },
  {
    value: "07384",
    label: "Xã Quang Thịnh",
    parent_code: "217",
  },
  {
    value: "06937",
    label: "Xã Quảng Thịnh",
    parent_code: "201",
  },
  {
    value: "16441",
    label: "Phường Quảng Thịnh",
    parent_code: "380",
  },
  {
    value: "18343",
    label: "Xã Quang Thọ",
    parent_code: "441",
  },
  {
    value: "16528",
    label: "Phường Quảng Thọ",
    parent_code: "382",
  },
  {
    value: "19894",
    label: "Xã Quảng Thọ",
    parent_code: "477",
  },
  {
    value: "19066",
    label: "Phường Quảng Thọ",
    parent_code: "458",
  },
  {
    value: "02017",
    label: "Xã Quang Thuận",
    parent_code: "063",
  },
  {
    value: "19081",
    label: "Phường Quảng Thuận",
    parent_code: "458",
  },
  {
    value: "19096",
    label: "Xã Quảng Thủy",
    parent_code: "458",
  },
  {
    value: "00409",
    label: "Xã Quang Tiến",
    parent_code: "016",
  },
  {
    value: "07315",
    label: "Xã Quang Tiến",
    parent_code: "216",
  },
  {
    value: "04906",
    label: "Xã Quang Tiến",
    parent_code: "148",
  },
  {
    value: "16994",
    label: "Phường Quang Tiến",
    parent_code: "414",
  },
  {
    value: "19069",
    label: "Xã Quảng Tiên",
    parent_code: "458",
  },
  {
    value: "14842",
    label: "Phường Quảng Tiến",
    parent_code: "382",
  },
  {
    value: "19039",
    label: "Xã Quảng Tiến",
    parent_code: "454",
  },
  {
    value: "26290",
    label: "Xã Quảng Tiến",
    parent_code: "737",
  },
  {
    value: "24262",
    label: "Xã Quảng Tiến",
    parent_code: "648",
  },
  {
    value: "24745",
    label: "Xã Quảng Tín",
    parent_code: "666",
  },
  {
    value: "16447",
    label: "Xã Quảng Trạch",
    parent_code: "406",
  },
  {
    value: "25138",
    label: "Xã Quảng Trị",
    parent_code: "682",
  },
  {
    value: "01813",
    label: "Xã Quang Trọng",
    parent_code: "053",
  },
  {
    value: "00214",
    label: "Phường Quang Trung",
    parent_code: "006",
  },
  {
    value: "09550",
    label: "Phường Quang Trung",
    parent_code: "268",
  },
  {
    value: "09583",
    label: "Phường Quang Trung",
    parent_code: "269",
  },
  {
    value: "10306",
    label: "Xã Quang Trung",
    parent_code: "280",
  },
  {
    value: "00688",
    label: "Phường Quang Trung",
    parent_code: "024",
  },
  {
    value: "01465",
    label: "Xã Quang Trung",
    parent_code: "047",
  },
  {
    value: "01702",
    label: "Xã Quang Trung",
    parent_code: "051",
  },
  {
    value: "10516",
    label: "Phường Quang Trung",
    parent_code: "288",
  },
  {
    value: "11134",
    label: "Xã Quang Trung",
    parent_code: "298",
  },
  {
    value: "11647",
    label: "Xã Quang Trung",
    parent_code: "313",
  },
  {
    value: "11965",
    label: "Phường Quang Trung",
    parent_code: "323",
  },
  {
    value: "12445",
    label: "Phường Quang Trung",
    parent_code: "336",
  },
  {
    value: "05446",
    label: "Phường Quang Trung",
    parent_code: "164",
  },
  {
    value: "06088",
    label: "Xã Quang Trung",
    parent_code: "181",
  },
  {
    value: "06817",
    label: "Phường Quang Trung",
    parent_code: "196",
  },
  {
    value: "13165",
    label: "Xã Quang Trung",
    parent_code: "343",
  },
  {
    value: "13285",
    label: "Phường Quang Trung",
    parent_code: "347",
  },
  {
    value: "13645",
    label: "Phường Quang Trung",
    parent_code: "356",
  },
  {
    value: "13768",
    label: "Xã Quang Trung",
    parent_code: "359",
  },
  {
    value: "14824",
    label: "Xã Quang Trung",
    parent_code: "381",
  },
  {
    value: "15085",
    label: "Xã Quang Trung",
    parent_code: "389",
  },
  {
    value: "16681",
    label: "Phường Quang Trung",
    parent_code: "412",
  },
  {
    value: "26311",
    label: "Xã Quang Trung",
    parent_code: "738",
  },
  {
    value: "23281",
    label: "Phường Quang Trung",
    parent_code: "608",
  },
  {
    value: "21565",
    label: "Phường Quang Trung",
    parent_code: "540",
  },
  {
    value: "16492",
    label: "Xã Quảng Trung",
    parent_code: "406",
  },
  {
    value: "19075",
    label: "Xã Quảng Trung",
    parent_code: "458",
  },
  {
    value: "24736",
    label: "Xã Quảng Trực",
    parent_code: "667",
  },
  {
    value: "16501",
    label: "Xã Quảng Trường",
    parent_code: "406",
  },
  {
    value: "19033",
    label: "Xã Quảng Tùng",
    parent_code: "454",
  },
  {
    value: "01576",
    label: "Thị trấn Quảng Uyên",
    parent_code: "049",
  },
  {
    value: "16474",
    label: "Xã Quảng Văn",
    parent_code: "406",
  },
  {
    value: "19099",
    label: "Xã Quảng Văn",
    parent_code: "458",
  },
  {
    value: "01468",
    label: "Xã Quang Vinh",
    parent_code: "047",
  },
  {
    value: "12163",
    label: "Xã Quang Vinh",
    parent_code: "329",
  },
  {
    value: "05434",
    label: "Phường Quang Vinh",
    parent_code: "164",
  },
  {
    value: "26023",
    label: "Phường Quang Vinh",
    parent_code: "731",
  },
  {
    value: "18235",
    label: "Xã Quang Vĩnh",
    parent_code: "440",
  },
  {
    value: "16534",
    label: "Phường Quảng Vinh",
    parent_code: "382",
  },
  {
    value: "19885",
    label: "Xã Quảng Vinh",
    parent_code: "477",
  },
  {
    value: "19045",
    label: "Xã Quảng Xuân",
    parent_code: "454",
  },
  {
    value: "08776",
    label: "Xã Quang Yên",
    parent_code: "253",
  },
  {
    value: "07132",
    label: "Phường Quảng Yên",
    parent_code: "206",
  },
  {
    value: "08173",
    label: "Xã Quảng Yên",
    parent_code: "232",
  },
  {
    value: "16480",
    label: "Xã Quảng Yên",
    parent_code: "406",
  },
  {
    value: "05764",
    label: "Thị trấn Quân Chu",
    parent_code: "171",
  },
  {
    value: "05851",
    label: "Xã Quân Chu",
    parent_code: "171",
  },
  {
    value: "02005",
    label: "Xã Quân Hà",
    parent_code: "063",
  },
  {
    value: "10234",
    label: "Xã Quất Động",
    parent_code: "279",
  },
  {
    value: "14152",
    label: "Thị trấn Quất Lâm",
    parent_code: "365",
  },
  {
    value: "08956",
    label: "Xã Quất Lưu",
    parent_code: "249",
  },
  {
    value: "13384",
    label: "Thị trấn Quế",
    parent_code: "350",
  },
  {
    value: "20686",
    label: "Xã Quế An",
    parent_code: "509",
  },
  {
    value: "20680",
    label: "Xã Quế Châu",
    parent_code: "509",
  },
  {
    value: "20659",
    label: "Xã Quế Hiệp",
    parent_code: "509",
  },
  {
    value: "20692",
    label: "Xã Quế Lâm",
    parent_code: "519",
  },
  {
    value: "20677",
    label: "Xã Quế Long",
    parent_code: "509",
  },
  {
    value: "20671",
    label: "Xã Quế Lộc",
    parent_code: "519",
  },
  {
    value: "20782",
    label: "Xã Quế Lưu",
    parent_code: "512",
  },
  {
    value: "20689",
    label: "Xã Quế Minh",
    parent_code: "509",
  },
  {
    value: "20665",
    label: "Xã Quế Mỹ",
    parent_code: "509",
  },
  {
    value: "28084",
    label: "Xã Quê Mỹ Thạnh",
    parent_code: "805",
  },
  {
    value: "07366",
    label: "Xã Quế Nham",
    parent_code: "216",
  },
  {
    value: "20683",
    label: "Xã Quế Phong",
    parent_code: "509",
  },
  {
    value: "20650",
    label: "Xã Quế Phú",
    parent_code: "509",
  },
  {
    value: "09268",
    label: "Xã Quế Tân",
    parent_code: "259",
  },
  {
    value: "20764",
    label: "Xã Quế Thọ",
    parent_code: "512",
  },
  {
    value: "20662",
    label: "Xã Quế Thuận",
    parent_code: "509",
  },
  {
    value: "20656",
    label: "Xã Quế Trung",
    parent_code: "519",
  },
  {
    value: "20644",
    label: "Xã Quế Xuân 1",
    parent_code: "509",
  },
  {
    value: "20647",
    label: "Xã Quế Xuân 2",
    parent_code: "509",
  },
  {
    value: "03991",
    label: "Xã Qui Hướng",
    parent_code: "123",
  },
  {
    value: "02431",
    label: "Xã Quí Quân",
    parent_code: "075",
  },
  {
    value: "06004",
    label: "Xã Quốc Khánh",
    parent_code: "180",
  },
  {
    value: "09895",
    label: "Thị trấn Quốc Oai",
    parent_code: "275",
  },
  {
    value: "25132",
    label: "Xã Quốc Oai",
    parent_code: "682",
  },
  {
    value: "30346",
    label: "Xã Quốc Thái",
    parent_code: "886",
  },
  {
    value: "01474",
    label: "Xã Quốc Toản",
    parent_code: "049",
  },
  {
    value: "10624",
    label: "Xã Quốc Tuấn",
    parent_code: "291",
  },
  {
    value: "11620",
    label: "Xã Quốc Tuấn",
    parent_code: "312",
  },
  {
    value: "11650",
    label: "Xã Quốc Tuấn",
    parent_code: "313",
  },
  {
    value: "13081",
    label: "Xã Quốc Tuấn",
    parent_code: "343",
  },
  {
    value: "00184",
    label: "Phường Quốc Tử Giám",
    parent_code: "006",
  },
  {
    value: "06058",
    label: "Xã Quốc Việt",
    parent_code: "180",
  },
  {
    value: "29668",
    label: "Xã Quới An",
    parent_code: "859",
  },
  {
    value: "29191",
    label: "Xã Quới Điền",
    parent_code: "837",
  },
  {
    value: "28843",
    label: "Xã Quới Thành",
    parent_code: "831",
  },
  {
    value: "29665",
    label: "Xã Quới Thiện",
    parent_code: "859",
  },
  {
    value: "28618",
    label: "Xã Quơn Long",
    parent_code: "822",
  },
  {
    value: "18901",
    label: "Thị trấn Quy Đạt",
    parent_code: "452",
  },
  {
    value: "27640",
    label: "Xã Quy Đức",
    parent_code: "785",
  },
  {
    value: "05269",
    label: "Xã Quý Hòa",
    parent_code: "157",
  },
  {
    value: "06076",
    label: "Xã Quý Hòa",
    parent_code: "181",
  },
  {
    value: "17035",
    label: "Thị trấn Quỳ Hợp",
    parent_code: "420",
  },
  {
    value: "05545",
    label: "Xã Quy Kỳ",
    parent_code: "167",
  },
  {
    value: "15412",
    label: "Thị trấn Quý Lộc",
    parent_code: "394",
  },
  {
    value: "04519",
    label: "Xã Quy Mông",
    parent_code: "138",
  },
  {
    value: "13936",
    label: "Thị trấn Quỹ Nhất",
    parent_code: "361",
  },
  {
    value: "01432",
    label: "Xã Quý Quân",
    parent_code: "045",
  },
  {
    value: "07576",
    label: "Xã Quý Sơn",
    parent_code: "219",
  },
  {
    value: "05152",
    label: "Xã Quyết Chiến",
    parent_code: "155",
  },
  {
    value: "03655",
    label: "Phường Quyết Tâm",
    parent_code: "116",
  },
  {
    value: "10822",
    label: "Xã Quyết Thắng",
    parent_code: "288",
  },
  {
    value: "05299",
    label: "Xã Quyết Thắng",
    parent_code: "157",
  },
  {
    value: "05491",
    label: "Xã Quyết Thắng",
    parent_code: "164",
  },
  {
    value: "06394",
    label: "Xã Quyết Thắng",
    parent_code: "186",
  },
  {
    value: "02584",
    label: "Xã Quyết Thắng",
    parent_code: "076",
  },
  {
    value: "03386",
    label: "Phường Quyết Thắng",
    parent_code: "105",
  },
  {
    value: "03652",
    label: "Phường Quyết Thắng",
    parent_code: "116",
  },
  {
    value: "26041",
    label: "Phường Quyết Thắng",
    parent_code: "731",
  },
  {
    value: "23287",
    label: "Phường Quyết Thắng",
    parent_code: "608",
  },
  {
    value: "00904",
    label: "Xã Quyết Tiến",
    parent_code: "029",
  },
  {
    value: "11770",
    label: "Xã Quyết Tiến",
    parent_code: "315",
  },
  {
    value: "03388",
    label: "Phường Quyết Tiến",
    parent_code: "105",
  },
  {
    value: "17185",
    label: "Xã Quỳnh Bá",
    parent_code: "421",
  },
  {
    value: "17158",
    label: "Xã Quỳnh Bảng",
    parent_code: "421",
  },
  {
    value: "12556",
    label: "Xã Quỳnh Bảo",
    parent_code: "338",
  },
  {
    value: "17122",
    label: "Xã Quỳnh Châu",
    parent_code: "421",
  },
  {
    value: "12472",
    label: "Thị trấn Quỳnh Côi",
    parent_code: "338",
  },
  {
    value: "17128",
    label: "Phường Quỳnh Dị",
    parent_code: "432",
  },
  {
    value: "17191",
    label: "Xã Quỳnh Diễn",
    parent_code: "421",
  },
  {
    value: "17173",
    label: "Xã Quỳnh Đôi",
    parent_code: "421",
  },
  {
    value: "17197",
    label: "Xã Quỳnh Giang",
    parent_code: "421",
  },
  {
    value: "12496",
    label: "Xã Quỳnh Giao",
    parent_code: "338",
  },
  {
    value: "12520",
    label: "Xã Quỳnh Hải",
    parent_code: "338",
  },
  {
    value: "17167",
    label: "Xã Quỳnh Hậu",
    parent_code: "421",
  },
  {
    value: "12481",
    label: "Xã Quỳnh Hoa",
    parent_code: "338",
  },
  {
    value: "17152",
    label: "Xã Quỳnh Hoa",
    parent_code: "421",
  },
  {
    value: "12493",
    label: "Xã Quỳnh Hoàng",
    parent_code: "338",
  },
  {
    value: "12529",
    label: "Xã Quỳnh Hội",
    parent_code: "338",
  },
  {
    value: "12505",
    label: "Xã Quỳnh Hồng",
    parent_code: "338",
  },
  {
    value: "17179",
    label: "Xã Quỳnh Hồng",
    parent_code: "421",
  },
  {
    value: "12553",
    label: "Xã Quỳnh Hưng",
    parent_code: "338",
  },
  {
    value: "17194",
    label: "Xã Quỳnh Hưng",
    parent_code: "421",
  },
  {
    value: "12508",
    label: "Xã Quỳnh Khê",
    parent_code: "338",
  },
  {
    value: "12484",
    label: "Xã Quỳnh Lâm",
    parent_code: "338",
  },
  {
    value: "04816",
    label: "Phường Quỳnh Lâm",
    parent_code: "148",
  },
  {
    value: "17170",
    label: "Xã Quỳnh Lâm",
    parent_code: "421",
  },
  {
    value: "17113",
    label: "Xã Quỳnh Lập",
    parent_code: "432",
  },
  {
    value: "17137",
    label: "Xã Quỳnh Liên",
    parent_code: "432",
  },
  {
    value: "17221",
    label: "Xã Quỳnh Long",
    parent_code: "421",
  },
  {
    value: "17107",
    label: "Xã Quỳnh Lộc",
    parent_code: "432",
  },
  {
    value: "00292",
    label: "Phường Quỳnh Lôi",
    parent_code: "007",
  },
  {
    value: "17176",
    label: "Xã Quỳnh Lương",
    parent_code: "421",
  },
  {
    value: "14452",
    label: "Xã Quỳnh Lưu",
    parent_code: "372",
  },
  {
    value: "00289",
    label: "Phường Quỳnh Mai",
    parent_code: "007",
  },
  {
    value: "12511",
    label: "Xã Quỳnh Minh",
    parent_code: "338",
  },
  {
    value: "17188",
    label: "Xã Quỳnh Minh",
    parent_code: "421",
  },
  {
    value: "12535",
    label: "Xã Quỳnh Mỹ",
    parent_code: "338",
  },
  {
    value: "17161",
    label: "Xã Quỳnh Mỹ",
    parent_code: "421",
  },
  {
    value: "17203",
    label: "Xã Quỳnh Nghĩa",
    parent_code: "421",
  },
  {
    value: "12517",
    label: "Xã Quỳnh Ngọc",
    parent_code: "338",
  },
  {
    value: "17200",
    label: "Xã Quỳnh Ngọc",
    parent_code: "421",
  },
  {
    value: "12562",
    label: "Xã Quỳnh Nguyên",
    parent_code: "338",
  },
  {
    value: "09493",
    label: "Xã Quỳnh Phú",
    parent_code: "263",
  },
  {
    value: "17134",
    label: "Phường Quỳnh Phương",
    parent_code: "432",
  },
  {
    value: "07702",
    label: "Xã Quỳnh Sơn",
    parent_code: "221",
  },
  {
    value: "17149",
    label: "Xã Quỳnh Tam",
    parent_code: "421",
  },
  {
    value: "17119",
    label: "Xã Quỳnh Tân",
    parent_code: "421",
  },
  {
    value: "17155",
    label: "Xã Quỳnh Thạch",
    parent_code: "421",
  },
  {
    value: "17164",
    label: "Xã Quỳnh Thanh",
    parent_code: "421",
  },
  {
    value: "17101",
    label: "Xã Quỳnh Thắng",
    parent_code: "421",
  },
  {
    value: "17110",
    label: "Phường Quỳnh Thiện",
    parent_code: "432",
  },
  {
    value: "12487",
    label: "Xã Quỳnh Thọ",
    parent_code: "338",
  },
  {
    value: "17215",
    label: "Xã Quỳnh Thọ",
    parent_code: "421",
  },
  {
    value: "17218",
    label: "Xã Quỳnh Thuận",
    parent_code: "421",
  },
  {
    value: "12577",
    label: "Xã Quỳnh Trang",
    parent_code: "338",
  },
  {
    value: "17116",
    label: "Xã Quỳnh Trang",
    parent_code: "432",
  },
  {
    value: "17143",
    label: "Xã Quỳnh Văn",
    parent_code: "421",
  },
  {
    value: "17104",
    label: "Xã Quỳnh Vinh",
    parent_code: "432",
  },
  {
    value: "12568",
    label: "Xã Quỳnh Xá",
    parent_code: "338",
  },
  {
    value: "17131",
    label: "Phường Quỳnh Xuân",
    parent_code: "432",
  },
  {
    value: "17182",
    label: "Xã Quỳnh Yên",
    parent_code: "421",
  },
  {
    value: "28807",
    label: "Xã Qưới Sơn",
    parent_code: "831",
  },
  {
    value: "32228",
    label: "Xã Rạch Chèo",
    parent_code: "972",
  },
  {
    value: "26535",
    label: "Phường Rạch Dừa",
    parent_code: "747",
  },
  {
    value: "31359",
    label: "Thị trấn Rạch Gòi",
    parent_code: "932",
  },
  {
    value: "32244",
    label: "Thị trấn Rạch Gốc",
    parent_code: "973",
  },
  {
    value: "30754",
    label: "Phường Rạch Sỏi",
    parent_code: "899",
  },
  {
    value: "13894",
    label: "Thị trấn Rạng Đông",
    parent_code: "361",
  },
  {
    value: "03260",
    label: "Xã Rạng Đông",
    parent_code: "099",
  },
  {
    value: "24877",
    label: "Xã Rô Men",
    parent_code: "674",
  },
  {
    value: "23530",
    label: "Xã Rơ Kơi",
    parent_code: "616",
  },
  {
    value: "16378",
    label: "Thị trấn Rừng Thông",
    parent_code: "405",
  },
  {
    value: "23545",
    label: "Xã Sa Bình",
    parent_code: "616",
  },
  {
    value: "03514",
    label: "Xã Sà Dề Phìn",
    parent_code: "108",
  },
  {
    value: "23398",
    label: "Xã Sa Loong",
    parent_code: "611",
  },
  {
    value: "03197",
    label: "Xã Sa Lông",
    parent_code: "097",
  },
  {
    value: "23542",
    label: "Xã Sa Nghĩa",
    parent_code: "616",
  },
  {
    value: "23533",
    label: "Xã Sa Nhơn",
    parent_code: "616",
  },
  {
    value: "03001",
    label: "Phường Sa Pa",
    parent_code: "088",
  },
  {
    value: "03002",
    label: "Phường Sa Pả",
    parent_code: "088",
  },
  {
    value: "29926",
    label: "Thị trấn Sa Rài",
    parent_code: "869",
  },
  {
    value: "23539",
    label: "Xã Sa Sơn",
    parent_code: "616",
  },
  {
    value: "23527",
    label: "Thị trấn Sa Thầy",
    parent_code: "616",
  },
  {
    value: "00142",
    label: "Phường Sài Đồng",
    parent_code: "004",
  },
  {
    value: "09898",
    label: "Xã Sài Sơn",
    parent_code: "275",
  },
  {
    value: "04225",
    label: "Xã Sam Kha",
    parent_code: "127",
  },
  {
    value: "03355",
    label: "Xã Sam Mứn",
    parent_code: "100",
  },
  {
    value: "02812",
    label: "Xã Sán Chải",
    parent_code: "084",
  },
  {
    value: "03409",
    label: "Xã San Thàng",
    parent_code: "105",
  },
  {
    value: "06589",
    label: "Xã Sàn Viên",
    parent_code: "188",
  },
  {
    value: "01060",
    label: "Xã Sán Xả Hồ",
    parent_code: "032",
  },
  {
    value: "02713",
    label: "Xã Sàng Ma Sáo",
    parent_code: "082",
  },
  {
    value: "05719",
    label: "Xã Sảng Mộc",
    parent_code: "170",
  },
  {
    value: "03244",
    label: "Xã Sáng Nhè",
    parent_code: "098",
  },
  {
    value: "00751",
    label: "Xã Sảng Tủng",
    parent_code: "026",
  },
  {
    value: "05080",
    label: "Xã Sào Báy",
    parent_code: "153",
  },
  {
    value: "10549",
    label: "Phường Sao Đỏ",
    parent_code: "290",
  },
  {
    value: "15553",
    label: "Thị trấn Sao Vàng",
    parent_code: "395",
  },
  {
    value: "05245",
    label: "Xã Săm Khóe",
    parent_code: "156",
  },
  {
    value: "04066",
    label: "Xã Sập Vạt",
    parent_code: "124",
  },
  {
    value: "03946",
    label: "Xã Sập Xa",
    parent_code: "122",
  },
  {
    value: "09733",
    label: "Xã Sen Phương",
    parent_code: "272",
  },
  {
    value: "19312",
    label: "Xã Sen Thủy",
    parent_code: "457",
  },
  {
    value: "03155",
    label: "Xã Sen Thượng",
    parent_code: "096",
  },
  {
    value: "01978",
    label: "Xã Sĩ Bình",
    parent_code: "063",
  },
  {
    value: "03550",
    label: "Xã Sì Lở Lầu",
    parent_code: "109",
  },
  {
    value: "02809",
    label: "Thị trấn Si Ma Cai",
    parent_code: "084",
  },
  {
    value: "03199",
    label: "Xã Si Pa Phìn",
    parent_code: "103",
  },
  {
    value: "19867",
    label: "Thị trấn Sịa",
    parent_code: "477",
  },
  {
    value: "02824",
    label: "Xã Sín Chéng",
    parent_code: "084",
  },
  {
    value: "03478",
    label: "Thị trấn Sìn Hồ",
    parent_code: "108",
  },
  {
    value: "03592",
    label: "Xã Sin Suối Hồ",
    parent_code: "109",
  },
  {
    value: "03154",
    label: "Xã Sín Thầu",
    parent_code: "096",
  },
  {
    value: "02227",
    label: "Xã Sinh Long",
    parent_code: "072",
  },
  {
    value: "00748",
    label: "Xã Sính Lủng",
    parent_code: "026",
  },
  {
    value: "03241",
    label: "Xã Sính Phình",
    parent_code: "098",
  },
  {
    value: "22739",
    label: "Xã Sinh Tồn",
    parent_code: "576",
  },
  {
    value: "08017",
    label: "Xã Sóc Đăng",
    parent_code: "230",
  },
  {
    value: "01417",
    label: "Xã Sóc Hà",
    parent_code: "045",
  },
  {
    value: "00376",
    label: "Thị trấn Sóc Sơn",
    parent_code: "016",
  },
  {
    value: "30820",
    label: "Thị trấn Sóc Sơn",
    parent_code: "903",
  },
  {
    value: "13249",
    label: "Xã Song An",
    parent_code: "344",
  },
  {
    value: "23632",
    label: "Xã Song An",
    parent_code: "623",
  },
  {
    value: "28630",
    label: "Xã Song Bình",
    parent_code: "822",
  },
  {
    value: "09472",
    label: "Xã Song Giang",
    parent_code: "263",
  },
  {
    value: "09412",
    label: "Xã Song Hồ",
    parent_code: "262",
  },
  {
    value: "07705",
    label: "Xã Song Khê",
    parent_code: "213",
  },
  {
    value: "04006",
    label: "Xã Song Khủa",
    parent_code: "128",
  },
  {
    value: "13213",
    label: "Xã Song Lãng",
    parent_code: "344",
  },
  {
    value: "09451",
    label: "Xã Song Liễu",
    parent_code: "262",
  },
  {
    value: "29392",
    label: "Xã Song Lộc",
    parent_code: "847",
  },
  {
    value: "12301",
    label: "Xã Song Mai",
    parent_code: "331",
  },
  {
    value: "07222",
    label: "Xã Song Mai",
    parent_code: "213",
  },
  {
    value: "03883",
    label: "Xã Song Pe",
    parent_code: "121",
  },
  {
    value: "29740",
    label: "Xã Song Phú",
    parent_code: "860",
  },
  {
    value: "31642",
    label: "Xã Song Phụng",
    parent_code: "946",
  },
  {
    value: "09874",
    label: "Xã Song Phương",
    parent_code: "274",
  },
  {
    value: "09829",
    label: "Xã Song Phượng",
    parent_code: "273",
  },
  {
    value: "28582",
    label: "Xã Song Thuận",
    parent_code: "821",
  },
  {
    value: "22737",
    label: "Xã Song Tử Tây",
    parent_code: "576",
  },
  {
    value: "07345",
    label: "Xã Song Vân",
    parent_code: "216",
  },
  {
    value: "01270",
    label: "Phường Sông Bằng",
    parent_code: "040",
  },
  {
    value: "23029",
    label: "Xã Sông Bình",
    parent_code: "596",
  },
  {
    value: "24045",
    label: "Phường Sông Bờ",
    parent_code: "624",
  },
  {
    value: "01837",
    label: "Phường Sông Cầu",
    parent_code: "058",
  },
  {
    value: "05656",
    label: "Thị trấn Sông Cầu",
    parent_code: "169",
  },
  {
    value: "22630",
    label: "Xã Sông Cầu",
    parent_code: "573",
  },
  {
    value: "03148",
    label: "Phường Sông Đà",
    parent_code: "095",
  },
  {
    value: "32098",
    label: "Thị trấn Sông Đốc",
    parent_code: "968",
  },
  {
    value: "01267",
    label: "Phường Sông Hiến",
    parent_code: "040",
  },
  {
    value: "22234",
    label: "Xã Sông Hinh",
    parent_code: "561",
  },
  {
    value: "07144",
    label: "Xã Sông Khoai",
    parent_code: "206",
  },
  {
    value: "20473",
    label: "Xã Sông Kôn",
    parent_code: "505",
  },
  {
    value: "07936",
    label: "Xã Sông Lô",
    parent_code: "227",
  },
  {
    value: "23023",
    label: "Xã Sông Lũy",
    parent_code: "596",
  },
  {
    value: "04168",
    label: "Thị trấn Sông Mã",
    parent_code: "126",
  },
  {
    value: "26329",
    label: "Xã Sông Nhạn",
    parent_code: "739",
  },
  {
    value: "23239",
    label: "Xã Sông Phan",
    parent_code: "601",
  },
  {
    value: "26362",
    label: "Xã Sông Ray",
    parent_code: "739",
  },
  {
    value: "26260",
    label: "Xã Sông Thao",
    parent_code: "737",
  },
  {
    value: "20770",
    label: "Xã Sông Trà",
    parent_code: "512",
  },
  {
    value: "26263",
    label: "Xã Sông Trầu",
    parent_code: "737",
  },
  {
    value: "21238",
    label: "Thị trấn Sông Vệ",
    parent_code: "528",
  },
  {
    value: "26722",
    label: "Xã Sông Xoài",
    parent_code: "754",
  },
  {
    value: "04231",
    label: "Xã Sốp Cộp",
    parent_code: "127",
  },
  {
    value: "11302",
    label: "Phường Sở Dầu",
    parent_code: "303",
  },
  {
    value: "23653",
    label: "Xã Sơ Pai",
    parent_code: "625",
  },
  {
    value: "04660",
    label: "Xã Sơn A",
    parent_code: "133",
  },
  {
    value: "21328",
    label: "Xã Sơn Ba",
    parent_code: "529",
  },
  {
    value: "21301",
    label: "Xã Sơn Bao",
    parent_code: "529",
  },
  {
    value: "18190",
    label: "Xã Sơn Bằng",
    parent_code: "439",
  },
  {
    value: "03413",
    label: "Xã Sơn Bình",
    parent_code: "106",
  },
  {
    value: "18193",
    label: "Xã Sơn Bình",
    parent_code: "439",
  },
  {
    value: "22726",
    label: "Xã Sơn Bình",
    parent_code: "575",
  },
  {
    value: "26587",
    label: "Xã Sơn Bình",
    parent_code: "750",
  },
  {
    value: "30836",
    label: "Xã Sơn Bình",
    parent_code: "903",
  },
  {
    value: "21331",
    label: "Xã Sơn Bua",
    parent_code: "530",
  },
  {
    value: "21316",
    label: "Xã Sơn Cao",
    parent_code: "529",
  },
  {
    value: "05653",
    label: "Xã Sơn Cẩm",
    parent_code: "164",
  },
  {
    value: "18178",
    label: "Xã Sơn Châu",
    parent_code: "439",
  },
  {
    value: "10378",
    label: "Xã Sơn Công",
    parent_code: "281",
  },
  {
    value: "08215",
    label: "Xã Sơn Cương",
    parent_code: "232",
  },
  {
    value: "21340",
    label: "Xã Sơn Dung",
    parent_code: "530",
  },
  {
    value: "07063",
    label: "Xã Sơn Dương",
    parent_code: "193",
  },
  {
    value: "02536",
    label: "Thị trấn Sơn Dương",
    parent_code: "076",
  },
  {
    value: "09676",
    label: "Xã Sơn Đà",
    parent_code: "271",
  },
  {
    value: "25048",
    label: "Xã Sơn Điền",
    parent_code: "679",
  },
  {
    value: "15022",
    label: "Xã Sơn Điện",
    parent_code: "387",
  },
  {
    value: "22174",
    label: "Xã Sơn Định",
    parent_code: "560",
  },
  {
    value: "28876",
    label: "Xã Sơn Định",
    parent_code: "832",
  },
  {
    value: "09613",
    label: "Xã Sơn Đông",
    parent_code: "269",
  },
  {
    value: "08866",
    label: "Xã Sơn Đông",
    parent_code: "246",
  },
  {
    value: "28783",
    label: "Xã Sơn Đông",
    parent_code: "829",
  },
  {
    value: "09859",
    label: "Xã Sơn Đồng",
    parent_code: "274",
  },
  {
    value: "18157",
    label: "Xã Sơn Giang",
    parent_code: "439",
  },
  {
    value: "25237",
    label: "Phường Sơn Giang",
    parent_code: "688",
  },
  {
    value: "22219",
    label: "Xã Sơn Giang",
    parent_code: "561",
  },
  {
    value: "21307",
    label: "Xã Sơn Giang",
    parent_code: "529",
  },
  {
    value: "10318",
    label: "Xã Sơn Hà",
    parent_code: "280",
  },
  {
    value: "06454",
    label: "Xã Sơn Hà",
    parent_code: "186",
  },
  {
    value: "12925",
    label: "Xã Sơn Hà",
    parent_code: "341",
  },
  {
    value: "14455",
    label: "Xã Sơn Hà",
    parent_code: "372",
  },
  {
    value: "15004",
    label: "Xã Sơn Hà",
    parent_code: "387",
  },
  {
    value: "02938",
    label: "Xã Sơn Hà",
    parent_code: "086",
  },
  {
    value: "22201",
    label: "Xã Sơn Hà",
    parent_code: "560",
  },
  {
    value: "21292",
    label: "Xã Sơn Hạ",
    parent_code: "529",
  },
  {
    value: "07546",
    label: "Xã Sơn Hải",
    parent_code: "219",
  },
  {
    value: "02929",
    label: "Xã Sơn Hải",
    parent_code: "086",
  },
  {
    value: "17212",
    label: "Xã Sơn Hải",
    parent_code: "421",
  },
  {
    value: "21319",
    label: "Xã Sơn Hải",
    parent_code: "529",
  },
  {
    value: "30811",
    label: "Xã Sơn Hải",
    parent_code: "902",
  },
  {
    value: "18214",
    label: "Xã Sơn Hàm",
    parent_code: "439",
  },
  {
    value: "22723",
    label: "Xã Sơn Hiệp",
    parent_code: "575",
  },
  {
    value: "28864",
    label: "Xã Sơn Hòa",
    parent_code: "831",
  },
  {
    value: "18973",
    label: "Xã Sơn Hóa",
    parent_code: "453",
  },
  {
    value: "22171",
    label: "Xã Sơn Hội",
    parent_code: "560",
  },
  {
    value: "18139",
    label: "Xã Sơn Hồng",
    parent_code: "439",
  },
  {
    value: "08563",
    label: "Xã Sơn Hùng",
    parent_code: "238",
  },
  {
    value: "30835",
    label: "Xã Sơn Kiên",
    parent_code: "903",
  },
  {
    value: "18196",
    label: "Xã Sơn Kim 1",
    parent_code: "439",
  },
  {
    value: "18199",
    label: "Xã Sơn Kim 2",
    parent_code: "439",
  },
  {
    value: "27016",
    label: "Phường Sơn Kỳ",
    parent_code: "767",
  },
  {
    value: "21325",
    label: "Xã Sơn Kỳ",
    parent_code: "529",
  },
  {
    value: "14437",
    label: "Xã Sơn Lai",
    parent_code: "372",
  },
  {
    value: "23647",
    label: "Xã Sơn Lang",
    parent_code: "625",
  },
  {
    value: "18145",
    label: "Xã Sơn Lâm",
    parent_code: "439",
  },
  {
    value: "22720",
    label: "Xã Sơn Lâm",
    parent_code: "575",
  },
  {
    value: "01359",
    label: "Xã Sơn Lập",
    parent_code: "043",
  },
  {
    value: "21346",
    label: "Xã Sơn Lập",
    parent_code: "530",
  },
  {
    value: "18148",
    label: "Xã Sơn Lễ",
    parent_code: "439",
  },
  {
    value: "21335",
    label: "Xã Sơn Liên",
    parent_code: "530",
  },
  {
    value: "21304",
    label: "Xã Sơn Linh",
    parent_code: "529",
  },
  {
    value: "18160",
    label: "Xã Sơn Lĩnh",
    parent_code: "439",
  },
  {
    value: "18205",
    label: "Xã Sơn Long",
    parent_code: "439",
  },
  {
    value: "22177",
    label: "Xã Sơn Long",
    parent_code: "560",
  },
  {
    value: "21341",
    label: "Xã Sơn Long",
    parent_code: "530",
  },
  {
    value: "01360",
    label: "Xã Sơn Lộ",
    parent_code: "043",
  },
  {
    value: "09586",
    label: "Phường Sơn Lộc",
    parent_code: "269",
  },
  {
    value: "18490",
    label: "Xã Sơn Lộc",
    parent_code: "443",
  },
  {
    value: "19150",
    label: "Xã Sơn Lộc",
    parent_code: "455",
  },
  {
    value: "08959",
    label: "Xã Sơn Lôi",
    parent_code: "249",
  },
  {
    value: "15016",
    label: "Thị trấn Sơn Lư",
    parent_code: "387",
  },
  {
    value: "04651",
    label: "Xã Sơn Lương",
    parent_code: "140",
  },
  {
    value: "21338",
    label: "Xã Sơn Màu",
    parent_code: "530",
  },
  {
    value: "21334",
    label: "Xã Sơn Mùa",
    parent_code: "530",
  },
  {
    value: "23266",
    label: "Xã Sơn Mỹ",
    parent_code: "601",
  },
  {
    value: "02620",
    label: "Xã Sơn Nam",
    parent_code: "076",
  },
  {
    value: "22189",
    label: "Xã Sơn Nguyên",
    parent_code: "560",
  },
  {
    value: "21298",
    label: "Xã Sơn Nham",
    parent_code: "529",
  },
  {
    value: "18175",
    label: "Xã Sơn Ninh",
    parent_code: "439",
  },
  {
    value: "20410",
    label: "Phường Sơn Phong",
    parent_code: "503",
  },
  {
    value: "05599",
    label: "Xã Sơn Phú",
    parent_code: "167",
  },
  {
    value: "02275",
    label: "Xã Sơn Phú",
    parent_code: "072",
  },
  {
    value: "18217",
    label: "Xã Sơn Phú",
    parent_code: "439",
  },
  {
    value: "29014",
    label: "Xã Sơn Phú",
    parent_code: "834",
  },
  {
    value: "22183",
    label: "Xã Sơn Phước",
    parent_code: "560",
  },
  {
    value: "22447",
    label: "Xã Sơn Tân",
    parent_code: "570",
  },
  {
    value: "21337",
    label: "Xã Sơn Tân",
    parent_code: "530",
  },
  {
    value: "18172",
    label: "Xã Sơn Tây",
    parent_code: "439",
  },
  {
    value: "22648",
    label: "Xã Sơn Thái",
    parent_code: "573",
  },
  {
    value: "14440",
    label: "Xã Sơn Thành",
    parent_code: "372",
  },
  {
    value: "02161",
    label: "Xã Sơn Thành",
    parent_code: "066",
  },
  {
    value: "17614",
    label: "Xã Sơn Thành",
    parent_code: "426",
  },
  {
    value: "21295",
    label: "Xã Sơn Thành",
    parent_code: "529",
  },
  {
    value: "22250",
    label: "Xã Sơn Thành Đông",
    parent_code: "562",
  },
  {
    value: "22249",
    label: "Xã Sơn Thành Tây",
    parent_code: "562",
  },
  {
    value: "04672",
    label: "Thị trấn Sơn Thịnh",
    parent_code: "140",
  },
  {
    value: "03064",
    label: "Xã Sơn Thuỷ",
    parent_code: "089",
  },
  {
    value: "08677",
    label: "Xã Sơn Thủy",
    parent_code: "239",
  },
  {
    value: "05206",
    label: "Xã Sơn Thủy",
    parent_code: "156",
  },
  {
    value: "15010",
    label: "Xã Sơn Thủy",
    parent_code: "387",
  },
  {
    value: "20071",
    label: "Xã Sơn Thủy",
    parent_code: "481",
  },
  {
    value: "19276",
    label: "Xã Sơn Thủy",
    parent_code: "457",
  },
  {
    value: "21322",
    label: "Xã Sơn Thủy",
    parent_code: "529",
  },
  {
    value: "21313",
    label: "Xã Sơn Thượng",
    parent_code: "529",
  },
  {
    value: "18142",
    label: "Xã Sơn Tiến",
    parent_code: "439",
  },
  {
    value: "21343",
    label: "Xã Sơn Tinh",
    parent_code: "530",
  },
  {
    value: "08395",
    label: "Xã Sơn Tình",
    parent_code: "235",
  },
  {
    value: "18202",
    label: "Xã Sơn Trà",
    parent_code: "439",
  },
  {
    value: "21148",
    label: "Xã Sơn Trà",
    parent_code: "525",
  },
  {
    value: "18187",
    label: "Xã Sơn Trung",
    parent_code: "439",
  },
  {
    value: "22729",
    label: "Xã Sơn Trung",
    parent_code: "575",
  },
  {
    value: "21310",
    label: "Xã Sơn Trung",
    parent_code: "529",
  },
  {
    value: "18223",
    label: "Xã Sơn Trường",
    parent_code: "439",
  },
  {
    value: "08518",
    label: "Xã Sơn Vi",
    parent_code: "237",
  },
  {
    value: "00793",
    label: "Xã Sơn Vĩ",
    parent_code: "027",
  },
  {
    value: "20672",
    label: "Xã Sơn Viên",
    parent_code: "519",
  },
  {
    value: "22186",
    label: "Xã Sơn Xuân",
    parent_code: "560",
  },
  {
    value: "23839",
    label: "Xã SRó",
    parent_code: "630",
  },
  {
    value: "04639",
    label: "Xã Sùng Đô",
    parent_code: "140",
  },
  {
    value: "00733",
    label: "Xã Sủng Là",
    parent_code: "026",
  },
  {
    value: "00790",
    label: "Xã Sủng Máng",
    parent_code: "027",
  },
  {
    value: "23200",
    label: "Xã Sùng Nhơn",
    parent_code: "600",
  },
  {
    value: "03403",
    label: "Xã Sùng Phài",
    parent_code: "105",
  },
  {
    value: "00838",
    label: "Xã Sủng Thài",
    parent_code: "028",
  },
  {
    value: "00787",
    label: "Xã Sủng Trà",
    parent_code: "027",
  },
  {
    value: "00766",
    label: "Xã Sủng Trái",
    parent_code: "026",
  },
  {
    value: "00829",
    label: "Xã Sủng Tráng",
    parent_code: "028",
  },
  {
    value: "22198",
    label: "Xã Suối Bạc",
    parent_code: "560",
  },
  {
    value: "03994",
    label: "Xã Suối Bàng",
    parent_code: "128",
  },
  {
    value: "03937",
    label: "Xã Suối Bau",
    parent_code: "122",
  },
  {
    value: "04669",
    label: "Xã Suối Bu",
    parent_code: "140",
  },
  {
    value: "26431",
    label: "Xã Suối Cao",
    parent_code: "741",
  },
  {
    value: "22708",
    label: "Xã Suối Cát",
    parent_code: "570",
  },
  {
    value: "26452",
    label: "Xã Suối Cát",
    parent_code: "741",
  },
  {
    value: "25534",
    label: "Xã Suối Dây",
    parent_code: "706",
  },
  {
    value: "25555",
    label: "Xã Suối Đá",
    parent_code: "707",
  },
  {
    value: "04657",
    label: "Xã Suối Giàng",
    parent_code: "140",
  },
  {
    value: "22702",
    label: "Xã Suối Hiệp",
    parent_code: "574",
  },
  {
    value: "09187",
    label: "Phường Suối Hoa",
    parent_code: "256",
  },
  {
    value: "05134",
    label: "Xã Suối Hoa",
    parent_code: "155",
  },
  {
    value: "23188",
    label: "Xã Suối Kiết",
    parent_code: "599",
  },
  {
    value: "26581",
    label: "Xã Suối Nghệ",
    parent_code: "750",
  },
  {
    value: "25531",
    label: "Xã Suối Ngô",
    parent_code: "706",
  },
  {
    value: "26245",
    label: "Xã Suối Nho",
    parent_code: "736",
  },
  {
    value: "04654",
    label: "Xã Suối Quyền",
    parent_code: "140",
  },
  {
    value: "26611",
    label: "Xã Suối Rao",
    parent_code: "750",
  },
  {
    value: "22711",
    label: "Xã Suối Tân",
    parent_code: "570",
  },
  {
    value: "22705",
    label: "Xã Suối Tiên",
    parent_code: "574",
  },
  {
    value: "03901",
    label: "Xã Suối Tọ",
    parent_code: "122",
  },
  {
    value: "22204",
    label: "Xã Suối Trai",
    parent_code: "560",
  },
  {
    value: "26095",
    label: "Phường Suối Tre",
    parent_code: "732",
  },
  {
    value: "32155",
    label: "Xã Tạ An Khương",
    parent_code: "970",
  },
  {
    value: "32158",
    label: "Xã Tạ An Khương  Đông",
    parent_code: "970",
  },
  {
    value: "32170",
    label: "Xã Tạ An Khương  Nam",
    parent_code: "970",
  },
  {
    value: "03440",
    label: "Xã Tá Bạ",
    parent_code: "107",
  },
  {
    value: "20710",
    label: "Xã Tà Bhinh",
    parent_code: "510",
  },
  {
    value: "03841",
    label: "Xã Tạ Bú",
    parent_code: "120",
  },
  {
    value: "16852",
    label: "Xã Tà Cạ",
    parent_code: "417",
  },
  {
    value: "02872",
    label: "Xã Tà Chải",
    parent_code: "085",
  },
  {
    value: "02854",
    label: "Xã Tả Củ Tỷ",
    parent_code: "085",
  },
  {
    value: "30571",
    label: "Xã Tà Đảnh",
    parent_code: "891",
  },
  {
    value: "03640",
    label: "Xã Tà Gia",
    parent_code: "110",
  },
  {
    value: "02767",
    label: "Xã Tả Gia Khâu",
    parent_code: "083",
  },
  {
    value: "24991",
    label: "Xã Tà Hine",
    parent_code: "678",
  },
  {
    value: "04165",
    label: "Xã Tà Hộc",
    parent_code: "125",
  },
  {
    value: "03634",
    label: "Xã Tà Hừa",
    parent_code: "110",
  },
  {
    value: "03889",
    label: "Xã Tạ Khoa",
    parent_code: "121",
  },
  {
    value: "04003",
    label: "Xã Tà Lai",
    parent_code: "123",
  },
  {
    value: "26131",
    label: "Xã Tà Lài",
    parent_code: "734",
  },
  {
    value: "03400",
    label: "Xã Tả Lèng",
    parent_code: "106",
  },
  {
    value: "19579",
    label: "Xã Tà Long",
    parent_code: "467",
  },
  {
    value: "20470",
    label: "Xã Tà Lu",
    parent_code: "505",
  },
  {
    value: "01627",
    label: "Thị trấn Tà Lùng",
    parent_code: "049",
  },
  {
    value: "00742",
    label: "Xã Tả Lủng",
    parent_code: "026",
  },
  {
    value: "00796",
    label: "Xã Tả Lủng",
    parent_code: "027",
  },
  {
    value: "03265",
    label: "Xã Ta Ma",
    parent_code: "099",
  },
  {
    value: "03622",
    label: "Xã Tà Mít",
    parent_code: "111",
  },
  {
    value: "03638",
    label: "Xã Tà Mung",
    parent_code: "110",
  },
  {
    value: "24988",
    label: "Xã Tà Năng",
    parent_code: "678",
  },
  {
    value: "02755",
    label: "Xã Tả Ngải Chồ",
    parent_code: "083",
  },
  {
    value: "03520",
    label: "Xã Tả Ngảo",
    parent_code: "108",
  },
  {
    value: "01132",
    label: "Xã Tả Nhìu",
    parent_code: "033",
  },
  {
    value: "24808",
    label: "Xã Tà Nung",
    parent_code: "672",
  },
  {
    value: "00739",
    label: "Xã Tả Phìn",
    parent_code: "026",
  },
  {
    value: "03013",
    label: "Xã Tả Phìn",
    parent_code: "088",
  },
  {
    value: "03232",
    label: "Xã Tả Phìn",
    parent_code: "098",
  },
  {
    value: "03511",
    label: "Xã Tả Phìn",
    parent_code: "108",
  },
  {
    value: "02677",
    label: "Xã Tả Phời",
    parent_code: "080",
  },
  {
    value: "20702",
    label: "Xã Tà Pơơ",
    parent_code: "510",
  },
  {
    value: "19588",
    label: "Xã Tà Rụt",
    parent_code: "467",
  },
  {
    value: "04603",
    label: "Xã Tà Si Láng",
    parent_code: "139",
  },
  {
    value: "03226",
    label: "Xã Tả Sìn Thàng",
    parent_code: "098",
  },
  {
    value: "01072",
    label: "Xã Tả Sử Choóng",
    parent_code: "032",
  },
  {
    value: "02794",
    label: "Xã Tả Thàng",
    parent_code: "083",
  },
  {
    value: "00649",
    label: "Xã Tả Thanh Oai",
    parent_code: "020",
  },
  {
    value: "03463",
    label: "Xã Tà Tổng",
    parent_code: "107",
  },
  {
    value: "03040",
    label: "Xã Tả Van",
    parent_code: "088",
  },
  {
    value: "00907",
    label: "Xã Tả Ván",
    parent_code: "029",
  },
  {
    value: "02851",
    label: "Xã Tả Van Chư",
    parent_code: "085",
  },
  {
    value: "08404",
    label: "Xã Tạ Xá",
    parent_code: "235",
  },
  {
    value: "03868",
    label: "Xã Tà Xùa",
    parent_code: "121",
  },
  {
    value: "11098",
    label: "Xã Tái Sơn",
    parent_code: "298",
  },
  {
    value: "31687",
    label: "Xã Tài Văn",
    parent_code: "951",
  },
  {
    value: "26398",
    label: "Xã Tam An",
    parent_code: "740",
  },
  {
    value: "20368",
    label: "Xã Tam An",
    parent_code: "518",
  },
  {
    value: "20983",
    label: "Xã Tam Anh Bắc",
    parent_code: "517",
  },
  {
    value: "20984",
    label: "Xã Tam Anh Nam",
    parent_code: "517",
  },
  {
    value: "26803",
    label: "Phường Tam Bình",
    parent_code: "769",
  },
  {
    value: "28513",
    label: "Xã Tam Bình",
    parent_code: "820",
  },
  {
    value: "29719",
    label: "Thị trấn Tam Bình",
    parent_code: "860",
  },
  {
    value: "25021",
    label: "Xã Tam Bố",
    parent_code: "679",
  },
  {
    value: "14848",
    label: "Xã Tam Chung",
    parent_code: "384",
  },
  {
    value: "11887",
    label: "Xã Tam Cường",
    parent_code: "316",
  },
  {
    value: "20392",
    label: "Xã Tam Dân",
    parent_code: "518",
  },
  {
    value: "07456",
    label: "Xã Tam Dị",
    parent_code: "218",
  },
  {
    value: "09199",
    label: "Xã Tam Đa",
    parent_code: "258",
  },
  {
    value: "11866",
    label: "Xã Tam Đa",
    parent_code: "316",
  },
  {
    value: "12421",
    label: "Xã Tam Đa",
    parent_code: "333",
  },
  {
    value: "02626",
    label: "Xã Tam Đa",
    parent_code: "076",
  },
  {
    value: "20387",
    label: "Xã Tam Đại",
    parent_code: "518",
  },
  {
    value: "20374",
    label: "Xã Tam Đàn",
    parent_code: "518",
  },
  {
    value: "08908",
    label: "Thị trấn Tam Đảo",
    parent_code: "248",
  },
  {
    value: "16927",
    label: "Xã Tam Đình",
    parent_code: "418",
  },
  {
    value: "08995",
    label: "Xã Tam Đồng",
    parent_code: "250",
  },
  {
    value: "03390",
    label: "Thị trấn Tam Đường",
    parent_code: "106",
  },
  {
    value: "06559",
    label: "Xã Tam Gia",
    parent_code: "188",
  },
  {
    value: "09202",
    label: "Xã Tam Giang",
    parent_code: "258",
  },
  {
    value: "24358",
    label: "Xã Tam Giang",
    parent_code: "650",
  },
  {
    value: "20995",
    label: "Xã Tam Giang",
    parent_code: "517",
  },
  {
    value: "32206",
    label: "Xã Tam Giang",
    parent_code: "971",
  },
  {
    value: "32209",
    label: "Xã Tam Giang Đông",
    parent_code: "971",
  },
  {
    value: "32233",
    label: "Xã Tam Giang Tây",
    parent_code: "973",
  },
  {
    value: "20992",
    label: "Xã Tam Hải",
    parent_code: "517",
  },
  {
    value: "00655",
    label: "Xã Tam Hiệp",
    parent_code: "020",
  },
  {
    value: "09775",
    label: "Xã Tam Hiệp",
    parent_code: "272",
  },
  {
    value: "07261",
    label: "Xã Tam Hiệp",
    parent_code: "215",
  },
  {
    value: "26017",
    label: "Phường Tam Hiệp",
    parent_code: "731",
  },
  {
    value: "20989",
    label: "Xã Tam Hiệp",
    parent_code: "517",
  },
  {
    value: "28537",
    label: "Xã Tam Hiệp",
    parent_code: "821",
  },
  {
    value: "29053",
    label: "Xã Tam Hiệp",
    parent_code: "835",
  },
  {
    value: "26035",
    label: "Phường Tam Hòa",
    parent_code: "731",
  },
  {
    value: "20986",
    label: "Xã Tam Hòa",
    parent_code: "517",
  },
  {
    value: "09043",
    label: "Xã Tam Hồng",
    parent_code: "251",
  },
  {
    value: "08953",
    label: "Xã Tam Hợp",
    parent_code: "249",
  },
  {
    value: "16936",
    label: "Xã Tam Hợp",
    parent_code: "418",
  },
  {
    value: "17059",
    label: "Xã Tam Hợp",
    parent_code: "420",
  },
  {
    value: "10138",
    label: "Xã Tam Hưng",
    parent_code: "278",
  },
  {
    value: "11545",
    label: "Xã Tam Hưng",
    parent_code: "311",
  },
  {
    value: "01774",
    label: "Xã Tam Kim",
    parent_code: "052",
  },
  {
    value: "10801",
    label: "Xã Tam Kỳ",
    parent_code: "293",
  },
  {
    value: "20395",
    label: "Xã Tam Lãnh",
    parent_code: "518",
  },
  {
    value: "25876",
    label: "Xã Tam Lập",
    parent_code: "722",
  },
  {
    value: "20377",
    label: "Xã Tam Lộc",
    parent_code: "518",
  },
  {
    value: "15019",
    label: "Xã Tam Lư",
    parent_code: "387",
  },
  {
    value: "21005",
    label: "Xã Tam Mỹ Đông",
    parent_code: "517",
  },
  {
    value: "21004",
    label: "Xã Tam Mỹ Tây",
    parent_code: "517",
  },
  {
    value: "29332",
    label: "Xã Tam Ngãi",
    parent_code: "845",
  },
  {
    value: "21001",
    label: "Xã Tam Nghĩa",
    parent_code: "517",
  },
  {
    value: "20389",
    label: "Xã Tam Ngọc",
    parent_code: "502",
  },
  {
    value: "26806",
    label: "Phường Tam Phú",
    parent_code: "769",
  },
  {
    value: "20371",
    label: "Xã Tam Phú",
    parent_code: "502",
  },
  {
    value: "09142",
    label: "Xã Tam Phúc",
    parent_code: "252",
  },
  {
    value: "26374",
    label: "Phường Tam Phước",
    parent_code: "731",
  },
  {
    value: "26668",
    label: "Xã Tam Phước",
    parent_code: "752",
  },
  {
    value: "20380",
    label: "Xã Tam Phước",
    parent_code: "518",
  },
  {
    value: "28831",
    label: "Xã Tam Phước",
    parent_code: "831",
  },
  {
    value: "08926",
    label: "Xã Tam Quan",
    parent_code: "248",
  },
  {
    value: "21637",
    label: "Phường Tam Quan",
    parent_code: "543",
  },
  {
    value: "21655",
    label: "Phường Tam Quan Bắc",
    parent_code: "543",
  },
  {
    value: "21658",
    label: "Phường Tam Quan Nam",
    parent_code: "543",
  },
  {
    value: "13237",
    label: "Xã Tam Quang",
    parent_code: "344",
  },
  {
    value: "16933",
    label: "Xã Tam Quang",
    parent_code: "418",
  },
  {
    value: "20998",
    label: "Xã Tam Quang",
    parent_code: "517",
  },
  {
    value: "00874",
    label: "Thị trấn Tam Sơn",
    parent_code: "029",
  },
  {
    value: "08824",
    label: "Thị trấn Tam Sơn",
    parent_code: "253",
  },
  {
    value: "09370",
    label: "Phường Tam Sơn",
    parent_code: "261",
  },
  {
    value: "08377",
    label: "Xã Tam Sơn",
    parent_code: "235",
  },
  {
    value: "17341",
    label: "Xã Tam Sơn",
    parent_code: "424",
  },
  {
    value: "20977",
    label: "Xã Tam Sơn",
    parent_code: "517",
  },
  {
    value: "16924",
    label: "Xã Tam Thái",
    parent_code: "418",
  },
  {
    value: "20386",
    label: "Xã Tam Thái",
    parent_code: "518",
  },
  {
    value: "08620",
    label: "Xã Tam Thanh",
    parent_code: "240",
  },
  {
    value: "05974",
    label: "Phường Tam Thanh",
    parent_code: "178",
  },
  {
    value: "13789",
    label: "Xã Tam Thanh",
    parent_code: "359",
  },
  {
    value: "15007",
    label: "Xã Tam Thanh",
    parent_code: "387",
  },
  {
    value: "23278",
    label: "Xã Tam Thanh",
    parent_code: "602",
  },
  {
    value: "20359",
    label: "Xã Tam Thanh",
    parent_code: "502",
  },
  {
    value: "20365",
    label: "Xã Tam Thành",
    parent_code: "518",
  },
  {
    value: "20980",
    label: "Xã Tam Thạnh",
    parent_code: "517",
  },
  {
    value: "20362",
    label: "Xã Tam Thăng",
    parent_code: "502",
  },
  {
    value: "27670",
    label: "Xã Tam Thôn Hiệp",
    parent_code: "787",
  },
  {
    value: "09772",
    label: "Xã Tam Thuấn",
    parent_code: "272",
  },
  {
    value: "20203",
    label: "Phường Tam Thuận",
    parent_code: "491",
  },
  {
    value: "07252",
    label: "Xã Tam Tiến",
    parent_code: "215",
  },
  {
    value: "20974",
    label: "Xã Tam Tiến",
    parent_code: "517",
  },
  {
    value: "21007",
    label: "Xã Tam Trà",
    parent_code: "517",
  },
  {
    value: "15049",
    label: "Xã Tam Văn",
    parent_code: "388",
  },
  {
    value: "20383",
    label: "Xã Tam Vinh",
    parent_code: "518",
  },
  {
    value: "00517",
    label: "Xã Tàm Xá",
    parent_code: "017",
  },
  {
    value: "20968",
    label: "Xã Tam Xuân I",
    parent_code: "517",
  },
  {
    value: "20971",
    label: "Xã Tam Xuân II",
    parent_code: "517",
  },
  {
    value: "09631",
    label: "Xã Tản Hồng",
    parent_code: "271",
  },
  {
    value: "09694",
    label: "Xã Tản Lĩnh",
    parent_code: "271",
  },
  {
    value: "10393",
    label: "Xã Tảo Dương Văn",
    parent_code: "281",
  },
  {
    value: "17359",
    label: "Xã Tào Sơn",
    parent_code: "424",
  },
  {
    value: "15913",
    label: "Phường Tào Xuyên",
    parent_code: "380",
  },
  {
    value: "00808",
    label: "Xã Tát Ngà",
    parent_code: "027",
  },
  {
    value: "32029",
    label: "Xã Tắc Vân",
    parent_code: "964",
  },
  {
    value: "21688",
    label: "Thị trấn Tăng Bạt Hổ",
    parent_code: "544",
  },
  {
    value: "28705",
    label: "Xã Tăng Hoà",
    parent_code: "824",
  },
  {
    value: "02908",
    label: "Thị trấn Tằng Loỏng",
    parent_code: "086",
  },
  {
    value: "26842",
    label: "Phường Tăng Nhơn Phú A",
    parent_code: "769",
  },
  {
    value: "26845",
    label: "Phường Tăng Nhơn Phú B",
    parent_code: "769",
  },
  {
    value: "17554",
    label: "Xã Tăng Thành",
    parent_code: "426",
  },
  {
    value: "07789",
    label: "Xã Tăng Tiến",
    parent_code: "222",
  },
  {
    value: "24655",
    label: "Xã Tâm Thắng",
    parent_code: "662",
  },
  {
    value: "28210",
    label: "Thị trấn Tầm Vu",
    parent_code: "808",
  },
  {
    value: "30181",
    label: "Xã Tân  Khánh Trung",
    parent_code: "875",
  },
  {
    value: "10840",
    label: "Xã Tân An",
    parent_code: "294",
  },
  {
    value: "07159",
    label: "Phường Tân An",
    parent_code: "206",
  },
  {
    value: "07682",
    label: "Thị trấn Tân An",
    parent_code: "221",
  },
  {
    value: "02320",
    label: "Xã Tân An",
    parent_code: "073",
  },
  {
    value: "03079",
    label: "Xã Tân An",
    parent_code: "089",
  },
  {
    value: "04288",
    label: "Phường Tân An",
    parent_code: "133",
  },
  {
    value: "17305",
    label: "Xã Tân An",
    parent_code: "423",
  },
  {
    value: "25765",
    label: "Phường Tân An",
    parent_code: "718",
  },
  {
    value: "26179",
    label: "Xã Tân An",
    parent_code: "735",
  },
  {
    value: "23235",
    label: "Phường Tân An",
    parent_code: "594",
  },
  {
    value: "24004",
    label: "Xã Tân An",
    parent_code: "634",
  },
  {
    value: "20401",
    label: "Phường Tân An",
    parent_code: "503",
  },
  {
    value: "24124",
    label: "Phường Tân An",
    parent_code: "643",
  },
  {
    value: "29281",
    label: "Xã Tân An",
    parent_code: "844",
  },
  {
    value: "30388",
    label: "Xã Tân An",
    parent_code: "887",
  },
  {
    value: "30871",
    label: "Xã Tân An",
    parent_code: "904",
  },
  {
    value: "31135",
    label: "Phường Tân An",
    parent_code: "916",
  },
  {
    value: "27532",
    label: "Xã Tân An Hội",
    parent_code: "783",
  },
  {
    value: "29650",
    label: "Xã Tân An Hội",
    parent_code: "858",
  },
  {
    value: "29674",
    label: "Xã Tân An Luông",
    parent_code: "859",
  },
  {
    value: "29782",
    label: "Xã Tân An Thạnh",
    parent_code: "863",
  },
  {
    value: "28147",
    label: "Xã Tân Ân",
    parent_code: "806",
  },
  {
    value: "32245",
    label: "Xã Tân Ân",
    parent_code: "973",
  },
  {
    value: "32236",
    label: "Xã Tân Ân Tây",
    parent_code: "973",
  },
  {
    value: "01243",
    label: "Xã Tân Bắc",
    parent_code: "035",
  },
  {
    value: "32069",
    label: "Xã Tân Bằng",
    parent_code: "967",
  },
  {
    value: "25486",
    label: "Thị trấn Tân Biên",
    parent_code: "705",
  },
  {
    value: "25999",
    label: "Phường Tân Biên",
    parent_code: "731",
  },
  {
    value: "10532",
    label: "Phường Tân Bình",
    parent_code: "288",
  },
  {
    value: "13225",
    label: "Xã Tân Bình",
    parent_code: "336",
  },
  {
    value: "06904",
    label: "Xã Tân Bình",
    parent_code: "200",
  },
  {
    value: "14375",
    label: "Phường Tân Bình",
    parent_code: "370",
  },
  {
    value: "16201",
    label: "Xã Tân Bình",
    parent_code: "402",
  },
  {
    value: "25201",
    label: "Phường Tân Bình",
    parent_code: "689",
  },
  {
    value: "25474",
    label: "Xã Tân Bình",
    parent_code: "703",
  },
  {
    value: "25495",
    label: "Xã Tân Bình",
    parent_code: "705",
  },
  {
    value: "25945",
    label: "Phường Tân Bình",
    parent_code: "724",
  },
  {
    value: "25900",
    label: "Thị trấn Tân Bình",
    parent_code: "726",
  },
  {
    value: "26194",
    label: "Xã Tân Bình",
    parent_code: "735",
  },
  {
    value: "23248",
    label: "Xã Tân Bình",
    parent_code: "594",
  },
  {
    value: "23704",
    label: "Xã Tân Bình",
    parent_code: "626",
  },
  {
    value: "20779",
    label: "Thị trấn Tân Bình",
    parent_code: "512",
  },
  {
    value: "27853",
    label: "Xã Tân Bình",
    parent_code: "799",
  },
  {
    value: "28078",
    label: "Xã Tân Bình",
    parent_code: "805",
  },
  {
    value: "28462",
    label: "Xã Tân Bình",
    parent_code: "817",
  },
  {
    value: "28933",
    label: "Xã Tân Bình",
    parent_code: "838",
  },
  {
    value: "29284",
    label: "Xã Tân Bình",
    parent_code: "844",
  },
  {
    value: "29797",
    label: "Xã Tân Bình",
    parent_code: "863",
  },
  {
    value: "30154",
    label: "Xã Tân Bình",
    parent_code: "874",
  },
  {
    value: "30256",
    label: "Xã Tân Bình",
    parent_code: "877",
  },
  {
    value: "31399",
    label: "Xã Tân Bình",
    parent_code: "934",
  },
  {
    value: "28606",
    label: "Xã Tân Bình Thạnh",
    parent_code: "822",
  },
  {
    value: "28009",
    label: "Xã Tân Bửu",
    parent_code: "803",
  },
  {
    value: "23437",
    label: "Xã Tân Cảnh",
    parent_code: "612",
  },
  {
    value: "28156",
    label: "Xã Tân Chánh",
    parent_code: "806",
  },
  {
    value: "26776",
    label: "Phường Tân Chánh Hiệp",
    parent_code: "761",
  },
  {
    value: "12247",
    label: "Xã Tân Châu",
    parent_code: "330",
  },
  {
    value: "15847",
    label: "Xã Tân Châu",
    parent_code: "398",
  },
  {
    value: "25009",
    label: "Xã Tân Châu",
    parent_code: "679",
  },
  {
    value: "25516",
    label: "Thị trấn Tân Châu",
    parent_code: "706",
  },
  {
    value: "09352",
    label: "Xã Tân Chi",
    parent_code: "260",
  },
  {
    value: "20212",
    label: "Phường Tân Chính",
    parent_code: "491",
  },
  {
    value: "29947",
    label: "Xã Tân Công Chí",
    parent_code: "869",
  },
  {
    value: "30007",
    label: "Xã Tân Công Sính",
    parent_code: "871",
  },
  {
    value: "05503",
    label: "Xã Tân Cương",
    parent_code: "164",
  },
  {
    value: "00415",
    label: "Xã Tân Dân",
    parent_code: "016",
  },
  {
    value: "10315",
    label: "Xã Tân Dân",
    parent_code: "280",
  },
  {
    value: "10603",
    label: "Phường Tân Dân",
    parent_code: "290",
  },
  {
    value: "10699",
    label: "Phường Tân Dân",
    parent_code: "292",
  },
  {
    value: "11659",
    label: "Xã Tân Dân",
    parent_code: "313",
  },
  {
    value: "12223",
    label: "Xã Tân Dân",
    parent_code: "330",
  },
  {
    value: "07039",
    label: "Xã Tân Dân",
    parent_code: "193",
  },
  {
    value: "07897",
    label: "Phường Tân Dân",
    parent_code: "227",
  },
  {
    value: "16594",
    label: "Phường Tân Dân",
    parent_code: "407",
  },
  {
    value: "18283",
    label: "Xã Tân Dân",
    parent_code: "440",
  },
  {
    value: "32174",
    label: "Xã Tân Dân",
    parent_code: "970",
  },
  {
    value: "07432",
    label: "Xã Tân Dĩnh",
    parent_code: "217",
  },
  {
    value: "32173",
    label: "Xã Tân Duyệt",
    parent_code: "970",
  },
  {
    value: "11575",
    label: "Xã Tân Dương",
    parent_code: "311",
  },
  {
    value: "05563",
    label: "Xã Tân Dương",
    parent_code: "167",
  },
  {
    value: "02965",
    label: "Xã Tân Dương",
    parent_code: "087",
  },
  {
    value: "30211",
    label: "Xã Tân Dương",
    parent_code: "876",
  },
  {
    value: "28738",
    label: "Xã Tân Điền",
    parent_code: "824",
  },
  {
    value: "25852",
    label: "Phường Tân Định",
    parent_code: "721",
  },
  {
    value: "25894",
    label: "Xã Tân Định",
    parent_code: "726",
  },
  {
    value: "26734",
    label: "Phường Tân Định",
    parent_code: "760",
  },
  {
    value: "06307",
    label: "Xã Tân Đoàn",
    parent_code: "184",
  },
  {
    value: "25522",
    label: "Xã Tân Đông",
    parent_code: "706",
  },
  {
    value: "27892",
    label: "Xã Tân Đông",
    parent_code: "800",
  },
  {
    value: "28732",
    label: "Xã Tân Đông",
    parent_code: "824",
  },
  {
    value: "04501",
    label: "Xã Tân Đồng",
    parent_code: "138",
  },
  {
    value: "25198",
    label: "Phường Tân Đồng",
    parent_code: "689",
  },
  {
    value: "25948",
    label: "Phường Tân Đông Hiệp",
    parent_code: "724",
  },
  {
    value: "05947",
    label: "Xã Tân Đức",
    parent_code: "173",
  },
  {
    value: "23251",
    label: "Xã Tân Đức",
    parent_code: "601",
  },
  {
    value: "32164",
    label: "Xã Tân Đức",
    parent_code: "970",
  },
  {
    value: "01276",
    label: "Phường Tân Giang",
    parent_code: "040",
  },
  {
    value: "18079",
    label: "Phường Tân Giang",
    parent_code: "436",
  },
  {
    value: "02216",
    label: "Phường Tân Hà",
    parent_code: "070",
  },
  {
    value: "24916",
    label: "Xã Tân Hà",
    parent_code: "676",
  },
  {
    value: "25519",
    label: "Xã Tân Hà",
    parent_code: "706",
  },
  {
    value: "23221",
    label: "Xã Tân Hà",
    parent_code: "600",
  },
  {
    value: "23257",
    label: "Xã Tân Hà",
    parent_code: "601",
  },
  {
    value: "22855",
    label: "Xã Tân Hải",
    parent_code: "586",
  },
  {
    value: "23245",
    label: "Xã Tân Hải",
    parent_code: "594",
  },
  {
    value: "26710",
    label: "Xã Tân Hải",
    parent_code: "754",
  },
  {
    value: "32221",
    label: "Xã Tân Hải",
    parent_code: "972",
  },
  {
    value: "26062",
    label: "Phường Tân Hạnh",
    parent_code: "731",
  },
  {
    value: "29593",
    label: "Xã Tân Hạnh",
    parent_code: "857",
  },
  {
    value: "29029",
    label: "Xã Tân Hào",
    parent_code: "834",
  },
  {
    value: "07276",
    label: "Xã Tân Hiệp",
    parent_code: "215",
  },
  {
    value: "25361",
    label: "Xã Tân Hiệp",
    parent_code: "694",
  },
  {
    value: "25537",
    label: "Xã Tân Hiệp",
    parent_code: "706",
  },
  {
    value: "25873",
    label: "Xã Tân Hiệp",
    parent_code: "722",
  },
  {
    value: "25920",
    label: "Phường Tân Hiệp",
    parent_code: "723",
  },
  {
    value: "26008",
    label: "Phường Tân Hiệp",
    parent_code: "731",
  },
  {
    value: "26419",
    label: "Xã Tân Hiệp",
    parent_code: "740",
  },
  {
    value: "27562",
    label: "Xã Tân Hiệp",
    parent_code: "784",
  },
  {
    value: "20434",
    label: "Xã Tân Hiệp",
    parent_code: "503",
  },
  {
    value: "27868",
    label: "Xã Tân Hiệp",
    parent_code: "800",
  },
  {
    value: "28519",
    label: "Thị trấn Tân Hiệp",
    parent_code: "821",
  },
  {
    value: "29509",
    label: "Xã Tân Hiệp",
    parent_code: "849",
  },
  {
    value: "30850",
    label: "Thị trấn Tân Hiệp",
    parent_code: "904",
  },
  {
    value: "30868",
    label: "Xã Tân Hiệp A",
    parent_code: "904",
  },
  {
    value: "30859",
    label: "Xã Tân Hiệp B",
    parent_code: "904",
  },
  {
    value: "07567",
    label: "Xã Tân Hoa",
    parent_code: "219",
  },
  {
    value: "26707",
    label: "Xã Tân Hoà",
    parent_code: "754",
  },
  {
    value: "24244",
    label: "Xã Tân Hoà",
    parent_code: "647",
  },
  {
    value: "30860",
    label: "Xã Tân Hoà",
    parent_code: "904",
  },
  {
    value: "31345",
    label: "Xã Tân Hoà",
    parent_code: "932",
  },
  {
    value: "09946",
    label: "Xã Tân Hòa",
    parent_code: "275",
  },
  {
    value: "05935",
    label: "Xã Tân Hòa",
    parent_code: "173",
  },
  {
    value: "06109",
    label: "Xã Tân Hòa",
    parent_code: "181",
  },
  {
    value: "12622",
    label: "Xã Tân Hòa",
    parent_code: "339",
  },
  {
    value: "13216",
    label: "Xã Tân Hòa",
    parent_code: "344",
  },
  {
    value: "04792",
    label: "Phường Tân Hòa",
    parent_code: "148",
  },
  {
    value: "25384",
    label: "Xã Tân Hòa",
    parent_code: "695",
  },
  {
    value: "25528",
    label: "Xã Tân Hòa",
    parent_code: "706",
  },
  {
    value: "26005",
    label: "Phường Tân Hòa",
    parent_code: "731",
  },
  {
    value: "24121",
    label: "Phường Tân Hòa",
    parent_code: "643",
  },
  {
    value: "27862",
    label: "Xã Tân Hòa",
    parent_code: "799",
  },
  {
    value: "28006",
    label: "Xã Tân Hòa",
    parent_code: "803",
  },
  {
    value: "28702",
    label: "Thị trấn Tân Hòa",
    parent_code: "824",
  },
  {
    value: "29371",
    label: "Xã Tân Hòa",
    parent_code: "846",
  },
  {
    value: "29566",
    label: "Phường Tân Hòa",
    parent_code: "855",
  },
  {
    value: "30136",
    label: "Xã Tân Hòa",
    parent_code: "874",
  },
  {
    value: "30235",
    label: "Xã Tân Hòa",
    parent_code: "876",
  },
  {
    value: "30457",
    label: "Xã Tân Hòa",
    parent_code: "888",
  },
  {
    value: "18934",
    label: "Xã Tân Hóa",
    parent_code: "452",
  },
  {
    value: "28324",
    label: "Xã Tân Hòa Đông",
    parent_code: "818",
  },
  {
    value: "28348",
    label: "Xã Tân Hòa Tây",
    parent_code: "818",
  },
  {
    value: "28339",
    label: "Xã Tân Hòa Thành",
    parent_code: "818",
  },
  {
    value: "12958",
    label: "Xã Tân Học",
    parent_code: "341",
  },
  {
    value: "29929",
    label: "Xã Tân Hộ Cơ",
    parent_code: "869",
  },
  {
    value: "09817",
    label: "Xã Tân Hội",
    parent_code: "273",
  },
  {
    value: "24976",
    label: "Xã Tân Hội",
    parent_code: "678",
  },
  {
    value: "25525",
    label: "Xã Tân Hội",
    parent_code: "706",
  },
  {
    value: "28468",
    label: "Xã Tân Hội",
    parent_code: "817",
  },
  {
    value: "28940",
    label: "Xã Tân Hội",
    parent_code: "833",
  },
  {
    value: "29569",
    label: "Phường Tân Hội",
    parent_code: "855",
  },
  {
    value: "29965",
    label: "Xã Tân Hội",
    parent_code: "868",
  },
  {
    value: "30853",
    label: "Xã Tân Hội",
    parent_code: "904",
  },
  {
    value: "28522",
    label: "Xã Tân Hội Đông",
    parent_code: "821",
  },
  {
    value: "30103",
    label: "Xã Tân Hội Trung",
    parent_code: "873",
  },
  {
    value: "09391",
    label: "Phường Tân Hồng",
    parent_code: "261",
  },
  {
    value: "10972",
    label: "Xã Tân Hồng",
    parent_code: "296",
  },
  {
    value: "03988",
    label: "Xã Tân Hợp",
    parent_code: "123",
  },
  {
    value: "04414",
    label: "Xã Tân Hợp",
    parent_code: "136",
  },
  {
    value: "17269",
    label: "Xã Tân Hợp",
    parent_code: "423",
  },
  {
    value: "19450",
    label: "Xã Tân Hợp",
    parent_code: "465",
  },
  {
    value: "30151",
    label: "Xã Tân Huề",
    parent_code: "874",
  },
  {
    value: "29362",
    label: "Xã Tân Hùng",
    parent_code: "846",
  },
  {
    value: "00394",
    label: "Xã Tân Hưng",
    parent_code: "016",
  },
  {
    value: "11011",
    label: "Phường Tân Hưng",
    parent_code: "288",
  },
  {
    value: "11857",
    label: "Xã Tân Hưng",
    parent_code: "316",
  },
  {
    value: "12385",
    label: "Xã Tân Hưng",
    parent_code: "323",
  },
  {
    value: "07417",
    label: "Xã Tân Hưng",
    parent_code: "217",
  },
  {
    value: "25345",
    label: "Xã Tân Hưng",
    parent_code: "694",
  },
  {
    value: "25375",
    label: "Xã Tân Hưng",
    parent_code: "695",
  },
  {
    value: "25549",
    label: "Xã Tân Hưng",
    parent_code: "706",
  },
  {
    value: "25825",
    label: "Xã Tân Hưng",
    parent_code: "719",
  },
  {
    value: "26567",
    label: "Xã Tân Hưng",
    parent_code: "748",
  },
  {
    value: "27475",
    label: "Phường Tân Hưng",
    parent_code: "778",
  },
  {
    value: "27721",
    label: "Thị trấn Tân Hưng",
    parent_code: "796",
  },
  {
    value: "28417",
    label: "Xã Tân Hưng",
    parent_code: "819",
  },
  {
    value: "29155",
    label: "Xã Tân Hưng",
    parent_code: "836",
  },
  {
    value: "29773",
    label: "Xã Tân Hưng",
    parent_code: "863",
  },
  {
    value: "31227",
    label: "Phường Tân Hưng",
    parent_code: "923",
  },
  {
    value: "31660",
    label: "Xã Tân Hưng",
    parent_code: "946",
  },
  {
    value: "32137",
    label: "Xã Tân Hưng",
    parent_code: "969",
  },
  {
    value: "32146",
    label: "Xã Tân Hưng Đông",
    parent_code: "969",
  },
  {
    value: "32227",
    label: "Xã Tân Hưng Tây",
    parent_code: "972",
  },
  {
    value: "26787",
    label: "Phường Tân Hưng Thuận",
    parent_code: "761",
  },
  {
    value: "11179",
    label: "Xã Tân Hương",
    parent_code: "299",
  },
  {
    value: "05893",
    label: "Xã Tân Hương",
    parent_code: "172",
  },
  {
    value: "06361",
    label: "Xã Tân Hương",
    parent_code: "185",
  },
  {
    value: "04756",
    label: "Xã Tân Hương",
    parent_code: "141",
  },
  {
    value: "17325",
    label: "Xã Tân Hương",
    parent_code: "423",
  },
  {
    value: "18310",
    label: "Xã Tân Hương",
    parent_code: "440",
  },
  {
    value: "28525",
    label: "Xã Tân Hương",
    parent_code: "821",
  },
  {
    value: "25357",
    label: "Thị trấn Tân Khai",
    parent_code: "694",
  },
  {
    value: "16291",
    label: "Xã Tân Khang",
    parent_code: "404",
  },
  {
    value: "05917",
    label: "Xã Tân Khánh",
    parent_code: "173",
  },
  {
    value: "13750",
    label: "Xã Tân Khánh",
    parent_code: "359",
  },
  {
    value: "27692",
    label: "Phường Tân Khánh",
    parent_code: "794",
  },
  {
    value: "29914",
    label: "Xã Tân Khánh Đông",
    parent_code: "867",
  },
  {
    value: "30796",
    label: "Xã Tân Khánh Hòa",
    parent_code: "914",
  },
  {
    value: "27616",
    label: "Xã Tân Kiên",
    parent_code: "785",
  },
  {
    value: "27472",
    label: "Phường Tân Kiểng",
    parent_code: "778",
  },
  {
    value: "30049",
    label: "Xã Tân Kiều",
    parent_code: "872",
  },
  {
    value: "05920",
    label: "Xã Tân Kim",
    parent_code: "173",
  },
  {
    value: "11113",
    label: "Xã Tân Kỳ",
    parent_code: "298",
  },
  {
    value: "17266",
    label: "Thị trấn Tân Kỳ",
    parent_code: "423",
  },
  {
    value: "16777",
    label: "Thị trấn Tân Lạc",
    parent_code: "416",
  },
  {
    value: "25087",
    label: "Xã Tân Lạc",
    parent_code: "680",
  },
  {
    value: "03919",
    label: "Xã Tân Lang",
    parent_code: "122",
  },
  {
    value: "09511",
    label: "Xã Tân Lãng",
    parent_code: "264",
  },
  {
    value: "25007",
    label: "Xã Tân Lâm",
    parent_code: "679",
  },
  {
    value: "26635",
    label: "Xã Tân Lâm",
    parent_code: "751",
  },
  {
    value: "18652",
    label: "Xã Tân Lâm Hương",
    parent_code: "445",
  },
  {
    value: "28138",
    label: "Xã Tân Lân",
    parent_code: "806",
  },
  {
    value: "09820",
    label: "Xã Tân Lập",
    parent_code: "273",
  },
  {
    value: "01159",
    label: "Xã Tân Lập",
    parent_code: "034",
  },
  {
    value: "02032",
    label: "Xã Tân Lập",
    parent_code: "064",
  },
  {
    value: "08641",
    label: "Xã Tân Lập",
    parent_code: "238",
  },
  {
    value: "08818",
    label: "Xã Tân Lập",
    parent_code: "253",
  },
  {
    value: "12073",
    label: "Xã Tân Lập",
    parent_code: "327",
  },
  {
    value: "05287",
    label: "Xã Tân Lập",
    parent_code: "157",
  },
  {
    value: "05464",
    label: "Phường Tân Lập",
    parent_code: "164",
  },
  {
    value: "06352",
    label: "Xã Tân Lập",
    parent_code: "185",
  },
  {
    value: "06917",
    label: "Xã Tân Lập",
    parent_code: "200",
  },
  {
    value: "07594",
    label: "Xã Tân Lập",
    parent_code: "219",
  },
  {
    value: "13240",
    label: "Xã Tân Lập",
    parent_code: "344",
  },
  {
    value: "03997",
    label: "Xã Tân Lập",
    parent_code: "123",
  },
  {
    value: "04354",
    label: "Xã Tân Lập",
    parent_code: "135",
  },
  {
    value: "25381",
    label: "Xã Tân Lập",
    parent_code: "695",
  },
  {
    value: "25489",
    label: "Xã Tân Lập",
    parent_code: "705",
  },
  {
    value: "22369",
    label: "Phường Tân Lập",
    parent_code: "568",
  },
  {
    value: "25903",
    label: "Xã Tân Lập",
    parent_code: "726",
  },
  {
    value: "23134",
    label: "Xã Tân Lập",
    parent_code: "598",
  },
  {
    value: "23497",
    label: "Xã Tân Lập",
    parent_code: "614",
  },
  {
    value: "19462",
    label: "Xã Tân Lập",
    parent_code: "465",
  },
  {
    value: "24118",
    label: "Phường Tân Lập",
    parent_code: "643",
  },
  {
    value: "24317",
    label: "Xã Tân Lập",
    parent_code: "649",
  },
  {
    value: "27820",
    label: "Xã Tân Lập",
    parent_code: "798",
  },
  {
    value: "27838",
    label: "Xã Tân Lập",
    parent_code: "799",
  },
  {
    value: "30541",
    label: "Xã Tân Lập",
    parent_code: "890",
  },
  {
    value: "28345",
    label: "Xã Tân Lập 1",
    parent_code: "818",
  },
  {
    value: "28354",
    label: "Xã Tân Lập 2",
    parent_code: "818",
  },
  {
    value: "12592",
    label: "Xã Tân Lễ",
    parent_code: "339",
  },
  {
    value: "11860",
    label: "Xã Tân Liên",
    parent_code: "316",
  },
  {
    value: "06244",
    label: "Xã Tân Liên",
    parent_code: "183",
  },
  {
    value: "19465",
    label: "Xã Tân Liên",
    parent_code: "465",
  },
  {
    value: "07717",
    label: "Xã Tân Liễu",
    parent_code: "221",
  },
  {
    value: "05788",
    label: "Xã Tân Linh",
    parent_code: "171",
  },
  {
    value: "04336",
    label: "Xã Tân Lĩnh",
    parent_code: "135",
  },
  {
    value: "05482",
    label: "Phường Tân Long",
    parent_code: "164",
  },
  {
    value: "05668",
    label: "Xã Tân Long",
    parent_code: "169",
  },
  {
    value: "02470",
    label: "Xã Tân Long",
    parent_code: "075",
  },
  {
    value: "17311",
    label: "Xã Tân Long",
    parent_code: "423",
  },
  {
    value: "25879",
    label: "Xã Tân Long",
    parent_code: "722",
  },
  {
    value: "19459",
    label: "Xã Tân Long",
    parent_code: "465",
  },
  {
    value: "28072",
    label: "Xã Tân Long",
    parent_code: "804",
  },
  {
    value: "28279",
    label: "Phường Tân Long",
    parent_code: "815",
  },
  {
    value: "29653",
    label: "Xã Tân Long",
    parent_code: "858",
  },
  {
    value: "30166",
    label: "Xã Tân Long",
    parent_code: "874",
  },
  {
    value: "31438",
    label: "Xã Tân Long",
    parent_code: "934",
  },
  {
    value: "31741",
    label: "Xã Tân Long",
    parent_code: "948",
  },
  {
    value: "29656",
    label: "Xã Tân Long Hội",
    parent_code: "858",
  },
  {
    value: "18409",
    label: "Xã Tân Lộc",
    parent_code: "448",
  },
  {
    value: "29722",
    label: "Xã Tân Lộc",
    parent_code: "860",
  },
  {
    value: "31213",
    label: "Phường Tân Lộc",
    parent_code: "923",
  },
  {
    value: "32086",
    label: "Xã Tân Lộc",
    parent_code: "967",
  },
  {
    value: "32083",
    label: "Xã Tân Lộc Bắc",
    parent_code: "967",
  },
  {
    value: "32089",
    label: "Xã Tân Lộc Đông",
    parent_code: "967",
  },
  {
    value: "05704",
    label: "Xã Tân Lợi",
    parent_code: "169",
  },
  {
    value: "25342",
    label: "Xã Tân Lợi",
    parent_code: "694",
  },
  {
    value: "25378",
    label: "Xã Tân Lợi",
    parent_code: "695",
  },
  {
    value: "24136",
    label: "Phường Tân Lợi",
    parent_code: "643",
  },
  {
    value: "30535",
    label: "Xã Tân Lợi",
    parent_code: "890",
  },
  {
    value: "29038",
    label: "Xã Tân Lợi Thạnh",
    parent_code: "834",
  },
  {
    value: "29785",
    label: "Xã Tân Lược",
    parent_code: "863",
  },
  {
    value: "28528",
    label: "Xã Tân Lý Đông",
    parent_code: "821",
  },
  {
    value: "28531",
    label: "Xã Tân Lý Tây",
    parent_code: "821",
  },
  {
    value: "00319",
    label: "Phường Tân Mai",
    parent_code: "008",
  },
  {
    value: "26026",
    label: "Phường Tân Mai",
    parent_code: "731",
  },
  {
    value: "00406",
    label: "Xã Tân Minh",
    parent_code: "016",
  },
  {
    value: "10240",
    label: "Xã Tân Minh",
    parent_code: "279",
  },
  {
    value: "08629",
    label: "Xã Tân Minh",
    parent_code: "238",
  },
  {
    value: "06028",
    label: "Xã Tân Minh",
    parent_code: "180",
  },
  {
    value: "04855",
    label: "Xã Tân Minh",
    parent_code: "150",
  },
  {
    value: "23230",
    label: "Thị trấn Tân Minh",
    parent_code: "601",
  },
  {
    value: "07606",
    label: "Xã Tân Mộc",
    parent_code: "219",
  },
  {
    value: "05344",
    label: "Xã Tân Mỹ",
    parent_code: "157",
  },
  {
    value: "06172",
    label: "Xã Tân Mỹ",
    parent_code: "182",
  },
  {
    value: "07687",
    label: "Xã Tân Mỹ",
    parent_code: "213",
  },
  {
    value: "02308",
    label: "Xã Tân Mỹ",
    parent_code: "073",
  },
  {
    value: "25918",
    label: "Xã Tân Mỹ",
    parent_code: "726",
  },
  {
    value: "27949",
    label: "Xã Tân Mỹ",
    parent_code: "802",
  },
  {
    value: "29113",
    label: "Xã Tân Mỹ",
    parent_code: "836",
  },
  {
    value: "29839",
    label: "Xã Tân Mỹ",
    parent_code: "862",
  },
  {
    value: "30145",
    label: "Xã Tân Mỹ",
    parent_code: "874",
  },
  {
    value: "30175",
    label: "Xã Tân Mỹ",
    parent_code: "875",
  },
  {
    value: "30643",
    label: "Xã Tấn Mỹ",
    parent_code: "893",
  },
  {
    value: "28291",
    label: "Xã Tân Mỹ Chánh",
    parent_code: "815",
  },
  {
    value: "18181",
    label: "Xã Tân Mỹ Hà",
    parent_code: "439",
  },
  {
    value: "01228",
    label: "Xã Tân Nam",
    parent_code: "035",
  },
  {
    value: "29563",
    label: "Phường Tân Ngãi",
    parent_code: "855",
  },
  {
    value: "25012",
    label: "Xã Tân Nghĩa",
    parent_code: "679",
  },
  {
    value: "23236",
    label: "Thị trấn Tân Nghĩa",
    parent_code: "601",
  },
  {
    value: "30091",
    label: "Xã Tân Nghĩa",
    parent_code: "873",
  },
  {
    value: "04732",
    label: "Xã Tân Nguyên",
    parent_code: "141",
  },
  {
    value: "30253",
    label: "Xã Tân Nhuận Đông",
    parent_code: "877",
  },
  {
    value: "27613",
    label: "Xã Tân Nhựt",
    parent_code: "785",
  },
  {
    value: "19234",
    label: "Xã Tân Ninh",
    parent_code: "456",
  },
  {
    value: "27856",
    label: "Xã Tân Ninh",
    parent_code: "799",
  },
  {
    value: "04849",
    label: "Xã Tân Pheo",
    parent_code: "150",
  },
  {
    value: "08965",
    label: "Xã Tân Phong",
    parent_code: "249",
  },
  {
    value: "11197",
    label: "Xã Tân Phong",
    parent_code: "299",
  },
  {
    value: "11734",
    label: "Xã Tân Phong",
    parent_code: "314",
  },
  {
    value: "13210",
    label: "Xã Tân Phong",
    parent_code: "344",
  },
  {
    value: "03387",
    label: "Phường Tân Phong",
    parent_code: "105",
  },
  {
    value: "03970",
    label: "Xã Tân Phong",
    parent_code: "122",
  },
  {
    value: "16438",
    label: "Thị trấn Tân Phong",
    parent_code: "406",
  },
  {
    value: "25507",
    label: "Xã Tân Phong",
    parent_code: "705",
  },
  {
    value: "25996",
    label: "Phường Tân Phong",
    parent_code: "731",
  },
  {
    value: "27490",
    label: "Phường Tân Phong",
    parent_code: "778",
  },
  {
    value: "28510",
    label: "Xã Tân Phong",
    parent_code: "820",
  },
  {
    value: "29194",
    label: "Xã Tân Phong",
    parent_code: "837",
  },
  {
    value: "31957",
    label: "Xã Tân Phong",
    parent_code: "959",
  },
  {
    value: "09934",
    label: "Xã Tân Phú",
    parent_code: "275",
  },
  {
    value: "08566",
    label: "Xã Tân Phú",
    parent_code: "240",
  },
  {
    value: "09124",
    label: "Xã Tân Phú",
    parent_code: "252",
  },
  {
    value: "05902",
    label: "Xã Tân Phú",
    parent_code: "172",
  },
  {
    value: "17272",
    label: "Xã Tân Phú",
    parent_code: "423",
  },
  {
    value: "25195",
    label: "Phường Tân Phú",
    parent_code: "689",
  },
  {
    value: "25363",
    label: "Thị trấn Tân Phú",
    parent_code: "695",
  },
  {
    value: "25546",
    label: "Xã Tân Phú",
    parent_code: "706",
  },
  {
    value: "26116",
    label: "Thị trấn Tân Phú",
    parent_code: "734",
  },
  {
    value: "26836",
    label: "Phường Tân Phú",
    parent_code: "769",
  },
  {
    value: "27487",
    label: "Phường Tân Phú",
    parent_code: "778",
  },
  {
    value: "27961",
    label: "Xã Tân Phú",
    parent_code: "802",
  },
  {
    value: "28459",
    label: "Xã Tân Phú",
    parent_code: "817",
  },
  {
    value: "28693",
    label: "Xã Tân Phú",
    parent_code: "825",
  },
  {
    value: "28840",
    label: "Xã Tân Phú",
    parent_code: "831",
  },
  {
    value: "29749",
    label: "Xã Tân Phú",
    parent_code: "860",
  },
  {
    value: "30160",
    label: "Xã Tân Phú",
    parent_code: "874",
  },
  {
    value: "30274",
    label: "Xã Tân Phú",
    parent_code: "877",
  },
  {
    value: "30622",
    label: "Xã Tân Phú",
    parent_code: "892",
  },
  {
    value: "31204",
    label: "Phường Tân Phú",
    parent_code: "919",
  },
  {
    value: "31481",
    label: "Xã Tân Phú",
    parent_code: "937",
  },
  {
    value: "32080",
    label: "Xã Tân Phú",
    parent_code: "967",
  },
  {
    value: "29923",
    label: "Xã Tân Phú Đông",
    parent_code: "867",
  },
  {
    value: "28912",
    label: "Xã Tân Phú Tây",
    parent_code: "838",
  },
  {
    value: "31363",
    label: "Xã Tân Phú Thạnh",
    parent_code: "932",
  },
  {
    value: "27553",
    label: "Xã Tân Phú Trung",
    parent_code: "783",
  },
  {
    value: "30259",
    label: "Xã Tân Phú Trung",
    parent_code: "877",
  },
  {
    value: "12157",
    label: "Xã Tân Phúc",
    parent_code: "329",
  },
  {
    value: "15046",
    label: "Xã Tân Phúc",
    parent_code: "388",
  },
  {
    value: "16282",
    label: "Xã Tân Phúc",
    parent_code: "404",
  },
  {
    value: "23242",
    label: "Xã Tân Phúc",
    parent_code: "601",
  },
  {
    value: "25372",
    label: "Xã Tân Phước",
    parent_code: "695",
  },
  {
    value: "23268",
    label: "Xã Tân Phước",
    parent_code: "594",
  },
  {
    value: "26716",
    label: "Phường Tân Phước",
    parent_code: "754",
  },
  {
    value: "28711",
    label: "Xã Tân Phước",
    parent_code: "824",
  },
  {
    value: "29944",
    label: "Xã Tân Phước",
    parent_code: "869",
  },
  {
    value: "30220",
    label: "Xã Tân Phước",
    parent_code: "876",
  },
  {
    value: "31432",
    label: "Xã Tân Phước Hưng",
    parent_code: "934",
  },
  {
    value: "25891",
    label: "Phường Tân Phước Khánh",
    parent_code: "723",
  },
  {
    value: "28093",
    label: "Xã Tân Phước Tây",
    parent_code: "805",
  },
  {
    value: "08671",
    label: "Xã Tân Phương",
    parent_code: "239",
  },
  {
    value: "04306",
    label: "Xã Tân Phượng",
    parent_code: "135",
  },
  {
    value: "25438",
    label: "Xã Tân Quan",
    parent_code: "694",
  },
  {
    value: "01171",
    label: "Xã Tân Quang",
    parent_code: "034",
  },
  {
    value: "11206",
    label: "Xã Tân Quang",
    parent_code: "299",
  },
  {
    value: "12001",
    label: "Xã Tân Quang",
    parent_code: "325",
  },
  {
    value: "05527",
    label: "Xã Tân Quang",
    parent_code: "165",
  },
  {
    value: "07588",
    label: "Xã Tân Quang",
    parent_code: "219",
  },
  {
    value: "02206",
    label: "Phường Tân Quang",
    parent_code: "070",
  },
  {
    value: "29800",
    label: "Thị trấn Tân Quới",
    parent_code: "863",
  },
  {
    value: "30133",
    label: "Xã Tân Quới",
    parent_code: "874",
  },
  {
    value: "29662",
    label: "Xã Tân Quới Trung",
    parent_code: "859",
  },
  {
    value: "27481",
    label: "Phường Tân Quy",
    parent_code: "778",
  },
  {
    value: "27019",
    label: "Phường Tân Quý",
    parent_code: "767",
  },
  {
    value: "29917",
    label: "Phường Tân Quy Đông",
    parent_code: "867",
  },
  {
    value: "29920",
    label: "Xã Tân Quy Tây",
    parent_code: "867",
  },
  {
    value: "27634",
    label: "Xã Tân Quý Tây",
    parent_code: "785",
  },
  {
    value: "07291",
    label: "Xã Tân Sỏi",
    parent_code: "215",
  },
  {
    value: "08578",
    label: "Xã Tân Sơn",
    parent_code: "240",
  },
  {
    value: "07531",
    label: "Xã Tân Sơn",
    parent_code: "219",
  },
  {
    value: "13411",
    label: "Xã Tân Sơn",
    parent_code: "350",
  },
  {
    value: "14788",
    label: "Phường Tân Sơn",
    parent_code: "380",
  },
  {
    value: "02089",
    label: "Xã Tân Sơn",
    parent_code: "065",
  },
  {
    value: "17140",
    label: "Xã Tân Sơn",
    parent_code: "421",
  },
  {
    value: "17674",
    label: "Xã Tân Sơn",
    parent_code: "427",
  },
  {
    value: "22810",
    label: "Thị trấn Tân Sơn",
    parent_code: "585",
  },
  {
    value: "23593",
    label: "Xã Tân Sơn",
    parent_code: "622",
  },
  {
    value: "29470",
    label: "Xã Tân Sơn",
    parent_code: "849",
  },
  {
    value: "27010",
    label: "Phường Tân Sơn Nhì",
    parent_code: "767",
  },
  {
    value: "06142",
    label: "Xã Tân Tác",
    parent_code: "182",
  },
  {
    value: "22756",
    label: "Phường Tấn Tài",
    parent_code: "582",
  },
  {
    value: "27454",
    label: "Phường Tân Tạo",
    parent_code: "777",
  },
  {
    value: "27457",
    label: "Phường Tân Tạo A",
    parent_code: "777",
  },
  {
    value: "28207",
    label: "Xã Tân Tập",
    parent_code: "807",
  },
  {
    value: "27889",
    label: "Xã Tân Tây",
    parent_code: "800",
  },
  {
    value: "28723",
    label: "Xã Tân Tây",
    parent_code: "824",
  },
  {
    value: "28804",
    label: "Xã Tân Thạch",
    parent_code: "831",
  },
  {
    value: "05827",
    label: "Xã Tân Thái",
    parent_code: "171",
  },
  {
    value: "06166",
    label: "Xã Tân Thanh",
    parent_code: "182",
  },
  {
    value: "07411",
    label: "Xã Tân Thanh",
    parent_code: "217",
  },
  {
    value: "13474",
    label: "Thị trấn Tân Thanh",
    parent_code: "351",
  },
  {
    value: "02590",
    label: "Xã Tân Thanh",
    parent_code: "076",
  },
  {
    value: "03133",
    label: "Phường Tân Thanh",
    parent_code: "094",
  },
  {
    value: "24907",
    label: "Xã Tân Thanh",
    parent_code: "676",
  },
  {
    value: "28423",
    label: "Xã Tân Thanh",
    parent_code: "819",
  },
  {
    value: "29035",
    label: "Xã Tân Thanh",
    parent_code: "834",
  },
  {
    value: "01162",
    label: "Xã Tân Thành",
    parent_code: "034",
  },
  {
    value: "11740",
    label: "Phường Tân Thành",
    parent_code: "309",
  },
  {
    value: "04882",
    label: "Xã Tân Thành",
    parent_code: "156",
  },
  {
    value: "05479",
    label: "Phường Tân Thành",
    parent_code: "164",
  },
  {
    value: "05923",
    label: "Xã Tân Thành",
    parent_code: "173",
  },
  {
    value: "06250",
    label: "Xã Tân Thành",
    parent_code: "183",
  },
  {
    value: "06379",
    label: "Xã Tân Thành",
    parent_code: "185",
  },
  {
    value: "06442",
    label: "Xã Tân Thành",
    parent_code: "186",
  },
  {
    value: "13759",
    label: "Xã Tân Thành",
    parent_code: "359",
  },
  {
    value: "14323",
    label: "Phường Tân Thành",
    parent_code: "369",
  },
  {
    value: "14668",
    label: "Xã Tân Thành",
    parent_code: "376",
  },
  {
    value: "15661",
    label: "Xã Tân Thành",
    parent_code: "396",
  },
  {
    value: "02401",
    label: "Xã Tân Thành",
    parent_code: "074",
  },
  {
    value: "17515",
    label: "Xã Tân Thành",
    parent_code: "426",
  },
  {
    value: "24979",
    label: "Xã Tân Thành",
    parent_code: "678",
  },
  {
    value: "25207",
    label: "Xã Tân Thành",
    parent_code: "689",
  },
  {
    value: "25318",
    label: "Xã Tân Thành",
    parent_code: "693",
  },
  {
    value: "25543",
    label: "Xã Tân Thành",
    parent_code: "706",
  },
  {
    value: "25906",
    label: "Thị trấn Tân Thành",
    parent_code: "726",
  },
  {
    value: "23146",
    label: "Xã Tân Thành",
    parent_code: "598",
  },
  {
    value: "27022",
    label: "Phường Tân Thành",
    parent_code: "767",
  },
  {
    value: "19456",
    label: "Xã Tân Thành",
    parent_code: "465",
  },
  {
    value: "24699",
    label: "Xã Tân Thành",
    parent_code: "664",
  },
  {
    value: "24142",
    label: "Phường Tân Thành",
    parent_code: "643",
  },
  {
    value: "27823",
    label: "Xã Tân Thành",
    parent_code: "798",
  },
  {
    value: "27850",
    label: "Xã Tân Thành",
    parent_code: "799",
  },
  {
    value: "28042",
    label: "Xã Tân Thành",
    parent_code: "804",
  },
  {
    value: "28747",
    label: "Xã Tân Thành",
    parent_code: "824",
  },
  {
    value: "29776",
    label: "Xã Tân Thành",
    parent_code: "863",
  },
  {
    value: "30226",
    label: "Xã Tân Thành",
    parent_code: "876",
  },
  {
    value: "30856",
    label: "Xã Tân Thành",
    parent_code: "904",
  },
  {
    value: "31414",
    label: "Xã Tân Thành",
    parent_code: "931",
  },
  {
    value: "32025",
    label: "Phường Tân Thành",
    parent_code: "964",
  },
  {
    value: "32026",
    label: "Xã Tân Thành",
    parent_code: "964",
  },
  {
    value: "20335",
    label: "Phường Tân Thạnh",
    parent_code: "502",
  },
  {
    value: "27826",
    label: "Thị trấn Tân Thạnh",
    parent_code: "799",
  },
  {
    value: "28699",
    label: "Xã Tân Thạnh",
    parent_code: "825",
  },
  {
    value: "30157",
    label: "Xã Tân Thạnh",
    parent_code: "874",
  },
  {
    value: "30387",
    label: "Xã Tân Thạnh",
    parent_code: "887",
  },
  {
    value: "31031",
    label: "Xã Tân Thạnh",
    parent_code: "909",
  },
  {
    value: "31268",
    label: "Xã Tân Thạnh",
    parent_code: "927",
  },
  {
    value: "31666",
    label: "Xã Tân Thạnh",
    parent_code: "946",
  },
  {
    value: "31969",
    label: "Xã Tân Thạnh",
    parent_code: "959",
  },
  {
    value: "29938",
    label: "Xã Tân Thành A",
    parent_code: "869",
  },
  {
    value: "29941",
    label: "Xã Tân Thành B",
    parent_code: "869",
  },
  {
    value: "28918",
    label: "Xã Tân Thành Bình",
    parent_code: "838",
  },
  {
    value: "27547",
    label: "Xã Tân Thạnh Đông",
    parent_code: "783",
  },
  {
    value: "28927",
    label: "Xã Tân Thanh Tây",
    parent_code: "838",
  },
  {
    value: "27541",
    label: "Xã Tân Thạnh Tây",
    parent_code: "783",
  },
  {
    value: "17224",
    label: "Xã Tân Thắng",
    parent_code: "421",
  },
  {
    value: "23254",
    label: "Xã Tân Thắng",
    parent_code: "601",
  },
  {
    value: "25205",
    label: "Phường Tân Thiện",
    parent_code: "689",
  },
  {
    value: "23234",
    label: "Phường Tân Thiện",
    parent_code: "594",
  },
  {
    value: "28891",
    label: "Xã Tân Thiềng",
    parent_code: "832",
  },
  {
    value: "05452",
    label: "Phường Tân Thịnh",
    parent_code: "164",
  },
  {
    value: "05548",
    label: "Xã Tân Thịnh",
    parent_code: "167",
  },
  {
    value: "13987",
    label: "Xã Tân Thịnh",
    parent_code: "362",
  },
  {
    value: "02344",
    label: "Xã Tân Thịnh",
    parent_code: "073",
  },
  {
    value: "04279",
    label: "Xã Tân Thịnh",
    parent_code: "132",
  },
  {
    value: "04696",
    label: "Xã Tân Thịnh",
    parent_code: "140",
  },
  {
    value: "04801",
    label: "Phường Tân Thịnh",
    parent_code: "148",
  },
  {
    value: "16285",
    label: "Xã Tân Thọ",
    parent_code: "404",
  },
  {
    value: "27556",
    label: "Xã Tân Thông Hội",
    parent_code: "783",
  },
  {
    value: "28690",
    label: "Xã Tân Thới",
    parent_code: "825",
  },
  {
    value: "31306",
    label: "Xã Tân Thới",
    parent_code: "926",
  },
  {
    value: "26782",
    label: "Phường Tân Thới Hiệp",
    parent_code: "761",
  },
  {
    value: "27040",
    label: "Phường Tân Thới Hòa",
    parent_code: "767",
  },
  {
    value: "26791",
    label: "Phường Tân Thới Nhất",
    parent_code: "761",
  },
  {
    value: "27571",
    label: "Xã Tân Thới Nhì",
    parent_code: "784",
  },
  {
    value: "23143",
    label: "Xã Tân Thuận",
    parent_code: "598",
  },
  {
    value: "31072",
    label: "Xã Tân Thuận",
    parent_code: "910",
  },
  {
    value: "32167",
    label: "Xã Tân Thuận",
    parent_code: "970",
  },
  {
    value: "28627",
    label: "Xã Tân Thuận Bình",
    parent_code: "822",
  },
  {
    value: "27466",
    label: "Phường Tân Thuận Đông",
    parent_code: "778",
  },
  {
    value: "29896",
    label: "Xã Tân Thuận Đông",
    parent_code: "866",
  },
  {
    value: "27469",
    label: "Phường Tân Thuận Tây",
    parent_code: "778",
  },
  {
    value: "29890",
    label: "Xã Tân Thuận Tây",
    parent_code: "866",
  },
  {
    value: "19294",
    label: "Xã Tân Thủy",
    parent_code: "457",
  },
  {
    value: "29167",
    label: "Xã Tân Thủy",
    parent_code: "836",
  },
  {
    value: "03070",
    label: "Xã Tân Thượng",
    parent_code: "089",
  },
  {
    value: "25006",
    label: "Xã Tân Thượng",
    parent_code: "679",
  },
  {
    value: "10066",
    label: "Xã Tân Tiến",
    parent_code: "277",
  },
  {
    value: "01051",
    label: "Xã Tân Tiến",
    parent_code: "032",
  },
  {
    value: "09103",
    label: "Xã Tân Tiến",
    parent_code: "252",
  },
  {
    value: "11032",
    label: "Xã Tân Tiến",
    parent_code: "297",
  },
  {
    value: "11596",
    label: "Xã Tân Tiến",
    parent_code: "312",
  },
  {
    value: "12043",
    label: "Xã Tân Tiến",
    parent_code: "326",
  },
  {
    value: "06019",
    label: "Xã Tân Tiến",
    parent_code: "180",
  },
  {
    value: "07699",
    label: "Xã Tân Tiến",
    parent_code: "213",
  },
  {
    value: "12610",
    label: "Xã Tân Tiến",
    parent_code: "339",
  },
  {
    value: "02461",
    label: "Xã Tân Tiến",
    parent_code: "075",
  },
  {
    value: "02950",
    label: "Xã Tân Tiến",
    parent_code: "087",
  },
  {
    value: "25321",
    label: "Xã Tân Tiến",
    parent_code: "693",
  },
  {
    value: "25393",
    label: "Xã Tân Tiến",
    parent_code: "695",
  },
  {
    value: "26014",
    label: "Phường Tân Tiến",
    parent_code: "731",
  },
  {
    value: "23246",
    label: "Xã Tân Tiến",
    parent_code: "594",
  },
  {
    value: "24145",
    label: "Phường Tân Tiến",
    parent_code: "643",
  },
  {
    value: "24526",
    label: "Xã Tân Tiến",
    parent_code: "654",
  },
  {
    value: "31338",
    label: "Xã Tân Tiến",
    parent_code: "930",
  },
  {
    value: "32176",
    label: "Xã Tân Tiến",
    parent_code: "970",
  },
  {
    value: "19192",
    label: "Xã Tân Trạch",
    parent_code: "455",
  },
  {
    value: "28132",
    label: "Xã Tân Trạch",
    parent_code: "806",
  },
  {
    value: "11257",
    label: "Xã Tân Trào",
    parent_code: "300",
  },
  {
    value: "11743",
    label: "Xã Tân Trào",
    parent_code: "314",
  },
  {
    value: "02545",
    label: "Xã Tân Trào",
    parent_code: "076",
  },
  {
    value: "06340",
    label: "Xã Tân Tri",
    parent_code: "185",
  },
  {
    value: "00643",
    label: "Xã Tân Triều",
    parent_code: "020",
  },
  {
    value: "01240",
    label: "Xã Tân Trịnh",
    parent_code: "035",
  },
  {
    value: "28075",
    label: "Thị trấn Tân Trụ",
    parent_code: "805",
  },
  {
    value: "07309",
    label: "Xã Tân Trung",
    parent_code: "216",
  },
  {
    value: "28729",
    label: "Xã Tân Trung",
    parent_code: "816",
  },
  {
    value: "28963",
    label: "Xã Tân Trung",
    parent_code: "833",
  },
  {
    value: "30460",
    label: "Xã Tân Trung",
    parent_code: "888",
  },
  {
    value: "32162",
    label: "Xã Tân Trung",
    parent_code: "970",
  },
  {
    value: "10930",
    label: "Xã Tân Trường",
    parent_code: "295",
  },
  {
    value: "16636",
    label: "Xã Tân Trường",
    parent_code: "407",
  },
  {
    value: "01993",
    label: "Xã Tân Tú",
    parent_code: "063",
  },
  {
    value: "27595",
    label: "Thị trấn Tân Túc",
    parent_code: "785",
  },
  {
    value: "30583",
    label: "Xã Tân Tuyến",
    parent_code: "891",
  },
  {
    value: "03598",
    label: "Thị trấn Tân Uyên",
    parent_code: "111",
  },
  {
    value: "10165",
    label: "Xã Tân Ước",
    parent_code: "278",
  },
  {
    value: "26059",
    label: "Phường Tân Vạn",
    parent_code: "731",
  },
  {
    value: "06121",
    label: "Xã Tân Văn",
    parent_code: "181",
  },
  {
    value: "24910",
    label: "Xã Tân Văn",
    parent_code: "676",
  },
  {
    value: "11665",
    label: "Xã Tân Viên",
    parent_code: "313",
  },
  {
    value: "10825",
    label: "Xã Tân Việt",
    parent_code: "294",
  },
  {
    value: "10966",
    label: "Xã Tân Việt",
    parent_code: "296",
  },
  {
    value: "12100",
    label: "Xã Tân Việt",
    parent_code: "327",
  },
  {
    value: "07087",
    label: "Xã Tân Việt",
    parent_code: "205",
  },
  {
    value: "04951",
    label: "Xã Tân Vinh",
    parent_code: "152",
  },
  {
    value: "25933",
    label: "Phường Tân Vĩnh Hiệp",
    parent_code: "723",
  },
  {
    value: "10000",
    label: "Xã Tân Xã",
    parent_code: "276",
  },
  {
    value: "04058",
    label: "Xã Tân Xuân",
    parent_code: "128",
  },
  {
    value: "17275",
    label: "Xã Tân Xuân",
    parent_code: "423",
  },
  {
    value: "25204",
    label: "Phường Tân Xuân",
    parent_code: "689",
  },
  {
    value: "23260",
    label: "Xã Tân Xuân",
    parent_code: "601",
  },
  {
    value: "27580",
    label: "Xã Tân Xuân",
    parent_code: "784",
  },
  {
    value: "29119",
    label: "Xã Tân Xuân",
    parent_code: "836",
  },
  {
    value: "32022",
    label: "Phường Tân Xuyên",
    parent_code: "964",
  },
  {
    value: "06022",
    label: "Xã Tân Yên",
    parent_code: "180",
  },
  {
    value: "02374",
    label: "Thị trấn Tân Yên",
    parent_code: "074",
  },
  {
    value: "29365",
    label: "Xã Tập Ngãi",
    parent_code: "846",
  },
  {
    value: "29467",
    label: "Xã Tập Sơn",
    parent_code: "849",
  },
  {
    value: "08605",
    label: "Xã Tất Thắng",
    parent_code: "238",
  },
  {
    value: "21826",
    label: "Xã Tây An",
    parent_code: "547",
  },
  {
    value: "21832",
    label: "Xã Tây Bình",
    parent_code: "547",
  },
  {
    value: "08023",
    label: "Xã Tây Cốc",
    parent_code: "230",
  },
  {
    value: "09619",
    label: "Thị trấn Tây Đằng",
    parent_code: "271",
  },
  {
    value: "12640",
    label: "Xã Tây Đô",
    parent_code: "339",
  },
  {
    value: "13021",
    label: "Xã Tây Giang",
    parent_code: "342",
  },
  {
    value: "21820",
    label: "Xã Tây Giang",
    parent_code: "547",
  },
  {
    value: "17011",
    label: "Xã Tây Hiếu",
    parent_code: "414",
  },
  {
    value: "26275",
    label: "Xã Tây Hoà",
    parent_code: "737",
  },
  {
    value: "15523",
    label: "Xã Tây Hồ",
    parent_code: "395",
  },
  {
    value: "11812",
    label: "Xã Tây Hưng",
    parent_code: "315",
  },
  {
    value: "19750",
    label: "Phường Tây Lộc",
    parent_code: "474",
  },
  {
    value: "12991",
    label: "Xã Tây Lương",
    parent_code: "342",
  },
  {
    value: "00628",
    label: "Phường Tây Mỗ",
    parent_code: "019",
  },
  {
    value: "12994",
    label: "Xã Tây Ninh",
    parent_code: "342",
  },
  {
    value: "05110",
    label: "Xã Tây Phong",
    parent_code: "154",
  },
  {
    value: "13030",
    label: "Xã Tây Phong",
    parent_code: "342",
  },
  {
    value: "21850",
    label: "Xã Tây Phú",
    parent_code: "547",
  },
  {
    value: "30691",
    label: "Xã Tây Phú",
    parent_code: "894",
  },
  {
    value: "13090",
    label: "Xã Tây Sơn",
    parent_code: "343",
  },
  {
    value: "14369",
    label: "Phường Tây Sơn",
    parent_code: "370",
  },
  {
    value: "16864",
    label: "Xã Tây Sơn",
    parent_code: "417",
  },
  {
    value: "23575",
    label: "Phường Tây Sơn",
    parent_code: "622",
  },
  {
    value: "23617",
    label: "Phường Tây Sơn",
    parent_code: "623",
  },
  {
    value: "17536",
    label: "Xã Tây Thành",
    parent_code: "426",
  },
  {
    value: "27013",
    label: "Phường Tây Thạnh",
    parent_code: "767",
  },
  {
    value: "21814",
    label: "Xã Tây Thuận",
    parent_code: "547",
  },
  {
    value: "13033",
    label: "Xã Tây Tiến",
    parent_code: "342",
  },
  {
    value: "19180",
    label: "Xã Tây Trạch",
    parent_code: "455",
  },
  {
    value: "00607",
    label: "Phường Tây Tựu",
    parent_code: "021",
  },
  {
    value: "21838",
    label: "Xã Tây Vinh",
    parent_code: "547",
  },
  {
    value: "21844",
    label: "Xã Tây Xuân",
    parent_code: "547",
  },
  {
    value: "30988",
    label: "Xã Tây Yên",
    parent_code: "908",
  },
  {
    value: "30991",
    label: "Xã Tây Yên A",
    parent_code: "908",
  },
  {
    value: "07616",
    label: "Thị trấn Tây Yên Tử",
    parent_code: "220",
  },
  {
    value: "08476",
    label: "Xã Tề Lễ",
    parent_code: "236",
  },
  {
    value: "09040",
    label: "Xã Tề Lỗ",
    parent_code: "251",
  },
  {
    value: "16315",
    label: "Xã Tế Lợi",
    parent_code: "404",
  },
  {
    value: "16318",
    label: "Xã Tế Nông",
    parent_code: "404",
  },
  {
    value: "16309",
    label: "Xã Tế Thắng",
    parent_code: "404",
  },
  {
    value: "23446",
    label: "Xã Tê Xăng",
    parent_code: "617",
  },
  {
    value: "03304",
    label: "Xã Tênh Phông",
    parent_code: "099",
  },
  {
    value: "04717",
    label: "Thị trấn Thác Bà",
    parent_code: "141",
  },
  {
    value: "20221",
    label: "Phường Thạc Gián",
    parent_code: "491",
  },
  {
    value: "25216",
    label: "Phường Thác Mơ",
    parent_code: "688",
  },
  {
    value: "00148",
    label: "Phường Thạch Bàn",
    parent_code: "004",
  },
  {
    value: "14395",
    label: "Xã Thạch Bình",
    parent_code: "372",
  },
  {
    value: "15211",
    label: "Xã Thạch Bình",
    parent_code: "391",
  },
  {
    value: "18112",
    label: "Xã Thạch Bình",
    parent_code: "436",
  },
  {
    value: "15205",
    label: "Xã Thạch Cẩm",
    parent_code: "391",
  },
  {
    value: "18583",
    label: "Xã Thạch Châu",
    parent_code: "448",
  },
  {
    value: "08980",
    label: "Xã Thạch Đà",
    parent_code: "250",
  },
  {
    value: "18643",
    label: "Xã Thạch Đài",
    parent_code: "445",
  },
  {
    value: "06199",
    label: "Xã Thạch Đạn",
    parent_code: "183",
  },
  {
    value: "15214",
    label: "Xã Thạch Định",
    parent_code: "391",
  },
  {
    value: "08665",
    label: "Xã Thạch Đồng",
    parent_code: "239",
  },
  {
    value: "15217",
    label: "Xã Thạch Đồng",
    parent_code: "391",
  },
  {
    value: "16876",
    label: "Thị trấn Thạch Giám",
    parent_code: "418",
  },
  {
    value: "18562",
    label: "Thị trấn Thạch Hà",
    parent_code: "445",
  },
  {
    value: "18100",
    label: "Xã Thạch Hạ",
    parent_code: "436",
  },
  {
    value: "18571",
    label: "Xã Thạch Hải",
    parent_code: "445",
  },
  {
    value: "09988",
    label: "Xã Thạch Hoà",
    parent_code: "276",
  },
  {
    value: "18985",
    label: "Xã Thạch Hóa",
    parent_code: "453",
  },
  {
    value: "18649",
    label: "Xã Thạch Hội",
    parent_code: "445",
  },
  {
    value: "18109",
    label: "Xã Thạch Hưng",
    parent_code: "436",
  },
  {
    value: "18586",
    label: "Xã Thạch Kênh",
    parent_code: "445",
  },
  {
    value: "18604",
    label: "Xã Thạch Khê",
    parent_code: "445",
  },
  {
    value: "08587",
    label: "Xã Thạch Khoán",
    parent_code: "238",
  },
  {
    value: "11002",
    label: "Phường Thạch Khôi",
    parent_code: "288",
  },
  {
    value: "08548",
    label: "Xã Thạch Kiệt",
    parent_code: "240",
  },
  {
    value: "18580",
    label: "Xã Thạch Kim",
    parent_code: "448",
  },
  {
    value: "18622",
    label: "Xã Thạch Lạc",
    parent_code: "445",
  },
  {
    value: "01304",
    label: "Xã Thạch Lâm",
    parent_code: "042",
  },
  {
    value: "15196",
    label: "Xã Thạch Lâm",
    parent_code: "391",
  },
  {
    value: "15073",
    label: "Xã Thạch Lập",
    parent_code: "389",
  },
  {
    value: "18592",
    label: "Xã Thạch Liên",
    parent_code: "445",
  },
  {
    value: "18094",
    label: "Phường Thạch Linh",
    parent_code: "436",
  },
  {
    value: "15220",
    label: "Xã Thạch Long",
    parent_code: "391",
  },
  {
    value: "18607",
    label: "Xã Thạch Long",
    parent_code: "445",
  },
  {
    value: "10906",
    label: "Xã Thạch Lỗi",
    parent_code: "295",
  },
  {
    value: "04684",
    label: "Xã Thạch Lương",
    parent_code: "133",
  },
  {
    value: "18577",
    label: "Xã Thạch Mỹ",
    parent_code: "448",
  },
  {
    value: "17239",
    label: "Xã Thạch Ngàn",
    parent_code: "422",
  },
  {
    value: "18625",
    label: "Xã Thạch Ngọc",
    parent_code: "445",
  },
  {
    value: "15199",
    label: "Xã Thạch Quảng",
    parent_code: "391",
  },
  {
    value: "18091",
    label: "Phường Thạch Quý",
    parent_code: "436",
  },
  {
    value: "08512",
    label: "Xã Thạch Sơn",
    parent_code: "237",
  },
  {
    value: "15208",
    label: "Xã Thạch Sơn",
    parent_code: "391",
  },
  {
    value: "17371",
    label: "Xã Thạch Sơn",
    parent_code: "424",
  },
  {
    value: "18589",
    label: "Xã Thạch Sơn",
    parent_code: "445",
  },
  {
    value: "09916",
    label: "Xã Thạch Thán",
    parent_code: "275",
  },
  {
    value: "20233",
    label: "Phường Thạch Thang",
    parent_code: "492",
  },
  {
    value: "18637",
    label: "Xã Thạch Thắng",
    parent_code: "445",
  },
  {
    value: "18619",
    label: "Xã Thạch Trị",
    parent_code: "445",
  },
  {
    value: "18088",
    label: "Xã Thạch Trung",
    parent_code: "436",
  },
  {
    value: "15202",
    label: "Xã Thạch Tượng",
    parent_code: "391",
  },
  {
    value: "18631",
    label: "Xã Thạch Văn",
    parent_code: "445",
  },
  {
    value: "10003",
    label: "Xã Thạch Xá",
    parent_code: "276",
  },
  {
    value: "18658",
    label: "Xã Thạch Xuân",
    parent_code: "445",
  },
  {
    value: "05125",
    label: "Xã Thạch Yên",
    parent_code: "154",
  },
  {
    value: "00910",
    label: "Xã Thái An",
    parent_code: "029",
  },
  {
    value: "09460",
    label: "Xã Thái Bảo",
    parent_code: "263",
  },
  {
    value: "06631",
    label: "Xã Thái Bình",
    parent_code: "189",
  },
  {
    value: "02494",
    label: "Xã Thái Bình",
    parent_code: "075",
  },
  {
    value: "04789",
    label: "Phường Thái Bình",
    parent_code: "148",
  },
  {
    value: "25597",
    label: "Xã Thái Bình",
    parent_code: "708",
  },
  {
    value: "27772",
    label: "Xã Thái Bình Trung",
    parent_code: "797",
  },
  {
    value: "01804",
    label: "Xã Thái Cường",
    parent_code: "053",
  },
  {
    value: "10990",
    label: "Xã Thái Dương",
    parent_code: "296",
  },
  {
    value: "07438",
    label: "Xã Thái Đào",
    parent_code: "217",
  },
  {
    value: "12940",
    label: "Xã Thái Đô",
    parent_code: "341",
  },
  {
    value: "12919",
    label: "Xã Thái Giang",
    parent_code: "341",
  },
  {
    value: "02857",
    label: "Xã Thải Giàng Phố",
    parent_code: "085",
  },
  {
    value: "09652",
    label: "Xã Thái Hòa",
    parent_code: "271",
  },
  {
    value: "08788",
    label: "Xã Thái Hòa",
    parent_code: "246",
  },
  {
    value: "10993",
    label: "Xã Thái Hòa",
    parent_code: "296",
  },
  {
    value: "15715",
    label: "Xã Thái Hòa",
    parent_code: "397",
  },
  {
    value: "02419",
    label: "Xã Thái Hòa",
    parent_code: "074",
  },
  {
    value: "25939",
    label: "Phường Thái Hòa",
    parent_code: "723",
  },
  {
    value: "01315",
    label: "Xã Thái Học",
    parent_code: "042",
  },
  {
    value: "10588",
    label: "Phường Thái Học",
    parent_code: "290",
  },
  {
    value: "10981",
    label: "Xã Thái Học",
    parent_code: "296",
  },
  {
    value: "12649",
    label: "Xã Thái Hưng",
    parent_code: "339",
  },
  {
    value: "12937",
    label: "Xã Thái Hưng",
    parent_code: "341",
  },
  {
    value: "02521",
    label: "Xã Thái Long",
    parent_code: "070",
  },
  {
    value: "27538",
    label: "Xã Thái Mỹ",
    parent_code: "783",
  },
  {
    value: "12910",
    label: "Xã Thái Nguyên",
    parent_code: "341",
  },
  {
    value: "02917",
    label: "Xã Thái Niên",
    parent_code: "086",
  },
  {
    value: "00730",
    label: "Xã Thài Phìn Tủng",
    parent_code: "026",
  },
  {
    value: "12934",
    label: "Xã Thái Phúc",
    parent_code: "341",
  },
  {
    value: "12652",
    label: "Xã Thái Phương",
    parent_code: "339",
  },
  {
    value: "01316",
    label: "Xã Thái Sơn",
    parent_code: "042",
  },
  {
    value: "11662",
    label: "Xã Thái Sơn",
    parent_code: "313",
  },
  {
    value: "07834",
    label: "Xã Thái Sơn",
    parent_code: "223",
  },
  {
    value: "02407",
    label: "Xã Thái Sơn",
    parent_code: "074",
  },
  {
    value: "17677",
    label: "Xã Thái Sơn",
    parent_code: "427",
  },
  {
    value: "10642",
    label: "Xã Thái Tân",
    parent_code: "291",
  },
  {
    value: "10741",
    label: "Phường Thái Thịnh",
    parent_code: "292",
  },
  {
    value: "12961",
    label: "Xã Thái Thịnh",
    parent_code: "341",
  },
  {
    value: "12967",
    label: "Xã Thái Thọ",
    parent_code: "341",
  },
  {
    value: "19315",
    label: "Xã Thái Thủy",
    parent_code: "457",
  },
  {
    value: "12907",
    label: "Xã Thái Thượng",
    parent_code: "341",
  },
  {
    value: "27766",
    label: "Xã Thái Trị",
    parent_code: "797",
  },
  {
    value: "12943",
    label: "Xã Thái Xuyên",
    parent_code: "341",
  },
  {
    value: "31693",
    label: "Xã Tham Đôn",
    parent_code: "947",
  },
  {
    value: "03595",
    label: "Thị trấn Than Uyên",
    parent_code: "110",
  },
  {
    value: "01027",
    label: "Xã Thàng Tín",
    parent_code: "032",
  },
  {
    value: "19480",
    label: "Xã Thanh",
    parent_code: "465",
  },
  {
    value: "10831",
    label: "Xã Thanh An",
    parent_code: "294",
  },
  {
    value: "03343",
    label: "Xã Thanh An",
    parent_code: "100",
  },
  {
    value: "17773",
    label: "Xã Thanh An",
    parent_code: "428",
  },
  {
    value: "25327",
    label: "Xã Thanh An",
    parent_code: "694",
  },
  {
    value: "25807",
    label: "Xã Thanh An",
    parent_code: "720",
  },
  {
    value: "19603",
    label: "Xã Thanh An",
    parent_code: "468",
  },
  {
    value: "21355",
    label: "Xã Thanh An",
    parent_code: "531",
  },
  {
    value: "31231",
    label: "Thị trấn Thanh An",
    parent_code: "924",
  },
  {
    value: "15250",
    label: "Xã Thành An",
    parent_code: "391",
  },
  {
    value: "23635",
    label: "Xã Thành An",
    parent_code: "623",
  },
  {
    value: "28921",
    label: "Xã Thành An",
    parent_code: "838",
  },
  {
    value: "27676",
    label: "Xã Thạnh An",
    parent_code: "787",
  },
  {
    value: "27895",
    label: "Xã Thạnh An",
    parent_code: "800",
  },
  {
    value: "31240",
    label: "Xã Thạnh An",
    parent_code: "924",
  },
  {
    value: "08152",
    label: "Thị trấn Thanh Ba",
    parent_code: "232",
  },
  {
    value: "25492",
    label: "Xã Thạnh Bắc",
    parent_code: "705",
  },
  {
    value: "10048",
    label: "Xã Thanh Bình",
    parent_code: "277",
  },
  {
    value: "10531",
    label: "Phường Thanh Bình",
    parent_code: "288",
  },
  {
    value: "14326",
    label: "Phường Thanh Bình",
    parent_code: "369",
  },
  {
    value: "02779",
    label: "Xã Thanh Bình",
    parent_code: "083",
  },
  {
    value: "03022",
    label: "Xã Thanh Bình",
    parent_code: "088",
  },
  {
    value: "03130",
    label: "Phường Thanh Bình",
    parent_code: "094",
  },
  {
    value: "25308",
    label: "Thị trấn Thanh Bình",
    parent_code: "693",
  },
  {
    value: "25354",
    label: "Xã Thanh Bình",
    parent_code: "694",
  },
  {
    value: "26044",
    label: "Phường Thanh Bình",
    parent_code: "731",
  },
  {
    value: "26251",
    label: "Xã Thanh Bình",
    parent_code: "737",
  },
  {
    value: "20227",
    label: "Phường Thanh Bình",
    parent_code: "492",
  },
  {
    value: "28615",
    label: "Xã Thanh Bình",
    parent_code: "822",
  },
  {
    value: "29677",
    label: "Xã Thanh Bình",
    parent_code: "859",
  },
  {
    value: "30130",
    label: "Thị trấn Thanh Bình",
    parent_code: "874",
  },
  {
    value: "25498",
    label: "Xã Thạnh Bình",
    parent_code: "705",
  },
  {
    value: "30917",
    label: "Xã Thạnh Bình",
    parent_code: "906",
  },
  {
    value: "18274",
    label: "Xã Thanh Bình Thịnh",
    parent_code: "440",
  },
  {
    value: "10141",
    label: "Xã Thanh Cao",
    parent_code: "278",
  },
  {
    value: "05047",
    label: "Xã Thanh Cao",
    parent_code: "152",
  },
  {
    value: "03337",
    label: "Xã Thanh Chăn",
    parent_code: "100",
  },
  {
    value: "13315",
    label: "Phường Thanh Châu",
    parent_code: "347",
  },
  {
    value: "17776",
    label: "Xã Thanh Chi",
    parent_code: "428",
  },
  {
    value: "17713",
    label: "Thị trấn Thanh Chương",
    parent_code: "428",
  },
  {
    value: "00034",
    label: "Phường Thành Công",
    parent_code: "001",
  },
  {
    value: "01777",
    label: "Xã Thành Công",
    parent_code: "052",
  },
  {
    value: "12274",
    label: "Xã Thành Công",
    parent_code: "330",
  },
  {
    value: "05881",
    label: "Xã Thành Công",
    parent_code: "172",
  },
  {
    value: "15235",
    label: "Xã Thành Công",
    parent_code: "391",
  },
  {
    value: "24139",
    label: "Phường Thành Công",
    parent_code: "643",
  },
  {
    value: "28663",
    label: "Xã Thành Công",
    parent_code: "823",
  },
  {
    value: "10882",
    label: "Xã Thanh Cường",
    parent_code: "294",
  },
  {
    value: "17782",
    label: "Xã Thanh Dương",
    parent_code: "428",
  },
  {
    value: "09757",
    label: "Xã Thanh Đa",
    parent_code: "272",
  },
  {
    value: "25618",
    label: "Xã Thanh Điền",
    parent_code: "708",
  },
  {
    value: "08515",
    label: "Xã Thanh Đình",
    parent_code: "227",
  },
  {
    value: "05578",
    label: "Xã Thanh Định",
    parent_code: "167",
  },
  {
    value: "17752",
    label: "Xã Thanh Đồng",
    parent_code: "428",
  },
  {
    value: "25540",
    label: "Xã Thạnh Đông",
    parent_code: "706",
  },
  {
    value: "30865",
    label: "Xã Thạnh Đông",
    parent_code: "904",
  },
  {
    value: "30874",
    label: "Xã Thạnh Đông A",
    parent_code: "904",
  },
  {
    value: "30862",
    label: "Xã Thạnh Đông B",
    parent_code: "904",
  },
  {
    value: "00931",
    label: "Xã Thanh Đức",
    parent_code: "030",
  },
  {
    value: "17824",
    label: "Xã Thanh Đức",
    parent_code: "428",
  },
  {
    value: "29590",
    label: "Xã Thanh Đức",
    parent_code: "857",
  },
  {
    value: "25657",
    label: "Xã Thạnh Đức",
    parent_code: "710",
  },
  {
    value: "28027",
    label: "Xã Thạnh Đức",
    parent_code: "803",
  },
  {
    value: "11287",
    label: "Xã Thanh Giang",
    parent_code: "300",
  },
  {
    value: "17809",
    label: "Xã Thanh Giang",
    parent_code: "428",
  },
  {
    value: "10813",
    label: "Thị trấn Thanh Hà",
    parent_code: "294",
  },
  {
    value: "08218",
    label: "Xã Thanh Hà",
    parent_code: "232",
  },
  {
    value: "13453",
    label: "Xã Thanh Hà",
    parent_code: "351",
  },
  {
    value: "17806",
    label: "Xã Thanh Hà",
    parent_code: "428",
  },
  {
    value: "20407",
    label: "Phường Thanh Hà",
    parent_code: "503",
  },
  {
    value: "10846",
    label: "Xã Thanh Hải",
    parent_code: "294",
  },
  {
    value: "07549",
    label: "Xã Thanh Hải",
    parent_code: "219",
  },
  {
    value: "13498",
    label: "Xã Thanh Hải",
    parent_code: "351",
  },
  {
    value: "22868",
    label: "Xã Thanh Hải",
    parent_code: "586",
  },
  {
    value: "22936",
    label: "Phường Thanh Hải",
    parent_code: "593",
  },
  {
    value: "22774",
    label: "Xã Thành Hải",
    parent_code: "582",
  },
  {
    value: "29221",
    label: "Xã Thạnh Hải",
    parent_code: "837",
  },
  {
    value: "16213",
    label: "Xã Thanh Hòa",
    parent_code: "402",
  },
  {
    value: "17725",
    label: "Xã Thanh Hòa",
    parent_code: "428",
  },
  {
    value: "25315",
    label: "Xã Thanh Hòa",
    parent_code: "693",
  },
  {
    value: "28480",
    label: "Xã Thanh Hòa",
    parent_code: "817",
  },
  {
    value: "18958",
    label: "Xã Thanh Hóa",
    parent_code: "453",
  },
  {
    value: "06163",
    label: "Xã Thành Hòa",
    parent_code: "182",
  },
  {
    value: "28333",
    label: "Xã Thạnh Hoà",
    parent_code: "818",
  },
  {
    value: "31217",
    label: "Phường Thạnh Hoà",
    parent_code: "923",
  },
  {
    value: "28000",
    label: "Xã Thạnh Hòa",
    parent_code: "803",
  },
  {
    value: "30916",
    label: "Xã Thạnh Hòa",
    parent_code: "906",
  },
  {
    value: "31405",
    label: "Xã Thạnh Hòa",
    parent_code: "934",
  },
  {
    value: "27865",
    label: "Thị trấn Thạnh Hóa",
    parent_code: "800",
  },
  {
    value: "29458",
    label: "Xã Thạnh Hòa Sơn",
    parent_code: "848",
  },
  {
    value: "05167",
    label: "Xã Thanh Hối",
    parent_code: "155",
  },
  {
    value: "25937",
    label: "Xã Thạnh Hội",
    parent_code: "723",
  },
  {
    value: "10879",
    label: "Xã Thanh Hồng",
    parent_code: "294",
  },
  {
    value: "03331",
    label: "Xã Thanh Hưng",
    parent_code: "100",
  },
  {
    value: "15265",
    label: "Xã Thành Hưng",
    parent_code: "391",
  },
  {
    value: "27817",
    label: "Xã Thạnh Hưng",
    parent_code: "795",
  },
  {
    value: "27733",
    label: "Xã Thạnh Hưng",
    parent_code: "796",
  },
  {
    value: "30907",
    label: "Xã Thạnh Hưng",
    parent_code: "906",
  },
  {
    value: "13486",
    label: "Xã Thanh Hương",
    parent_code: "351",
  },
  {
    value: "17758",
    label: "Xã Thanh Hương",
    parent_code: "428",
  },
  {
    value: "17800",
    label: "Xã Thanh Khai",
    parent_code: "428",
  },
  {
    value: "10849",
    label: "Xã Thanh Khê",
    parent_code: "294",
  },
  {
    value: "17788",
    label: "Xã Thanh Khê",
    parent_code: "428",
  },
  {
    value: "20207",
    label: "Phường Thanh Khê Đông",
    parent_code: "491",
  },
  {
    value: "20206",
    label: "Phường Thanh Khê Tây",
    parent_code: "491",
  },
  {
    value: "09427",
    label: "Xã Thanh Khương",
    parent_code: "262",
  },
  {
    value: "16276",
    label: "Xã Thanh Kỳ",
    parent_code: "403",
  },
  {
    value: "14434",
    label: "Xã Thanh Lạc",
    parent_code: "372",
  },
  {
    value: "10834",
    label: "Xã Thanh Lang",
    parent_code: "294",
  },
  {
    value: "08968",
    label: "Thị trấn Thanh Lãng",
    parent_code: "249",
  },
  {
    value: "08992",
    label: "Xã Thanh Lâm",
    parent_code: "250",
  },
  {
    value: "06976",
    label: "Xã Thanh Lâm",
    parent_code: "202",
  },
  {
    value: "07465",
    label: "Xã Thanh Lâm",
    parent_code: "218",
  },
  {
    value: "16219",
    label: "Xã Thanh Lâm",
    parent_code: "402",
  },
  {
    value: "17815",
    label: "Xã Thanh Lâm",
    parent_code: "428",
  },
  {
    value: "14968",
    label: "Xã Thành Lâm",
    parent_code: "386",
  },
  {
    value: "07198",
    label: "Xã Thanh Lân",
    parent_code: "207",
  },
  {
    value: "17743",
    label: "Xã Thanh Liên",
    parent_code: "428",
  },
  {
    value: "00646",
    label: "Xã Thanh Liệt",
    parent_code: "020",
  },
  {
    value: "17761",
    label: "Xã Thanh Lĩnh",
    parent_code: "428",
  },
  {
    value: "06193",
    label: "Xã Thanh Lòa",
    parent_code: "183",
  },
  {
    value: "01387",
    label: "Xã Thanh Long",
    parent_code: "045",
  },
  {
    value: "12076",
    label: "Xã Thanh Long",
    parent_code: "327",
  },
  {
    value: "06148",
    label: "Xã Thanh Long",
    parent_code: "182",
  },
  {
    value: "17794",
    label: "Xã Thanh Long",
    parent_code: "428",
  },
  {
    value: "15259",
    label: "Xã Thành Long",
    parent_code: "391",
  },
  {
    value: "02413",
    label: "Xã Thành Long",
    parent_code: "074",
  },
  {
    value: "25621",
    label: "Xã Thành Long",
    parent_code: "708",
  },
  {
    value: "18433",
    label: "Xã Thanh Lộc",
    parent_code: "443",
  },
  {
    value: "16036",
    label: "Xã Thành Lộc",
    parent_code: "400",
  },
  {
    value: "26767",
    label: "Phường Thạnh Lộc",
    parent_code: "761",
  },
  {
    value: "28438",
    label: "Xã Thạnh Lộc",
    parent_code: "820",
  },
  {
    value: "30901",
    label: "Xã Thạnh Lộc",
    parent_code: "905",
  },
  {
    value: "30913",
    label: "Xã Thạnh Lộc",
    parent_code: "906",
  },
  {
    value: "31252",
    label: "Xã Thạnh Lộc",
    parent_code: "924",
  },
  {
    value: "13777",
    label: "Xã Thành Lợi",
    parent_code: "359",
  },
  {
    value: "29791",
    label: "Xã Thành Lợi",
    parent_code: "863",
  },
  {
    value: "27994",
    label: "Xã Thạnh Lợi",
    parent_code: "803",
  },
  {
    value: "30040",
    label: "Xã Thạnh Lợi",
    parent_code: "872",
  },
  {
    value: "31244",
    label: "Xã Thạnh Lợi",
    parent_code: "924",
  },
  {
    value: "07678",
    label: "Xã Thanh Luận",
    parent_code: "220",
  },
  {
    value: "03328",
    label: "Xã Thanh Luông",
    parent_code: "100",
  },
  {
    value: "00268",
    label: "Phường Thanh Lương",
    parent_code: "007",
  },
  {
    value: "11878",
    label: "Xã Thanh Lương",
    parent_code: "316",
  },
  {
    value: "04675",
    label: "Xã Thanh Lương",
    parent_code: "133",
  },
  {
    value: "17785",
    label: "Xã Thanh Lương",
    parent_code: "428",
  },
  {
    value: "25333",
    label: "Xã Thanh Lương",
    parent_code: "690",
  },
  {
    value: "10147",
    label: "Xã Thanh Mai",
    parent_code: "278",
  },
  {
    value: "02101",
    label: "Xã Thanh Mai",
    parent_code: "065",
  },
  {
    value: "17818",
    label: "Xã Thanh Mai",
    parent_code: "428",
  },
  {
    value: "11239",
    label: "Thị trấn Thanh Miện",
    parent_code: "300",
  },
  {
    value: "07909",
    label: "Phường Thanh Miếu",
    parent_code: "227",
  },
  {
    value: "07960",
    label: "Xã Thanh Minh",
    parent_code: "228",
  },
  {
    value: "03145",
    label: "Xã Thanh Minh",
    parent_code: "094",
  },
  {
    value: "15232",
    label: "Xã Thành Minh",
    parent_code: "391",
  },
  {
    value: "09604",
    label: "Xã Thanh Mỹ",
    parent_code: "269",
  },
  {
    value: "17734",
    label: "Xã Thanh Mỹ",
    parent_code: "428",
  },
  {
    value: "29383",
    label: "Xã Thanh Mỹ",
    parent_code: "847",
  },
  {
    value: "30073",
    label: "Xã Thanh Mỹ",
    parent_code: "872",
  },
  {
    value: "15223",
    label: "Xã Thành Mỹ",
    parent_code: "391",
  },
  {
    value: "24931",
    label: "Thị trấn Thạnh Mỹ",
    parent_code: "677",
  },
  {
    value: "20695",
    label: "Thị trấn Thạnh Mỹ",
    parent_code: "510",
  },
  {
    value: "28330",
    label: "Xã Thạnh Mỹ",
    parent_code: "818",
  },
  {
    value: "31234",
    label: "Xã Thạnh Mỹ",
    parent_code: "924",
  },
  {
    value: "27112",
    label: "Phường Thạnh Mỹ Lợi",
    parent_code: "769",
  },
  {
    value: "30481",
    label: "Xã Thạnh Mỹ Tây",
    parent_code: "889",
  },
  {
    value: "28909",
    label: "Xã Thạnh Ngãi",
    parent_code: "838",
  },
  {
    value: "13489",
    label: "Xã Thanh Nghị",
    parent_code: "351",
  },
  {
    value: "17755",
    label: "Xã Thanh Ngọc",
    parent_code: "428",
  },
  {
    value: "13495",
    label: "Xã Thanh Nguyên",
    parent_code: "351",
  },
  {
    value: "00271",
    label: "Phường Thanh Nhàn",
    parent_code: "007",
  },
  {
    value: "01558",
    label: "Thị trấn Thanh Nhật",
    parent_code: "048",
  },
  {
    value: "24130",
    label: "Phường Thành Nhất",
    parent_code: "643",
  },
  {
    value: "17719",
    label: "Xã Thanh Nho",
    parent_code: "428",
  },
  {
    value: "28675",
    label: "Xã Thạnh Nhựt",
    parent_code: "823",
  },
  {
    value: "05962",
    label: "Xã Thanh Ninh",
    parent_code: "173",
  },
  {
    value: "03322",
    label: "Xã Thanh Nưa",
    parent_code: "100",
  },
  {
    value: "13471",
    label: "Xã Thanh Phong",
    parent_code: "351",
  },
  {
    value: "16216",
    label: "Xã Thanh Phong",
    parent_code: "402",
  },
  {
    value: "17731",
    label: "Xã Thanh Phong",
    parent_code: "428",
  },
  {
    value: "29230",
    label: "Xã Thạnh Phong",
    parent_code: "837",
  },
  {
    value: "25336",
    label: "Xã Thanh Phú",
    parent_code: "690",
  },
  {
    value: "28021",
    label: "Xã Thanh Phú",
    parent_code: "803",
  },
  {
    value: "26188",
    label: "Xã Thạnh Phú",
    parent_code: "735",
  },
  {
    value: "27877",
    label: "Xã Thạnh Phú",
    parent_code: "800",
  },
  {
    value: "28570",
    label: "Xã Thạnh Phú",
    parent_code: "821",
  },
  {
    value: "29182",
    label: "Thị trấn Thạnh Phú",
    parent_code: "837",
  },
  {
    value: "29338",
    label: "Xã Thạnh Phú",
    parent_code: "845",
  },
  {
    value: "31249",
    label: "Xã Thạnh Phú",
    parent_code: "925",
  },
  {
    value: "31708",
    label: "Xã Thạnh Phú",
    parent_code: "947",
  },
  {
    value: "32130",
    label: "Xã Thạnh Phú",
    parent_code: "969",
  },
  {
    value: "29041",
    label: "Xã Thạnh Phú Đông",
    parent_code: "834",
  },
  {
    value: "28234",
    label: "Xã Thanh Phú Long",
    parent_code: "808",
  },
  {
    value: "25678",
    label: "Xã Thanh Phước",
    parent_code: "710",
  },
  {
    value: "29771",
    label: "Phường Thành Phước",
    parent_code: "861",
  },
  {
    value: "25936",
    label: "Phường Thạnh Phước",
    parent_code: "723",
  },
  {
    value: "27874",
    label: "Xã Thạnh Phước",
    parent_code: "800",
  },
  {
    value: "29104",
    label: "Xã Thạnh Phước",
    parent_code: "835",
  },
  {
    value: "30910",
    label: "Xã Thạnh Phước",
    parent_code: "906",
  },
  {
    value: "10621",
    label: "Xã Thanh Quang",
    parent_code: "291",
  },
  {
    value: "10876",
    label: "Xã Thanh Quang",
    parent_code: "294",
  },
  {
    value: "16207",
    label: "Xã Thanh Quân",
    parent_code: "402",
  },
  {
    value: "29614",
    label: "Xã Thạnh Quới",
    parent_code: "857",
  },
  {
    value: "31714",
    label: "Xã Thạnh Quới",
    parent_code: "947",
  },
  {
    value: "31246",
    label: "Xã Thạnh Qưới",
    parent_code: "924",
  },
  {
    value: "08542",
    label: "Thị trấn Thanh Sơn",
    parent_code: "238",
  },
  {
    value: "10867",
    label: "Xã Thanh Sơn",
    parent_code: "294",
  },
  {
    value: "11722",
    label: "Xã Thanh Sơn",
    parent_code: "314",
  },
  {
    value: "06421",
    label: "Xã Thanh Sơn",
    parent_code: "186",
  },
  {
    value: "06811",
    label: "Phường Thanh Sơn",
    parent_code: "196",
  },
  {
    value: "06973",
    label: "Xã Thanh Sơn",
    parent_code: "202",
  },
  {
    value: "13438",
    label: "Xã Thanh Sơn",
    parent_code: "350",
  },
  {
    value: "05041",
    label: "Xã Thanh Sơn",
    parent_code: "152",
  },
  {
    value: "16222",
    label: "Xã Thanh Sơn",
    parent_code: "402",
  },
  {
    value: "16570",
    label: "Xã Thanh Sơn",
    parent_code: "407",
  },
  {
    value: "17723",
    label: "Xã Thanh Sơn",
    parent_code: "428",
  },
  {
    value: "22750",
    label: "Phường Thanh Sơn",
    parent_code: "582",
  },
  {
    value: "26143",
    label: "Xã Thanh Sơn",
    parent_code: "734",
  },
  {
    value: "26209",
    label: "Xã Thanh Sơn",
    parent_code: "736",
  },
  {
    value: "29485",
    label: "Xã Thanh Sơn",
    parent_code: "849",
  },
  {
    value: "05254",
    label: "Xã Thành Sơn",
    parent_code: "156",
  },
  {
    value: "14872",
    label: "Xã Thành Sơn",
    parent_code: "385",
  },
  {
    value: "14938",
    label: "Xã Thành Sơn",
    parent_code: "386",
  },
  {
    value: "17335",
    label: "Xã Thành Sơn",
    parent_code: "424",
  },
  {
    value: "22717",
    label: "Xã Thành Sơn",
    parent_code: "575",
  },
  {
    value: "13492",
    label: "Xã Thanh Tâm",
    parent_code: "351",
  },
  {
    value: "15247",
    label: "Xã Thành Tâm",
    parent_code: "391",
  },
  {
    value: "25433",
    label: "Xã Thành Tâm",
    parent_code: "697",
  },
  {
    value: "13114",
    label: "Xã Thanh Tân",
    parent_code: "343",
  },
  {
    value: "13477",
    label: "Xã Thanh Tân",
    parent_code: "351",
  },
  {
    value: "16273",
    label: "Xã Thanh Tân",
    parent_code: "403",
  },
  {
    value: "28906",
    label: "Xã Thanh Tân",
    parent_code: "838",
  },
  {
    value: "15238",
    label: "Xã Thành Tân",
    parent_code: "391",
  },
  {
    value: "25471",
    label: "Xã Thạnh Tân",
    parent_code: "703",
  },
  {
    value: "28327",
    label: "Xã Thạnh Tân",
    parent_code: "818",
  },
  {
    value: "31762",
    label: "Xã Thạnh Tân",
    parent_code: "949",
  },
  {
    value: "25501",
    label: "Xã Thạnh Tây",
    parent_code: "705",
  },
  {
    value: "18961",
    label: "Xã Thanh Thạch",
    parent_code: "453",
  },
  {
    value: "31243",
    label: "Xã Thạnh Thắng",
    parent_code: "924",
  },
  {
    value: "02113",
    label: "Xã Thanh Thịnh",
    parent_code: "065",
  },
  {
    value: "17770",
    label: "Xã Thanh Thịnh",
    parent_code: "428",
  },
  {
    value: "15253",
    label: "Xã Thành Thọ",
    parent_code: "391",
  },
  {
    value: "28969",
    label: "Xã Thành Thới A",
    parent_code: "833",
  },
  {
    value: "31699",
    label: "Xã Thạnh Thới An",
    parent_code: "951",
  },
  {
    value: "28960",
    label: "Xã Thành Thới B",
    parent_code: "833",
  },
  {
    value: "31702",
    label: "Xã Thạnh Thới Thuận",
    parent_code: "951",
  },
  {
    value: "10144",
    label: "Xã Thanh Thùy",
    parent_code: "278",
  },
  {
    value: "00928",
    label: "Xã Thanh Thủy",
    parent_code: "030",
  },
  {
    value: "08674",
    label: "Thị trấn Thanh Thủy",
    parent_code: "239",
  },
  {
    value: "10861",
    label: "Xã Thanh Thủy",
    parent_code: "294",
  },
  {
    value: "13468",
    label: "Xã Thanh Thủy",
    parent_code: "351",
  },
  {
    value: "16567",
    label: "Xã Thanh Thủy",
    parent_code: "407",
  },
  {
    value: "17797",
    label: "Xã Thanh Thủy",
    parent_code: "428",
  },
  {
    value: "19261",
    label: "Xã Thanh Thủy",
    parent_code: "457",
  },
  {
    value: "17737",
    label: "Xã Thanh Tiên",
    parent_code: "428",
  },
  {
    value: "15256",
    label: "Xã Thành Tiến",
    parent_code: "391",
  },
  {
    value: "31241",
    label: "Xã Thạnh Tiến",
    parent_code: "924",
  },
  {
    value: "11414",
    label: "Phường Thành Tô",
    parent_code: "306",
  },
  {
    value: "19132",
    label: "Xã Thanh Trạch",
    parent_code: "455",
  },
  {
    value: "00301",
    label: "Phường Thanh Trì",
    parent_code: "008",
  },
  {
    value: "27790",
    label: "Xã Thạnh Trị",
    parent_code: "795",
  },
  {
    value: "28672",
    label: "Xã Thạnh Trị",
    parent_code: "823",
  },
  {
    value: "29095",
    label: "Xã Thạnh Trị",
    parent_code: "835",
  },
  {
    value: "30877",
    label: "Xã Thạnh Trị",
    parent_code: "904",
  },
  {
    value: "31774",
    label: "Xã Thạnh Trị",
    parent_code: "949",
  },
  {
    value: "28834",
    label: "Xã Thành Triệu",
    parent_code: "831",
  },
  {
    value: "08731",
    label: "Xã Thanh Trù",
    parent_code: "243",
  },
  {
    value: "29779",
    label: "Xã Thành Trung",
    parent_code: "863",
  },
  {
    value: "15241",
    label: "Xã Thành Trực",
    parent_code: "391",
  },
  {
    value: "03142",
    label: "Phường Thanh Trường",
    parent_code: "094",
  },
  {
    value: "11242",
    label: "Xã Thanh Tùng",
    parent_code: "300",
  },
  {
    value: "17812",
    label: "Xã Thanh Tùng",
    parent_code: "428",
  },
  {
    value: "32185",
    label: "Xã Thanh Tùng",
    parent_code: "970",
  },
  {
    value: "13459",
    label: "Phường Thanh Tuyền",
    parent_code: "347",
  },
  {
    value: "25810",
    label: "Xã Thanh Tuyền",
    parent_code: "720",
  },
  {
    value: "02284",
    label: "Xã Thanh Tương",
    parent_code: "072",
  },
  {
    value: "08446",
    label: "Xã Thanh Uyên",
    parent_code: "236",
  },
  {
    value: "10150",
    label: "Xã Thanh Văn",
    parent_code: "278",
  },
  {
    value: "00889",
    label: "Xã Thanh Vân",
    parent_code: "029",
  },
  {
    value: "08890",
    label: "Xã Thanh Vân",
    parent_code: "247",
  },
  {
    value: "07816",
    label: "Xã Thanh Vân",
    parent_code: "223",
  },
  {
    value: "02092",
    label: "Xã Thanh Vận",
    parent_code: "065",
  },
  {
    value: "07966",
    label: "Phường Thanh Vinh",
    parent_code: "228",
  },
  {
    value: "15229",
    label: "Xã Thành Vinh",
    parent_code: "391",
  },
  {
    value: "28246",
    label: "Xã Thanh Vĩnh Đông",
    parent_code: "808",
  },
  {
    value: "10852",
    label: "Xã Thanh Xá",
    parent_code: "294",
  },
  {
    value: "00433",
    label: "Xã Thanh Xuân",
    parent_code: "016",
  },
  {
    value: "10855",
    label: "Xã Thanh Xuân",
    parent_code: "294",
  },
  {
    value: "16210",
    label: "Xã Thanh Xuân",
    parent_code: "402",
  },
  {
    value: "17821",
    label: "Xã Thanh Xuân",
    parent_code: "428",
  },
  {
    value: "26764",
    label: "Phường Thạnh Xuân",
    parent_code: "761",
  },
  {
    value: "31360",
    label: "Xã Thạnh Xuân",
    parent_code: "932",
  },
  {
    value: "00367",
    label: "Phường Thanh Xuân Bắc",
    parent_code: "009",
  },
  {
    value: "00370",
    label: "Phường Thanh Xuân Nam",
    parent_code: "009",
  },
  {
    value: "00355",
    label: "Phường Thanh Xuân Trung",
    parent_code: "009",
  },
  {
    value: "03334",
    label: "Xã Thanh Xương",
    parent_code: "100",
  },
  {
    value: "03346",
    label: "Xã Thanh Yên",
    parent_code: "100",
  },
  {
    value: "17803",
    label: "Xã Thanh Yên",
    parent_code: "428",
  },
  {
    value: "15226",
    label: "Xã Thành Yên",
    parent_code: "391",
  },
  {
    value: "31012",
    label: "Xã Thạnh Yên",
    parent_code: "913",
  },
  {
    value: "31015",
    label: "Xã Thạnh Yên A",
    parent_code: "913",
  },
  {
    value: "02803",
    label: "Xã Thào Chư Phìn",
    parent_code: "084",
  },
  {
    value: "27088",
    label: "Phường Thảo Điền",
    parent_code: "769",
  },
  {
    value: "07840",
    label: "Thị trấn Thắng",
    parent_code: "223",
  },
  {
    value: "16351",
    label: "Xã Thăng Bình",
    parent_code: "404",
  },
  {
    value: "23255",
    label: "Xã Thắng Hải",
    parent_code: "601",
  },
  {
    value: "23896",
    label: "Xã Thăng Hưng",
    parent_code: "632",
  },
  {
    value: "10717",
    label: "Xã Thăng Long",
    parent_code: "292",
  },
  {
    value: "12754",
    label: "Xã Thăng Long",
    parent_code: "340",
  },
  {
    value: "16342",
    label: "Xã Thăng Long",
    parent_code: "404",
  },
  {
    value: "10246",
    label: "Xã Thắng Lợi",
    parent_code: "279",
  },
  {
    value: "01540",
    label: "Xã Thắng Lợi",
    parent_code: "048",
  },
  {
    value: "12046",
    label: "Xã Thắng Lợi",
    parent_code: "326",
  },
  {
    value: "05518",
    label: "Phường Thắng Lợi",
    parent_code: "165",
  },
  {
    value: "07021",
    label: "Xã Thắng Lợi",
    parent_code: "203",
  },
  {
    value: "23293",
    label: "Phường Thắng Lợi",
    parent_code: "608",
  },
  {
    value: "23582",
    label: "Phường Thắng Lợi",
    parent_code: "622",
  },
  {
    value: "24133",
    label: "Phường Thắng Lợi",
    parent_code: "643",
  },
  {
    value: "00823",
    label: "Xã Thắng Mố",
    parent_code: "028",
  },
  {
    value: "26533",
    label: "Phường Thắng Nhất",
    parent_code: "747",
  },
  {
    value: "26521",
    label: "Phường Thắng Nhì",
    parent_code: "747",
  },
  {
    value: "20785",
    label: "Xã Thăng Phước",
    parent_code: "512",
  },
  {
    value: "08623",
    label: "Xã Thắng Sơn",
    parent_code: "238",
  },
  {
    value: "26508",
    label: "Phường Thắng Tam",
    parent_code: "747",
  },
  {
    value: "16360",
    label: "Xã Thăng Thọ",
    parent_code: "404",
  },
  {
    value: "11833",
    label: "Xã Thắng Thuỷ",
    parent_code: "316",
  },
  {
    value: "03115",
    label: "Xã Thẩm Dương",
    parent_code: "089",
  },
  {
    value: "28534",
    label: "Xã Thân Cửu Nghĩa",
    parent_code: "821",
  },
  {
    value: "03604",
    label: "Xã Thân Thuộc",
    parent_code: "111",
  },
  {
    value: "05725",
    label: "Xã Thần Xa",
    parent_code: "170",
  },
  {
    value: "10681",
    label: "Phường Thất Hùng",
    parent_code: "292",
  },
  {
    value: "05995",
    label: "Thị trấn Thất Khê",
    parent_code: "180",
  },
  {
    value: "01030",
    label: "Xã Thèn Chu Phìn",
    parent_code: "032",
  },
  {
    value: "01114",
    label: "Xã Thèn Phàng",
    parent_code: "033",
  },
  {
    value: "03394",
    label: "Xã Thèn Sin",
    parent_code: "106",
  },
  {
    value: "01750",
    label: "Xã Thể Dục",
    parent_code: "052",
  },
  {
    value: "09169",
    label: "Phường Thị Cầu",
    parent_code: "256",
  },
  {
    value: "01573",
    label: "Xã Thị Hoa",
    parent_code: "048",
  },
  {
    value: "21568",
    label: "Phường Thị Nại",
    parent_code: "540",
  },
  {
    value: "13435",
    label: "Xã Thi Sơn",
    parent_code: "350",
  },
  {
    value: "24311",
    label: "Phường Thiện An",
    parent_code: "644",
  },
  {
    value: "18676",
    label: "Thị trấn Thiên Cầm",
    parent_code: "446",
  },
  {
    value: "06085",
    label: "Xã Thiện Hòa",
    parent_code: "181",
  },
  {
    value: "25312",
    label: "Xã Thiện Hưng",
    parent_code: "693",
  },
  {
    value: "11557",
    label: "Xã Thiên Hương",
    parent_code: "311",
  },
  {
    value: "08947",
    label: "Xã Thiện Kế",
    parent_code: "249",
  },
  {
    value: "02605",
    label: "Xã Thiện Kế",
    parent_code: "076",
  },
  {
    value: "06097",
    label: "Xã Thiện Long",
    parent_code: "181",
  },
  {
    value: "18415",
    label: "Xã Thiên Lộc",
    parent_code: "443",
  },
  {
    value: "29854",
    label: "Xã Thiện Mỹ",
    parent_code: "862",
  },
  {
    value: "31585",
    label: "Xã Thiện Mỹ",
    parent_code: "942",
  },
  {
    value: "22957",
    label: "Xã Thiện Nghiệp",
    parent_code: "593",
  },
  {
    value: "12370",
    label: "Xã Thiện Phiến",
    parent_code: "332",
  },
  {
    value: "14908",
    label: "Xã Thiên Phủ",
    parent_code: "385",
  },
  {
    value: "06406",
    label: "Xã Thiện Tân",
    parent_code: "186",
  },
  {
    value: "26191",
    label: "Xã Thiện Tân",
    parent_code: "735",
  },
  {
    value: "06091",
    label: "Xã Thiện Thuật",
    parent_code: "181",
  },
  {
    value: "14527",
    label: "Thị trấn Thiên Tôn",
    parent_code: "374",
  },
  {
    value: "28402",
    label: "Xã Thiện Trí",
    parent_code: "819",
  },
  {
    value: "28384",
    label: "Xã Thiện Trung",
    parent_code: "819",
  },
  {
    value: "14986",
    label: "Xã Thiết Kế",
    parent_code: "386",
  },
  {
    value: "14980",
    label: "Xã Thiết Ống",
    parent_code: "386",
  },
  {
    value: "15820",
    label: "Xã Thiệu Chính",
    parent_code: "398",
  },
  {
    value: "15787",
    label: "Xã Thiệu Công",
    parent_code: "398",
  },
  {
    value: "15799",
    label: "Xã Thiệu Duy",
    parent_code: "398",
  },
  {
    value: "15859",
    label: "Phường Thiệu Dương",
    parent_code: "380",
  },
  {
    value: "15796",
    label: "Xã Thiệu Giang",
    parent_code: "398",
  },
  {
    value: "15853",
    label: "Xã Thiệu Giao",
    parent_code: "398",
  },
  {
    value: "15823",
    label: "Xã Thiệu Hòa",
    parent_code: "398",
  },
  {
    value: "15772",
    label: "Thị trấn Thiệu Hóa",
    parent_code: "398",
  },
  {
    value: "15805",
    label: "Xã Thiệu Hợp",
    parent_code: "398",
  },
  {
    value: "15856",
    label: "Phường Thiệu Khánh",
    parent_code: "380",
  },
  {
    value: "15793",
    label: "Xã Thiệu Long",
    parent_code: "398",
  },
  {
    value: "15835",
    label: "Xã Thiệu Lý",
    parent_code: "398",
  },
  {
    value: "15775",
    label: "Xã Thiệu Ngọc",
    parent_code: "398",
  },
  {
    value: "15802",
    label: "Xã Thiệu Nguyên",
    parent_code: "398",
  },
  {
    value: "15790",
    label: "Xã Thiệu Phú",
    parent_code: "398",
  },
  {
    value: "15781",
    label: "Xã Thiệu Phúc",
    parent_code: "398",
  },
  {
    value: "15811",
    label: "Xã Thiệu Quang",
    parent_code: "398",
  },
  {
    value: "15814",
    label: "Xã Thiệu Thành",
    parent_code: "398",
  },
  {
    value: "15808",
    label: "Xã Thiệu Thịnh",
    parent_code: "398",
  },
  {
    value: "15784",
    label: "Xã Thiệu Tiến",
    parent_code: "398",
  },
  {
    value: "15817",
    label: "Xã Thiệu Toán",
    parent_code: "398",
  },
  {
    value: "15841",
    label: "Xã Thiệu Trung",
    parent_code: "398",
  },
  {
    value: "15850",
    label: "Xã Thiệu Vân",
    parent_code: "380",
  },
  {
    value: "15838",
    label: "Xã Thiệu Vận",
    parent_code: "398",
  },
  {
    value: "15832",
    label: "Xã Thiệu Viên",
    parent_code: "398",
  },
  {
    value: "15778",
    label: "Xã Thiệu Vũ",
    parent_code: "398",
  },
  {
    value: "05455",
    label: "Phường Thịnh Đán",
    parent_code: "164",
  },
  {
    value: "05497",
    label: "Xã Thịnh Đức",
    parent_code: "164",
  },
  {
    value: "04777",
    label: "Xã Thịnh Hưng",
    parent_code: "141",
  },
  {
    value: "04795",
    label: "Phường Thịnh Lang",
    parent_code: "148",
  },
  {
    value: "00331",
    label: "Phường Thịnh Liệt",
    parent_code: "008",
  },
  {
    value: "14221",
    label: "Thị trấn Thịnh Long",
    parent_code: "366",
  },
  {
    value: "18421",
    label: "Xã Thịnh Lộc",
    parent_code: "448",
  },
  {
    value: "04897",
    label: "Xã Thịnh Minh",
    parent_code: "148",
  },
  {
    value: "00223",
    label: "Phường Thịnh Quang",
    parent_code: "006",
  },
  {
    value: "17683",
    label: "Xã Thịnh Sơn",
    parent_code: "427",
  },
  {
    value: "17560",
    label: "Xã Thịnh Thành",
    parent_code: "426",
  },
  {
    value: "01780",
    label: "Xã Thịnh Vượng",
    parent_code: "052",
  },
  {
    value: "09790",
    label: "Xã Thọ An",
    parent_code: "273",
  },
  {
    value: "15670",
    label: "Xã Thọ Bình",
    parent_code: "397",
  },
  {
    value: "15754",
    label: "Xã Thọ Cường",
    parent_code: "397",
  },
  {
    value: "15742",
    label: "Xã Thọ Dân",
    parent_code: "397",
  },
  {
    value: "15538",
    label: "Xã Thọ Diên",
    parent_code: "395",
  },
  {
    value: "18325",
    label: "Xã Thọ Điền",
    parent_code: "441",
  },
  {
    value: "15520",
    label: "Xã Thọ Hải",
    parent_code: "395",
  },
  {
    value: "17068",
    label: "Xã Thọ Hợp",
    parent_code: "420",
  },
  {
    value: "15541",
    label: "Xã Thọ Lâm",
    parent_code: "395",
  },
  {
    value: "15568",
    label: "Xã Thọ Lập",
    parent_code: "395",
  },
  {
    value: "09742",
    label: "Xã Thọ Lộc",
    parent_code: "272",
  },
  {
    value: "15511",
    label: "Xã Thọ Lộc",
    parent_code: "395",
  },
  {
    value: "14125",
    label: "Xã Thọ Nghiệp",
    parent_code: "364",
  },
  {
    value: "15751",
    label: "Xã Thọ Ngọc",
    parent_code: "397",
  },
  {
    value: "15757",
    label: "Xã Thọ Phú",
    parent_code: "397",
  },
  {
    value: "20263",
    label: "Phường Thọ Quang",
    parent_code: "493",
  },
  {
    value: "07906",
    label: "Phường Thọ Sơn",
    parent_code: "227",
  },
  {
    value: "15667",
    label: "Xã Thọ Sơn",
    parent_code: "397",
  },
  {
    value: "17332",
    label: "Xã Thọ Sơn",
    parent_code: "424",
  },
  {
    value: "25402",
    label: "Xã Thọ Sơn",
    parent_code: "696",
  },
  {
    value: "15748",
    label: "Xã Thọ Tân",
    parent_code: "397",
  },
  {
    value: "15652",
    label: "Xã Thọ Thanh",
    parent_code: "396",
  },
  {
    value: "17530",
    label: "Xã Thọ Thành",
    parent_code: "426",
  },
  {
    value: "15763",
    label: "Xã Thọ Thế",
    parent_code: "397",
  },
  {
    value: "15673",
    label: "Xã Thọ Tiến",
    parent_code: "397",
  },
  {
    value: "08479",
    label: "Xã Thọ Văn",
    parent_code: "236",
  },
  {
    value: "12295",
    label: "Xã Thọ Vinh",
    parent_code: "331",
  },
  {
    value: "15760",
    label: "Xã Thọ Vực",
    parent_code: "397",
  },
  {
    value: "09793",
    label: "Xã Thọ Xuân",
    parent_code: "273",
  },
  {
    value: "15499",
    label: "Thị trấn Thọ Xuân",
    parent_code: "395",
  },
  {
    value: "07201",
    label: "Phường Thọ Xương",
    parent_code: "213",
  },
  {
    value: "15544",
    label: "Xã Thọ Xương",
    parent_code: "395",
  },
  {
    value: "30721",
    label: "Xã Thoại Giang",
    parent_code: "894",
  },
  {
    value: "02296",
    label: "Xã Thổ Bình",
    parent_code: "071",
  },
  {
    value: "31105",
    label: "Xã Thổ Châu",
    parent_code: "911",
  },
  {
    value: "00205",
    label: "Phường Thổ Quan",
    parent_code: "006",
  },
  {
    value: "30841",
    label: "Xã Thổ Sơn",
    parent_code: "903",
  },
  {
    value: "09112",
    label: "Thị Trấn Thổ Tang",
    parent_code: "252",
  },
  {
    value: "03769",
    label: "Xã Thôm Mòn",
    parent_code: "119",
  },
  {
    value: "29932",
    label: "Xã Thông Bình",
    parent_code: "869",
  },
  {
    value: "29335",
    label: "Xã Thông Hòa",
    parent_code: "845",
  },
  {
    value: "11059",
    label: "Xã Thống Kênh",
    parent_code: "297",
  },
  {
    value: "01090",
    label: "Xã Thông Nguyên",
    parent_code: "032",
  },
  {
    value: "10252",
    label: "Xã Thống Nhất",
    parent_code: "279",
  },
  {
    value: "01564",
    label: "Xã Thống Nhất",
    parent_code: "048",
  },
  {
    value: "11008",
    label: "Xã Thống Nhất",
    parent_code: "297",
  },
  {
    value: "05425",
    label: "Xã Thống Nhất",
    parent_code: "159",
  },
  {
    value: "06577",
    label: "Xã Thống Nhất",
    parent_code: "188",
  },
  {
    value: "07060",
    label: "Xã Thống Nhất",
    parent_code: "193",
  },
  {
    value: "12643",
    label: "Xã Thống Nhất",
    parent_code: "339",
  },
  {
    value: "13681",
    label: "Phường Thống Nhất",
    parent_code: "356",
  },
  {
    value: "15397",
    label: "Thị trấn Thống Nhất",
    parent_code: "394",
  },
  {
    value: "02659",
    label: "Xã Thống Nhất",
    parent_code: "080",
  },
  {
    value: "04828",
    label: "Phường Thống Nhất",
    parent_code: "148",
  },
  {
    value: "25420",
    label: "Xã Thống Nhất",
    parent_code: "696",
  },
  {
    value: "26029",
    label: "Phường Thống Nhất",
    parent_code: "731",
  },
  {
    value: "23299",
    label: "Phường Thống Nhất",
    parent_code: "608",
  },
  {
    value: "23578",
    label: "Phường Thống Nhất",
    parent_code: "622",
  },
  {
    value: "24127",
    label: "Phường Thống Nhất",
    parent_code: "643",
  },
  {
    value: "24331",
    label: "Phường Thống Nhất",
    parent_code: "644",
  },
  {
    value: "01363",
    label: "Thị trấn Thông Nông",
    parent_code: "045",
  },
  {
    value: "16741",
    label: "Xã Thông Thụ",
    parent_code: "415",
  },
  {
    value: "31207",
    label: "Phường Thốt Nốt",
    parent_code: "923",
  },
  {
    value: "26773",
    label: "Phường Thới An",
    parent_code: "761",
  },
  {
    value: "31159",
    label: "Phường Thới An",
    parent_code: "917",
  },
  {
    value: "31174",
    label: "Phường Thới An Đông",
    parent_code: "918",
  },
  {
    value: "31549",
    label: "Xã Thới An Hội",
    parent_code: "943",
  },
  {
    value: "31123",
    label: "Phường Thới Bình",
    parent_code: "916",
  },
  {
    value: "32065",
    label: "Thị trấn Thới Bình",
    parent_code: "967",
  },
  {
    value: "32077",
    label: "Xã Thới Bình",
    parent_code: "967",
  },
  {
    value: "31276",
    label: "Xã Thới Đông",
    parent_code: "925",
  },
  {
    value: "25846",
    label: "Phường Thới Hòa",
    parent_code: "721",
  },
  {
    value: "29833",
    label: "Xã Thới Hòa",
    parent_code: "862",
  },
  {
    value: "31154",
    label: "Phường Thới Hòa",
    parent_code: "917",
  },
  {
    value: "31264",
    label: "Xã Thới Hưng",
    parent_code: "925",
  },
  {
    value: "29083",
    label: "Xã Thới Lai",
    parent_code: "835",
  },
  {
    value: "31258",
    label: "Thị trấn Thới Lai",
    parent_code: "927",
  },
  {
    value: "31156",
    label: "Phường Thới Long",
    parent_code: "917",
  },
  {
    value: "30961",
    label: "Xã Thới Quản",
    parent_code: "907",
  },
  {
    value: "28591",
    label: "Xã Thới Sơn",
    parent_code: "815",
  },
  {
    value: "30517",
    label: "Xã Thới Sơn",
    parent_code: "890",
  },
  {
    value: "27574",
    label: "Xã Thới Tam Thôn",
    parent_code: "784",
  },
  {
    value: "31285",
    label: "Xã Thới Tân",
    parent_code: "927",
  },
  {
    value: "29203",
    label: "Xã Thới Thạnh",
    parent_code: "837",
  },
  {
    value: "31267",
    label: "Xã Thới Thạnh",
    parent_code: "927",
  },
  {
    value: "29107",
    label: "Xã Thới Thuận",
    parent_code: "835",
  },
  {
    value: "31210",
    label: "Phường Thới Thuận",
    parent_code: "923",
  },
  {
    value: "31277",
    label: "Xã Thới Xuân",
    parent_code: "925",
  },
  {
    value: "08545",
    label: "Xã Thu Cúc",
    parent_code: "240",
  },
  {
    value: "03436",
    label: "Xã Thu Lũm",
    parent_code: "107",
  },
  {
    value: "08551",
    label: "Xã Thu Ngạc",
    parent_code: "240",
  },
  {
    value: "05101",
    label: "Xã Thu Phong",
    parent_code: "154",
  },
  {
    value: "12367",
    label: "Xã Thủ Sỹ",
    parent_code: "332",
  },
  {
    value: "01126",
    label: "Xã Thu Tà",
    parent_code: "033",
  },
  {
    value: "27118",
    label: "Phường Thủ Thiêm",
    parent_code: "769",
  },
  {
    value: "16723",
    label: "Phường Thu Thuỷ",
    parent_code: "413",
  },
  {
    value: "28036",
    label: "Thị trấn Thủ Thừa",
    parent_code: "804",
  },
  {
    value: "19471",
    label: "Xã Thuận",
    parent_code: "465",
  },
  {
    value: "24682",
    label: "Xã Thuận An",
    parent_code: "663",
  },
  {
    value: "19900",
    label: "Phường Thuận An",
    parent_code: "474",
  },
  {
    value: "29806",
    label: "Xã Thuận An",
    parent_code: "861",
  },
  {
    value: "31212",
    label: "Phường Thuận An",
    parent_code: "923",
  },
  {
    value: "31471",
    label: "Phường Thuận An",
    parent_code: "937",
  },
  {
    value: "27871",
    label: "Xã Thuận Bình",
    parent_code: "800",
  },
  {
    value: "03721",
    label: "Thị trấn Thuận Châu",
    parent_code: "119",
  },
  {
    value: "29011",
    label: "Xã Thuận Điền",
    parent_code: "834",
  },
  {
    value: "18895",
    label: "Xã Thuận Đức",
    parent_code: "450",
  },
  {
    value: "25972",
    label: "Phường Thuận Giao",
    parent_code: "725",
  },
  {
    value: "24722",
    label: "Xã Thuận Hà",
    parent_code: "665",
  },
  {
    value: "24724",
    label: "Xã Thuận Hạnh",
    parent_code: "665",
  },
  {
    value: "00922",
    label: "Xã Thuận Hoà",
    parent_code: "030",
  },
  {
    value: "31021",
    label: "Xã Thuận Hoà",
    parent_code: "909",
  },
  {
    value: "23071",
    label: "Xã Thuận Hòa",
    parent_code: "597",
  },
  {
    value: "19762",
    label: "Phường Thuận Hòa",
    parent_code: "474",
  },
  {
    value: "29440",
    label: "Xã Thuận Hòa",
    parent_code: "848",
  },
  {
    value: "31484",
    label: "Xã Thuận Hòa",
    parent_code: "936",
  },
  {
    value: "31576",
    label: "Xã Thuận Hòa",
    parent_code: "942",
  },
  {
    value: "18964",
    label: "Xã Thuận Hóa",
    parent_code: "453",
  },
  {
    value: "12271",
    label: "Xã Thuần Hưng",
    parent_code: "330",
  },
  {
    value: "31228",
    label: "Phường Thuận Hưng",
    parent_code: "923",
  },
  {
    value: "31483",
    label: "Xã Thuận Hưng",
    parent_code: "936",
  },
  {
    value: "31606",
    label: "Xã Thuận Hưng",
    parent_code: "944",
  },
  {
    value: "16048",
    label: "Xã Thuần Lộc",
    parent_code: "400",
  },
  {
    value: "18130",
    label: "Xã Thuận Lộc",
    parent_code: "437",
  },
  {
    value: "19753",
    label: "Phường Thuận Lộc",
    parent_code: "474",
  },
  {
    value: "25366",
    label: "Xã Thuận Lợi",
    parent_code: "695",
  },
  {
    value: "01963",
    label: "Xã Thuần Mang",
    parent_code: "062",
  },
  {
    value: "15565",
    label: "Xã Thuận Minh",
    parent_code: "395",
  },
  {
    value: "23083",
    label: "Xã Thuận Minh",
    parent_code: "597",
  },
  {
    value: "09691",
    label: "Xã Thuần Mỹ",
    parent_code: "271",
  },
  {
    value: "28225",
    label: "Xã Thuận Mỹ",
    parent_code: "808",
  },
  {
    value: "23110",
    label: "Thị trấn Thuận Nam",
    parent_code: "598",
  },
  {
    value: "27880",
    label: "Xã Thuận Nghĩa Hòa",
    parent_code: "800",
  },
  {
    value: "25387",
    label: "Xã Thuận Phú",
    parent_code: "695",
  },
  {
    value: "20230",
    label: "Phường Thuận Phước",
    parent_code: "492",
  },
  {
    value: "23140",
    label: "Xã Thuận Quí",
    parent_code: "598",
  },
  {
    value: "17695",
    label: "Xã Thuận Sơn",
    parent_code: "427",
  },
  {
    value: "12964",
    label: "Xã Thuần Thành",
    parent_code: "341",
  },
  {
    value: "05905",
    label: "Xã Thuận Thành",
    parent_code: "172",
  },
  {
    value: "28189",
    label: "Xã Thuận Thành",
    parent_code: "807",
  },
  {
    value: "18418",
    label: "Xã Thuần Thiện",
    parent_code: "443",
  },
  {
    value: "11698",
    label: "Xã Thuận Thiên",
    parent_code: "314",
  },
  {
    value: "29848",
    label: "Xã Thuận Thới",
    parent_code: "862",
  },
  {
    value: "30784",
    label: "Xã Thuận Yên",
    parent_code: "900",
  },
  {
    value: "10969",
    label: "Xã Thúc Kháng",
    parent_code: "296",
  },
  {
    value: "08581",
    label: "Xã Thục Luyện",
    parent_code: "238",
  },
  {
    value: "05095",
    label: "Xã Thung Nai",
    parent_code: "154",
  },
  {
    value: "07102",
    label: "Xã Thủy An",
    parent_code: "205",
  },
  {
    value: "09685",
    label: "Xã Thụy An",
    parent_code: "271",
  },
  {
    value: "19981",
    label: "Xã Thủy Bằng",
    parent_code: "474",
  },
  {
    value: "19807",
    label: "Phường Thuỷ Biều",
    parent_code: "474",
  },
  {
    value: "12871",
    label: "Xã Thụy Bình",
    parent_code: "341",
  },
  {
    value: "19975",
    label: "Phường Thủy Châu",
    parent_code: "479",
  },
  {
    value: "12874",
    label: "Xã Thụy Chính",
    parent_code: "341",
  },
  {
    value: "12877",
    label: "Xã Thụy Dân",
    parent_code: "341",
  },
  {
    value: "12892",
    label: "Xã Thụy Duyên",
    parent_code: "341",
  },
  {
    value: "19969",
    label: "Phường Thủy Dương",
    parent_code: "479",
  },
  {
    value: "27883",
    label: "Xã Thủy Đông",
    parent_code: "800",
  },
  {
    value: "11563",
    label: "Xã Thuỷ Đường",
    parent_code: "311",
  },
  {
    value: "12880",
    label: "Xã Thụy Hải",
    parent_code: "341",
  },
  {
    value: "09208",
    label: "Xã Thụy Hòa",
    parent_code: "258",
  },
  {
    value: "01810",
    label: "Xã Thụy Hùng",
    parent_code: "053",
  },
  {
    value: "06136",
    label: "Xã Thụy Hùng",
    parent_code: "182",
  },
  {
    value: "06208",
    label: "Xã Thụy Hùng",
    parent_code: "183",
  },
  {
    value: "12853",
    label: "Xã Thụy Hưng",
    parent_code: "341",
  },
  {
    value: "11719",
    label: "Xã Thuỵ Hương",
    parent_code: "314",
  },
  {
    value: "10057",
    label: "Xã Thụy Hương",
    parent_code: "277",
  },
  {
    value: "00112",
    label: "Phường Thụy Khuê",
    parent_code: "003",
  },
  {
    value: "00460",
    label: "Xã Thuỵ Lâm",
    parent_code: "017",
  },
  {
    value: "12889",
    label: "Xã Thụy Liên",
    parent_code: "341",
  },
  {
    value: "30967",
    label: "Xã Thủy Liễu",
    parent_code: "907",
  },
  {
    value: "08362",
    label: "Xã Thụy Liễu",
    parent_code: "235",
  },
  {
    value: "12373",
    label: "Xã Thụy Lôi",
    parent_code: "332",
  },
  {
    value: "13414",
    label: "Xã Thụy Lôi",
    parent_code: "350",
  },
  {
    value: "19978",
    label: "Phường Thủy Lương",
    parent_code: "479",
  },
  {
    value: "12850",
    label: "Xã Thụy Ninh",
    parent_code: "341",
  },
  {
    value: "12904",
    label: "Xã Thụy Phong",
    parent_code: "341",
  },
  {
    value: "19987",
    label: "Xã Thủy Phù",
    parent_code: "479",
  },
  {
    value: "19972",
    label: "Phường Thủy Phương",
    parent_code: "479",
  },
  {
    value: "00604",
    label: "Phường Thụy Phương",
    parent_code: "021",
  },
  {
    value: "12844",
    label: "Xã Thụy Quỳnh",
    parent_code: "341",
  },
  {
    value: "11560",
    label: "Xã Thuỷ Sơn",
    parent_code: "311",
  },
  {
    value: "15070",
    label: "Xã Thúy Sơn",
    parent_code: "389",
  },
  {
    value: "12901",
    label: "Xã Thụy Sơn",
    parent_code: "341",
  },
  {
    value: "19984",
    label: "Xã Thủy Tân",
    parent_code: "479",
  },
  {
    value: "27886",
    label: "Xã Thủy Tây",
    parent_code: "800",
  },
  {
    value: "19966",
    label: "Xã Thủy Thanh",
    parent_code: "479",
  },
  {
    value: "12898",
    label: "Xã Thụy Thanh",
    parent_code: "341",
  },
  {
    value: "11536",
    label: "Xã Thuỷ Triều",
    parent_code: "311",
  },
  {
    value: "12868",
    label: "Xã Thụy Trình",
    parent_code: "341",
  },
  {
    value: "12832",
    label: "Xã Thụy Trường",
    parent_code: "341",
  },
  {
    value: "12859",
    label: "Xã Thụy Văn",
    parent_code: "341",
  },
  {
    value: "19963",
    label: "Phường Thủy Vân",
    parent_code: "474",
  },
  {
    value: "07924",
    label: "Xã Thụy Vân",
    parent_code: "227",
  },
  {
    value: "12856",
    label: "Xã Thụy Việt",
    parent_code: "341",
  },
  {
    value: "19813",
    label: "Phường Thuỷ Xuân",
    parent_code: "474",
  },
  {
    value: "12862",
    label: "Xã Thụy Xuân",
    parent_code: "341",
  },
  {
    value: "10045",
    label: "Xã Thủy Xuân Tiên",
    parent_code: "277",
  },
  {
    value: "30985",
    label: "Thị trấn Thứ Ba",
    parent_code: "908",
  },
  {
    value: "31018",
    label: "Thị trấn Thứ Mười Một",
    parent_code: "909",
  },
  {
    value: "10228",
    label: "Xã Thư Phú",
    parent_code: "279",
  },
  {
    value: "09496",
    label: "Thị trấn Thứa",
    parent_code: "264",
  },
  {
    value: "26347",
    label: "Xã Thừa Đức",
    parent_code: "739",
  },
  {
    value: "29101",
    label: "Xã Thừa Đức",
    parent_code: "835",
  },
  {
    value: "02551",
    label: "Xã Thượng Ấm",
    parent_code: "076",
  },
  {
    value: "01939",
    label: "Xã Thượng Ân",
    parent_code: "062",
  },
  {
    value: "04705",
    label: "Xã Thượng Bằng La",
    parent_code: "140",
  },
  {
    value: "01174",
    label: "Xã Thượng Bình",
    parent_code: "034",
  },
  {
    value: "00595",
    label: "Phường Thượng Cát",
    parent_code: "021",
  },
  {
    value: "09748",
    label: "Xã Thượng Cốc",
    parent_code: "272",
  },
  {
    value: "05293",
    label: "Xã Thượng Cốc",
    parent_code: "157",
  },
  {
    value: "06490",
    label: "Xã Thượng Cường",
    parent_code: "187",
  },
  {
    value: "08650",
    label: "Xã Thượng Cửu",
    parent_code: "238",
  },
  {
    value: "00346",
    label: "Phường Thượng Đình",
    parent_code: "009",
  },
  {
    value: "05932",
    label: "Xã Thượng Đình",
    parent_code: "173",
  },
  {
    value: "01912",
    label: "Xã Thượng Giáo",
    parent_code: "061",
  },
  {
    value: "02230",
    label: "Xã Thượng Giáp",
    parent_code: "072",
  },
  {
    value: "01327",
    label: "Xã Thượng Hà",
    parent_code: "043",
  },
  {
    value: "02968",
    label: "Xã Thượng Hà",
    parent_code: "087",
  },
  {
    value: "13117",
    label: "Xã Thượng Hiền",
    parent_code: "343",
  },
  {
    value: "14425",
    label: "Xã Thượng Hòa",
    parent_code: "372",
  },
  {
    value: "18946",
    label: "Xã Thượng Hóa",
    parent_code: "452",
  },
  {
    value: "14662",
    label: "Xã Thượng Kiệm",
    parent_code: "376",
  },
  {
    value: "29977",
    label: "Xã Thường Lạc",
    parent_code: "870",
  },
  {
    value: "07759",
    label: "Xã Thượng Lan",
    parent_code: "222",
  },
  {
    value: "10447",
    label: "Xã Thượng Lâm",
    parent_code: "282",
  },
  {
    value: "02269",
    label: "Xã Thượng Lâm",
    parent_code: "071",
  },
  {
    value: "08323",
    label: "Xã Thượng Long",
    parent_code: "234",
  },
  {
    value: "20188",
    label: "Xã Thượng Long",
    parent_code: "483",
  },
  {
    value: "20185",
    label: "Xã Thượng Lộ",
    parent_code: "483",
  },
  {
    value: "18478",
    label: "Xã Thượng Lộc",
    parent_code: "443",
  },
  {
    value: "11305",
    label: "Phường Thượng Lý",
    parent_code: "303",
  },
  {
    value: "09814",
    label: "Xã Thượng Mỗ",
    parent_code: "273",
  },
  {
    value: "18439",
    label: "Xã Thường Nga",
    parent_code: "443",
  },
  {
    value: "20191",
    label: "Xã Thượng Nhật",
    parent_code: "483",
  },
  {
    value: "16225",
    label: "Xã Thượng Ninh",
    parent_code: "402",
  },
  {
    value: "02239",
    label: "Xã Thượng Nông",
    parent_code: "072",
  },
  {
    value: "05731",
    label: "Xã Thượng Nung",
    parent_code: "170",
  },
  {
    value: "00772",
    label: "Xã Thượng Phùng",
    parent_code: "027",
  },
  {
    value: "29956",
    label: "Xã Thường Phước 1",
    parent_code: "870",
  },
  {
    value: "29974",
    label: "Xã Thường Phước 2",
    parent_code: "870",
  },
  {
    value: "01957",
    label: "Xã Thượng Quan",
    parent_code: "062",
  },
  {
    value: "20173",
    label: "Xã Thượng Quảng",
    parent_code: "483",
  },
  {
    value: "00958",
    label: "Xã Thượng Sơn",
    parent_code: "030",
  },
  {
    value: "17644",
    label: "Xã Thượng Sơn",
    parent_code: "427",
  },
  {
    value: "25927",
    label: "Xã Thường Tân",
    parent_code: "726",
  },
  {
    value: "01009",
    label: "Xã Thượng Tân",
    parent_code: "031",
  },
  {
    value: "17968",
    label: "Xã Thượng Tân Lộc",
    parent_code: "430",
  },
  {
    value: "31198",
    label: "Phường Thường Thạnh",
    parent_code: "919",
  },
  {
    value: "00115",
    label: "Phường Thượng Thanh",
    parent_code: "004",
  },
  {
    value: "07855",
    label: "Xã Thường Thắng",
    parent_code: "223",
  },
  {
    value: "01420",
    label: "Xã Thượng Thôn",
    parent_code: "045",
  },
  {
    value: "29962",
    label: "Xã Thường Thới Hậu A",
    parent_code: "870",
  },
  {
    value: "29971",
    label: "Thị trấn Thường Thới Tiền",
    parent_code: "870",
  },
  {
    value: "10183",
    label: "Thị trấn Thường Tín",
    parent_code: "279",
  },
  {
    value: "19147",
    label: "Xã Thượng Trạch",
    parent_code: "455",
  },
  {
    value: "09127",
    label: "Xã Thượng Trưng",
    parent_code: "252",
  },
  {
    value: "10759",
    label: "Xã Thượng Vũ",
    parent_code: "293",
  },
  {
    value: "10090",
    label: "Xã Thượng Vực",
    parent_code: "277",
  },
  {
    value: "15646",
    label: "Thị trấn Thường Xuân",
    parent_code: "396",
  },
  {
    value: "06829",
    label: "Xã Thượng Yên Công",
    parent_code: "196",
  },
  {
    value: "03384",
    label: "Xã Tìa Dình",
    parent_code: "101",
  },
  {
    value: "09754",
    label: "Xã Tích Giang",
    parent_code: "272",
  },
  {
    value: "05500",
    label: "Phường Tích Lương",
    parent_code: "164",
  },
  {
    value: "08707",
    label: "Phường Tích Sơn",
    parent_code: "243",
  },
  {
    value: "29860",
    label: "Xã Tích Thiện",
    parent_code: "862",
  },
  {
    value: "20890",
    label: "Xã Tiên An",
    parent_code: "514",
  },
  {
    value: "09178",
    label: "Phường Tiền An",
    parent_code: "256",
  },
  {
    value: "07153",
    label: "Xã Tiền An",
    parent_code: "206",
  },
  {
    value: "02500",
    label: "Xã Tiến Bộ",
    parent_code: "075",
  },
  {
    value: "20878",
    label: "Xã Tiên Cảnh",
    parent_code: "514",
  },
  {
    value: "07903",
    label: "Phường Tiên Cát",
    parent_code: "227",
  },
  {
    value: "20863",
    label: "Xã Tiên Cẩm",
    parent_code: "514",
  },
  {
    value: "20866",
    label: "Xã Tiên Châu",
    parent_code: "514",
  },
  {
    value: "08758",
    label: "Phường Tiền Châu",
    parent_code: "244",
  },
  {
    value: "11761",
    label: "Xã Tiên Cường",
    parent_code: "315",
  },
  {
    value: "08263",
    label: "Xã Tiên Du",
    parent_code: "233",
  },
  {
    value: "07729",
    label: "Xã Tiến Dũng",
    parent_code: "221",
  },
  {
    value: "00418",
    label: "Xã Tiên Dược",
    parent_code: "016",
  },
  {
    value: "00472",
    label: "Xã Tiên Dương",
    parent_code: "017",
  },
  {
    value: "18373",
    label: "Thị trấn Tiên Điền",
    parent_code: "442",
  },
  {
    value: "11143",
    label: "Xã Tiên Động",
    parent_code: "298",
  },
  {
    value: "12646",
    label: "Xã Tiến Đức",
    parent_code: "339",
  },
  {
    value: "20860",
    label: "Xã Tiên Hà",
    parent_code: "514",
  },
  {
    value: "13381",
    label: "Xã Tiên Hải",
    parent_code: "347",
  },
  {
    value: "30781",
    label: "Xã Tiên Hải",
    parent_code: "900",
  },
  {
    value: "12970",
    label: "Thị trấn Tiền Hải",
    parent_code: "342",
  },
  {
    value: "13372",
    label: "Xã Tiên Hiệp",
    parent_code: "347",
  },
  {
    value: "20875",
    label: "Xã Tiên Hiệp",
    parent_code: "514",
  },
  {
    value: "18997",
    label: "Xã Tiến Hóa",
    parent_code: "453",
  },
  {
    value: "25162",
    label: "Xã Tiên Hoàng",
    parent_code: "683",
  },
  {
    value: "05803",
    label: "Xã Tiên Hội",
    parent_code: "171",
  },
  {
    value: "25213",
    label: "Xã Tiến Hưng",
    parent_code: "689",
  },
  {
    value: "08497",
    label: "Xã Tiên Kiên",
    parent_code: "237",
  },
  {
    value: "01207",
    label: "Xã Tiên Kiều",
    parent_code: "034",
  },
  {
    value: "17302",
    label: "Xã Tiên Kỳ",
    parent_code: "423",
  },
  {
    value: "20854",
    label: "Thị trấn Tiên Kỳ",
    parent_code: "514",
  },
  {
    value: "11755",
    label: "Thị trấn Tiên Lãng",
    parent_code: "315",
  },
  {
    value: "06889",
    label: "Xã Tiên Lãng",
    parent_code: "199",
  },
  {
    value: "20869",
    label: "Xã Tiên Lãnh",
    parent_code: "514",
  },
  {
    value: "20896",
    label: "Xã Tiên Lập",
    parent_code: "514",
  },
  {
    value: "28852",
    label: "Xã Tiên Long",
    parent_code: "831",
  },
  {
    value: "20893",
    label: "Xã Tiên Lộc",
    parent_code: "514",
  },
  {
    value: "16027",
    label: "Xã Tiến Lộc",
    parent_code: "400",
  },
  {
    value: "22963",
    label: "Xã Tiến Lợi",
    parent_code: "593",
  },
  {
    value: "07393",
    label: "Xã Tiên Lục",
    parent_code: "217",
  },
  {
    value: "08842",
    label: "Xã Tiên Lữ",
    parent_code: "246",
  },
  {
    value: "08344",
    label: "Xã Tiên Lương",
    parent_code: "235",
  },
  {
    value: "11800",
    label: "Xã Tiên Minh",
    parent_code: "315",
  },
  {
    value: "20881",
    label: "Xã Tiên Mỹ",
    parent_code: "514",
  },
  {
    value: "13363",
    label: "Xã Tiên Ngoại",
    parent_code: "349",
  },
  {
    value: "20872",
    label: "Xã Tiên Ngọc",
    parent_code: "514",
  },
  {
    value: "01225",
    label: "Xã Tiên Nguyên",
    parent_code: "035",
  },
  {
    value: "07468",
    label: "Xã Tiên Nha",
    parent_code: "218",
  },
  {
    value: "13354",
    label: "Phường Tiên Nội",
    parent_code: "349",
  },
  {
    value: "15730",
    label: "Xã Tiến Nông",
    parent_code: "397",
  },
  {
    value: "09682",
    label: "Xã Tiên Phong",
    parent_code: "271",
  },
  {
    value: "05884",
    label: "Xã Tiên Phong",
    parent_code: "172",
  },
  {
    value: "20884",
    label: "Xã Tiên Phong",
    parent_code: "514",
  },
  {
    value: "09019",
    label: "Xã Tiền Phong",
    parent_code: "250",
  },
  {
    value: "10222",
    label: "Xã Tiền Phong",
    parent_code: "279",
  },
  {
    value: "11893",
    label: "Xã Tiền Phong",
    parent_code: "316",
  },
  {
    value: "12193",
    label: "Xã Tiền Phong",
    parent_code: "329",
  },
  {
    value: "12451",
    label: "Phường Tiền Phong",
    parent_code: "336",
  },
  {
    value: "07189",
    label: "Xã Tiền Phong",
    parent_code: "206",
  },
  {
    value: "07711",
    label: "Xã Tiền Phong",
    parent_code: "221",
  },
  {
    value: "04888",
    label: "Xã Tiền Phong",
    parent_code: "150",
  },
  {
    value: "16750",
    label: "Xã Tiền Phong",
    parent_code: "415",
  },
  {
    value: "08248",
    label: "Xã Tiên Phú",
    parent_code: "233",
  },
  {
    value: "10024",
    label: "Xã Tiên Phương",
    parent_code: "277",
  },
  {
    value: "07786",
    label: "Xã Tiên Sơn",
    parent_code: "222",
  },
  {
    value: "13369",
    label: "Xã Tiên Sơn",
    parent_code: "349",
  },
  {
    value: "20857",
    label: "Xã Tiên Sơn",
    parent_code: "514",
  },
  {
    value: "13366",
    label: "Xã Tiên Tân",
    parent_code: "347",
  },
  {
    value: "11776",
    label: "Xã Tiên Thanh",
    parent_code: "315",
  },
  {
    value: "01645",
    label: "Xã Tiên Thành",
    parent_code: "049",
  },
  {
    value: "17510",
    label: "Xã Tiến Thành",
    parent_code: "426",
  },
  {
    value: "25210",
    label: "Phường Tiến Thành",
    parent_code: "689",
  },
  {
    value: "22966",
    label: "Xã Tiến Thành",
    parent_code: "593",
  },
  {
    value: "11797",
    label: "Xã Tiên Thắng",
    parent_code: "315",
  },
  {
    value: "08983",
    label: "Xã Tiến Thắng",
    parent_code: "250",
  },
  {
    value: "07264",
    label: "Xã Tiến Thắng",
    parent_code: "215",
  },
  {
    value: "13627",
    label: "Xã Tiến Thắng",
    parent_code: "353",
  },
  {
    value: "09007",
    label: "Xã Tiến Thịnh",
    parent_code: "250",
  },
  {
    value: "20887",
    label: "Xã Tiên Thọ",
    parent_code: "514",
  },
  {
    value: "25693",
    label: "Xã Tiên Thuận",
    parent_code: "711",
  },
  {
    value: "28861",
    label: "Xã Tiên Thủy",
    parent_code: "831",
  },
  {
    value: "17209",
    label: "Xã Tiến Thủy",
    parent_code: "421",
  },
  {
    value: "10837",
    label: "Xã Tiền Tiến",
    parent_code: "288",
  },
  {
    value: "12418",
    label: "Xã Tiền Tiến",
    parent_code: "333",
  },
  {
    value: "16549",
    label: "Xã Tiên Trang",
    parent_code: "406",
  },
  {
    value: "04936",
    label: "Xã Tiến Xuân",
    parent_code: "276",
  },
  {
    value: "01261",
    label: "Xã Tiên Yên",
    parent_code: "035",
  },
  {
    value: "06862",
    label: "Thị trấn Tiên Yên",
    parent_code: "199",
  },
  {
    value: "09871",
    label: "Xã Tiền Yên",
    parent_code: "274",
  },
  {
    value: "29341",
    label: "Thị trấn Tiểu Cần",
    parent_code: "846",
  },
  {
    value: "13558",
    label: "Xã Tiêu Động",
    parent_code: "352",
  },
  {
    value: "08038",
    label: "Xã Tiêu Sơn",
    parent_code: "230",
  },
  {
    value: "21232",
    label: "Xã Tịnh An",
    parent_code: "522",
  },
  {
    value: "21202",
    label: "Xã Tịnh Ấn Đông",
    parent_code: "522",
  },
  {
    value: "21223",
    label: "Xã Tịnh Ấn Tây",
    parent_code: "522",
  },
  {
    value: "06574",
    label: "Xã Tĩnh Bắc",
    parent_code: "188",
  },
  {
    value: "21205",
    label: "Xã Tịnh Bắc",
    parent_code: "527",
  },
  {
    value: "30520",
    label: "Thị trấn Tịnh Biên",
    parent_code: "890",
  },
  {
    value: "21193",
    label: "Xã Tịnh Bình",
    parent_code: "527",
  },
  {
    value: "21208",
    label: "Xã Tịnh Châu",
    parent_code: "522",
  },
  {
    value: "21196",
    label: "Xã Tịnh Đông",
    parent_code: "527",
  },
  {
    value: "21226",
    label: "Xã Tịnh Giang",
    parent_code: "527",
  },
  {
    value: "21220",
    label: "Xã Tịnh Hà",
    parent_code: "527",
  },
  {
    value: "16642",
    label: "Phường Tĩnh Hải",
    parent_code: "407",
  },
  {
    value: "21184",
    label: "Xã Tịnh Hiệp",
    parent_code: "527",
  },
  {
    value: "21187",
    label: "Xã Tịnh Hòa",
    parent_code: "522",
  },
  {
    value: "21211",
    label: "Xã Tịnh Khê",
    parent_code: "522",
  },
  {
    value: "21190",
    label: "Xã Tịnh Kỳ",
    parent_code: "522",
  },
  {
    value: "21214",
    label: "Xã Tịnh Long",
    parent_code: "522",
  },
  {
    value: "21229",
    label: "Xã Tịnh Minh",
    parent_code: "527",
  },
  {
    value: "08659",
    label: "Xã Tinh Nhuệ",
    parent_code: "238",
  },
  {
    value: "21181",
    label: "Xã Tịnh Phong",
    parent_code: "527",
  },
  {
    value: "21217",
    label: "Xã Tịnh Sơn",
    parent_code: "527",
  },
  {
    value: "21199",
    label: "Xã Tịnh Thiện",
    parent_code: "522",
  },
  {
    value: "21175",
    label: "Xã Tịnh Thọ",
    parent_code: "527",
  },
  {
    value: "29899",
    label: "Xã Tịnh Thới",
    parent_code: "866",
  },
  {
    value: "21178",
    label: "Xã Tịnh Trà",
    parent_code: "527",
  },
  {
    value: "01729",
    label: "Thị trấn Tĩnh Túc",
    parent_code: "052",
  },
  {
    value: "03280",
    label: "Xã Tỏa Tình",
    parent_code: "099",
  },
  {
    value: "04879",
    label: "Xã Toàn Sơn",
    parent_code: "150",
  },
  {
    value: "11044",
    label: "Xã Toàn Thắng",
    parent_code: "297",
  },
  {
    value: "11794",
    label: "Xã Toàn Thắng",
    parent_code: "315",
  },
  {
    value: "12286",
    label: "Xã Toàn Thắng",
    parent_code: "331",
  },
  {
    value: "26731",
    label: "Xã Tóc Tiên",
    parent_code: "754",
  },
  {
    value: "09670",
    label: "Xã Tòng Bạt",
    parent_code: "271",
  },
  {
    value: "05233",
    label: "Xã Tòng Đậu",
    parent_code: "156",
  },
  {
    value: "02749",
    label: "Xã Tòng Sành",
    parent_code: "082",
  },
  {
    value: "30766",
    label: "Phường Tô Châu",
    parent_code: "900",
  },
  {
    value: "22714",
    label: "Thị trấn Tô Hạp",
    parent_code: "575",
  },
  {
    value: "10258",
    label: "Xã Tô Hiệu",
    parent_code: "279",
  },
  {
    value: "03649",
    label: "Phường Tô Hiệu",
    parent_code: "116",
  },
  {
    value: "04333",
    label: "Xã Tô Mậu",
    parent_code: "135",
  },
  {
    value: "04018",
    label: "Xã Tô Múa",
    parent_code: "128",
  },
  {
    value: "03775",
    label: "Xã Tông Cọ",
    parent_code: "119",
  },
  {
    value: "01414",
    label: "Xã Tổng Cọt",
    parent_code: "045",
  },
  {
    value: "03772",
    label: "Xã Tông Lạnh",
    parent_code: "119",
  },
  {
    value: "12409",
    label: "Xã Tống Phan",
    parent_code: "333",
  },
  {
    value: "03565",
    label: "Xã Tông Qua Lìn",
    parent_code: "109",
  },
  {
    value: "12430",
    label: "Xã Tống Trân",
    parent_code: "333",
  },
  {
    value: "10060",
    label: "Xã Tốt Động",
    parent_code: "277",
  },
  {
    value: "23665",
    label: "Xã Tơ Tung",
    parent_code: "625",
  },
  {
    value: "20446",
    label: "Xã Tr'Hy",
    parent_code: "504",
  },
  {
    value: "31169",
    label: "Phường Trà An",
    parent_code: "918",
  },
  {
    value: "23581",
    label: "Phường Trà Bá",
    parent_code: "622",
  },
  {
    value: "21127",
    label: "Xã Trà Bình",
    parent_code: "525",
  },
  {
    value: "20917",
    label: "Xã Trà Bui",
    parent_code: "515",
  },
  {
    value: "21142",
    label: "Xã Trà Bùi",
    parent_code: "525",
  },
  {
    value: "20947",
    label: "Xã Trà Cang",
    parent_code: "516",
  },
  {
    value: "06721",
    label: "Phường Trà Cổ",
    parent_code: "194",
  },
  {
    value: "26164",
    label: "Xã Trà Cổ",
    parent_code: "734",
  },
  {
    value: "29836",
    label: "Xã Trà Côn",
    parent_code: "862",
  },
  {
    value: "29461",
    label: "Thị trấn Trà Cú",
    parent_code: "849",
  },
  {
    value: "20956",
    label: "Xã Trà Don",
    parent_code: "516",
  },
  {
    value: "20938",
    label: "Xã Trà Dơn",
    parent_code: "516",
  },
  {
    value: "20911",
    label: "Xã Trà Dương",
    parent_code: "515",
  },
  {
    value: "23596",
    label: "Xã Trà Đa",
    parent_code: "622",
  },
  {
    value: "20920",
    label: "Xã Trà Đốc",
    parent_code: "515",
  },
  {
    value: "20908",
    label: "Xã Trà Đông",
    parent_code: "515",
  },
  {
    value: "20926",
    label: "Xã Trà Giác",
    parent_code: "515",
  },
  {
    value: "13078",
    label: "Xã Trà Giang",
    parent_code: "343",
  },
  {
    value: "20914",
    label: "Xã Trà Giang",
    parent_code: "515",
  },
  {
    value: "21118",
    label: "Xã Trà Giang",
    parent_code: "525",
  },
  {
    value: "20929",
    label: "Xã Trà Giáp",
    parent_code: "515",
  },
  {
    value: "21124",
    label: "Xã Trà Hiệp",
    parent_code: "525",
  },
  {
    value: "20932",
    label: "Xã Trà Ka",
    parent_code: "515",
  },
  {
    value: "20902",
    label: "Xã Trà Kót",
    parent_code: "515",
  },
  {
    value: "21133",
    label: "Xã Trà Lâm",
    parent_code: "525",
  },
  {
    value: "20935",
    label: "Xã Trà Leng",
    parent_code: "516",
  },
  {
    value: "20950",
    label: "Xã Trà Linh",
    parent_code: "516",
  },
  {
    value: "01447",
    label: "Thị trấn Trà Lĩnh",
    parent_code: "047",
  },
  {
    value: "31472",
    label: "Phường Trà Lồng",
    parent_code: "937",
  },
  {
    value: "20944",
    label: "Xã Trà Mai",
    parent_code: "516",
  },
  {
    value: "20899",
    label: "Thị trấn Trà My",
    parent_code: "515",
  },
  {
    value: "20953",
    label: "Xã Trà Nam",
    parent_code: "516",
  },
  {
    value: "31171",
    label: "Phường Trà Nóc",
    parent_code: "918",
  },
  {
    value: "20905",
    label: "Xã Trà Nú",
    parent_code: "515",
  },
  {
    value: "29821",
    label: "Thị trấn Trà Ôn",
    parent_code: "862",
  },
  {
    value: "21154",
    label: "Xã Trà Phong",
    parent_code: "525",
  },
  {
    value: "21130",
    label: "Xã Trà Phú",
    parent_code: "525",
  },
  {
    value: "20900",
    label: "Xã Trà Sơn",
    parent_code: "515",
  },
  {
    value: "21139",
    label: "Xã Trà Sơn",
    parent_code: "525",
  },
  {
    value: "23227",
    label: "Xã Trà Tân",
    parent_code: "600",
  },
  {
    value: "20923",
    label: "Xã Trà Tân",
    parent_code: "515",
  },
  {
    value: "21136",
    label: "Xã Trà Tân",
    parent_code: "525",
  },
  {
    value: "20941",
    label: "Xã Trà Tập",
    parent_code: "516",
  },
  {
    value: "21166",
    label: "Xã Trà Tây",
    parent_code: "525",
  },
  {
    value: "21145",
    label: "Xã Trà Thanh",
    parent_code: "525",
  },
  {
    value: "21121",
    label: "Xã Trà Thủy",
    parent_code: "525",
  },
  {
    value: "20959",
    label: "Xã Trà Vân",
    parent_code: "516",
  },
  {
    value: "20962",
    label: "Xã Trà Vinh",
    parent_code: "516",
  },
  {
    value: "25513",
    label: "Xã Trà Vong",
    parent_code: "705",
  },
  {
    value: "21163",
    label: "Xã Trà Xinh",
    parent_code: "525",
  },
  {
    value: "21115",
    label: "Thị trấn Trà Xuân",
    parent_code: "525",
  },
  {
    value: "13351",
    label: "Xã Trác Văn",
    parent_code: "349",
  },
  {
    value: "09760",
    label: "Xã Trạch Mỹ Lộc",
    parent_code: "272",
  },
  {
    value: "11386",
    label: "Phường Trại Cau",
    parent_code: "305",
  },
  {
    value: "05662",
    label: "Thị trấn Trại Cau",
    parent_code: "169",
  },
  {
    value: "11314",
    label: "Phường Trại Chuối",
    parent_code: "303",
  },
  {
    value: "30001",
    label: "Thị trấn Tràm Chim",
    parent_code: "871",
  },
  {
    value: "24810",
    label: "Xã Trạm Hành",
    parent_code: "672",
  },
  {
    value: "09430",
    label: "Xã Trạm Lộ",
    parent_code: "262",
  },
  {
    value: "04585",
    label: "Thị trấn Trạm Tấu",
    parent_code: "139",
  },
  {
    value: "04600",
    label: "Xã Trạm Tấu",
    parent_code: "139",
  },
  {
    value: "08239",
    label: "Xã Trạm Thản",
    parent_code: "233",
  },
  {
    value: "09832",
    label: "Thị trấn Trạm Trôi",
    parent_code: "274",
  },
  {
    value: "23713",
    label: "Xã Trang",
    parent_code: "626",
  },
  {
    value: "07096",
    label: "Phường Tràng An",
    parent_code: "205",
  },
  {
    value: "13510",
    label: "Xã Tràng An",
    parent_code: "352",
  },
  {
    value: "25708",
    label: "Phường Trảng Bàng",
    parent_code: "712",
  },
  {
    value: "26248",
    label: "Thị trấn Trảng Bom",
    parent_code: "737",
  },
  {
    value: "06301",
    label: "Xã Tràng Các",
    parent_code: "184",
  },
  {
    value: "11425",
    label: "Phường Tràng Cát",
    parent_code: "306",
  },
  {
    value: "25993",
    label: "Phường Trảng Dài",
    parent_code: "731",
  },
  {
    value: "02209",
    label: "Xã Tràng Đà",
    parent_code: "070",
  },
  {
    value: "09383",
    label: "Phường Trang Hạ",
    parent_code: "261",
  },
  {
    value: "07078",
    label: "Xã Tràng Lương",
    parent_code: "205",
  },
  {
    value: "11452",
    label: "Phường Tràng Minh",
    parent_code: "307",
  },
  {
    value: "06316",
    label: "Xã Tràng Phái",
    parent_code: "184",
  },
  {
    value: "17641",
    label: "Xã Tràng Sơn",
    parent_code: "427",
  },
  {
    value: "00079",
    label: "Phường Tràng Tiền",
    parent_code: "002",
  },
  {
    value: "09022",
    label: "Xã Tráng Việt",
    parent_code: "250",
  },
  {
    value: "05746",
    label: "Xã Tràng Xá",
    parent_code: "170",
  },
  {
    value: "10408",
    label: "Xã Trầm Lộng",
    parent_code: "281",
  },
  {
    value: "12391",
    label: "Thị trấn Trần Cao",
    parent_code: "333",
  },
  {
    value: "11941",
    label: "Xã Trân Châu",
    parent_code: "317",
  },
  {
    value: "11911",
    label: "Xã Trấn Dương",
    parent_code: "316",
  },
  {
    value: "13669",
    label: "Phường Trần Đăng Ninh",
    parent_code: "356",
  },
  {
    value: "31673",
    label: "Thị trấn Trần Đề",
    parent_code: "951",
  },
  {
    value: "32107",
    label: "Xã Trần Hợi",
    parent_code: "968",
  },
  {
    value: "00082",
    label: "Phường Trần Hưng Đạo",
    parent_code: "002",
  },
  {
    value: "10525",
    label: "Phường Trần Hưng Đạo",
    parent_code: "288",
  },
  {
    value: "12452",
    label: "Phường Trần Hưng Đạo",
    parent_code: "336",
  },
  {
    value: "06685",
    label: "Phường Trần Hưng Đạo",
    parent_code: "193",
  },
  {
    value: "13300",
    label: "Phường Trần Hưng Đạo",
    parent_code: "347",
  },
  {
    value: "13594",
    label: "Xã Trần Hưng Đạo",
    parent_code: "353",
  },
  {
    value: "13666",
    label: "Phường Trần Hưng Đạo",
    parent_code: "356",
  },
  {
    value: "23308",
    label: "Phường Trần Hưng Đạo",
    parent_code: "608",
  },
  {
    value: "21022",
    label: "Phường Trần Hưng Đạo",
    parent_code: "522",
  },
  {
    value: "21574",
    label: "Phường Trần Hưng Đạo",
    parent_code: "540",
  },
  {
    value: "12454",
    label: "Phường Trần Lãm",
    parent_code: "336",
  },
  {
    value: "11380",
    label: "Phường Trần Nguyên Hãn",
    parent_code: "305",
  },
  {
    value: "07204",
    label: "Phường Trần Nguyên Hãn",
    parent_code: "213",
  },
  {
    value: "06256",
    label: "Xã Trấn Ninh",
    parent_code: "184",
  },
  {
    value: "32161",
    label: "Xã Trần Phán",
    parent_code: "970",
  },
  {
    value: "00334",
    label: "Phường Trần Phú",
    parent_code: "008",
  },
  {
    value: "10099",
    label: "Xã Trần Phú",
    parent_code: "277",
  },
  {
    value: "00691",
    label: "Phường Trần Phú",
    parent_code: "024",
  },
  {
    value: "10528",
    label: "Phường Trần Phú",
    parent_code: "288",
  },
  {
    value: "06712",
    label: "Phường Trần Phú",
    parent_code: "194",
  },
  {
    value: "07213",
    label: "Phường Trần Phú",
    parent_code: "213",
  },
  {
    value: "02179",
    label: "Xã Trần Phú",
    parent_code: "066",
  },
  {
    value: "18070",
    label: "Phường Trần Phú",
    parent_code: "436",
  },
  {
    value: "21013",
    label: "Phường Trần Phú",
    parent_code: "522",
  },
  {
    value: "21586",
    label: "Phường Trần Phú",
    parent_code: "540",
  },
  {
    value: "21559",
    label: "Phường Trần Quang Diệu",
    parent_code: "540",
  },
  {
    value: "13678",
    label: "Phường Trần Quang Khải",
    parent_code: "356",
  },
  {
    value: "13636",
    label: "Phường Trần Tế Xương",
    parent_code: "356",
  },
  {
    value: "11443",
    label: "Phường Trần Thành Ngọ",
    parent_code: "307",
  },
  {
    value: "32149",
    label: "Xã Trần Thới",
    parent_code: "969",
  },
  {
    value: "32095",
    label: "Thị trấn Trần Văn Thời",
    parent_code: "968",
  },
  {
    value: "06370",
    label: "Xã Trấn Yên",
    parent_code: "185",
  },
  {
    value: "00565",
    label: "Thị trấn Trâu Quỳ",
    parent_code: "018",
  },
  {
    value: "26176",
    label: "Xã Trị An",
    parent_code: "735",
  },
  {
    value: "25609",
    label: "Xã Trí Bình",
    parent_code: "708",
  },
  {
    value: "22864",
    label: "Xã Tri Hải",
    parent_code: "586",
  },
  {
    value: "06313",
    label: "Xã Tri Lễ",
    parent_code: "184",
  },
  {
    value: "16756",
    label: "Xã Tri Lễ",
    parent_code: "415",
  },
  {
    value: "32072",
    label: "Xã Trí Lực",
    parent_code: "967",
  },
  {
    value: "15037",
    label: "Xã Trí Nang",
    parent_code: "388",
  },
  {
    value: "32071",
    label: "Xã Trí Phải",
    parent_code: "967",
  },
  {
    value: "02359",
    label: "Xã Tri Phú",
    parent_code: "073",
  },
  {
    value: "01453",
    label: "Xã Tri Phương",
    parent_code: "047",
  },
  {
    value: "09358",
    label: "Xã Tri Phương",
    parent_code: "260",
  },
  {
    value: "06016",
    label: "Xã Tri Phương",
    parent_code: "180",
  },
  {
    value: "09421",
    label: "Xã Trí Quả",
    parent_code: "262",
  },
  {
    value: "02935",
    label: "Xã Trì Quang",
    parent_code: "086",
  },
  {
    value: "10333",
    label: "Xã Tri Thủy",
    parent_code: "280",
  },
  {
    value: "30544",
    label: "Thị trấn Tri Tôn",
    parent_code: "891",
  },
  {
    value: "10288",
    label: "Xã Tri Trung",
    parent_code: "280",
  },
  {
    value: "07720",
    label: "Xã Trí Yên",
    parent_code: "221",
  },
  {
    value: "19669",
    label: "Xã Triệu Ái",
    parent_code: "469",
  },
  {
    value: "19627",
    label: "Xã Triệu An",
    parent_code: "469",
  },
  {
    value: "19645",
    label: "Xã Triệu Đại",
    parent_code: "469",
  },
  {
    value: "08863",
    label: "Xã Triệu Đề",
    parent_code: "246",
  },
  {
    value: "19636",
    label: "Xã Triệu Độ",
    parent_code: "469",
  },
  {
    value: "19675",
    label: "Xã Triệu Giang",
    parent_code: "469",
  },
  {
    value: "25147",
    label: "Xã Triệu Hải",
    parent_code: "682",
  },
  {
    value: "19648",
    label: "Xã Triệu Hòa",
    parent_code: "469",
  },
  {
    value: "19651",
    label: "Xã Triệu Lăng",
    parent_code: "469",
  },
  {
    value: "19657",
    label: "Xã Triệu Long",
    parent_code: "469",
  },
  {
    value: "16021",
    label: "Xã Triệu Lộc",
    parent_code: "400",
  },
  {
    value: "01735",
    label: "Xã Triệu Nguyên",
    parent_code: "052",
  },
  {
    value: "19567",
    label: "Xã Triệu Nguyên",
    parent_code: "467",
  },
  {
    value: "19633",
    label: "Xã Triệu Phước",
    parent_code: "469",
  },
  {
    value: "15664",
    label: "Thị trấn Triệu Sơn",
    parent_code: "397",
  },
  {
    value: "19654",
    label: "Xã Triệu Sơn",
    parent_code: "469",
  },
  {
    value: "19660",
    label: "Xã Triệu Tài",
    parent_code: "469",
  },
  {
    value: "15685",
    label: "Xã Triệu Thành",
    parent_code: "397",
  },
  {
    value: "19678",
    label: "Xã Triệu Thành",
    parent_code: "469",
  },
  {
    value: "19642",
    label: "Xã Triệu Thuận",
    parent_code: "469",
  },
  {
    value: "19672",
    label: "Xã Triệu Thượng",
    parent_code: "469",
  },
  {
    value: "19639",
    label: "Xã Triệu Trạch",
    parent_code: "469",
  },
  {
    value: "19666",
    label: "Xã Triệu Trung",
    parent_code: "469",
  },
  {
    value: "19630",
    label: "Xã Triệu Vân",
    parent_code: "469",
  },
  {
    value: "31543",
    label: "Xã Trinh Phú",
    parent_code: "943",
  },
  {
    value: "02695",
    label: "Xã Trịnh Tường",
    parent_code: "082",
  },
  {
    value: "13513",
    label: "Xã Trịnh Xá",
    parent_code: "347",
  },
  {
    value: "01816",
    label: "Xã Trọng Con",
    parent_code: "053",
  },
  {
    value: "18907",
    label: "Xã Trọng Hóa",
    parent_code: "452",
  },
  {
    value: "12784",
    label: "Xã Trọng Quan",
    parent_code: "340",
  },
  {
    value: "07579",
    label: "Xã Trù Hựu",
    parent_code: "219",
  },
  {
    value: "17707",
    label: "Xã Trù Sơn",
    parent_code: "427",
  },
  {
    value: "00004",
    label: "Phường Trúc Bạch",
    parent_code: "001",
  },
  {
    value: "16630",
    label: "Phường Trúc Lâm",
    parent_code: "407",
  },
  {
    value: "04360",
    label: "Xã Trúc Lâu",
    parent_code: "135",
  },
  {
    value: "24661",
    label: "Xã Trúc Sơn",
    parent_code: "662",
  },
  {
    value: "13252",
    label: "Xã Trung An",
    parent_code: "344",
  },
  {
    value: "27523",
    label: "Xã Trung An",
    parent_code: "783",
  },
  {
    value: "28285",
    label: "Xã Trung An",
    parent_code: "815",
  },
  {
    value: "29707",
    label: "Xã Trung An",
    parent_code: "859",
  },
  {
    value: "31222",
    label: "Xã Trung An",
    parent_code: "925",
  },
  {
    value: "31681",
    label: "Xã Trung Bình",
    parent_code: "951",
  },
  {
    value: "03010",
    label: "Xã Trung Chải",
    parent_code: "088",
  },
  {
    value: "03503",
    label: "Xã Trung Chải",
    parent_code: "112",
  },
  {
    value: "27586",
    label: "Xã Trung Chánh",
    parent_code: "784",
  },
  {
    value: "29671",
    label: "Xã Trung Chánh",
    parent_code: "859",
  },
  {
    value: "09787",
    label: "Xã Trung Châu",
    parent_code: "273",
  },
  {
    value: "09523",
    label: "Xã Trung Chính",
    parent_code: "264",
  },
  {
    value: "16297",
    label: "Xã Trung Chính",
    parent_code: "404",
  },
  {
    value: "12361",
    label: "Xã Trung Dũng",
    parent_code: "332",
  },
  {
    value: "26032",
    label: "Phường Trung Dũng",
    parent_code: "731",
  },
  {
    value: "16699",
    label: "Phường Trung Đô",
    parent_code: "412",
  },
  {
    value: "14035",
    label: "Xã Trung Đông",
    parent_code: "363",
  },
  {
    value: "03605",
    label: "Xã Trung Đồng",
    parent_code: "111",
  },
  {
    value: "00391",
    label: "Xã Trung Giã",
    parent_code: "016",
  },
  {
    value: "19498",
    label: "Xã Trung Giang",
    parent_code: "466",
  },
  {
    value: "08245",
    label: "Xã Trung Giáp",
    parent_code: "233",
  },
  {
    value: "09073",
    label: "Xã Trung Hà",
    parent_code: "251",
  },
  {
    value: "11530",
    label: "Xã Trung Hà",
    parent_code: "311",
  },
  {
    value: "02305",
    label: "Xã Trung Hà",
    parent_code: "073",
  },
  {
    value: "15001",
    label: "Xã Trung Hạ",
    parent_code: "387",
  },
  {
    value: "19501",
    label: "Xã Trung Hải",
    parent_code: "466",
  },
  {
    value: "29683",
    label: "Xã Trung Hiệp",
    parent_code: "859",
  },
  {
    value: "29695",
    label: "Xã Trung Hiếu",
    parent_code: "859",
  },
  {
    value: "00175",
    label: "Phường Trung Hoà",
    parent_code: "005",
  },
  {
    value: "01948",
    label: "Xã Trung Hoà",
    parent_code: "062",
  },
  {
    value: "26281",
    label: "Xã Trung Hoà",
    parent_code: "737",
  },
  {
    value: "10051",
    label: "Xã Trung Hòa",
    parent_code: "277",
  },
  {
    value: "12085",
    label: "Xã Trung Hòa",
    parent_code: "327",
  },
  {
    value: "02347",
    label: "Xã Trung Hòa",
    parent_code: "073",
  },
  {
    value: "28597",
    label: "Xã Trung Hòa",
    parent_code: "822",
  },
  {
    value: "18943",
    label: "Xã Trung Hóa",
    parent_code: "452",
  },
  {
    value: "05581",
    label: "Xã Trung Hội",
    parent_code: "167",
  },
  {
    value: "09601",
    label: "Phường Trung Hưng",
    parent_code: "269",
  },
  {
    value: "12094",
    label: "Xã Trung Hưng",
    parent_code: "327",
  },
  {
    value: "31255",
    label: "Xã Trung Hưng",
    parent_code: "925",
  },
  {
    value: "09502",
    label: "Xã Trung Kênh",
    parent_code: "264",
  },
  {
    value: "01477",
    label: "Thị trấn Trùng Khánh",
    parent_code: "047",
  },
  {
    value: "06127",
    label: "Xã Trùng Khánh",
    parent_code: "182",
  },
  {
    value: "09061",
    label: "Xã Trung Kiên",
    parent_code: "251",
  },
  {
    value: "31219",
    label: "Phường Trung Kiên",
    parent_code: "923",
  },
  {
    value: "11836",
    label: "Xã Trung Lập",
    parent_code: "316",
  },
  {
    value: "27520",
    label: "Xã Trung Lập Hạ",
    parent_code: "783",
  },
  {
    value: "27505",
    label: "Xã Trung Lập Thượng",
    parent_code: "783",
  },
  {
    value: "02731",
    label: "Xã Trung Lèng Hồ",
    parent_code: "082",
  },
  {
    value: "00217",
    label: "Phường Trung Liệt",
    parent_code: "006",
  },
  {
    value: "18472",
    label: "Xã Trung Lộc",
    parent_code: "443",
  },
  {
    value: "05584",
    label: "Xã Trung Lương",
    parent_code: "167",
  },
  {
    value: "13546",
    label: "Xã Trung Lương",
    parent_code: "352",
  },
  {
    value: "18121",
    label: "Phường Trung Lương",
    parent_code: "437",
  },
  {
    value: "14857",
    label: "Xã Trung Lý",
    parent_code: "384",
  },
  {
    value: "00547",
    label: "Xã Trung Mầu",
    parent_code: "018",
  },
  {
    value: "02440",
    label: "Xã Trung Minh",
    parent_code: "075",
  },
  {
    value: "04918",
    label: "Phường Trung Minh",
    parent_code: "148",
  },
  {
    value: "02488",
    label: "Xã Trung Môn",
    parent_code: "075",
  },
  {
    value: "08938",
    label: "Xã Trung Mỹ",
    parent_code: "249",
  },
  {
    value: "26785",
    label: "Phường Trung Mỹ Tây",
    parent_code: "761",
  },
  {
    value: "19378",
    label: "Xã Trung Nam",
    parent_code: "464",
  },
  {
    value: "29698",
    label: "Xã Trung Ngãi",
    parent_code: "859",
  },
  {
    value: "09223",
    label: "Xã Trung Nghĩa",
    parent_code: "258",
  },
  {
    value: "11971",
    label: "Xã Trung Nghĩa",
    parent_code: "323",
  },
  {
    value: "29704",
    label: "Xã Trung Nghĩa",
    parent_code: "859",
  },
  {
    value: "09037",
    label: "Xã Trung Nguyên",
    parent_code: "251",
  },
  {
    value: "31216",
    label: "Phường Trung Nhứt",
    parent_code: "923",
  },
  {
    value: "01516",
    label: "Xã Trung Phúc",
    parent_code: "047",
  },
  {
    value: "17989",
    label: "Xã Trung Phúc Cường",
    parent_code: "430",
  },
  {
    value: "00211",
    label: "Phường Trung Phụng",
    parent_code: "006",
  },
  {
    value: "07780",
    label: "Xã Trung Sơn",
    parent_code: "222",
  },
  {
    value: "08311",
    label: "Xã Trung Sơn",
    parent_code: "234",
  },
  {
    value: "14365",
    label: "Phường Trung Sơn",
    parent_code: "370",
  },
  {
    value: "14830",
    label: "Phường Trung Sơn",
    parent_code: "382",
  },
  {
    value: "14875",
    label: "Xã Trung Sơn",
    parent_code: "385",
  },
  {
    value: "02458",
    label: "Xã Trung Sơn",
    parent_code: "075",
  },
  {
    value: "17686",
    label: "Xã Trung Sơn",
    parent_code: "427",
  },
  {
    value: "19504",
    label: "Xã Trung Sơn",
    parent_code: "466",
  },
  {
    value: "20056",
    label: "Xã Trung Sơn",
    parent_code: "481",
  },
  {
    value: "09607",
    label: "Phường Trung Sơn Trầm",
    parent_code: "269",
  },
  {
    value: "04285",
    label: "Phường Trung Tâm",
    parent_code: "133",
  },
  {
    value: "04372",
    label: "Xã Trung Tâm",
    parent_code: "135",
  },
  {
    value: "00979",
    label: "Xã Trung Thành",
    parent_code: "030",
  },
  {
    value: "05476",
    label: "Phường Trung Thành",
    parent_code: "164",
  },
  {
    value: "05899",
    label: "Xã Trung Thành",
    parent_code: "172",
  },
  {
    value: "06037",
    label: "Xã Trung Thành",
    parent_code: "180",
  },
  {
    value: "13765",
    label: "Xã Trung Thành",
    parent_code: "359",
  },
  {
    value: "14881",
    label: "Xã Trung Thành",
    parent_code: "385",
  },
  {
    value: "04870",
    label: "Xã Trung Thành",
    parent_code: "150",
  },
  {
    value: "16303",
    label: "Xã Trung Thành",
    parent_code: "404",
  },
  {
    value: "17575",
    label: "Xã Trung Thành",
    parent_code: "426",
  },
  {
    value: "29692",
    label: "Xã Trung Thành",
    parent_code: "859",
  },
  {
    value: "31225",
    label: "Xã Trung Thạnh",
    parent_code: "925",
  },
  {
    value: "29689",
    label: "Xã Trung Thành Đông",
    parent_code: "859",
  },
  {
    value: "29680",
    label: "Xã Trung Thành Tây",
    parent_code: "859",
  },
  {
    value: "01117",
    label: "Xã Trung Thịnh",
    parent_code: "033",
  },
  {
    value: "03238",
    label: "Xã Trung Thu",
    parent_code: "098",
  },
  {
    value: "14998",
    label: "Xã Trung Thượng",
    parent_code: "387",
  },
  {
    value: "14999",
    label: "Xã Trung Tiến",
    parent_code: "387",
  },
  {
    value: "19177",
    label: "Xã Trung Trạch",
    parent_code: "455",
  },
  {
    value: "02446",
    label: "Xã Trung Trực",
    parent_code: "075",
  },
  {
    value: "10387",
    label: "Xã Trung Tú",
    parent_code: "281",
  },
  {
    value: "00226",
    label: "Phường Trung Tự",
    parent_code: "006",
  },
  {
    value: "00637",
    label: "Phường Trung Văn",
    parent_code: "019",
  },
  {
    value: "14995",
    label: "Xã Trung Xuân",
    parent_code: "387",
  },
  {
    value: "02539",
    label: "Xã Trung Yên",
    parent_code: "076",
  },
  {
    value: "25582",
    label: "Xã Truông Mít",
    parent_code: "707",
  },
  {
    value: "25816",
    label: "Xã Trừ Văn Thố",
    parent_code: "719",
  },
  {
    value: "14032",
    label: "Xã Trực Chính",
    parent_code: "363",
  },
  {
    value: "14074",
    label: "Xã Trực Cường",
    parent_code: "363",
  },
  {
    value: "14071",
    label: "Xã Trực Đại",
    parent_code: "363",
  },
  {
    value: "14047",
    label: "Xã Trực Đạo",
    parent_code: "363",
  },
  {
    value: "14083",
    label: "Xã Trực Hùng",
    parent_code: "363",
  },
  {
    value: "14050",
    label: "Xã Trực Hưng",
    parent_code: "363",
  },
  {
    value: "14062",
    label: "Xã Trực Khang",
    parent_code: "363",
  },
  {
    value: "14068",
    label: "Xã Trực Mỹ",
    parent_code: "363",
  },
  {
    value: "14053",
    label: "Xã Trực Nội",
    parent_code: "363",
  },
  {
    value: "14080",
    label: "Xã Trực Thái",
    parent_code: "363",
  },
  {
    value: "14059",
    label: "Xã Trực Thanh",
    parent_code: "363",
  },
  {
    value: "14086",
    label: "Xã Trực Thắng",
    parent_code: "363",
  },
  {
    value: "14065",
    label: "Xã Trực Thuận",
    parent_code: "363",
  },
  {
    value: "14041",
    label: "Xã Trực Tuấn",
    parent_code: "363",
  },
  {
    value: "08740",
    label: "Phường Trưng Nhị",
    parent_code: "244",
  },
  {
    value: "08734",
    label: "Phường Trưng Trắc",
    parent_code: "244",
  },
  {
    value: "12013",
    label: "Xã Trưng Trắc",
    parent_code: "325",
  },
  {
    value: "05443",
    label: "Phường Trưng Vương",
    parent_code: "164",
  },
  {
    value: "06820",
    label: "Phường Trưng Vương",
    parent_code: "196",
  },
  {
    value: "07930",
    label: "Xã Trưng Vương",
    parent_code: "227",
  },
  {
    value: "09517",
    label: "Xã Trừng Xá",
    parent_code: "264",
  },
  {
    value: "19795",
    label: "Phường Trường An",
    parent_code: "474",
  },
  {
    value: "29572",
    label: "Phường Trường An",
    parent_code: "855",
  },
  {
    value: "23290",
    label: "Phường Trường Chinh",
    parent_code: "608",
  },
  {
    value: "00298",
    label: "Phường Trương Định",
    parent_code: "007",
  },
  {
    value: "25642",
    label: "Xã Trường Đông",
    parent_code: "709",
  },
  {
    value: "07471",
    label: "Xã Trường Giang",
    parent_code: "218",
  },
  {
    value: "16336",
    label: "Xã Trường Giang",
    parent_code: "404",
  },
  {
    value: "01399",
    label: "Xã Trường Hà",
    parent_code: "045",
  },
  {
    value: "25639",
    label: "Xã Trường Hòa",
    parent_code: "709",
  },
  {
    value: "31654",
    label: "Xã Trường Khánh",
    parent_code: "946",
  },
  {
    value: "31165",
    label: "Phường Trường Lạc",
    parent_code: "917",
  },
  {
    value: "16648",
    label: "Xã Trường Lâm",
    parent_code: "407",
  },
  {
    value: "31309",
    label: "Xã Trường Long",
    parent_code: "926",
  },
  {
    value: "31351",
    label: "Xã Trường Long A",
    parent_code: "932",
  },
  {
    value: "29527",
    label: "Xã Trường Long Hòa",
    parent_code: "851",
  },
  {
    value: "31348",
    label: "Xã Trường Long Tây",
    parent_code: "932",
  },
  {
    value: "01675",
    label: "Xã Trương Lương",
    parent_code: "051",
  },
  {
    value: "16345",
    label: "Xã Trường Minh",
    parent_code: "404",
  },
  {
    value: "21172",
    label: "Phường Trương Quang Trọng",
    parent_code: "522",
  },
  {
    value: "22736",
    label: "Thị trấn Trường Sa",
    parent_code: "576",
  },
  {
    value: "02632",
    label: "Xã Trường Sinh",
    parent_code: "076",
  },
  {
    value: "11656",
    label: "Thị trấn Trường Sơn",
    parent_code: "313",
  },
  {
    value: "07507",
    label: "Xã Trường Sơn",
    parent_code: "218",
  },
  {
    value: "14836",
    label: "Phường Trường Sơn",
    parent_code: "382",
  },
  {
    value: "16348",
    label: "Xã Trường Sơn",
    parent_code: "404",
  },
  {
    value: "18244",
    label: "Xã Trường Sơn",
    parent_code: "440",
  },
  {
    value: "19204",
    label: "Xã Trường Sơn",
    parent_code: "456",
  },
  {
    value: "25648",
    label: "Xã Trường Tây",
    parent_code: "709",
  },
  {
    value: "11638",
    label: "Xã Trường Thành",
    parent_code: "313",
  },
  {
    value: "31291",
    label: "Xã Trường Thành",
    parent_code: "927",
  },
  {
    value: "26854",
    label: "Phường Trường Thạnh",
    parent_code: "769",
  },
  {
    value: "31286",
    label: "Xã Trường Thắng",
    parent_code: "927",
  },
  {
    value: "13657",
    label: "Phường Trường Thi",
    parent_code: "356",
  },
  {
    value: "14764",
    label: "Phường Trường Thi",
    parent_code: "380",
  },
  {
    value: "16690",
    label: "Phường Trường Thi",
    parent_code: "412",
  },
  {
    value: "10369",
    label: "Xã Trường Thịnh",
    parent_code: "281",
  },
  {
    value: "11635",
    label: "Xã Trường Thọ",
    parent_code: "313",
  },
  {
    value: "26827",
    label: "Phường Trường Thọ",
    parent_code: "769",
  },
  {
    value: "29449",
    label: "Xã Trường Thọ",
    parent_code: "848",
  },
  {
    value: "19321",
    label: "Xã Trường Thủy",
    parent_code: "457",
  },
  {
    value: "16330",
    label: "Xã Trường Trung",
    parent_code: "404",
  },
  {
    value: "15598",
    label: "Xã Trường Xuân",
    parent_code: "395",
  },
  {
    value: "24730",
    label: "Xã Trường Xuân",
    parent_code: "665",
  },
  {
    value: "20353",
    label: "Phường Trường Xuân",
    parent_code: "502",
  },
  {
    value: "19228",
    label: "Xã Trường Xuân",
    parent_code: "456",
  },
  {
    value: "30046",
    label: "Xã Trường Xuân",
    parent_code: "872",
  },
  {
    value: "31294",
    label: "Xã Trường Xuân",
    parent_code: "927",
  },
  {
    value: "31297",
    label: "Xã Trường Xuân A",
    parent_code: "927",
  },
  {
    value: "31298",
    label: "Xã Trường Xuân B",
    parent_code: "927",
  },
  {
    value: "10039",
    label: "Xã Trường Yên",
    parent_code: "277",
  },
  {
    value: "14533",
    label: "Xã Trường Yên",
    parent_code: "374",
  },
  {
    value: "23626",
    label: "Xã Tú An",
    parent_code: "623",
  },
  {
    value: "06562",
    label: "Xã Tú Đoạn",
    parent_code: "188",
  },
  {
    value: "04630",
    label: "Xã Tú Lệ",
    parent_code: "140",
  },
  {
    value: "04867",
    label: "Xã Tú Lý",
    parent_code: "150",
  },
  {
    value: "06547",
    label: "Xã Tú Mịch",
    parent_code: "188",
  },
  {
    value: "23422",
    label: "Xã Tu Mơ Rông",
    parent_code: "617",
  },
  {
    value: "04093",
    label: "Xã Tú Nang",
    parent_code: "124",
  },
  {
    value: "01048",
    label: "Xã Tụ Nhân",
    parent_code: "032",
  },
  {
    value: "11749",
    label: "Xã Tú Sơn",
    parent_code: "314",
  },
  {
    value: "04999",
    label: "Xã Tú Sơn",
    parent_code: "153",
  },
  {
    value: "02560",
    label: "Xã Tú Thịnh",
    parent_code: "076",
  },
  {
    value: "24952",
    label: "Xã Tu Tra",
    parent_code: "677",
  },
  {
    value: "08701",
    label: "Xã Tu Vũ",
    parent_code: "239",
  },
  {
    value: "06277",
    label: "Xã Tú Xuyên",
    parent_code: "184",
  },
  {
    value: "03217",
    label: "Thị trấn Tủa Chùa",
    parent_code: "098",
  },
  {
    value: "03541",
    label: "Xã Tủa Sín Chải",
    parent_code: "108",
  },
  {
    value: "03235",
    label: "Xã Tủa Thàng",
    parent_code: "098",
  },
  {
    value: "06700",
    label: "Phường Tuần Châu",
    parent_code: "193",
  },
  {
    value: "09136",
    label: "Xã Tuân Chính",
    parent_code: "252",
  },
  {
    value: "05278",
    label: "Xã Tuân Đạo",
    parent_code: "157",
  },
  {
    value: "07663",
    label: "Xã Tuấn Đạo",
    parent_code: "220",
  },
  {
    value: "03253",
    label: "Thị trấn Tuần Giáo",
    parent_code: "099",
  },
  {
    value: "31768",
    label: "Xã Tuân Tức",
    parent_code: "949",
  },
  {
    value: "10768",
    label: "Xã Tuấn Việt",
    parent_code: "293",
  },
  {
    value: "05437",
    label: "Phường Túc Duyên",
    parent_code: "164",
  },
  {
    value: "04588",
    label: "Xã Túc Đán",
    parent_code: "139",
  },
  {
    value: "26239",
    label: "Xã Túc Trưng",
    parent_code: "736",
  },
  {
    value: "18259",
    label: "Xã Tùng Ảnh",
    parent_code: "440",
  },
  {
    value: "00925",
    label: "Xã Tùng Bá",
    parent_code: "030",
  },
  {
    value: "18241",
    label: "Xã Tùng Châu",
    parent_code: "440",
  },
  {
    value: "02758",
    label: "Xã Tung Chung Phố",
    parent_code: "083",
  },
  {
    value: "08374",
    label: "Xã Tùng Khê",
    parent_code: "235",
  },
  {
    value: "16639",
    label: "Xã Tùng Lâm",
    parent_code: "407",
  },
  {
    value: "18445",
    label: "Xã Tùng Lộc",
    parent_code: "443",
  },
  {
    value: "01039",
    label: "Xã Túng Sán",
    parent_code: "032",
  },
  {
    value: "00892",
    label: "Xã Tùng Vài",
    parent_code: "029",
  },
  {
    value: "10450",
    label: "Xã Tuy Lai",
    parent_code: "282",
  },
  {
    value: "08347",
    label: "Xã Tuy Lộc",
    parent_code: "235",
  },
  {
    value: "04276",
    label: "Xã Tuy Lộc",
    parent_code: "132",
  },
  {
    value: "16039",
    label: "Xã Tuy Lộc",
    parent_code: "400",
  },
  {
    value: "21952",
    label: "Thị trấn Tuy Phước",
    parent_code: "550",
  },
  {
    value: "27781",
    label: "Xã Tuyên Bình",
    parent_code: "797",
  },
  {
    value: "27784",
    label: "Xã Tuyên Bình Tây",
    parent_code: "797",
  },
  {
    value: "27805",
    label: "Xã Tuyên Thạnh",
    parent_code: "795",
  },
  {
    value: "09925",
    label: "Xã Tuyết Nghĩa",
    parent_code: "275",
  },
  {
    value: "24148",
    label: "Phường Tự An",
    parent_code: "643",
  },
  {
    value: "11269",
    label: "Xã Tứ Cường",
    parent_code: "300",
  },
  {
    value: "11764",
    label: "Xã Tự Cường",
    parent_code: "315",
  },
  {
    value: "12226",
    label: "Xã Tứ Dân",
    parent_code: "330",
  },
  {
    value: "01609",
    label: "Xã Tự Do",
    parent_code: "049",
  },
  {
    value: "05338",
    label: "Xã Tự Do",
    parent_code: "157",
  },
  {
    value: "08815",
    label: "Xã Tử Du",
    parent_code: "246",
  },
  {
    value: "19996",
    label: "Phường Tứ Hạ",
    parent_code: "480",
  },
  {
    value: "00658",
    label: "Xã Tứ Hiệp",
    parent_code: "020",
  },
  {
    value: "08071",
    label: "Xã Tứ Hiệp",
    parent_code: "231",
  },
  {
    value: "11074",
    label: "Thị trấn Tứ Kỳ",
    parent_code: "298",
  },
  {
    value: "07774",
    label: "Xã Tự Lạn",
    parent_code: "222",
  },
  {
    value: "08986",
    label: "Xã Tự Lập",
    parent_code: "250",
  },
  {
    value: "00097",
    label: "Phường Tứ Liên",
    parent_code: "003",
  },
  {
    value: "07741",
    label: "Xã Tư Mại",
    parent_code: "221",
  },
  {
    value: "10540",
    label: "Phường Tứ Minh",
    parent_code: "288",
  },
  {
    value: "05164",
    label: "Xã Tử Nê",
    parent_code: "155",
  },
  {
    value: "10219",
    label: "Xã Tự Nhiên",
    parent_code: "279",
  },
  {
    value: "13246",
    label: "Xã Tự Tân",
    parent_code: "344",
  },
  {
    value: "09145",
    label: "Thị trấn Tứ Trưng",
    parent_code: "252",
  },
  {
    value: "08536",
    label: "Xã Tứ Xã",
    parent_code: "237",
  },
  {
    value: "08851",
    label: "Xã Tứ Yên",
    parent_code: "253",
  },
  {
    value: "05641",
    label: "Xã Tức Tranh",
    parent_code: "168",
  },
  {
    value: "25771",
    label: "Phường Tương Bình Hiệp",
    parent_code: "718",
  },
  {
    value: "28837",
    label: "Xã Tường Đa",
    parent_code: "831",
  },
  {
    value: "09376",
    label: "Phường Tương Giang",
    parent_code: "261",
  },
  {
    value: "03958",
    label: "Xã Tường Hạ",
    parent_code: "122",
  },
  {
    value: "13396",
    label: "Xã Tượng Lĩnh",
    parent_code: "350",
  },
  {
    value: "16363",
    label: "Xã Tượng Lĩnh",
    parent_code: "404",
  },
  {
    value: "29758",
    label: "Xã Tường Lộc",
    parent_code: "860",
  },
  {
    value: "00313",
    label: "Phường Tương Mai",
    parent_code: "008",
  },
  {
    value: "03955",
    label: "Xã Tường Phong",
    parent_code: "122",
  },
  {
    value: "03925",
    label: "Xã Tường Phù",
    parent_code: "122",
  },
  {
    value: "17356",
    label: "Xã Tường Sơn",
    parent_code: "424",
  },
  {
    value: "16366",
    label: "Xã Tượng Sơn",
    parent_code: "404",
  },
  {
    value: "18628",
    label: "Xã Tượng Sơn",
    parent_code: "445",
  },
  {
    value: "03949",
    label: "Xã Tường Thượng",
    parent_code: "122",
  },
  {
    value: "03952",
    label: "Xã Tường Tiến",
    parent_code: "122",
  },
  {
    value: "16357",
    label: "Xã Tượng Văn",
    parent_code: "404",
  },
  {
    value: "32044",
    label: "Thị trấn U Minh",
    parent_code: "966",
  },
  {
    value: "24109",
    label: "Xã Uar",
    parent_code: "637",
  },
  {
    value: "05950",
    label: "Xã Úc Kỳ",
    parent_code: "173",
  },
  {
    value: "00478",
    label: "Xã Uy Nỗ",
    parent_code: "017",
  },
  {
    value: "25888",
    label: "Phường Uyên Hưng",
    parent_code: "723",
  },
  {
    value: "11161",
    label: "Xã Ứng Hoè",
    parent_code: "299",
  },
  {
    value: "31327",
    label: "Phường V",
    parent_code: "930",
  },
  {
    value: "28720",
    label: "Thị trấn Vàm Láng",
    parent_code: "824",
  },
  {
    value: "09226",
    label: "Phường Vạn An",
    parent_code: "256",
  },
  {
    value: "22501",
    label: "Xã Vạn Bình",
    parent_code: "571",
  },
  {
    value: "10264",
    label: "Xã Vạn Điểm",
    parent_code: "279",
  },
  {
    value: "22489",
    label: "Thị trấn Vạn Giã",
    parent_code: "571",
  },
  {
    value: "02665",
    label: "Xã Vạn Hoà",
    parent_code: "080",
  },
  {
    value: "16327",
    label: "Xã Vạn Hòa",
    parent_code: "404",
  },
  {
    value: "22525",
    label: "Xã Vạn Hưng",
    parent_code: "571",
  },
  {
    value: "11461",
    label: "Phường Vạn Hương",
    parent_code: "308",
  },
  {
    value: "22507",
    label: "Xã Vạn Khánh",
    parent_code: "571",
  },
  {
    value: "10483",
    label: "Xã Vạn Kim",
    parent_code: "282",
  },
  {
    value: "06505",
    label: "Xã Vạn Linh",
    parent_code: "187",
  },
  {
    value: "22498",
    label: "Xã Vạn Long",
    parent_code: "571",
  },
  {
    value: "22513",
    label: "Xã Vạn Lương",
    parent_code: "571",
  },
  {
    value: "05263",
    label: "Xã Vạn Mai",
    parent_code: "156",
  },
  {
    value: "11335",
    label: "Phường Vạn Mỹ",
    parent_code: "304",
  },
  {
    value: "09457",
    label: "Xã Vạn Ninh",
    parent_code: "263",
  },
  {
    value: "06748",
    label: "Xã Vạn Ninh",
    parent_code: "194",
  },
  {
    value: "19243",
    label: "Xã Vạn Ninh",
    parent_code: "456",
  },
  {
    value: "05887",
    label: "Xã Vạn Phái",
    parent_code: "172",
  },
  {
    value: "22510",
    label: "Xã Vạn Phú",
    parent_code: "571",
  },
  {
    value: "00676",
    label: "Xã Vạn Phúc",
    parent_code: "020",
  },
  {
    value: "09544",
    label: "Phường Vạn Phúc",
    parent_code: "268",
  },
  {
    value: "11176",
    label: "Xã Vạn Phúc",
    parent_code: "299",
  },
  {
    value: "22495",
    label: "Xã Vạn Phước",
    parent_code: "571",
  },
  {
    value: "10396",
    label: "Xã Vạn Thái",
    parent_code: "281",
  },
  {
    value: "22348",
    label: "Phường Vạn Thạnh",
    parent_code: "568",
  },
  {
    value: "22519",
    label: "Xã Vạn Thạnh",
    parent_code: "571",
  },
  {
    value: "09634",
    label: "Xã Vạn Thắng",
    parent_code: "271",
  },
  {
    value: "16333",
    label: "Xã Vạn Thắng",
    parent_code: "404",
  },
  {
    value: "22345",
    label: "Phường Vạn Thắng",
    parent_code: "568",
  },
  {
    value: "22516",
    label: "Xã Vạn Thắng",
    parent_code: "571",
  },
  {
    value: "16339",
    label: "Xã Vạn Thiện",
    parent_code: "404",
  },
  {
    value: "05839",
    label: "Xã Vạn Thọ",
    parent_code: "171",
  },
  {
    value: "22504",
    label: "Xã Vạn Thọ",
    parent_code: "571",
  },
  {
    value: "06331",
    label: "Xã Vạn Thủy",
    parent_code: "185",
  },
  {
    value: "19168",
    label: "Xã Vạn Trạch",
    parent_code: "455",
  },
  {
    value: "08467",
    label: "Xã Vạn Xuân",
    parent_code: "236",
  },
  {
    value: "15622",
    label: "Xã Vạn Xuân",
    parent_code: "396",
  },
  {
    value: "09001",
    label: "Xã Vạn Yên",
    parent_code: "250",
  },
  {
    value: "07003",
    label: "Xã Vạn Yên",
    parent_code: "203",
  },
  {
    value: "06808",
    label: "Phường Vàng Danh",
    parent_code: "196",
  },
  {
    value: "03176",
    label: "Xã Vàng Đán",
    parent_code: "103",
  },
  {
    value: "03562",
    label: "Xã Vàng Ma Chải",
    parent_code: "109",
  },
  {
    value: "29068",
    label: "Xã Vang Quới Đông",
    parent_code: "835",
  },
  {
    value: "29065",
    label: "Xã Vang Quới Tây",
    parent_code: "835",
  },
  {
    value: "03467",
    label: "Xã Vàng San",
    parent_code: "107",
  },
  {
    value: "10579",
    label: "Phường Văn An",
    parent_code: "290",
  },
  {
    value: "08380",
    label: "Xã Văn Bán",
    parent_code: "235",
  },
  {
    value: "10201",
    label: "Xã Văn Bình",
    parent_code: "279",
  },
  {
    value: "12625",
    label: "Xã Văn Cẩm",
    parent_code: "339",
  },
  {
    value: "00193",
    label: "Phường Văn Chương",
    parent_code: "006",
  },
  {
    value: "11446",
    label: "Phường Văn Đẩu",
    parent_code: "307",
  },
  {
    value: "00640",
    label: "Thị trấn Văn Điển",
    parent_code: "020",
  },
  {
    value: "00589",
    label: "Xã Văn Đức",
    parent_code: "018",
  },
  {
    value: "10585",
    label: "Phường Văn Đức",
    parent_code: "290",
  },
  {
    value: "12019",
    label: "Thị trấn Văn Giang",
    parent_code: "326",
  },
  {
    value: "30523",
    label: "Xã Văn Giáo",
    parent_code: "890",
  },
  {
    value: "14680",
    label: "Xã Văn Hải",
    parent_code: "376",
  },
  {
    value: "22777",
    label: "Phường Văn Hải",
    parent_code: "582",
  },
  {
    value: "05680",
    label: "Xã Văn Hán",
    parent_code: "169",
  },
  {
    value: "19006",
    label: "Xã Văn Hóa",
    parent_code: "453",
  },
  {
    value: "10297",
    label: "Xã Văn Hoàng",
    parent_code: "280",
  },
  {
    value: "11218",
    label: "Xã Văn Hội",
    parent_code: "299",
  },
  {
    value: "09013",
    label: "Xã Văn Khê",
    parent_code: "250",
  },
  {
    value: "08419",
    label: "Xã Văn Khúc",
    parent_code: "235",
  },
  {
    value: "08134",
    label: "Xã Văn Lang",
    parent_code: "231",
  },
  {
    value: "12673",
    label: "Xã Văn Lang",
    parent_code: "339",
  },
  {
    value: "02140",
    label: "Xã Văn Lang",
    parent_code: "066",
  },
  {
    value: "05665",
    label: "Xã Văn Lăng",
    parent_code: "169",
  },
  {
    value: "23431",
    label: "Xã Văn Lem",
    parent_code: "612",
  },
  {
    value: "17083",
    label: "Xã Văn Lợi",
    parent_code: "420",
  },
  {
    value: "07957",
    label: "Xã Văn Lung",
    parent_code: "228",
  },
  {
    value: "08596",
    label: "Xã Văn Luông",
    parent_code: "240",
  },
  {
    value: "13585",
    label: "Xã Văn Lý",
    parent_code: "353",
  },
  {
    value: "00181",
    label: "Phường Văn Miếu",
    parent_code: "006",
  },
  {
    value: "08611",
    label: "Xã Văn Miếu",
    parent_code: "238",
  },
  {
    value: "13675",
    label: "Phường Văn Miếu",
    parent_code: "356",
  },
  {
    value: "02170",
    label: "Xã Văn Minh",
    parent_code: "066",
  },
  {
    value: "09238",
    label: "Xã Văn Môn",
    parent_code: "258",
  },
  {
    value: "05281",
    label: "Xã Văn Nghĩa",
    parent_code: "157",
  },
  {
    value: "14977",
    label: "Xã Văn Nho",
    parent_code: "386",
  },
  {
    value: "12175",
    label: "Xã Văn Nhuệ",
    parent_code: "329",
  },
  {
    value: "11929",
    label: "Xã Văn Phong",
    parent_code: "317",
  },
  {
    value: "14428",
    label: "Xã Văn Phong",
    parent_code: "372",
  },
  {
    value: "10216",
    label: "Xã Văn Phú",
    parent_code: "279",
  },
  {
    value: "14443",
    label: "Xã Văn Phú",
    parent_code: "372",
  },
  {
    value: "02596",
    label: "Xã Văn Phú",
    parent_code: "076",
  },
  {
    value: "04558",
    label: "Xã Văn Phú",
    parent_code: "132",
  },
  {
    value: "14431",
    label: "Xã Văn Phương",
    parent_code: "372",
  },
  {
    value: "06253",
    label: "Thị trấn Văn Quan",
    parent_code: "184",
  },
  {
    value: "09542",
    label: "Phường Văn Quán",
    parent_code: "268",
  },
  {
    value: "08845",
    label: "Xã Văn Quán",
    parent_code: "246",
  },
  {
    value: "05284",
    label: "Xã Văn Sơn",
    parent_code: "157",
  },
  {
    value: "15712",
    label: "Xã Văn Sơn",
    parent_code: "397",
  },
  {
    value: "17665",
    label: "Xã Văn Sơn",
    parent_code: "427",
  },
  {
    value: "17557",
    label: "Xã Văn Thành",
    parent_code: "426",
  },
  {
    value: "09049",
    label: "Xã Văn Tiến",
    parent_code: "251",
  },
  {
    value: "11131",
    label: "Xã Văn Tố",
    parent_code: "298",
  },
  {
    value: "10261",
    label: "Xã Văn Tự",
    parent_code: "279",
  },
  {
    value: "10102",
    label: "Xã Văn Võ",
    parent_code: "277",
  },
  {
    value: "02137",
    label: "Xã Văn Vũ",
    parent_code: "066",
  },
  {
    value: "13417",
    label: "Xã Văn Xá",
    parent_code: "350",
  },
  {
    value: "23449",
    label: "Xã Văn Xuôi",
    parent_code: "617",
  },
  {
    value: "05842",
    label: "Xã Văn Yên",
    parent_code: "171",
  },
  {
    value: "18097",
    label: "Phường Văn Yên",
    parent_code: "436",
  },
  {
    value: "06469",
    label: "Xã Vân An",
    parent_code: "187",
  },
  {
    value: "15076",
    label: "Xã Vân Âm",
    parent_code: "389",
  },
  {
    value: "09862",
    label: "Xã Vân Canh",
    parent_code: "274",
  },
  {
    value: "21994",
    label: "Thị trấn Vân Canh",
    parent_code: "551",
  },
  {
    value: "00760",
    label: "Xã Vần Chải",
    parent_code: "026",
  },
  {
    value: "09883",
    label: "Xã Vân Côn",
    parent_code: "274",
  },
  {
    value: "07891",
    label: "Phường Vân Cơ",
    parent_code: "227",
  },
  {
    value: "12160",
    label: "Xã Vân Du",
    parent_code: "329",
  },
  {
    value: "07984",
    label: "Xã Vân Du",
    parent_code: "230",
  },
  {
    value: "15190",
    label: "Thị trấn Vân Du",
    parent_code: "391",
  },
  {
    value: "09271",
    label: "Phường Vân Dương",
    parent_code: "256",
  },
  {
    value: "10354",
    label: "Thị trấn Vân Đình",
    parent_code: "281",
  },
  {
    value: "08035",
    label: "Xã Vân Đồn",
    parent_code: "230",
  },
  {
    value: "14329",
    label: "Phường Vân Giang",
    parent_code: "369",
  },
  {
    value: "00475",
    label: "Xã Vân Hà",
    parent_code: "017",
  },
  {
    value: "09718",
    label: "Xã Vân Hà",
    parent_code: "272",
  },
  {
    value: "07804",
    label: "Xã Vân Hà",
    parent_code: "222",
  },
  {
    value: "09706",
    label: "Xã Vân Hòa",
    parent_code: "271",
  },
  {
    value: "04048",
    label: "Xã Vân Hồ",
    parent_code: "128",
  },
  {
    value: "08902",
    label: "Xã Vân Hội",
    parent_code: "247",
  },
  {
    value: "04582",
    label: "Xã Vân Hội",
    parent_code: "138",
  },
  {
    value: "31042",
    label: "Xã Vân Khánh",
    parent_code: "909",
  },
  {
    value: "31045",
    label: "Xã Vân Khánh Đông",
    parent_code: "909",
  },
  {
    value: "31048",
    label: "Xã Vân Khánh Tây",
    parent_code: "909",
  },
  {
    value: "08156",
    label: "Xã Vân Lĩnh",
    parent_code: "232",
  },
  {
    value: "09724",
    label: "Xã Vân Nam",
    parent_code: "272",
  },
  {
    value: "06433",
    label: "Xã Vân Nham",
    parent_code: "186",
  },
  {
    value: "00481",
    label: "Xã Vân Nội",
    parent_code: "017",
  },
  {
    value: "07918",
    label: "Phường Vân Phú",
    parent_code: "227",
  },
  {
    value: "09721",
    label: "Xã Vân Phúc",
    parent_code: "272",
  },
  {
    value: "05176",
    label: "Xã Vân Sơn",
    parent_code: "155",
  },
  {
    value: "07621",
    label: "Xã Vân Sơn",
    parent_code: "220",
  },
  {
    value: "02593",
    label: "Xã Vân Sơn",
    parent_code: "076",
  },
  {
    value: "10210",
    label: "Xã Vân Tảo",
    parent_code: "279",
  },
  {
    value: "06472",
    label: "Xã Vân Thủy",
    parent_code: "187",
  },
  {
    value: "01807",
    label: "Xã Vân Trình",
    parent_code: "053",
  },
  {
    value: "08797",
    label: "Xã Vân Trục",
    parent_code: "246",
  },
  {
    value: "07801",
    label: "Xã Vân Trung",
    parent_code: "222",
  },
  {
    value: "13039",
    label: "Xã Vân Trường",
    parent_code: "342",
  },
  {
    value: "01954",
    label: "Xã Vân Tùng",
    parent_code: "062",
  },
  {
    value: "10330",
    label: "Xã Vân Từ",
    parent_code: "280",
  },
  {
    value: "09139",
    label: "Xã Vân Xuân",
    parent_code: "252",
  },
  {
    value: "09664",
    label: "Xã Vật Lại",
    parent_code: "271",
  },
  {
    value: "04891",
    label: "Xã Vầy Nưa",
    parent_code: "150",
  },
  {
    value: "09175",
    label: "Phường Vệ An",
    parent_code: "256",
  },
  {
    value: "31468",
    label: "Xã Vị Bình",
    parent_code: "935",
  },
  {
    value: "31462",
    label: "Xã Vị Đông",
    parent_code: "935",
  },
  {
    value: "13639",
    label: "Phường Vị Hoàng",
    parent_code: "356",
  },
  {
    value: "01975",
    label: "Xã Vi Hương",
    parent_code: "063",
  },
  {
    value: "31333",
    label: "Xã Vị Tân",
    parent_code: "930",
  },
  {
    value: "31465",
    label: "Xã Vị Thanh",
    parent_code: "935",
  },
  {
    value: "31450",
    label: "Xã Vị Thắng",
    parent_code: "935",
  },
  {
    value: "31447",
    label: "Xã Vị Thuỷ",
    parent_code: "935",
  },
  {
    value: "01264",
    label: "Xã Vĩ Thượng",
    parent_code: "035",
  },
  {
    value: "31444",
    label: "Xã Vị Trung",
    parent_code: "935",
  },
  {
    value: "00913",
    label: "Thị trấn Vị Xuyên",
    parent_code: "030",
  },
  {
    value: "13642",
    label: "Phường Vị Xuyên",
    parent_code: "356",
  },
  {
    value: "10357",
    label: "Xã Viên An",
    parent_code: "281",
  },
  {
    value: "31696",
    label: "Xã Viên An",
    parent_code: "951",
  },
  {
    value: "32242",
    label: "Xã Viên An",
    parent_code: "973",
  },
  {
    value: "32239",
    label: "Xã Viên An Đông",
    parent_code: "973",
  },
  {
    value: "31705",
    label: "Xã Viên Bình",
    parent_code: "951",
  },
  {
    value: "10360",
    label: "Xã Viên Nội",
    parent_code: "281",
  },
  {
    value: "09595",
    label: "Phường Viên Sơn",
    parent_code: "269",
  },
  {
    value: "04447",
    label: "Xã Viễn Sơn",
    parent_code: "136",
  },
  {
    value: "17596",
    label: "Xã Viên Thành",
    parent_code: "426",
  },
  {
    value: "04075",
    label: "Xã Viêng Lán",
    parent_code: "124",
  },
  {
    value: "12082",
    label: "Xã Việt Cường",
    parent_code: "327",
  },
  {
    value: "04564",
    label: "Xã Việt Cường",
    parent_code: "138",
  },
  {
    value: "07084",
    label: "Xã Việt Dân",
    parent_code: "205",
  },
  {
    value: "09346",
    label: "Xã Việt Đoàn",
    parent_code: "260",
  },
  {
    value: "11944",
    label: "Xã Việt Hải",
    parent_code: "317",
  },
  {
    value: "10543",
    label: "Phường Việt Hoà",
    parent_code: "288",
  },
  {
    value: "12256",
    label: "Xã Việt Hòa",
    parent_code: "330",
  },
  {
    value: "01198",
    label: "Xã Việt Hồng",
    parent_code: "034",
  },
  {
    value: "10819",
    label: "Xã Việt Hồng",
    parent_code: "294",
  },
  {
    value: "04579",
    label: "Xã Việt Hồng",
    parent_code: "138",
  },
  {
    value: "00487",
    label: "Xã Việt Hùng",
    parent_code: "017",
  },
  {
    value: "09283",
    label: "Xã Việt Hùng",
    parent_code: "259",
  },
  {
    value: "13219",
    label: "Xã Việt Hùng",
    parent_code: "344",
  },
  {
    value: "14044",
    label: "Xã Việt Hùng",
    parent_code: "363",
  },
  {
    value: "00127",
    label: "Phường Việt Hưng",
    parent_code: "004",
  },
  {
    value: "11998",
    label: "Xã Việt Hưng",
    parent_code: "325",
  },
  {
    value: "06703",
    label: "Phường Việt Hưng",
    parent_code: "193",
  },
  {
    value: "00967",
    label: "Xã Việt Lâm",
    parent_code: "030",
  },
  {
    value: "07354",
    label: "Xã Việt Lập",
    parent_code: "216",
  },
  {
    value: "00421",
    label: "Xã Việt Long",
    parent_code: "016",
  },
  {
    value: "07342",
    label: "Xã Việt Ngọc",
    parent_code: "216",
  },
  {
    value: "01153",
    label: "Thị trấn Việt Quang",
    parent_code: "034",
  },
  {
    value: "04510",
    label: "Xã Việt Thành",
    parent_code: "138",
  },
  {
    value: "32224",
    label: "Xã Việt Thắng",
    parent_code: "972",
  },
  {
    value: "09250",
    label: "Xã Việt Thống",
    parent_code: "259",
  },
  {
    value: "13264",
    label: "Xã Việt Thuận",
    parent_code: "344",
  },
  {
    value: "11839",
    label: "Xã Việt Tiến",
    parent_code: "316",
  },
  {
    value: "07762",
    label: "Xã Việt Tiến",
    parent_code: "222",
  },
  {
    value: "02983",
    label: "Xã Việt Tiến",
    parent_code: "087",
  },
  {
    value: "18601",
    label: "Xã Việt Tiến",
    parent_code: "445",
  },
  {
    value: "01183",
    label: "Xã Việt Vinh",
    parent_code: "034",
  },
  {
    value: "09094",
    label: "Xã Việt Xuân",
    parent_code: "252",
  },
  {
    value: "31330",
    label: "Phường VII",
    parent_code: "930",
  },
  {
    value: "19948",
    label: "Xã Vinh An",
    parent_code: "478",
  },
  {
    value: "11842",
    label: "Xã Vĩnh An",
    parent_code: "316",
  },
  {
    value: "07648",
    label: "Xã Vĩnh An",
    parent_code: "220",
  },
  {
    value: "15391",
    label: "Xã Vĩnh An",
    parent_code: "393",
  },
  {
    value: "26170",
    label: "Thị trấn Vĩnh An",
    parent_code: "735",
  },
  {
    value: "21841",
    label: "Xã Vĩnh An",
    parent_code: "547",
  },
  {
    value: "29170",
    label: "Xã Vĩnh An",
    parent_code: "836",
  },
  {
    value: "30610",
    label: "Xã Vĩnh An",
    parent_code: "892",
  },
  {
    value: "11824",
    label: "Thị trấn Vĩnh Bảo",
    parent_code: "316",
  },
  {
    value: "30742",
    label: "Phường Vĩnh Bảo",
    parent_code: "899",
  },
  {
    value: "27775",
    label: "Xã Vĩnh Bình",
    parent_code: "797",
  },
  {
    value: "28651",
    label: "Thị trấn Vĩnh Bình",
    parent_code: "823",
  },
  {
    value: "28879",
    label: "Xã Vĩnh Bình",
    parent_code: "832",
  },
  {
    value: "30604",
    label: "Thị trấn Vĩnh Bình",
    parent_code: "892",
  },
  {
    value: "31211",
    label: "Xã Vĩnh Bình",
    parent_code: "924",
  },
  {
    value: "31918",
    label: "Xã Vĩnh Bình",
    parent_code: "961",
  },
  {
    value: "31060",
    label: "Xã Vĩnh Bình Bắc",
    parent_code: "910",
  },
  {
    value: "31063",
    label: "Xã Vĩnh Bình Nam",
    parent_code: "910",
  },
  {
    value: "27754",
    label: "Xã Vĩnh Bửu",
    parent_code: "796",
  },
  {
    value: "30703",
    label: "Xã Vĩnh Chánh",
    parent_code: "894",
  },
  {
    value: "08143",
    label: "Xã Vĩnh Chân",
    parent_code: "231",
  },
  {
    value: "19375",
    label: "Xã Vĩnh Chấp",
    parent_code: "464",
  },
  {
    value: "30334",
    label: "Xã Vĩnh Châu",
    parent_code: "884",
  },
  {
    value: "27751",
    label: "Xã Vĩnh Châu A",
    parent_code: "796",
  },
  {
    value: "27742",
    label: "Xã Vĩnh Châu B",
    parent_code: "796",
  },
  {
    value: "28222",
    label: "Xã Vĩnh Công",
    parent_code: "808",
  },
  {
    value: "27748",
    label: "Xã Vĩnh Đại",
    parent_code: "796",
  },
  {
    value: "20551",
    label: "Phường Vĩnh Điện",
    parent_code: "507",
  },
  {
    value: "30793",
    label: "Xã Vĩnh Điều",
    parent_code: "914",
  },
  {
    value: "05026",
    label: "Xã Vĩnh Đồng",
    parent_code: "153",
  },
  {
    value: "30556",
    label: "Xã Vĩnh Gia",
    parent_code: "891",
  },
  {
    value: "19423",
    label: "Xã Vĩnh Giang",
    parent_code: "464",
  },
  {
    value: "19957",
    label: "Xã Vinh Hà",
    parent_code: "478",
  },
  {
    value: "19417",
    label: "Xã Vĩnh Hà",
    parent_code: "464",
  },
  {
    value: "22330",
    label: "Phường Vĩnh Hải",
    parent_code: "568",
  },
  {
    value: "22846",
    label: "Xã Vĩnh Hải",
    parent_code: "586",
  },
  {
    value: "31795",
    label: "Xã Vĩnh Hải",
    parent_code: "950",
  },
  {
    value: "30598",
    label: "Xã Vĩnh Hanh",
    parent_code: "892",
  },
  {
    value: "13792",
    label: "Xã Vĩnh Hào",
    parent_code: "359",
  },
  {
    value: "01210",
    label: "Xã Vĩnh Hảo",
    parent_code: "034",
  },
  {
    value: "22981",
    label: "Xã Vĩnh Hảo",
    parent_code: "595",
  },
  {
    value: "21799",
    label: "Xã Vĩnh Hảo",
    parent_code: "546",
  },
  {
    value: "30364",
    label: "Xã Vĩnh Hậu",
    parent_code: "886",
  },
  {
    value: "31927",
    label: "Xã Vĩnh Hậu",
    parent_code: "961",
  },
  {
    value: "31930",
    label: "Xã Vĩnh Hậu A",
    parent_code: "961",
  },
  {
    value: "20125",
    label: "Xã Vinh Hiền",
    parent_code: "482",
  },
  {
    value: "22399",
    label: "Xã Vĩnh Hiệp",
    parent_code: "568",
  },
  {
    value: "21796",
    label: "Xã Vĩnh Hiệp",
    parent_code: "546",
  },
  {
    value: "30739",
    label: "Phường Vĩnh Hiệp",
    parent_code: "899",
  },
  {
    value: "31792",
    label: "Xã Vĩnh Hiệp",
    parent_code: "950",
  },
  {
    value: "25882",
    label: "Xã Vĩnh Hoà",
    parent_code: "722",
  },
  {
    value: "11185",
    label: "Xã Vĩnh Hòa",
    parent_code: "299",
  },
  {
    value: "15376",
    label: "Xã Vĩnh Hòa",
    parent_code: "393",
  },
  {
    value: "22327",
    label: "Phường Vĩnh Hòa",
    parent_code: "568",
  },
  {
    value: "19396",
    label: "Xã Vĩnh Hòa",
    parent_code: "464",
  },
  {
    value: "21801",
    label: "Xã Vĩnh Hòa",
    parent_code: "546",
  },
  {
    value: "28897",
    label: "Xã Vĩnh Hòa",
    parent_code: "832",
  },
  {
    value: "29164",
    label: "Xã Vĩnh Hòa",
    parent_code: "836",
  },
  {
    value: "30385",
    label: "Xã Vĩnh Hòa",
    parent_code: "887",
  },
  {
    value: "31054",
    label: "Xã Vĩnh Hòa",
    parent_code: "913",
  },
  {
    value: "30892",
    label: "Xã Vĩnh Hòa Hiệp",
    parent_code: "905",
  },
  {
    value: "30955",
    label: "Xã Vĩnh Hòa Hưng Bắc",
    parent_code: "907",
  },
  {
    value: "30970",
    label: "Xã Vĩnh Hòa Hưng Nam",
    parent_code: "907",
  },
  {
    value: "30893",
    label: "Xã Vĩnh Hoà Phú",
    parent_code: "905",
  },
  {
    value: "30370",
    label: "Xã Vĩnh Hội Đông",
    parent_code: "886",
  },
  {
    value: "10960",
    label: "Xã Vĩnh Hồng",
    parent_code: "296",
  },
  {
    value: "15379",
    label: "Xã Vĩnh Hùng",
    parent_code: "393",
  },
  {
    value: "20116",
    label: "Xã Vinh Hưng",
    parent_code: "482",
  },
  {
    value: "00304",
    label: "Phường Vĩnh Hưng",
    parent_code: "008",
  },
  {
    value: "10951",
    label: "Xã Vĩnh Hưng",
    parent_code: "296",
  },
  {
    value: "15367",
    label: "Xã Vĩnh Hưng",
    parent_code: "393",
  },
  {
    value: "27757",
    label: "Thị trấn Vĩnh Hưng",
    parent_code: "797",
  },
  {
    value: "31894",
    label: "Xã Vĩnh Hưng",
    parent_code: "958",
  },
  {
    value: "31897",
    label: "Xã Vĩnh Hưng A",
    parent_code: "958",
  },
  {
    value: "28684",
    label: "Xã Vĩnh Hựu",
    parent_code: "823",
  },
  {
    value: "30718",
    label: "Xã Vĩnh Khánh",
    parent_code: "894",
  },
  {
    value: "19393",
    label: "Xã Vĩnh Khê",
    parent_code: "464",
  },
  {
    value: "12037",
    label: "Xã Vĩnh Khúc",
    parent_code: "326",
  },
  {
    value: "04771",
    label: "Xã Vĩnh Kiên",
    parent_code: "141",
  },
  {
    value: "21790",
    label: "Xã Vĩnh Kim",
    parent_code: "546",
  },
  {
    value: "28576",
    label: "Xã Vĩnh Kim",
    parent_code: "821",
  },
  {
    value: "29431",
    label: "Xã Vĩnh Kim",
    parent_code: "848",
  },
  {
    value: "04345",
    label: "Xã Vĩnh Lạc",
    parent_code: "135",
  },
  {
    value: "30745",
    label: "Phường Vĩnh Lạc",
    parent_code: "899",
  },
  {
    value: "08533",
    label: "Xã Vĩnh Lại",
    parent_code: "237",
  },
  {
    value: "19405",
    label: "Xã Vĩnh Lâm",
    parent_code: "464",
  },
  {
    value: "10885",
    label: "Xã Vĩnh Lập",
    parent_code: "294",
  },
  {
    value: "11845",
    label: "Xã Vĩnh Long",
    parent_code: "316",
  },
  {
    value: "15361",
    label: "Xã Vĩnh Long",
    parent_code: "393",
  },
  {
    value: "19387",
    label: "Xã Vĩnh Long",
    parent_code: "464",
  },
  {
    value: "15349",
    label: "Thị trấn Vĩnh Lộc",
    parent_code: "393",
  },
  {
    value: "02287",
    label: "Thị trấn Vĩnh Lộc",
    parent_code: "073",
  },
  {
    value: "30361",
    label: "Xã Vĩnh Lộc",
    parent_code: "886",
  },
  {
    value: "31858",
    label: "Xã Vĩnh Lộc",
    parent_code: "956",
  },
  {
    value: "27601",
    label: "Xã Vĩnh Lộc A",
    parent_code: "785",
  },
  {
    value: "31861",
    label: "Xã Vĩnh Lộc A",
    parent_code: "956",
  },
  {
    value: "27604",
    label: "Xã Vĩnh Lộc B",
    parent_code: "785",
  },
  {
    value: "02548",
    label: "Xã Vĩnh Lợi",
    parent_code: "076",
  },
  {
    value: "27745",
    label: "Xã Vĩnh Lợi",
    parent_code: "796",
  },
  {
    value: "30616",
    label: "Xã Vĩnh Lợi",
    parent_code: "892",
  },
  {
    value: "30757",
    label: "Phường Vĩnh Lợi",
    parent_code: "899",
  },
  {
    value: "31777",
    label: "Xã Vĩnh Lợi",
    parent_code: "949",
  },
  {
    value: "22384",
    label: "Xã Vĩnh Lương",
    parent_code: "568",
  },
  {
    value: "20113",
    label: "Xã Vinh Mỹ",
    parent_code: "482",
  },
  {
    value: "30322",
    label: "Phường Vĩnh Mỹ",
    parent_code: "884",
  },
  {
    value: "31933",
    label: "Xã Vĩnh Mỹ A",
    parent_code: "961",
  },
  {
    value: "31924",
    label: "Xã Vĩnh Mỹ B",
    parent_code: "961",
  },
  {
    value: "00502",
    label: "Xã Vĩnh Ngọc",
    parent_code: "017",
  },
  {
    value: "22390",
    label: "Xã Vĩnh Ngọc",
    parent_code: "568",
  },
  {
    value: "22375",
    label: "Phường Vĩnh Nguyên",
    parent_code: "568",
  },
  {
    value: "30328",
    label: "Phường Vĩnh Ngươn",
    parent_code: "884",
  },
  {
    value: "30619",
    label: "Xã Vĩnh Nhuận",
    parent_code: "892",
  },
  {
    value: "11407",
    label: "Phường Vĩnh Niệm",
    parent_code: "305",
  },
  {
    value: "09160",
    label: "Xã Vĩnh Ninh",
    parent_code: "252",
  },
  {
    value: "19783",
    label: "Phường Vĩnh Ninh",
    parent_code: "474",
  },
  {
    value: "19210",
    label: "Xã Vĩnh Ninh",
    parent_code: "456",
  },
  {
    value: "19426",
    label: "Xã Vĩnh Ô",
    parent_code: "464",
  },
  {
    value: "01309",
    label: "Xã Vĩnh Phong",
    parent_code: "042",
  },
  {
    value: "11896",
    label: "Xã Vĩnh Phong",
    parent_code: "316",
  },
  {
    value: "31075",
    label: "Xã Vĩnh Phong",
    parent_code: "910",
  },
  {
    value: "25990",
    label: "Phường Vĩnh Phú",
    parent_code: "725",
  },
  {
    value: "30694",
    label: "Xã Vĩnh Phú",
    parent_code: "894",
  },
  {
    value: "30947",
    label: "Xã Vĩnh Phú",
    parent_code: "906",
  },
  {
    value: "30791",
    label: "Xã Vĩnh Phú",
    parent_code: "914",
  },
  {
    value: "31870",
    label: "Xã Vĩnh Phú Đông",
    parent_code: "957",
  },
  {
    value: "31873",
    label: "Xã Vĩnh Phú Tây",
    parent_code: "957",
  },
  {
    value: "00006",
    label: "Phường Vĩnh Phúc",
    parent_code: "001",
  },
  {
    value: "01213",
    label: "Xã Vĩnh Phúc",
    parent_code: "034",
  },
  {
    value: "15364",
    label: "Xã Vĩnh Phúc",
    parent_code: "393",
  },
  {
    value: "22333",
    label: "Phường Vĩnh Phước",
    parent_code: "568",
  },
  {
    value: "30559",
    label: "Xã Vĩnh Phước",
    parent_code: "891",
  },
  {
    value: "31804",
    label: "Phường Vĩnh Phước",
    parent_code: "950",
  },
  {
    value: "30973",
    label: "Xã Vĩnh Phước A",
    parent_code: "907",
  },
  {
    value: "30976",
    label: "Xã Vĩnh Phước B",
    parent_code: "907",
  },
  {
    value: "22387",
    label: "Xã Vĩnh Phương",
    parent_code: "568",
  },
  {
    value: "01021",
    label: "Thị trấn Vinh Quang",
    parent_code: "032",
  },
  {
    value: "11821",
    label: "Xã Vinh Quang",
    parent_code: "315",
  },
  {
    value: "11872",
    label: "Xã Vinh Quang",
    parent_code: "316",
  },
  {
    value: "02356",
    label: "Xã Vinh Quang",
    parent_code: "073",
  },
  {
    value: "23320",
    label: "Xã Vinh Quang",
    parent_code: "608",
  },
  {
    value: "01693",
    label: "Xã Vĩnh Quang",
    parent_code: "040",
  },
  {
    value: "01300",
    label: "Xã Vĩnh Quang",
    parent_code: "042",
  },
  {
    value: "15352",
    label: "Xã Vĩnh Quang",
    parent_code: "393",
  },
  {
    value: "21805",
    label: "Xã Vĩnh Quang",
    parent_code: "546",
  },
  {
    value: "30736",
    label: "Phường Vĩnh Quang",
    parent_code: "899",
  },
  {
    value: "31738",
    label: "Xã Vĩnh Quới",
    parent_code: "948",
  },
  {
    value: "01561",
    label: "Xã Vinh Quý",
    parent_code: "048",
  },
  {
    value: "00664",
    label: "Xã Vĩnh Quỳnh",
    parent_code: "020",
  },
  {
    value: "09115",
    label: "Xã Vĩnh Sơn",
    parent_code: "252",
  },
  {
    value: "17362",
    label: "Xã Vĩnh Sơn",
    parent_code: "424",
  },
  {
    value: "19420",
    label: "Xã Vĩnh Sơn",
    parent_code: "464",
  },
  {
    value: "21787",
    label: "Xã Vĩnh Sơn",
    parent_code: "546",
  },
  {
    value: "16714",
    label: "Phường Vinh Tân",
    parent_code: "412",
  },
  {
    value: "25912",
    label: "Phường Vĩnh Tân",
    parent_code: "723",
  },
  {
    value: "26182",
    label: "Xã Vĩnh Tân",
    parent_code: "735",
  },
  {
    value: "22984",
    label: "Xã Vĩnh Tân",
    parent_code: "595",
  },
  {
    value: "31807",
    label: "Xã Vĩnh Tân",
    parent_code: "950",
  },
  {
    value: "30331",
    label: "Xã Vĩnh Tế",
    parent_code: "884",
  },
  {
    value: "22402",
    label: "Xã Vĩnh Thái",
    parent_code: "568",
  },
  {
    value: "19369",
    label: "Xã Vĩnh Thái",
    parent_code: "464",
  },
  {
    value: "19945",
    label: "Xã Vinh Thanh",
    parent_code: "478",
  },
  {
    value: "26497",
    label: "Xã Vĩnh Thanh",
    parent_code: "742",
  },
  {
    value: "30733",
    label: "Phường Vĩnh Thanh",
    parent_code: "899",
  },
  {
    value: "31882",
    label: "Xã Vĩnh Thanh",
    parent_code: "957",
  },
  {
    value: "17587",
    label: "Xã Vĩnh Thành",
    parent_code: "426",
  },
  {
    value: "28894",
    label: "Xã Vĩnh Thành",
    parent_code: "832",
  },
  {
    value: "30625",
    label: "Xã Vĩnh Thành",
    parent_code: "892",
  },
  {
    value: "31771",
    label: "Xã Vĩnh Thành",
    parent_code: "949",
  },
  {
    value: "22393",
    label: "Xã Vĩnh Thạnh",
    parent_code: "568",
  },
  {
    value: "21786",
    label: "Thị trấn Vĩnh Thạnh",
    parent_code: "546",
  },
  {
    value: "27739",
    label: "Xã Vĩnh Thạnh",
    parent_code: "796",
  },
  {
    value: "30187",
    label: "Xã Vĩnh Thạnh",
    parent_code: "875",
  },
  {
    value: "30946",
    label: "Xã Vĩnh Thạnh",
    parent_code: "906",
  },
  {
    value: "31232",
    label: "Thị trấn Vĩnh Thạnh",
    parent_code: "924",
  },
  {
    value: "30478",
    label: "Thị trấn Vĩnh Thạnh Trung",
    parent_code: "889",
  },
  {
    value: "30730",
    label: "Phường Vĩnh Thanh Vân",
    parent_code: "899",
  },
  {
    value: "30982",
    label: "Xã Vĩnh Thắng",
    parent_code: "907",
  },
  {
    value: "09154",
    label: "Xã Vĩnh Thịnh",
    parent_code: "252",
  },
  {
    value: "15388",
    label: "Xã Vĩnh Thịnh",
    parent_code: "393",
  },
  {
    value: "21802",
    label: "Xã Vĩnh Thịnh",
    parent_code: "546",
  },
  {
    value: "31936",
    label: "Xã Vĩnh Thịnh",
    parent_code: "961",
  },
  {
    value: "22339",
    label: "Phường Vĩnh Thọ",
    parent_code: "568",
  },
  {
    value: "30760",
    label: "Phường Vĩnh Thông",
    parent_code: "899",
  },
  {
    value: "30232",
    label: "Xã Vĩnh Thới",
    parent_code: "876",
  },
  {
    value: "21804",
    label: "Xã Vĩnh Thuận",
    parent_code: "546",
  },
  {
    value: "27778",
    label: "Xã Vĩnh Thuận",
    parent_code: "797",
  },
  {
    value: "31051",
    label: "Thị trấn Vĩnh Thuận",
    parent_code: "910",
  },
  {
    value: "31069",
    label: "Xã Vĩnh Thuận",
    parent_code: "910",
  },
  {
    value: "31486",
    label: "Xã Vĩnh Thuận Đông",
    parent_code: "936",
  },
  {
    value: "31453",
    label: "Xã Vĩnh Thuận Tây",
    parent_code: "935",
  },
  {
    value: "19402",
    label: "Xã Vĩnh Thủy",
    parent_code: "464",
  },
  {
    value: "06757",
    label: "Xã Vĩnh Thực",
    parent_code: "194",
  },
  {
    value: "08626",
    label: "Xã Vinh Tiền",
    parent_code: "240",
  },
  {
    value: "11908",
    label: "Xã Vĩnh Tiến",
    parent_code: "316",
  },
  {
    value: "06007",
    label: "Xã Vĩnh Tiến",
    parent_code: "180",
  },
  {
    value: "15358",
    label: "Xã Vĩnh Tiến",
    parent_code: "393",
  },
  {
    value: "05005",
    label: "Xã Vĩnh Tiến",
    parent_code: "153",
  },
  {
    value: "30697",
    label: "Xã Vĩnh Trạch",
    parent_code: "894",
  },
  {
    value: "31834",
    label: "Xã Vĩnh Trạch",
    parent_code: "954",
  },
  {
    value: "31837",
    label: "Xã Vĩnh Trạch Đông",
    parent_code: "954",
  },
  {
    value: "05977",
    label: "Phường Vĩnh Trại",
    parent_code: "178",
  },
  {
    value: "27769",
    label: "Xã Vĩnh Trị",
    parent_code: "797",
  },
  {
    value: "31237",
    label: "Xã Vĩnh Trinh",
    parent_code: "924",
  },
  {
    value: "13597",
    label: "Thị trấn Vĩnh Trụ",
    parent_code: "353",
  },
  {
    value: "06754",
    label: "Xã Vĩnh Trung",
    parent_code: "194",
  },
  {
    value: "22396",
    label: "Xã Vĩnh Trung",
    parent_code: "568",
  },
  {
    value: "20218",
    label: "Phường Vĩnh Trung",
    parent_code: "491",
  },
  {
    value: "30532",
    label: "Xã Vĩnh Trung",
    parent_code: "890",
  },
  {
    value: "31456",
    label: "Xã Vĩnh Trung",
    parent_code: "935",
  },
  {
    value: "22381",
    label: "Phường Vĩnh Trường",
    parent_code: "568",
  },
  {
    value: "30367",
    label: "Xã Vĩnh Trường",
    parent_code: "886",
  },
  {
    value: "19372",
    label: "Xã Vĩnh Tú",
    parent_code: "464",
  },
  {
    value: "00283",
    label: "Phường Vĩnh Tuy",
    parent_code: "007",
  },
  {
    value: "01156",
    label: "Thị trấn Vĩnh Tuy",
    parent_code: "034",
  },
  {
    value: "30979",
    label: "Xã Vĩnh Tuy",
    parent_code: "907",
  },
  {
    value: "09076",
    label: "Thị trấn Vĩnh Tường",
    parent_code: "252",
  },
  {
    value: "31459",
    label: "Xã Vĩnh Tường",
    parent_code: "935",
  },
  {
    value: "31475",
    label: "Phường Vĩnh Tường",
    parent_code: "937",
  },
  {
    value: "31489",
    label: "Thị trấn Vĩnh Viễn",
    parent_code: "936",
  },
  {
    value: "31490",
    label: "Xã Vĩnh Viễn A",
    parent_code: "936",
  },
  {
    value: "12289",
    label: "Xã Vĩnh Xá",
    parent_code: "331",
  },
  {
    value: "19936",
    label: "Xã Vinh Xuân",
    parent_code: "478",
  },
  {
    value: "29845",
    label: "Xã Vĩnh Xuân",
    parent_code: "862",
  },
  {
    value: "30382",
    label: "Xã Vĩnh Xương",
    parent_code: "887",
  },
  {
    value: "06070",
    label: "Xã Vĩnh Yên",
    parent_code: "181",
  },
  {
    value: "15355",
    label: "Xã Vĩnh Yên",
    parent_code: "393",
  },
  {
    value: "02956",
    label: "Xã Vĩnh Yên",
    parent_code: "087",
  },
  {
    value: "09190",
    label: "Phường Võ Cường",
    parent_code: "256",
  },
  {
    value: "08194",
    label: "Xã Võ Lao",
    parent_code: "232",
  },
  {
    value: "03061",
    label: "Xã Võ Lao",
    parent_code: "089",
  },
  {
    value: "17791",
    label: "Xã Võ Liệt",
    parent_code: "428",
  },
  {
    value: "08584",
    label: "Xã Võ Miếu",
    parent_code: "238",
  },
  {
    value: "19213",
    label: "Xã Võ Ninh",
    parent_code: "456",
  },
  {
    value: "27139",
    label: "Phường Võ Thị Sáu",
    parent_code: "770",
  },
  {
    value: "23191",
    label: "Thị trấn Võ Xu",
    parent_code: "600",
  },
  {
    value: "30715",
    label: "Xã Vọng Đông",
    parent_code: "894",
  },
  {
    value: "00514",
    label: "Xã Võng La",
    parent_code: "017",
  },
  {
    value: "30727",
    label: "Xã Vọng Thê",
    parent_code: "894",
  },
  {
    value: "09739",
    label: "Xã Võng Xuyên",
    parent_code: "272",
  },
  {
    value: "01195",
    label: "Xã Vô Điếm",
    parent_code: "034",
  },
  {
    value: "06853",
    label: "Xã Vô Ngại",
    parent_code: "198",
  },
  {
    value: "05647",
    label: "Xã Vô Tranh",
    parent_code: "168",
  },
  {
    value: "07489",
    label: "Xã Vô Tranh",
    parent_code: "218",
  },
  {
    value: "08131",
    label: "Xã Vô Tranh",
    parent_code: "231",
  },
  {
    value: "07375",
    label: "Thị trấn Vôi",
    parent_code: "217",
  },
  {
    value: "13129",
    label: "Xã Vũ An",
    parent_code: "343",
  },
  {
    value: "13543",
    label: "Xã Vũ Bản",
    parent_code: "352",
  },
  {
    value: "05266",
    label: "Thị trấn Vụ Bản",
    parent_code: "157",
  },
  {
    value: "05335",
    label: "Xã Vũ Bình",
    parent_code: "157",
  },
  {
    value: "13174",
    label: "Xã Vũ Bình",
    parent_code: "343",
  },
  {
    value: "24529",
    label: "Xã Vụ Bổn",
    parent_code: "654",
  },
  {
    value: "05728",
    label: "Xã Vũ Chấn",
    parent_code: "170",
  },
  {
    value: "12469",
    label: "Xã Vũ Chính",
    parent_code: "336",
  },
  {
    value: "13156",
    label: "Xã Vũ Công",
    parent_code: "343",
  },
  {
    value: "09130",
    label: "Xã Vũ Di",
    parent_code: "252",
  },
  {
    value: "13270",
    label: "Xã Vũ Đoài",
    parent_code: "344",
  },
  {
    value: "13084",
    label: "Xã Vũ Đông",
    parent_code: "336",
  },
  {
    value: "23218",
    label: "Xã Vũ Hoà",
    parent_code: "600",
  },
  {
    value: "13159",
    label: "Xã Vũ Hòa",
    parent_code: "343",
  },
  {
    value: "13255",
    label: "Xã Vũ Hội",
    parent_code: "344",
  },
  {
    value: "13108",
    label: "Xã Vũ Lạc",
    parent_code: "336",
  },
  {
    value: "06367",
    label: "Xã Vũ Lăng",
    parent_code: "185",
  },
  {
    value: "12985",
    label: "Xã Vũ Lăng",
    parent_code: "342",
  },
  {
    value: "06373",
    label: "Xã Vũ Lễ",
    parent_code: "185",
  },
  {
    value: "13111",
    label: "Xã Vũ Lễ",
    parent_code: "343",
  },
  {
    value: "04765",
    label: "Xã Vũ Linh",
    parent_code: "141",
  },
  {
    value: "01762",
    label: "Xã Vũ Minh",
    parent_code: "052",
  },
  {
    value: "01981",
    label: "Xã Vũ Muộn",
    parent_code: "063",
  },
  {
    value: "09163",
    label: "Phường Vũ Ninh",
    parent_code: "256",
  },
  {
    value: "13126",
    label: "Xã Vũ Ninh",
    parent_code: "343",
  },
  {
    value: "01744",
    label: "Xã Vũ Nông",
    parent_code: "052",
  },
  {
    value: "07048",
    label: "Xã Vũ Oai",
    parent_code: "193",
  },
  {
    value: "12466",
    label: "Xã Vũ Phúc",
    parent_code: "336",
  },
  {
    value: "18313",
    label: "Thị trấn Vũ Quang",
    parent_code: "441",
  },
  {
    value: "08032",
    label: "Xã Vụ Quang",
    parent_code: "230",
  },
  {
    value: "13141",
    label: "Xã Vũ Quí",
    parent_code: "343",
  },
  {
    value: "06355",
    label: "Xã Vũ Sơn",
    parent_code: "185",
  },
  {
    value: "13153",
    label: "Xã Vũ Thắng",
    parent_code: "343",
  },
  {
    value: "13192",
    label: "Thị trấn Vũ Thư",
    parent_code: "344",
  },
  {
    value: "13273",
    label: "Xã Vũ Tiến",
    parent_code: "344",
  },
  {
    value: "13150",
    label: "Xã Vũ Trung",
    parent_code: "343",
  },
  {
    value: "13276",
    label: "Xã Vũ Vân",
    parent_code: "344",
  },
  {
    value: "13267",
    label: "Xã Vũ Vinh",
    parent_code: "344",
  },
  {
    value: "12325",
    label: "Xã Vũ Xá",
    parent_code: "331",
  },
  {
    value: "07516",
    label: "Xã Vũ Xá",
    parent_code: "218",
  },
  {
    value: "29659",
    label: "Thị trấn Vũng Liêm",
    parent_code: "859",
  },
  {
    value: "12337",
    label: "Thị trấn Vương",
    parent_code: "332",
  },
  {
    value: "18427",
    label: "Xã Vượng Lộc",
    parent_code: "443",
  },
  {
    value: "19777",
    label: "Phường Vỹ Dạ",
    parent_code: "474",
  },
  {
    value: "26596",
    label: "Xã Xà Bang",
    parent_code: "750",
  },
  {
    value: "03373",
    label: "Xã Xa Dung",
    parent_code: "101",
  },
  {
    value: "04594",
    label: "Xã Xà Hồ",
    parent_code: "139",
  },
  {
    value: "16921",
    label: "Xã Xá Lượng",
    parent_code: "418",
  },
  {
    value: "07540",
    label: "Xã Xa Lý",
    parent_code: "219",
  },
  {
    value: "31495",
    label: "Xã Xà Phiên",
    parent_code: "936",
  },
  {
    value: "00736",
    label: "Xã Xà Phìn",
    parent_code: "026",
  },
  {
    value: "26674",
    label: "Xã Phước Tỉnh",
    parent_code: "752",
  },
  {
    value: "10729",
    label: "Xã Thượng Quận",
    parent_code: "292",
  },
  {
    value: "03178",
    label: "Xã Xá Tổng",
    parent_code: "097",
  },
  {
    value: "08242",
    label: "Xã Trị Quận",
    parent_code: "233",
  },
  {
    value: "02464",
    label: "Xã Tứ Quận",
    parent_code: "075",
  },
  {
    value: "14386",
    label: "Xã Xích Thổ",
    parent_code: "372",
  },
  {
    value: "16904",
    label: "Xã Xiêng My",
    parent_code: "418",
  },
  {
    value: "03865",
    label: "Xã Xím Vàng",
    parent_code: "121",
  },
  {
    value: "00778",
    label: "Xã Xín Cái",
    parent_code: "027",
  },
  {
    value: "00937",
    label: "Xã Xín Chải",
    parent_code: "030",
  },
  {
    value: "03223",
    label: "Xã Xín Chải",
    parent_code: "098",
  },
  {
    value: "01108",
    label: "Xã Xín Mần",
    parent_code: "033",
  },
  {
    value: "23359",
    label: "Xã Xốp",
    parent_code: "610",
  },
  {
    value: "04441",
    label: "Xã Xuân Ái",
    parent_code: "136",
  },
  {
    value: "08302",
    label: "Xã Xuân An",
    parent_code: "234",
  },
  {
    value: "18352",
    label: "Thị trấn Xuân An",
    parent_code: "442",
  },
  {
    value: "26080",
    label: "Phường Xuân An",
    parent_code: "732",
  },
  {
    value: "22933",
    label: "Phường Xuân An",
    parent_code: "593",
  },
  {
    value: "23627",
    label: "Xã Xuân An",
    parent_code: "623",
  },
  {
    value: "08110",
    label: "Xã Xuân Áng",
    parent_code: "231",
  },
  {
    value: "15547",
    label: "Xã Xuân Bái",
    parent_code: "395",
  },
  {
    value: "26353",
    label: "Xã Xuân Bảo",
    parent_code: "739",
  },
  {
    value: "14119",
    label: "Xã Xuân Bắc",
    parent_code: "364",
  },
  {
    value: "26428",
    label: "Xã Xuân Bắc",
    parent_code: "741",
  },
  {
    value: "16183",
    label: "Xã Xuân Bình",
    parent_code: "402",
  },
  {
    value: "26077",
    label: "Phường Xuân Bình",
    parent_code: "732",
  },
  {
    value: "22060",
    label: "Xã Xuân Bình",
    parent_code: "557",
  },
  {
    value: "00511",
    label: "Xã Xuân Canh",
    parent_code: "017",
  },
  {
    value: "22066",
    label: "Xã Xuân Cảnh",
    parent_code: "557",
  },
  {
    value: "15631",
    label: "Xã Xuân Cao",
    parent_code: "396",
  },
  {
    value: "07873",
    label: "Xã Xuân Cẩm",
    parent_code: "223",
  },
  {
    value: "14092",
    label: "Xã Xuân Châu",
    parent_code: "364",
  },
  {
    value: "15658",
    label: "Xã Xuân Chinh",
    parent_code: "396",
  },
  {
    value: "14632",
    label: "Xã Xuân Chính",
    parent_code: "376",
  },
  {
    value: "16234",
    label: "Xã Xuân Du",
    parent_code: "403",
  },
  {
    value: "12133",
    label: "Xã Xuân Dục",
    parent_code: "328",
  },
  {
    value: "10177",
    label: "Xã Xuân Dương",
    parent_code: "278",
  },
  {
    value: "06607",
    label: "Xã Xuân Dương",
    parent_code: "188",
  },
  {
    value: "15649",
    label: "Xã Xuân Dương",
    parent_code: "396",
  },
  {
    value: "02191",
    label: "Xã Xuân Dương",
    parent_code: "066",
  },
  {
    value: "08590",
    label: "Xã Xuân Đài",
    parent_code: "240",
  },
  {
    value: "14107",
    label: "Xã Xuân Đài",
    parent_code: "364",
  },
  {
    value: "22076",
    label: "Phường Xuân Đài",
    parent_code: "557",
  },
  {
    value: "11947",
    label: "Xã Xuân Đám",
    parent_code: "317",
  },
  {
    value: "09727",
    label: "Xã Xuân Đình",
    parent_code: "272",
  },
  {
    value: "00610",
    label: "Phường Xuân Đỉnh",
    parent_code: "021",
  },
  {
    value: "26461",
    label: "Xã Xuân Định",
    parent_code: "741",
  },
  {
    value: "26359",
    label: "Xã Xuân Đông",
    parent_code: "739",
  },
  {
    value: "28642",
    label: "Xã Xuân Đông",
    parent_code: "822",
  },
  {
    value: "26338",
    label: "Xã Xuân Đường",
    parent_code: "739",
  },
  {
    value: "00424",
    label: "Xã Xuân Giang",
    parent_code: "016",
  },
  {
    value: "01255",
    label: "Xã Xuân Giang",
    parent_code: "035",
  },
  {
    value: "15526",
    label: "Xã Xuân Giang",
    parent_code: "395",
  },
  {
    value: "18370",
    label: "Xã Xuân Giang",
    parent_code: "442",
  },
  {
    value: "02932",
    label: "Xã Xuân Giao",
    parent_code: "086",
  },
  {
    value: "20209",
    label: "Phường Xuân Hà",
    parent_code: "491",
  },
  {
    value: "18367",
    label: "Xã Xuân Hải",
    parent_code: "442",
  },
  {
    value: "22858",
    label: "Xã Xuân Hải",
    parent_code: "586",
  },
  {
    value: "22054",
    label: "Xã Xuân Hải",
    parent_code: "557",
  },
  {
    value: "26455",
    label: "Xã Xuân Hiệp",
    parent_code: "741",
  },
  {
    value: "29824",
    label: "Xã Xuân Hiệp",
    parent_code: "862",
  },
  {
    value: "08746",
    label: "Phường Xuân Hoà",
    parent_code: "244",
  },
  {
    value: "02962",
    label: "Xã Xuân Hoà",
    parent_code: "087",
  },
  {
    value: "26083",
    label: "Phường Xuân Hoà",
    parent_code: "732",
  },
  {
    value: "01392",
    label: "Thị trấn Xuân Hòa",
    parent_code: "045",
  },
  {
    value: "08794",
    label: "Xã Xuân Hòa",
    parent_code: "246",
  },
  {
    value: "13201",
    label: "Xã Xuân Hòa",
    parent_code: "344",
  },
  {
    value: "14146",
    label: "Xã Xuân Hòa",
    parent_code: "364",
  },
  {
    value: "15517",
    label: "Xã Xuân Hòa",
    parent_code: "395",
  },
  {
    value: "16180",
    label: "Xã Xuân Hòa",
    parent_code: "402",
  },
  {
    value: "17959",
    label: "Xã Xuân Hòa",
    parent_code: "430",
  },
  {
    value: "26443",
    label: "Xã Xuân Hòa",
    parent_code: "741",
  },
  {
    value: "31534",
    label: "Xã Xuân Hòa",
    parent_code: "943",
  },
  {
    value: "18925",
    label: "Xã Xuân Hóa",
    parent_code: "452",
  },
  {
    value: "18355",
    label: "Xã Xuân Hội",
    parent_code: "442",
  },
  {
    value: "14095",
    label: "Xã Xuân Hồng",
    parent_code: "364",
  },
  {
    value: "15493",
    label: "Xã Xuân Hồng",
    parent_code: "395",
  },
  {
    value: "18388",
    label: "Xã Xuân Hồng",
    parent_code: "442",
  },
  {
    value: "08509",
    label: "Xã Xuân Huy",
    parent_code: "237",
  },
  {
    value: "15535",
    label: "Xã Xuân Hưng",
    parent_code: "395",
  },
  {
    value: "26446",
    label: "Xã Xuân Hưng",
    parent_code: "741",
  },
  {
    value: "07429",
    label: "Xã Xuân Hương",
    parent_code: "217",
  },
  {
    value: "16246",
    label: "Xã Xuân Khang",
    parent_code: "403",
  },
  {
    value: "09589",
    label: "Phường Xuân Khanh",
    parent_code: "269",
  },
  {
    value: "31144",
    label: "Phường Xuân Khánh",
    parent_code: "916",
  },
  {
    value: "13624",
    label: "Xã Xuân Khê",
    parent_code: "353",
  },
  {
    value: "14137",
    label: "Xã Xuân Kiên",
    parent_code: "364",
  },
  {
    value: "00103",
    label: "Phường Xuân La",
    parent_code: "003",
  },
  {
    value: "01873",
    label: "Xã Xuân La",
    parent_code: "060",
  },
  {
    value: "02023",
    label: "Xã Xuân Lạc",
    parent_code: "064",
  },
  {
    value: "09484",
    label: "Xã Xuân Lai",
    parent_code: "263",
  },
  {
    value: "15583",
    label: "Xã Xuân Lai",
    parent_code: "395",
  },
  {
    value: "04744",
    label: "Xã Xuân Lai",
    parent_code: "141",
  },
  {
    value: "18055",
    label: "Xã Xuân Lam",
    parent_code: "431",
  },
  {
    value: "18400",
    label: "Xã Xuân Lam",
    parent_code: "442",
  },
  {
    value: "22090",
    label: "Xã Xuân Lãnh",
    parent_code: "558",
  },
  {
    value: "03302",
    label: "Xã Xuân Lao",
    parent_code: "102",
  },
  {
    value: "09433",
    label: "Xã Xuân Lâm",
    parent_code: "262",
  },
  {
    value: "16627",
    label: "Phường Xuân Lâm",
    parent_code: "407",
  },
  {
    value: "17980",
    label: "Xã Xuân Lâm",
    parent_code: "430",
  },
  {
    value: "22052",
    label: "Xã Xuân Lâm",
    parent_code: "557",
  },
  {
    value: "15586",
    label: "Xã Xuân Lập",
    parent_code: "395",
  },
  {
    value: "02242",
    label: "Xã Xuân Lập",
    parent_code: "071",
  },
  {
    value: "26101",
    label: "Phường Xuân Lập",
    parent_code: "732",
  },
  {
    value: "15619",
    label: "Xã Xuân Lẹ",
    parent_code: "396",
  },
  {
    value: "18394",
    label: "Xã Xuân Liên",
    parent_code: "442",
  },
  {
    value: "18397",
    label: "Xã Xuân Lĩnh",
    parent_code: "442",
  },
  {
    value: "06241",
    label: "Xã Xuân Long",
    parent_code: "183",
  },
  {
    value: "04720",
    label: "Xã Xuân Long",
    parent_code: "141",
  },
  {
    value: "22093",
    label: "Xã Xuân Long",
    parent_code: "558",
  },
  {
    value: "08668",
    label: "Xã Xuân Lộc",
    parent_code: "239",
  },
  {
    value: "15643",
    label: "Xã Xuân Lộc",
    parent_code: "396",
  },
  {
    value: "15739",
    label: "Xã Xuân Lộc",
    parent_code: "397",
  },
  {
    value: "16057",
    label: "Xã Xuân Lộc",
    parent_code: "400",
  },
  {
    value: "18475",
    label: "Xã Xuân Lộc",
    parent_code: "443",
  },
  {
    value: "20158",
    label: "Xã Xuân Lộc",
    parent_code: "482",
  },
  {
    value: "22057",
    label: "Xã Xuân Lộc",
    parent_code: "557",
  },
  {
    value: "08836",
    label: "Xã Xuân Lôi",
    parent_code: "246",
  },
  {
    value: "08500",
    label: "Xã Xuân Lũng",
    parent_code: "237",
  },
  {
    value: "07249",
    label: "Xã Xuân Lương",
    parent_code: "215",
  },
  {
    value: "10018",
    label: "Thị trấn Xuân Mai",
    parent_code: "277",
  },
  {
    value: "01222",
    label: "Xã Xuân Minh",
    parent_code: "035",
  },
  {
    value: "15592",
    label: "Xã Xuân Minh",
    parent_code: "395",
  },
  {
    value: "18379",
    label: "Xã Xuân Mỹ",
    parent_code: "442",
  },
  {
    value: "26344",
    label: "Xã Xuân Mỹ",
    parent_code: "739",
  },
  {
    value: "14116",
    label: "Xã Xuân Ngọc",
    parent_code: "364",
  },
  {
    value: "04057",
    label: "Xã Xuân Nha",
    parent_code: "128",
  },
  {
    value: "14143",
    label: "Xã Xuân Ninh",
    parent_code: "364",
  },
  {
    value: "19237",
    label: "Xã Xuân Ninh",
    parent_code: "456",
  },
  {
    value: "01462",
    label: "Xã Xuân Nội",
    parent_code: "047",
  },
  {
    value: "00457",
    label: "Xã Xuân Nộn",
    parent_code: "017",
  },
  {
    value: "14104",
    label: "Xã Xuân Phong",
    parent_code: "364",
  },
  {
    value: "15508",
    label: "Xã Xuân Phong",
    parent_code: "395",
  },
  {
    value: "18364",
    label: "Xã Xuân Phổ",
    parent_code: "442",
  },
  {
    value: "07714",
    label: "Xã Xuân Phú",
    parent_code: "221",
  },
  {
    value: "14128",
    label: "Xã Xuân Phú",
    parent_code: "364",
  },
  {
    value: "15550",
    label: "Xã Xuân Phú",
    parent_code: "395",
  },
  {
    value: "26458",
    label: "Xã Xuân Phú",
    parent_code: "741",
  },
  {
    value: "19792",
    label: "Phường Xuân Phú",
    parent_code: "474",
  },
  {
    value: "24382",
    label: "Xã Xuân Phú",
    parent_code: "651",
  },
  {
    value: "22051",
    label: "Phường Xuân Phú",
    parent_code: "557",
  },
  {
    value: "16261",
    label: "Xã Xuân Phúc",
    parent_code: "403",
  },
  {
    value: "22111",
    label: "Xã Xuân Phước",
    parent_code: "558",
  },
  {
    value: "00622",
    label: "Phường Xuân Phương",
    parent_code: "019",
  },
  {
    value: "05944",
    label: "Xã Xuân Phương",
    parent_code: "173",
  },
  {
    value: "14122",
    label: "Xã Xuân Phương",
    parent_code: "364",
  },
  {
    value: "22072",
    label: "Xã Xuân Phương",
    parent_code: "557",
  },
  {
    value: "12022",
    label: "Xã Xuân Quan",
    parent_code: "326",
  },
  {
    value: "02326",
    label: "Xã Xuân Quang",
    parent_code: "073",
  },
  {
    value: "02926",
    label: "Xã Xuân Quang",
    parent_code: "086",
  },
  {
    value: "22096",
    label: "Xã Xuân Quang 1",
    parent_code: "558",
  },
  {
    value: "22102",
    label: "Xã Xuân Quang 2",
    parent_code: "558",
  },
  {
    value: "22108",
    label: "Xã Xuân Quang 3",
    parent_code: "558",
  },
  {
    value: "26332",
    label: "Xã Xuân Quế",
    parent_code: "739",
  },
  {
    value: "15532",
    label: "Xã Xuân Sinh",
    parent_code: "395",
  },
  {
    value: "09598",
    label: "Xã Xuân Sơn",
    parent_code: "269",
  },
  {
    value: "08599",
    label: "Xã Xuân Sơn",
    parent_code: "240",
  },
  {
    value: "07105",
    label: "Phường Xuân Sơn",
    parent_code: "205",
  },
  {
    value: "17689",
    label: "Xã Xuân Sơn",
    parent_code: "427",
  },
  {
    value: "22522",
    label: "Xã Xuân Sơn",
    parent_code: "571",
  },
  {
    value: "26584",
    label: "Xã Xuân Sơn",
    parent_code: "750",
  },
  {
    value: "22099",
    label: "Xã Xuân Sơn Bắc",
    parent_code: "558",
  },
  {
    value: "22105",
    label: "Xã Xuân Sơn Nam",
    parent_code: "558",
  },
  {
    value: "00611",
    label: "Phường Xuân Tảo",
    parent_code: "021",
  },
  {
    value: "02656",
    label: "Phường Xuân Tăng",
    parent_code: "080",
  },
  {
    value: "26449",
    label: "Xã Xuân Tâm",
    parent_code: "741",
  },
  {
    value: "04411",
    label: "Xã Xuân Tầm",
    parent_code: "136",
  },
  {
    value: "14110",
    label: "Xã Xuân Tân",
    parent_code: "364",
  },
  {
    value: "26110",
    label: "Phường Xuân Tân",
    parent_code: "732",
  },
  {
    value: "26356",
    label: "Xã Xuân Tây",
    parent_code: "739",
  },
  {
    value: "16258",
    label: "Xã Xuân Thái",
    parent_code: "403",
  },
  {
    value: "26074",
    label: "Phường Xuân Thanh",
    parent_code: "732",
  },
  {
    value: "14098",
    label: "Xã Xuân Thành",
    parent_code: "364",
  },
  {
    value: "17566",
    label: "Xã Xuân Thành",
    parent_code: "426",
  },
  {
    value: "18382",
    label: "Xã Xuân Thành",
    parent_code: "442",
  },
  {
    value: "26434",
    label: "Xã Xuân Thành",
    parent_code: "741",
  },
  {
    value: "22053",
    label: "Phường Xuân Thành",
    parent_code: "557",
  },
  {
    value: "15640",
    label: "Xã Xuân Thắng",
    parent_code: "396",
  },
  {
    value: "31270",
    label: "Xã Xuân Thắng",
    parent_code: "927",
  },
  {
    value: "15559",
    label: "Xã Xuân Thiên",
    parent_code: "395",
  },
  {
    value: "26323",
    label: "Xã Xuân Thiện",
    parent_code: "738",
  },
  {
    value: "15736",
    label: "Xã Xuân Thịnh",
    parent_code: "397",
  },
  {
    value: "22069",
    label: "Xã Xuân Thịnh",
    parent_code: "557",
  },
  {
    value: "15745",
    label: "Xã Xuân Thọ",
    parent_code: "397",
  },
  {
    value: "24805",
    label: "Xã Xuân Thọ",
    parent_code: "672",
  },
  {
    value: "26437",
    label: "Xã Xuân Thọ",
    parent_code: "741",
  },
  {
    value: "22075",
    label: "Xã Xuân Thọ 1",
    parent_code: "557",
  },
  {
    value: "22078",
    label: "Xã Xuân Thọ 2",
    parent_code: "557",
  },
  {
    value: "27583",
    label: "Xã Xuân Thới Đông",
    parent_code: "784",
  },
  {
    value: "27577",
    label: "Xã Xuân Thới Sơn",
    parent_code: "784",
  },
  {
    value: "27589",
    label: "Xã Xuân Thới Thượng",
    parent_code: "784",
  },
  {
    value: "00451",
    label: "Xã Xuân Thu",
    parent_code: "016",
  },
  {
    value: "08308",
    label: "Xã Xuân Thủy",
    parent_code: "234",
  },
  {
    value: "14113",
    label: "Xã Xuân Thủy",
    parent_code: "364",
  },
  {
    value: "05017",
    label: "Xã Xuân Thủy",
    parent_code: "153",
  },
  {
    value: "19300",
    label: "Xã Xuân Thủy",
    parent_code: "457",
  },
  {
    value: "14101",
    label: "Xã Xuân Thượng",
    parent_code: "364",
  },
  {
    value: "02980",
    label: "Xã Xuân Thượng",
    parent_code: "087",
  },
  {
    value: "14140",
    label: "Xã Xuân Tiến",
    parent_code: "364",
  },
  {
    value: "15574",
    label: "Xã Xuân Tín",
    parent_code: "395",
  },
  {
    value: "19117",
    label: "Xã Xuân Trạch",
    parent_code: "455",
  },
  {
    value: "12166",
    label: "Xã Xuân Trúc",
    parent_code: "329",
  },
  {
    value: "14131",
    label: "Xã Xuân Trung",
    parent_code: "364",
  },
  {
    value: "26071",
    label: "Phường Xuân Trung",
    parent_code: "732",
  },
  {
    value: "01339",
    label: "Xã Xuân Trường",
    parent_code: "043",
  },
  {
    value: "14089",
    label: "Thị trấn Xuân Trường",
    parent_code: "364",
  },
  {
    value: "15514",
    label: "Xã Xuân Trường",
    parent_code: "395",
  },
  {
    value: "24811",
    label: "Xã Xuân Trường",
    parent_code: "672",
  },
  {
    value: "26440",
    label: "Xã Xuân Trường",
    parent_code: "741",
  },
  {
    value: "17779",
    label: "Xã Xuân Tường",
    parent_code: "428",
  },
  {
    value: "02449",
    label: "Xã Xuân Vân",
    parent_code: "075",
  },
  {
    value: "08305",
    label: "Xã Xuân Viên",
    parent_code: "234",
  },
  {
    value: "18385",
    label: "Xã Xuân Viên",
    parent_code: "442",
  },
  {
    value: "14134",
    label: "Xã Xuân Vinh",
    parent_code: "364",
  },
  {
    value: "18376",
    label: "Xã Xuân Yên",
    parent_code: "442",
  },
  {
    value: "22073",
    label: "Phường Xuân Yên",
    parent_code: "557",
  },
  {
    value: "01855",
    label: "Phường Xuất Hóa",
    parent_code: "058",
  },
  {
    value: "05302",
    label: "Xã Xuất Hóa",
    parent_code: "157",
  },
  {
    value: "06202",
    label: "Xã Xuất Lễ",
    parent_code: "183",
  },
  {
    value: "10471",
    label: "Xã Xuy Xá",
    parent_code: "282",
  },
  {
    value: "26629",
    label: "Xã Xuyên Mộc",
    parent_code: "751",
  },
  {
    value: "07225",
    label: "Phường Xương Giang",
    parent_code: "213",
  },
  {
    value: "22342",
    label: "Phường Xương Huân",
    parent_code: "568",
  },
  {
    value: "07426",
    label: "Xã Xương Lâm",
    parent_code: "217",
  },
  {
    value: "08389",
    label: "Xã Xương Thịnh",
    parent_code: "235",
  },
  {
    value: "19492",
    label: "Xã Xy",
    parent_code: "465",
  },
  {
    value: "04531",
    label: "Xã Y Can",
    parent_code: "138",
  },
  {
    value: "02215",
    label: "Phường Ỷ La",
    parent_code: "070",
  },
  {
    value: "06520",
    label: "Xã Y Tịch",
    parent_code: "187",
  },
  {
    value: "02701",
    label: "Xã Y Tý",
    parent_code: "082",
  },
  {
    value: "24010",
    label: "Xã Ya Hội",
    parent_code: "634",
  },
  {
    value: "23554",
    label: "Xã Ya ly",
    parent_code: "616",
  },
  {
    value: "23848",
    label: "Xã Ya Ma",
    parent_code: "630",
  },
  {
    value: "23551",
    label: "Xã Ya Tăng",
    parent_code: "616",
  },
  {
    value: "24220",
    label: "Xã Ya Tờ Mốt",
    parent_code: "646",
  },
  {
    value: "23548",
    label: "Xã Ya Xiêr",
    parent_code: "616",
  },
  {
    value: "23998",
    label: "Xã Yang Bắc",
    parent_code: "634",
  },
  {
    value: "24487",
    label: "Xã Yang Mao",
    parent_code: "653",
  },
  {
    value: "23854",
    label: "Xã Yang Nam",
    parent_code: "630",
  },
  {
    value: "24469",
    label: "Xã Yang Reh",
    parent_code: "653",
  },
  {
    value: "24583",
    label: "Xã Yang Tao",
    parent_code: "656",
  },
  {
    value: "23845",
    label: "Xã Yang Trung",
    parent_code: "630",
  },
  {
    value: "09709",
    label: "Xã Yên Bài",
    parent_code: "271",
  },
  {
    value: "13348",
    label: "Phường Yên Bắc",
    parent_code: "349",
  },
  {
    value: "13876",
    label: "Xã Yên Bằng",
    parent_code: "360",
  },
  {
    value: "04930",
    label: "Xã Yên Bình",
    parent_code: "276",
  },
  {
    value: "01237",
    label: "Thị trấn Yên Bình",
    parent_code: "035",
  },
  {
    value: "09082",
    label: "Xã Yên Bình",
    parent_code: "252",
  },
  {
    value: "06391",
    label: "Xã Yên Bình",
    parent_code: "186",
  },
  {
    value: "13825",
    label: "Xã Yên Bình",
    parent_code: "360",
  },
  {
    value: "14374",
    label: "Phường Yên Bình",
    parent_code: "370",
  },
  {
    value: "04714",
    label: "Thị trấn Yên Bình",
    parent_code: "141",
  },
  {
    value: "04774",
    label: "Xã Yên Bình",
    parent_code: "141",
  },
  {
    value: "05422",
    label: "Xã Yên Bồng",
    parent_code: "159",
  },
  {
    value: "16174",
    label: "Thị trấn Yên Cát",
    parent_code: "402",
  },
  {
    value: "04060",
    label: "Thị trấn Yên Châu",
    parent_code: "124",
  },
  {
    value: "13822",
    label: "Xã Yên Chính",
    parent_code: "360",
  },
  {
    value: "02110",
    label: "Xã Yên Cư",
    parent_code: "065",
  },
  {
    value: "01006",
    label: "Xã Yên Cường",
    parent_code: "031",
  },
  {
    value: "13870",
    label: "Xã Yên Cường",
    parent_code: "360",
  },
  {
    value: "08917",
    label: "Xã Yên Dương",
    parent_code: "248",
  },
  {
    value: "13834",
    label: "Xã Yên Dương",
    parent_code: "360",
  },
  {
    value: "15286",
    label: "Xã Yên Dương",
    parent_code: "392",
  },
  {
    value: "08422",
    label: "Xã Yên Dưỡng",
    parent_code: "235",
  },
  {
    value: "01918",
    label: "Xã Yến Dương",
    parent_code: "061",
  },
  {
    value: "00988",
    label: "Xã Yên Định",
    parent_code: "031",
  },
  {
    value: "07651",
    label: "Xã Yên Định",
    parent_code: "220",
  },
  {
    value: "14215",
    label: "Thị trấn Yên Định",
    parent_code: "366",
  },
  {
    value: "05620",
    label: "Xã Yên Đổ",
    parent_code: "168",
  },
  {
    value: "23557",
    label: "Phường Yên Đỗ",
    parent_code: "622",
  },
  {
    value: "09046",
    label: "Xã Yên Đồng",
    parent_code: "251",
  },
  {
    value: "13879",
    label: "Xã Yên Đồng",
    parent_code: "360",
  },
  {
    value: "14746",
    label: "Xã Yên Đồng",
    parent_code: "377",
  },
  {
    value: "07129",
    label: "Xã Yên Đức",
    parent_code: "205",
  },
  {
    value: "09304",
    label: "Xã Yên Giả",
    parent_code: "259",
  },
  {
    value: "07162",
    label: "Phường Yên Giang",
    parent_code: "206",
  },
  {
    value: "01249",
    label: "Xã Yên Hà",
    parent_code: "035",
  },
  {
    value: "07177",
    label: "Phường Yên Hải",
    parent_code: "206",
  },
  {
    value: "02116",
    label: "Xã Yên Hân",
    parent_code: "065",
  },
  {
    value: "02248",
    label: "Xã Yên Hoa",
    parent_code: "072",
  },
  {
    value: "00172",
    label: "Phường Yên Hoà",
    parent_code: "005",
  },
  {
    value: "12088",
    label: "Xã Yên Hòa",
    parent_code: "327",
  },
  {
    value: "14722",
    label: "Xã Yên Hòa",
    parent_code: "377",
  },
  {
    value: "04873",
    label: "Xã Yên Hòa",
    parent_code: "150",
  },
  {
    value: "16909",
    label: "Xã Yên Hòa",
    parent_code: "418",
  },
  {
    value: "18679",
    label: "Xã Yên Hòa",
    parent_code: "446",
  },
  {
    value: "18928",
    label: "Xã Yên Hóa",
    parent_code: "452",
  },
  {
    value: "18253",
    label: "Xã Yên Hồ",
    parent_code: "440",
  },
  {
    value: "13855",
    label: "Xã Yên Hồng",
    parent_code: "360",
  },
  {
    value: "04426",
    label: "Xã Yên Hợp",
    parent_code: "136",
  },
  {
    value: "17038",
    label: "Xã Yên Hợp",
    parent_code: "420",
  },
  {
    value: "15433",
    label: "Xã Yên Hùng",
    parent_code: "394",
  },
  {
    value: "13840",
    label: "Xã Yên Hưng",
    parent_code: "360",
  },
  {
    value: "14731",
    label: "Xã Yên Hưng",
    parent_code: "377",
  },
  {
    value: "04192",
    label: "Xã Yên Hưng",
    parent_code: "126",
  },
  {
    value: "13882",
    label: "Xã Yên Khang",
    parent_code: "360",
  },
  {
    value: "13843",
    label: "Xã Yên Khánh",
    parent_code: "360",
  },
  {
    value: "17257",
    label: "Xã Yên Khê",
    parent_code: "422",
  },
  {
    value: "06541",
    label: "Xã Yên Khoái",
    parent_code: "188",
  },
  {
    value: "15031",
    label: "Xã Yên Khương",
    parent_code: "388",
  },
  {
    value: "08026",
    label: "Xã Yên Kiện",
    parent_code: "230",
  },
  {
    value: "08113",
    label: "Xã Yên Kỳ",
    parent_code: "231",
  },
  {
    value: "01732",
    label: "Xã Yên Lạc",
    parent_code: "052",
  },
  {
    value: "09025",
    label: "Thị trấn Yên Lạc",
    parent_code: "251",
  },
  {
    value: "05623",
    label: "Xã Yên Lạc",
    parent_code: "168",
  },
  {
    value: "15442",
    label: "Xã Yên Lạc",
    parent_code: "394",
  },
  {
    value: "16267",
    label: "Xã Yên Lạc",
    parent_code: "403",
  },
  {
    value: "02155",
    label: "Thị trấn Yến Lạc",
    parent_code: "066",
  },
  {
    value: "08644",
    label: "Xã Yên Lãng",
    parent_code: "238",
  },
  {
    value: "05773",
    label: "Xã Yên Lãng",
    parent_code: "171",
  },
  {
    value: "14752",
    label: "Xã Yên Lâm",
    parent_code: "377",
  },
  {
    value: "15403",
    label: "Thị trấn Yên Lâm",
    parent_code: "394",
  },
  {
    value: "02386",
    label: "Xã Yên Lâm",
    parent_code: "074",
  },
  {
    value: "09091",
    label: "Xã Yên Lập",
    parent_code: "252",
  },
  {
    value: "08290",
    label: "Thị trấn Yên Lập",
    parent_code: "234",
  },
  {
    value: "02317",
    label: "Xã Yên Lập",
    parent_code: "073",
  },
  {
    value: "06082",
    label: "Xã Yên Lỗ",
    parent_code: "181",
  },
  {
    value: "13873",
    label: "Xã Yên Lộc",
    parent_code: "360",
  },
  {
    value: "14671",
    label: "Xã Yên Lộc",
    parent_code: "376",
  },
  {
    value: "13807",
    label: "Xã Yên Lợi",
    parent_code: "360",
  },
  {
    value: "08128",
    label: "Xã Yên Luật",
    parent_code: "231",
  },
  {
    value: "28669",
    label: "Xã Yên Luông",
    parent_code: "823",
  },
  {
    value: "07726",
    label: "Xã Yên Lư",
    parent_code: "221",
  },
  {
    value: "08647",
    label: "Xã Yên Lương",
    parent_code: "238",
  },
  {
    value: "13852",
    label: "Xã Yên Lương",
    parent_code: "360",
  },
  {
    value: "14743",
    label: "Xã Yên Mạc",
    parent_code: "377",
  },
  {
    value: "00820",
    label: "Thị trấn Yên Minh",
    parent_code: "028",
  },
  {
    value: "13816",
    label: "Xã Yên Minh",
    parent_code: "360",
  },
  {
    value: "04813",
    label: "Xã Yên Mông",
    parent_code: "148",
  },
  {
    value: "00661",
    label: "Xã Yên Mỹ",
    parent_code: "020",
  },
  {
    value: "12052",
    label: "Thị trấn Yên Mỹ",
    parent_code: "327",
  },
  {
    value: "07414",
    label: "Xã Yên Mỹ",
    parent_code: "217",
  },
  {
    value: "13831",
    label: "Xã Yên Mỹ",
    parent_code: "360",
  },
  {
    value: "14740",
    label: "Xã Yên Mỹ",
    parent_code: "377",
  },
  {
    value: "02077",
    label: "Xã Yên Mỹ",
    parent_code: "064",
  },
  {
    value: "16375",
    label: "Xã Yên Mỹ",
    parent_code: "404",
  },
  {
    value: "16912",
    label: "Xã Yên Na",
    parent_code: "418",
  },
  {
    value: "13360",
    label: "Xã Yên Nam",
    parent_code: "349",
  },
  {
    value: "09562",
    label: "Phường Yên Nghĩa",
    parent_code: "268",
  },
  {
    value: "13813",
    label: "Xã Yên Nghĩa",
    parent_code: "360",
  },
  {
    value: "05341",
    label: "Xã Yên Nghiệp",
    parent_code: "157",
  },
  {
    value: "02365",
    label: "Xã Yên Nguyên",
    parent_code: "073",
  },
  {
    value: "13885",
    label: "Xã Yên Nhân",
    parent_code: "360",
  },
  {
    value: "14737",
    label: "Xã Yên Nhân",
    parent_code: "377",
  },
  {
    value: "15610",
    label: "Xã Yên Nhân",
    parent_code: "396",
  },
  {
    value: "05614",
    label: "Xã Yên Ninh",
    parent_code: "168",
  },
  {
    value: "13849",
    label: "Xã Yên Ninh",
    parent_code: "360",
  },
  {
    value: "14560",
    label: "Thị trấn Yên Ninh",
    parent_code: "375",
  },
  {
    value: "15439",
    label: "Xã Yên Ninh",
    parent_code: "394",
  },
  {
    value: "04252",
    label: "Phường Yên Ninh",
    parent_code: "132",
  },
  {
    value: "00997",
    label: "Xã Yên Phong",
    parent_code: "031",
  },
  {
    value: "13846",
    label: "Xã Yên Phong",
    parent_code: "360",
  },
  {
    value: "14719",
    label: "Xã Yên Phong",
    parent_code: "377",
  },
  {
    value: "15427",
    label: "Xã Yên Phong",
    parent_code: "394",
  },
  {
    value: "02083",
    label: "Xã Yên Phong",
    parent_code: "064",
  },
  {
    value: "00991",
    label: "Thị trấn Yên Phú",
    parent_code: "031",
  },
  {
    value: "12079",
    label: "Xã Yên Phú",
    parent_code: "327",
  },
  {
    value: "05305",
    label: "Xã Yên Phú",
    parent_code: "157",
  },
  {
    value: "13828",
    label: "Xã Yên Phú",
    parent_code: "360",
  },
  {
    value: "15409",
    label: "Xã Yên Phú",
    parent_code: "394",
  },
  {
    value: "02398",
    label: "Xã Yên Phú",
    parent_code: "074",
  },
  {
    value: "04438",
    label: "Xã Yên Phú",
    parent_code: "136",
  },
  {
    value: "00106",
    label: "Phường Yên Phụ",
    parent_code: "003",
  },
  {
    value: "09220",
    label: "Xã Yên Phụ",
    parent_code: "258",
  },
  {
    value: "06319",
    label: "Xã Yên Phúc",
    parent_code: "184",
  },
  {
    value: "13867",
    label: "Xã Yên Phúc",
    parent_code: "360",
  },
  {
    value: "09055",
    label: "Xã Yên Phương",
    parent_code: "251",
  },
  {
    value: "13819",
    label: "Xã Yên Phương",
    parent_code: "360",
  },
  {
    value: "13858",
    label: "Xã Yên Quang",
    parent_code: "360",
  },
  {
    value: "14419",
    label: "Xã Yên Quang",
    parent_code: "372",
  },
  {
    value: "00340",
    label: "Phường Yên Sở",
    parent_code: "008",
  },
  {
    value: "09856",
    label: "Xã Yên Sở",
    parent_code: "274",
  },
  {
    value: "09904",
    label: "Xã Yên Sơn",
    parent_code: "275",
  },
  {
    value: "01381",
    label: "Xã Yên Sơn",
    parent_code: "045",
  },
  {
    value: "08656",
    label: "Xã Yên Sơn",
    parent_code: "238",
  },
  {
    value: "06403",
    label: "Xã Yên Sơn",
    parent_code: "186",
  },
  {
    value: "07498",
    label: "Xã Yên Sơn",
    parent_code: "218",
  },
  {
    value: "14371",
    label: "Xã Yên Sơn",
    parent_code: "370",
  },
  {
    value: "02473",
    label: "Thị trấn Yên Sơn",
    parent_code: "075",
  },
  {
    value: "02986",
    label: "Xã Yên Sơn",
    parent_code: "087",
  },
  {
    value: "04087",
    label: "Xã Yên Sơn",
    parent_code: "124",
  },
  {
    value: "17662",
    label: "Xã Yên Sơn",
    parent_code: "427",
  },
  {
    value: "15307",
    label: "Xã Yến Sơn",
    parent_code: "392",
  },
  {
    value: "15406",
    label: "Xã Yên Tâm",
    parent_code: "394",
  },
  {
    value: "13804",
    label: "Xã Yên Tân",
    parent_code: "360",
  },
  {
    value: "08398",
    label: "Xã Yên Tập",
    parent_code: "235",
  },
  {
    value: "08830",
    label: "Xã Yên Thạch",
    parent_code: "253",
  },
  {
    value: "14749",
    label: "Xã Yên Thái",
    parent_code: "377",
  },
  {
    value: "15430",
    label: "Xã Yên Thái",
    parent_code: "394",
  },
  {
    value: "04420",
    label: "Xã Yên Thái",
    parent_code: "136",
  },
  {
    value: "06880",
    label: "Xã Yên Than",
    parent_code: "199",
  },
  {
    value: "06826",
    label: "Phường Yên Thanh",
    parent_code: "196",
  },
  {
    value: "01234",
    label: "Xã Yên Thành",
    parent_code: "035",
  },
  {
    value: "13801",
    label: "Xã Yên Thành",
    parent_code: "360",
  },
  {
    value: "14734",
    label: "Xã Yên Thành",
    parent_code: "377",
  },
  {
    value: "04753",
    label: "Xã Yên Thành",
    parent_code: "141",
  },
  {
    value: "17506",
    label: "Thị trấn Yên Thành",
    parent_code: "426",
  },
  {
    value: "13864",
    label: "Xã Yên Thắng",
    parent_code: "360",
  },
  {
    value: "14725",
    label: "Xã Yên Thắng",
    parent_code: "377",
  },
  {
    value: "15034",
    label: "Xã Yên Thắng",
    parent_code: "388",
  },
  {
    value: "04339",
    label: "Xã Yên Thắng",
    parent_code: "135",
  },
  {
    value: "16930",
    label: "Xã Yên Thắng",
    parent_code: "418",
  },
  {
    value: "04303",
    label: "Thị trấn Yên Thế",
    parent_code: "135",
  },
  {
    value: "23584",
    label: "Phường Yên Thế",
    parent_code: "622",
  },
  {
    value: "02044",
    label: "Xã Yên Thịnh",
    parent_code: "064",
  },
  {
    value: "06400",
    label: "Xã Yên Thịnh",
    parent_code: "186",
  },
  {
    value: "14701",
    label: "Thị trấn Yên Thịnh",
    parent_code: "377",
  },
  {
    value: "15436",
    label: "Xã Yên Thịnh",
    parent_code: "394",
  },
  {
    value: "04249",
    label: "Phường Yên Thịnh",
    parent_code: "132",
  },
  {
    value: "07117",
    label: "Phường Yên Thọ",
    parent_code: "205",
  },
  {
    value: "13810",
    label: "Xã Yên Thọ",
    parent_code: "360",
  },
  {
    value: "15415",
    label: "Xã Yên Thọ",
    parent_code: "394",
  },
  {
    value: "16264",
    label: "Xã Yên Thọ",
    parent_code: "403",
  },
  {
    value: "01318",
    label: "Xã Yên Thổ",
    parent_code: "042",
  },
  {
    value: "02377",
    label: "Xã Yên Thuận",
    parent_code: "074",
  },
  {
    value: "00529",
    label: "Xã Yên Thường",
    parent_code: "018",
  },
  {
    value: "02047",
    label: "Xã Yên Thượng",
    parent_code: "064",
  },
  {
    value: "13861",
    label: "Xã Yên Tiến",
    parent_code: "360",
  },
  {
    value: "16900",
    label: "Xã Yên Tĩnh",
    parent_code: "418",
  },
  {
    value: "05617",
    label: "Xã Yên Trạch",
    parent_code: "168",
  },
  {
    value: "06247",
    label: "Xã Yên Trạch",
    parent_code: "183",
  },
  {
    value: "05386",
    label: "Xã Yên Trị",
    parent_code: "158",
  },
  {
    value: "13888",
    label: "Xã Yên Trị",
    parent_code: "360",
  },
  {
    value: "04927",
    label: "Xã Yên Trung",
    parent_code: "276",
  },
  {
    value: "09205",
    label: "Xã Yên Trung",
    parent_code: "258",
  },
  {
    value: "13798",
    label: "Xã Yên Trung",
    parent_code: "360",
  },
  {
    value: "15418",
    label: "Xã Yên Trung",
    parent_code: "394",
  },
  {
    value: "15421",
    label: "Xã Yên Trường",
    parent_code: "394",
  },
  {
    value: "14728",
    label: "Xã Yên Từ",
    parent_code: "377",
  },
  {
    value: "00526",
    label: "Thị trấn Yên Viên",
    parent_code: "018",
  },
  {
    value: "00532",
    label: "Xã Yên Viên",
    parent_code: "018",
  },
  {
    value: "06412",
    label: "Xã Yên Vượng",
    parent_code: "186",
  },
  {
    value: "09547",
    label: "Phường Yết Kiêu",
    parent_code: "268",
  },
  {
    value: "11020",
    label: "Xã Yết Kiêu",
    parent_code: "297",
  },
  {
    value: "06682",
    label: "Phường Yết Kiêu",
    parent_code: "193",
  },
  {
    value: "20491",
    label: "Xã Za Hung",
    parent_code: "505",
  },
  {
    value: "20701",
    label: "Xã Zuôich",
    parent_code: "510",
  },
];

export default WARDS;
